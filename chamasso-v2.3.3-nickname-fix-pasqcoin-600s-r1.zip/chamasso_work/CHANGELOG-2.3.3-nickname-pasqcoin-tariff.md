# Chamasso v2.3.3 — Nickname + tarifa PASQcoin

- Corrigido o travamento ao salvar nickname escolhido após o cadastro comum.
- Causa corrigida: o modal devolvia um objeto `User`, enquanto `App.tsx` o tratava como string de nickname, podendo inserir um objeto no campo `nickname` e quebrar a renderização.
- Nova tarifa inicial: **1 PASQcoin = 600 segundos (10 minutos)**.
- Novo valor inicial: **1 PASQcoin = R$ 1,00**.
- A promoção de 60 minutos continua concedendo exatamente 60 minutos; com esta tarifa, corresponde a **6 PASQcoin**.
- Migração automática da tarifa padrão antiga `60 s / R$ 0,01` para `600 s / R$ 1,00`; tarifas administrativas personalizadas são preservadas.
