import React, { useState } from 'react';
import {
  SystemExecutionResult,
  GodOutput,
  ContradictionNode,
  ARESAttack,
  EpistemicType,
} from '../types';
import {
  ShieldCheck,
  AlertTriangle,
  Skull,
  Swords,
  Scale,
  Crown,
  CheckCircle2,
  HelpCircle,
  BookOpen,
  FileText,
  Zap,
} from 'lucide-react';

interface ReasoningDashboardProps {
  result: SystemExecutionResult;
  onGenerateEbook: () => void;
}

const EPISTEMIC_COLORS: Record<EpistemicType, string> = {
  FACT: 'bg-[#111111] text-[#00FF41] border-[#00FF41]',
  INFERENCE: 'bg-[#111111] text-[#3B82F6] border-[#3B82F6]',
  FICTION: 'bg-[#111111] text-[#EC4899] border-[#EC4899]',
  HYPOTHESIS: 'bg-[#111111] text-[#A855F7] border-[#A855F7]',
  COUNTERFACTUAL: 'bg-[#111111] text-[#FF3E00] border-[#FF3E00]',
};

export const ReasoningDashboard: React.FC<ReasoningDashboardProps> = ({
  result,
  onGenerateEbook,
}) => {
  const [selectedGodTab, setSelectedGodTab] = useState<string>(result.godOutputs[0]?.god_id || 'ZEUS');

  const { mvedScores, zeusDecision, hadesRisk, aresAttacks, contradictions, godOutputs } = result;

  return (
    <div className="space-y-6">
      {/* 1. ZEUS Executive Decision & Status Banner */}
      <div className="bg-[#0F0F0F] border-2 border-[#FF3E00] border-l-8 p-5 sm:p-6 text-[#E0E0E0] shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#222222] pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-[#111111] border border-[#FF3E00] text-[#FF3E00]">
              <Crown className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-black text-white tracking-tight uppercase">
                  Arbitragem Executiva ZEUS
                </h3>
                <span className="text-[10px] font-mono font-bold tracking-widest px-2.5 py-0.5 uppercase bg-[#1A1A1A] text-[#00FF41] border border-[#333333]">
                  Estado: {zeusDecision.decision_state}
                </span>
              </div>
              <p className="text-xs text-[#888888] font-mono">
                Resolução integrada sem falsificação de fatos • {zeusDecision.dissents.length} dissidências registradas
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="text-right font-mono">
              <span className="text-[9px] uppercase font-bold text-[#666666] block tracking-widest">
                MVED 2.0 Score
              </span>
              <span className="text-xl font-black text-[#FF3E00]">
                {mvedScores.compositeMVED.toFixed(3)}
              </span>
            </div>
            <button
              id="btn-trigger-generate-ebook"
              onClick={onGenerateEbook}
              className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black uppercase px-4 py-2.5 transition-all text-xs sm:text-sm flex items-center space-x-2 tracking-wider font-mono"
            >
              <BookOpen className="w-4 h-4" />
              <span>Gerar E-Book Sob Medida</span>
            </button>
          </div>
        </div>

        {/* Primary Decision Text */}
        <div className="mt-4 bg-[#0A0A0A] p-4 border border-[#222222] space-y-2">
          <p className="text-sm font-medium text-white leading-relaxed">
            {zeusDecision.primary_decision}
          </p>
          <p className="text-xs text-[#888888] font-mono border-t border-[#222222] pt-2">
            <strong className="text-white">Fundamentação:</strong> {zeusDecision.reasoning}
          </p>
        </div>

        {/* Epistemic Breakdown Badges */}
        <div className="mt-4 flex flex-wrap gap-2 items-center text-xs font-mono">
          <span className="text-[#888888] font-bold mr-1">Classificação Epistemológica:</span>
          {Object.entries(zeusDecision.epistemic_breakdown).map(([type, count]) => (
            <span
              key={type}
              className={`px-2 py-0.5 font-bold border text-[10px] uppercase ${EPISTEMIC_COLORS[type as EpistemicType]}`}
            >
              {type}: {count}
            </span>
          ))}
        </div>
      </div>

      {/* 2. MVED 2.0 Multi-Vector Evidence Decision Engine Matrix */}
      <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#FF3E00] p-5 sm:p-6 text-[#E0E0E0] space-y-4">
        <div className="flex items-center justify-between border-b border-[#222222] pb-3">
          <div className="flex items-center space-x-2">
            <Scale className="w-5 h-5 text-[#FF3E00]" />
            <h3 className="text-sm sm:text-base font-black text-white tracking-tight uppercase">
              MVED 2.0 — Multi-Vector Evidence Decision Engine
            </h3>
          </div>
          <span className="text-xs font-mono text-[#666666]">
            Fórmula: w1M1 + w2M2 + w3M3 + w4M4 + w5M5
          </span>
        </div>

        {/* 5 Vectors Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs font-mono">
          <div className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1">
            <div className="flex justify-between text-[10px] text-[#888888]">
              <span>M1: Evidência (30%)</span>
              <span className="text-[#FF3E00] font-bold">{mvedScores.evidenceScore}</span>
            </div>
            <div className="w-full bg-[#1A1A1A] h-1 overflow-hidden">
              <div
                className="bg-[#FF3E00] h-full"
                style={{ width: `${mvedScores.evidenceScore * 100}%` }}
              />
            </div>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1">
            <div className="flex justify-between text-[10px] text-[#888888]">
              <span>M2: Lógica (25%)</span>
              <span className="text-[#FF3E00] font-bold">{mvedScores.logicScore}</span>
            </div>
            <div className="w-full bg-[#1A1A1A] h-1 overflow-hidden">
              <div
                className="bg-[#3B82F6] h-full"
                style={{ width: `${mvedScores.logicScore * 100}%` }}
              />
            </div>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1">
            <div className="flex justify-between text-[10px] text-[#888888]">
              <span>M3: Relevância (20%)</span>
              <span className="text-[#FF3E00] font-bold">{mvedScores.relevanceScore}</span>
            </div>
            <div className="w-full bg-[#1A1A1A] h-1 overflow-hidden">
              <div
                className="bg-[#00FF41] h-full"
                style={{ width: `${mvedScores.relevanceScore * 100}%` }}
              />
            </div>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1">
            <div className="flex justify-between text-[10px] text-[#888888]">
              <span>M4: Risco (15%)</span>
              <span className="text-[#FF3E00] font-bold">{mvedScores.riskScore}</span>
            </div>
            <div className="w-full bg-[#1A1A1A] h-1 overflow-hidden">
              <div
                className="bg-[#A855F7] h-full"
                style={{ width: `${mvedScores.riskScore * 100}%` }}
              />
            </div>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1">
            <div className="flex justify-between text-[10px] text-[#888888]">
              <span>M5: Consenso (10%)</span>
              <span className="text-[#FF3E00] font-bold">{mvedScores.consensusScore}</span>
            </div>
            <div className="w-full bg-[#1A1A1A] h-1 overflow-hidden">
              <div
                className="bg-[#14B8A6] h-full"
                style={{ width: `${mvedScores.consensusScore * 100}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 3. ARES Adversarial & HADES Risk Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ARES Engine */}
        <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#FF3E00] p-5 text-[#E0E0E0] space-y-3">
          <div className="flex items-center space-x-2 border-b border-[#222222] pb-3">
            <Swords className="w-5 h-5 text-[#FF3E00]" />
            <h3 className="font-black text-white text-sm sm:text-base uppercase tracking-tight">
              ARES — Motor de Refutação Adversarial
            </h3>
          </div>

          <div className="space-y-2 text-xs">
            {aresAttacks.map((attack, idx) => (
              <div key={idx} className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1 font-mono">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#FF3E00]">Atacando {attack.god_id}</span>
                  <span className="px-1.5 py-0.5 text-[9px] font-bold bg-[#111111] text-[#FF3E00] border border-[#FF3E00]">
                    Severidade: {attack.severity}
                  </span>
                </div>
                <p className="text-white font-medium">{attack.attack}</p>
                <p className="text-[10px] text-[#888888]">
                  <strong className="text-white">Contra-exemplo:</strong> {attack.counterexample}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* HADES Engine */}
        <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#A855F7] p-5 text-[#E0E0E0] space-y-3">
          <div className="flex items-center space-x-2 border-b border-[#222222] pb-3">
            <Skull className="w-5 h-5 text-[#A855F7]" />
            <h3 className="font-black text-white text-sm sm:text-base uppercase tracking-tight">
              HADES — Auditoria de Risco & Omissões
            </h3>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222] text-xs font-mono space-y-2">
            <div className="flex justify-between items-center border-b border-[#222222] pb-2">
              <span className="text-[#888888] font-bold">Risk Score Estimado</span>
              <span className="text-[#A855F7] font-bold">{hadesRisk.risk_score}</span>
            </div>

            <div>
              <span className="text-[#888888] font-bold block mb-1">Dados Ausentes / Omissões:</span>
              <ul className="list-disc list-inside text-white space-y-0.5">
                {hadesRisk.missing_data.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>

            <div>
              <span className="text-[#888888] font-bold block mb-1">Riscos de Fonte & Viés:</span>
              <ul className="list-disc list-inside text-white space-y-0.5">
                {hadesRisk.biases.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Parallel Specialist Outputs Tabs */}
      <div className="bg-[#0F0F0F] border border-[#222222] p-5 sm:p-6 text-[#E0E0E0] space-y-4">
        <h3 className="font-black text-white text-sm sm:text-base border-b border-[#222222] pb-3 uppercase tracking-tight">
          Respostas Paralelas dos Especialistas Selecionados
        </h3>

        {/* God Tabs */}
        <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-none">
          {godOutputs.map(out => (
            <button
              key={out.god_id}
              onClick={() => setSelectedGodTab(out.god_id)}
              className={`px-3.5 py-1.5 text-xs font-mono font-bold uppercase transition-all border whitespace-nowrap ${
                selectedGodTab === out.god_id
                  ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                  : 'bg-[#0A0A0A] border-[#222222] text-[#888888] hover:text-white'
              }`}
            >
              {out.god_id}
            </button>
          ))}
        </div>

        {/* Selected God Output Content */}
        {godOutputs
          .filter(out => out.god_id === selectedGodTab)
          .map(out => (
            <div key={out.god_id} className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-3 text-xs font-mono">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-white text-sm">{out.god_id} Output</span>
                  <span className={`px-2 py-0.5 font-bold border text-[9px] uppercase ${EPISTEMIC_COLORS[out.epistemic_type]}`}>
                    {out.epistemic_type}
                  </span>
                </div>
                <span className="text-[#888888]">Confiança: {(out.confidence * 100).toFixed(0)}%</span>
              </div>

              <div>
                <strong className="text-[#FF3E00] block mb-0.5">Afirmação Principal:</strong>
                <p className="text-white font-medium">{out.claim}</p>
              </div>

              <div>
                <strong className="text-[#888888] block mb-0.5">Resumo do Raciocínio:</strong>
                <p className="text-[#CCCCCC]">{out.reasoning_summary}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-[#222222]">
                <div>
                  <strong className="text-[#888888] block mb-1">Evidências Citadas:</strong>
                  <ul className="list-disc list-inside text-white space-y-0.5">
                    {out.evidence.map((ev, i) => (
                      <li key={i}>{ev}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <strong className="text-[#888888] block mb-1">Incertezas & Contrapontos:</strong>
                  <ul className="list-disc list-inside text-[#888888] space-y-0.5">
                    {out.uncertainties.map((unc, i) => (
                      <li key={i}>{unc}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};
