import React, { useState, useEffect } from 'react';
import { EbookManuscript, EbookChapter, ReaderSettings, ClaimWithEpistemology, EpistemicType } from '../types';
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Settings,
  Bookmark,
  Highlighter,
  MessageSquare,
  Eye,
  CheckCircle,
  Share2,
  Download,
  List,
  Maximize2,
  Sun,
  Moon,
  Compass,
} from 'lucide-react';

interface EbookReaderProps {
  manuscript: EbookManuscript;
  onClose: () => void;
}

const EPISTEMIC_BADGES: Record<EpistemicType, string> = {
  FACT: 'bg-[#111111] text-[#00FF41] border-[#00FF41]',
  INFERENCE: 'bg-[#111111] text-[#3B82F6] border-[#3B82F6]',
  FICTION: 'bg-[#111111] text-[#EC4899] border-[#EC4899]',
  HYPOTHESIS: 'bg-[#111111] text-[#A855F7] border-[#A855F7]',
  COUNTERFACTUAL: 'bg-[#111111] text-[#FF3E00] border-[#FF3E00]',
};

export const EbookReader: React.FC<EbookReaderProps> = ({ manuscript, onClose }) => {
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [showToc, setShowToc] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showEvidenceMode, setShowEvidenceMode] = useState(true);
  const [selectedClaim, setSelectedClaim] = useState<ClaimWithEpistemology | null>(null);

  const [settings, setSettings] = useState<ReaderSettings>({
    fontSize: 16,
    fontFamily: 'sans',
    theme: 'dark',
    lineSpacing: 1.6,
    maxWidth: 800,
    showEpistemicLabels: true,
    showEvidenceDetails: true,
  });

  const [bookmarks, setBookmarks] = useState<number[]>([]);
  const [notes, setNotes] = useState<{ chapterIndex: number; note: string }[]>([]);
  const [newNoteText, setNewNoteText] = useState('');

  const currentChapter: EbookChapter = manuscript.chapters[currentChapterIndex] || manuscript.chapters[0];
  const progressPercent = Math.round(((currentChapterIndex + 1) / manuscript.chapters.length) * 100);

  const handleBookmarkToggle = () => {
    if (bookmarks.includes(currentChapterIndex)) {
      setBookmarks(bookmarks.filter(b => b !== currentChapterIndex));
    } else {
      setBookmarks([...bookmarks, currentChapterIndex]);
    }
  };

  const handleAddNote = () => {
    if (!newNoteText.trim()) return;
    setNotes([...notes, { chapterIndex: currentChapterIndex, note: newNoteText }]);
    setNewNoteText('');
  };

  const themeClasses = {
    dark: 'bg-[#0A0A0A] text-[#E0E0E0] border-[#222222]',
    light: 'bg-[#F5F5F0] text-[#111111] border-[#CCCCCC]',
    sepia: 'bg-[#1A1815] text-[#D8C7A5] border-[#3A3225]',
  }[settings.theme];

  const fontClasses = {
    sans: 'font-sans',
    serif: 'font-serif',
    mono: 'font-mono',
  }[settings.fontFamily];

  return (
    <div className={`fixed inset-0 z-50 flex flex-col ${themeClasses} transition-colors duration-300`}>
      {/* 1. Reader Header */}
      <div className="h-14 border-b flex items-center justify-between px-4 sm:px-6 bg-[#0D0D0D] border-[#222222] select-none font-mono">
        <div className="flex items-center space-x-3">
          <button
            id="btn-close-reader"
            onClick={onClose}
            className="px-2.5 py-1 bg-[#151515] text-white border border-[#333333] hover:border-[#FF3E00] transition-all flex items-center space-x-1 text-xs font-bold uppercase"
          >
            <ChevronLeft className="w-4 h-4 text-[#FF3E00]" />
            <span>Voltar</span>
          </button>

          <button
            id="btn-toggle-toc"
            onClick={() => setShowToc(!showToc)}
            className="px-2.5 py-1 bg-[#151515] text-[#888888] hover:text-white border border-[#222222] transition-all flex items-center space-x-1 text-xs font-bold uppercase"
          >
            <List className="w-4 h-4" />
            <span className="hidden sm:inline">Sumário</span>
          </button>

          <span className="text-xs font-bold truncate max-w-xs sm:max-w-md hidden md:inline text-white">
            {manuscript.title}
          </span>
        </div>

        {/* Center Reading Progress */}
        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-[#00FF41] font-bold">{progressPercent}% Lido</span>
          <div className="w-24 bg-[#111111] border border-[#222222] h-2 overflow-hidden hidden sm:block">
            <div className="bg-[#FF3E00] h-full" style={{ width: `${progressPercent}%` }} />
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center space-x-2">
          <button
            id="btn-toggle-evidence-mode"
            onClick={() => setShowEvidenceMode(!showEvidenceMode)}
            className={`px-2.5 py-1 text-xs font-mono font-bold uppercase flex items-center space-x-1.5 transition-all border ${
              showEvidenceMode ? 'bg-[#FF3E00] text-black border-[#FF3E00]' : 'bg-[#151515] text-[#888888] border-[#222222]'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Modo Evidências</span>
          </button>

          <button
            id="btn-toggle-bookmark"
            onClick={handleBookmarkToggle}
            className={`p-1.5 bg-[#151515] border border-[#222222] transition-all ${
              bookmarks.includes(currentChapterIndex) ? 'text-[#FF3E00] border-[#FF3E00]' : 'text-[#888888]'
            }`}
          >
            <Bookmark className="w-4 h-4" />
          </button>

          <button
            id="btn-toggle-reader-settings"
            onClick={() => setShowSettings(!showSettings)}
            className="p-1.5 bg-[#151515] text-[#888888] border border-[#222222] hover:text-white transition-all"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Main Reader Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* TOC Sidebar */}
        {showToc && (
          <div className="w-64 sm:w-80 border-r border-[#222222] flex flex-col bg-[#0D0D0D] p-4 space-y-3 overflow-y-auto shrink-0 select-none font-mono">
            <h4 className="text-xs font-black uppercase tracking-wider flex items-center space-x-2 text-white">
              <BookOpen className="w-4 h-4 text-[#FF3E00]" />
              <span>Sumário do E-Book</span>
            </h4>

            <div className="space-y-1 text-xs">
              {manuscript.chapters.map((ch, idx) => (
                <button
                  key={ch.chapter_id}
                  onClick={() => {
                    setCurrentChapterIndex(idx);
                    setShowToc(false);
                  }}
                  className={`w-full text-left p-2.5 transition-all flex items-start justify-between space-x-2 border ${
                    currentChapterIndex === idx
                      ? 'bg-[#FF3E00] text-black font-bold border-[#FF3E00]'
                      : 'bg-[#0A0A0A] border-[#222222] text-[#888888] hover:text-white'
                  }`}
                >
                  <span className="line-clamp-2">{ch.title}</span>
                  {bookmarks.includes(idx) && <Bookmark className="w-3.5 h-3.5 shrink-0 text-black" />}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Reader Settings Drawer */}
        {showSettings && (
          <div className="absolute right-4 top-4 z-20 w-72 p-4 border bg-[#0F0F0F] text-[#E0E0E0] border-[#FF3E00] space-y-4 text-xs font-mono">
            <h4 className="font-black text-white border-b border-[#222222] pb-2 uppercase">Configurações de Leitura</h4>

            <div>
              <label className="block text-[#888888] mb-1 uppercase">Tema Visual</label>
              <div className="grid grid-cols-3 gap-2">
                {(['dark', 'light', 'sepia'] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => setSettings({ ...settings, theme: t })}
                    className={`py-1.5 font-bold uppercase border ${
                      settings.theme === t ? 'border-[#FF3E00] text-[#FF3E00] bg-[#111111]' : 'border-[#222222] text-[#888888]'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[#888888] mb-1 uppercase">Tipografia</label>
              <div className="grid grid-cols-3 gap-2">
                {(['sans', 'serif', 'mono'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setSettings({ ...settings, fontFamily: f })}
                    className={`py-1.5 font-bold uppercase border ${
                      settings.fontFamily === f ? 'border-[#FF3E00] text-[#FF3E00] bg-[#111111]' : 'border-[#222222] text-[#888888]'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#888888] mb-1">
                <span>Tamanho da Fonte</span>
                <span className="font-bold text-[#FF3E00]">{settings.fontSize}px</span>
              </div>
              <input
                type="range"
                min="13"
                max="24"
                value={settings.fontSize}
                onChange={e => setSettings({ ...settings, fontSize: parseInt(e.target.value, 10) })}
                className="w-full accent-[#FF3E00]"
              />
            </div>
          </div>
        )}

        {/* Reading Canvas */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-8 flex justify-center">
          <div
            className={`w-full ${fontClasses} space-y-6 transition-all`}
            style={{
              maxWidth: `${settings.maxWidth}px`,
              fontSize: `${settings.fontSize}px`,
              lineHeight: settings.lineSpacing,
            }}
          >
            {/* Chapter Header */}
            <div className="border-b border-[#222222] pb-4 space-y-2">
              <span className="text-xs font-mono font-bold uppercase text-[#FF3E00] tracking-widest">
                Capítulo {currentChapter.chapter_number}
              </span>
              <h1 className="text-xl sm:text-2xl font-black leading-tight uppercase tracking-tight">{currentChapter.title}</h1>
              <p className="text-xs text-opacity-70 italic font-mono">{currentChapter.objective}</p>
            </div>

            {/* Chapter Claims & Epistemic Badges (Evidence Viewer Mode) */}
            {showEvidenceMode && currentChapter.claims && currentChapter.claims.length > 0 && (
              <div className="p-4 border border-[#222222] bg-[#0F0F0F] space-y-3 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#FF3E00] flex items-center space-x-1.5 uppercase">
                    <Eye className="w-4 h-4 text-[#FF3E00]" />
                    <span>Matriz de Fatos & Evidências (Modo Auditoria)</span>
                  </span>
                  <span className="text-[10px] text-[#888888]">Clique para inspecionar fontes</span>
                </div>

                <div className="space-y-2">
                  {currentChapter.claims.map(claim => (
                    <div
                      key={claim.id}
                      onClick={() => setSelectedClaim(claim)}
                      className="p-2.5 border border-[#222222] hover:border-[#FF3E00] cursor-pointer transition-all space-y-1 bg-[#0A0A0A]"
                    >
                      <div className="flex items-center justify-between">
                        <span className={`px-2 py-0.5 font-bold text-[9px] border uppercase ${EPISTEMIC_BADGES[claim.epistemicType]}`}>
                          [{claim.epistemicType}]
                        </span>
                        <span className="text-[10px] font-mono text-[#00FF41]">
                          Evidência: {(claim.evidenceScore * 100).toFixed(0)}%
                        </span>
                      </div>
                      <p className="font-medium text-white">{claim.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Main Text Markdown Rendering */}
            <div className="space-y-4 leading-relaxed whitespace-pre-line text-opacity-90">
              {currentChapter.content}
            </div>

            {/* Selected Claim Evidence Inspector Detail Modal */}
            {selectedClaim && (
              <div className="p-4 border-2 border-[#FF3E00] bg-[#0A0A0A] text-xs font-mono space-y-2 mt-4">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#FF3E00] uppercase">Inspeção Detalhada de Fonte</span>
                  <button onClick={() => setSelectedClaim(null)} className="text-[#FF3E00] font-bold uppercase underline">
                    Fechar
                  </button>
                </div>
                <p className="font-bold text-white">{selectedClaim.text}</p>
                <div className="grid grid-cols-2 gap-2 text-[10px] text-[#888888] pt-1 border-t border-[#222222]">
                  <span>Fonte: {selectedClaim.source}</span>
                  <span>Confiança: {(selectedClaim.confidence * 100).toFixed(0)}%</span>
                </div>
                <p className="text-[11px] text-[#CCCCCC] italic">{selectedClaim.explanation}</p>
              </div>
            )}

            {/* Navigation Footer */}
            <div className="flex items-center justify-between pt-8 border-t border-[#222222] space-x-4 font-mono">
              <button
                id="btn-prev-chapter"
                disabled={currentChapterIndex === 0}
                onClick={() => setCurrentChapterIndex(currentChapterIndex - 1)}
                className="px-4 py-2 bg-[#151515] border border-[#222222] font-bold text-xs uppercase flex items-center space-x-2 disabled:opacity-30 hover:border-[#FF3E00]"
              >
                <ChevronLeft className="w-4 h-4 text-[#FF3E00]" />
                <span>Capítulo Anterior</span>
              </button>

              <span className="text-xs font-mono text-[#888888]">
                {currentChapterIndex + 1} de {manuscript.chapters.length}
              </span>

              <button
                id="btn-next-chapter"
                disabled={currentChapterIndex === manuscript.chapters.length - 1}
                onClick={() => setCurrentChapterIndex(currentChapterIndex + 1)}
                className="px-4 py-2 bg-[#151515] border border-[#222222] font-bold text-xs uppercase flex items-center space-x-2 disabled:opacity-30 hover:border-[#FF3E00]"
              >
                <span>Próximo Capítulo</span>
                <ChevronRight className="w-4 h-4 text-[#FF3E00]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
