const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

for (let i = 1138; i < 1145; i++) console.log(i+1, lines[i]);

let b = fs.readFileSync('src/lib/backup.ts', 'utf8').split('\n');
for (let i = 15; i < 25; i++) console.log(i+1, b[i]);
