import React, { useState, useEffect } from 'react';
import { User as UserIcon, Check, Trash2, ShieldCheck, Clock, Sparkles, AlertCircle, X } from 'lucide-react';
import type { User } from '../types.ts';
import { validateNicknameFormat, NICKNAME_MAX_LENGTH } from '../utils/nickname.ts';

interface NicknameModalProps {
  currentUser: User;
  isOpen: boolean;
  onClose: () => void;
  onNicknameUpdated: (updatedUser: User) => void;
}

export const NicknameModal: React.FC<NicknameModalProps> = ({
  currentUser,
  isOpen,
  onClose,
  onNicknameUpdated,
}) => {
  const [nicknameInput, setNicknameInput] = useState(currentUser.nickname || '');
  const [nicknameType, setNicknameType] = useState<'temporary' | 'permanent'>(
    currentUser.nicknameType || 'permanent'
  );
  const [isChecking, setIsChecking] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setNicknameInput(currentUser.nickname || '');
      setNicknameType(currentUser.nicknameType || 'permanent');
      setStatusMessage(null);
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  const handleCheckAvailability = async () => {
    const trimmed = nicknameInput.trim();
    if (!trimmed) {
      setStatusMessage({ type: 'error', text: 'Digite um nickname para verificar.' });
      return;
    }

    const validation = validateNicknameFormat(trimmed);
    if (!validation.isValid) {
      setStatusMessage({ type: 'error', text: validation.error || 'Nickname inválido.' });
      return;
    }

    setIsChecking(true);
    setStatusMessage(null);
    try {
      const res = await fetch(
        `/api/user/nickname-check?nickname=${encodeURIComponent(trimmed)}&userId=${encodeURIComponent(currentUser.id)}`
      );
      const data = await res.json();
      if (data.available) {
        setStatusMessage({ type: 'success', text: `O nickname "${trimmed}" está livre e disponível!` });
      } else {
        setStatusMessage({ type: 'error', text: data.error || 'Nickname indisponível.' });
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'Erro ao verificar disponibilidade.' });
    } finally {
      setIsChecking(false);
    }
  };

  const handleSaveNickname = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = nicknameInput.trim();
    if (!trimmed) {
      setStatusMessage({ type: 'error', text: 'Informe um nickname.' });
      return;
    }

    const validation = validateNicknameFormat(trimmed);
    if (!validation.isValid) {
      setStatusMessage({ type: 'error', text: validation.error || 'Nickname inválido.' });
      return;
    }

    setIsSaving(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/user/nickname', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          nickname: trimmed,
          type: nicknameType,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Erro ao salvar nickname.' });
        return;
      }

      onNicknameUpdated(data.user);
      setStatusMessage({ type: 'success', text: data.message });
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch {
      setStatusMessage({ type: 'error', text: 'Falha na conexão com o servidor.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteNickname = async () => {
    if (!confirm('Deseja realmente excluir seu nickname? Ele ficará imediatamente livre para qualquer pessoa usar!')) {
      return;
    }

    setIsDeleting(true);
    setStatusMessage(null);

    try {
      const res = await fetch('/api/user/nickname', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Erro ao excluir nickname.' });
        return;
      }

      onNicknameUpdated(data.user);
      setNicknameInput('');
      setStatusMessage({ type: 'success', text: data.message });
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch {
      setStatusMessage({ type: 'error', text: 'Falha na conexão com o servidor.' });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl border-2 border-[#22D3EE]/40 bg-[#0F172A] p-6 sm:p-8 shadow-[0_0_50px_rgba(34,211,238,0.2)] text-[#E2E8F0]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
          title="Fechar"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Cabeçalho */}
        <div className="flex items-center gap-3.5 mb-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[#22D3EE] to-[#F472B6] text-black shadow-lg shadow-[#22D3EE]/25 shrink-0">
            <UserIcon className="h-6 w-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#22D3EE]">
              Identidade no Chamasso Live
            </span>
            <h2 className="text-xl font-black text-white uppercase tracking-tight">
              Gerenciar Nickname
            </h2>
          </div>
        </div>

        {/* Status atual do Nickname */}
        {currentUser.nickname ? (
          <div className="mb-5 rounded-2xl border border-[#22D3EE]/30 bg-[#0A0C10] p-4 flex items-center justify-between gap-3">
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Nickname Atual em Uso</p>
              <p className="text-lg font-black text-white flex items-center gap-2">
                <span>{currentUser.nickname}</span>
                <span
                  className={`rounded-md px-2 py-0.5 text-[10px] font-extrabold uppercase ${
                    currentUser.nicknameType === 'permanent'
                      ? 'bg-[#22D3EE]/20 text-[#22D3EE] border border-[#22D3EE]/40'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  }`}
                >
                  {currentUser.nicknameType === 'permanent' ? 'Permanente' : 'Temporário'}
                </span>
              </p>
              {currentUser.nicknameType === 'permanent' && (
                <p className="text-[11px] text-slate-400 mt-0.5">
                  ✅ Usado automaticamente ao entrar em qualquer sala sem pedir novamente.
                </p>
              )}
            </div>

            <button
              onClick={handleDeleteNickname}
              disabled={isDeleting}
              className="flex items-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-950/30 px-3 py-2 text-xs font-bold text-rose-400 hover:bg-rose-900/50 hover:text-rose-200 transition active:scale-95 disabled:opacity-50"
              title="Excluir este nickname e liberá-lo para qualquer pessoa poder usar"
            >
              <Trash2 className="h-4 w-4" />
              <span className="hidden sm:inline">Excluir & Liberar</span>
            </button>
          </div>
        ) : (
          <div className="mb-5 rounded-2xl border border-dashed border-[#1E293B] bg-[#0A0C10]/50 p-3.5 text-xs text-slate-400">
            Você ainda não possui um nickname definido. Defina um apelido exclusivo para suas salas de conferência e chat.
          </div>
        )}

        {/* Formulário de Definição do Nickname */}
        <form onSubmit={handleSaveNickname} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Escolha seu Nickname
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={nicknameInput}
                  onChange={(e) => setNicknameInput(e.target.value.slice(0, NICKNAME_MAX_LENGTH))}
                  placeholder="Ex: joão_silva-2026"
                  maxLength={NICKNAME_MAX_LENGTH}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                />
              </div>
              <button
                type="button"
                onClick={handleCheckAvailability}
                disabled={isChecking || !nicknameInput.trim()}
                className="rounded-xl border border-[#22D3EE]/40 bg-[#1E293B] px-3 py-2 text-xs font-bold text-[#22D3EE] hover:bg-[#334155] transition disabled:opacity-50"
              >
                {isChecking ? 'Verificando...' : 'Verificar'}
              </button>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
              <span>Até 16 caracteres: letras do alfabeto brasileiro, números e os símbolos ".", "-" e "_".</span>
              <span className="font-mono text-[#22D3EE]">{nicknameInput.length}/{NICKNAME_MAX_LENGTH}</span>
            </div>
          </div>

          {/* Opção de tipo de nickname */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Tipo de Nickname
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label
                className={`flex flex-col rounded-2xl border p-3 cursor-pointer transition ${
                  nicknameType === 'permanent'
                    ? 'border-[#22D3EE] bg-[#22D3EE]/10 text-white'
                    : 'border-[#1E293B] bg-[#0A0C10] text-slate-400 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-black text-[#22D3EE]">
                    <ShieldCheck className="h-4 w-4" />
                    Permanente
                  </span>
                  <input
                    type="radio"
                    name="nicknameType"
                    value="permanent"
                    checked={nicknameType === 'permanent'}
                    onChange={() => setNicknameType('permanent')}
                    className="h-4 w-4 text-[#22D3EE] focus:ring-[#22D3EE]"
                  />
                </div>
                <p className="mt-1 text-[11px] leading-relaxed">
                  Fica reservado para você e é usado <strong>automaticamente</strong> em todas as salas sem perguntar novamente.
                </p>
              </label>

              <label
                className={`flex flex-col rounded-2xl border p-3 cursor-pointer transition ${
                  nicknameType === 'temporary'
                    ? 'border-amber-400 bg-amber-400/10 text-white'
                    : 'border-[#1E293B] bg-[#0A0C10] text-slate-400 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-black text-amber-400">
                    <Clock className="h-4 w-4" />
                    Temporário
                  </span>
                  <input
                    type="radio"
                    name="nicknameType"
                    value="temporary"
                    checked={nicknameType === 'temporary'}
                    onChange={() => setNicknameType('temporary')}
                    className="h-4 w-4 text-amber-400 focus:ring-amber-400"
                  />
                </div>
                <p className="mt-1 text-[11px] leading-relaxed">
                  Válido para a sessão atual. Não bloqueia o nome permanentemente para outros usuários.
                </p>
              </label>
            </div>
          </div>

          {/* Mensagens de feedback */}
          {statusMessage && (
            <div
              className={`flex items-center gap-2 rounded-xl p-3 text-xs ${
                statusMessage.type === 'success'
                  ? 'border border-[#22D3EE]/40 bg-[#22D3EE]/10 text-[#22D3EE]'
                  : 'border border-rose-500/40 bg-rose-950/40 text-rose-300'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <Check className="h-4 w-4 shrink-0" />
              ) : (
                <AlertCircle className="h-4 w-4 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* Ações */}
          <div className="flex gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-bold text-slate-300 hover:bg-[#334155] hover:text-white transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving || !nicknameInput.trim()}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
            >
              <Sparkles className="h-4 w-4 text-black" />
              <span>{isSaving ? 'Salvando...' : 'Salvar Nickname'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
