# Chamasso 2.3.5 — Home na compra + Mediação Psicossocial por IA

- Adiciona **Voltar à Home** e **Sair da compra** à tela de compra de PASQcoin, inclusive no layout móvel.
- Após pagamento confirmado, o botão principal retorna à Home.
- Adiciona o nível **Auxílio por IA — Mediação Psicossocial** aos tipos de relacionamento/conversa.
- Migração aditiva no boot inclui o novo nível em instalações existentes sem apagar níveis personalizados.
- O texto do modo IA deixa explícito que o recurso é apoio informativo e mediação, não substituto de atendimento profissional ou de emergência.
