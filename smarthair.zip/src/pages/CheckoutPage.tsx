import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { initMercadoPago, Payment } from '@mercadopago/sdk-react';
import Logo from '../components/Logo';
import { ArrowLeft, Clock, Calendar, CheckCircle } from 'lucide-react';

export default function CheckoutPage() {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const navigate = useNavigate();
  const [appointment, setAppointment] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isMpInitialized, setIsMpInitialized] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);
  const [pixData, setPixData] = useState<{qr_code_base64: string, qr_code: string} | null>(null);

  useEffect(() => {
    const fetchCheckoutData = async () => {
      try {
        // Fetch appointment details
        const apptRes = await fetch(`/api/appointments/${appointmentId}`);
        if (!apptRes.ok) {
          throw new Error('Agendamento não encontrado');
        }
        const apptData = await apptRes.json();
        setAppointment(apptData);

        // Fetch preference settings to get the public key
        const prefRes = await fetch('/api/checkout/preference', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: `Agendamento: ${apptData.service_name} - ${apptData.salon_name}`,
            price: apptData.paid_amount,
            appointmentId: apptData.id,
            salonId: apptData.salon_id,
            totalServicePrice: apptData.service_price
          })
        });

        if (prefRes.ok) {
          const prefData = await prefRes.json();
          if (prefData.publicKey) {
            initMercadoPago(prefData.publicKey, { locale: 'pt-BR' });
            setIsMpInitialized(true);
          }
        }
      } catch (err: any) {
        setError(err.message || 'Erro ao carregar o checkout');
      } finally {
        setLoading(false);
      }
    };

    if (appointmentId) {
      fetchCheckoutData();
    }
  }, [appointmentId]);

  const handlePaymentSubmit = async (param: any) => {
    return new Promise<void>((resolve, reject) => {
      fetch('/api/checkout/process_payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...param.formData,
          external_reference: appointmentId,
          description: `Agendamento: ${appointment?.service_name}`
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.success) {
            setPaymentStatus(response.status);
            if (response.status === 'pending' && response.data?.point_of_interaction?.transaction_data) {
              setPixData({
                qr_code_base64: response.data.point_of_interaction.transaction_data.qr_code_base64,
                qr_code: response.data.point_of_interaction.transaction_data.qr_code,
              });
            }
            resolve();
            if (response.status === 'approved') {
               setTimeout(() => navigate('/dashboard/client?payment=success&appointment_id=' + appointmentId), 2000);
            }
          } else {
            console.error('Falha no pagamento', response.message);
            reject();
          }
        })
        .catch((error) => {
           console.error('Erro de requisição', error);
           reject();
        });
    });
  };

  const onError = async (error: any) => {
    console.log(error);
  };

  const onReady = async () => {
    console.log("Payment Brick Ready");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-600"></div>
      </div>
    );
  }

  if (error || !appointment) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50">
        <p className="text-red-500 mb-4">{error || "Não foi possível carregar."}</p>
        <button onClick={() => navigate(-1)} className="text-cyan-600 font-medium hover:underline">Voltar</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans pb-16">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-3xl mx-auto px-4 h-16 flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="text-slate-500 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 font-bold text-teal-900">
            <Logo className="w-6 h-6" variant="dark" />
            Checkout
          </div>
          <div className="w-5"></div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 mt-8">
        {paymentStatus === 'approved' ? (
          <div className="bg-white rounded-3xl p-12 text-center shadow-lg border border-slate-200">
             <CheckCircle className="w-20 h-20 text-cyan-500 mx-auto mb-6" />
             <h2 className="text-3xl font-bold text-slate-900 mb-2">Pagamento Aprovado!</h2>
             <p className="text-slate-500 mb-8">Sua reserva foi confirmada com sucesso.</p>
             <p className="text-sm text-slate-400">Redirecionando para seus agendamentos...</p>
          </div>
        ) : paymentStatus === 'pending' ? (
           <div className="bg-white rounded-3xl p-8 text-center shadow-lg border border-slate-200">
             <Clock className="w-16 h-16 text-amber-500 mx-auto mb-4" />
             <h2 className="text-3xl font-bold text-slate-900 mb-2">Aguardando Pagamento</h2>
             <p className="text-slate-600 mb-6">Complete o pagamento com Pix usando o código gerado abaixo.</p>
             {pixData && (
                <div className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-200 inline-block">
                   <img src={`data:image/jpeg;base64,${pixData.qr_code_base64}`} alt="QR Code Pix" className="w-48 h-48 mx-auto mb-4 border border-slate-300 rounded-lg shadow-sm" />
                   <p className="text-sm font-bold text-slate-700 mb-2">Pix Copia e Cola:</p>
                   <div className="flex items-center gap-2 max-w-sm mx-auto">
                      <input 
                         type="text" 
                         readOnly 
                         value={pixData.qr_code} 
                         className="w-full text-xs p-3 bg-white border border-slate-300 rounded-lg text-slate-600 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                      />
                      <button 
                         onClick={() => {
                           navigator.clipboard.writeText(pixData.qr_code);
                           alert("Código Pix copiado!");
                         }} 
                         className="px-4 py-3 bg-cyan-600 text-white text-xs font-bold rounded-lg hover:bg-teal-600"
                      >
                         Copiar
                      </button>
                   </div>
                </div>
             )}
             <p className="text-sm text-slate-500">Seu agendamento será confirmado automaticamente assim que o pagamento for reconhecido pelo banco.</p>
             <div className="mt-8">
               <button onClick={() => navigate('/dashboard/client')} className="px-6 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors">
                  Acompanhar meus agendamentos
               </button>
             </div>
           </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-lg text-slate-900 mb-4">Resumo do Agendamento</h3>
                
                <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
                  <span className="text-slate-600">{appointment.service_name}</span>
                  <span className="font-bold text-slate-900">R$ {appointment.service_price.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
                  <span className="text-slate-600 font-medium">Sinal de Reserva (20%)</span>
                  <span className="font-bold text-cyan-600">R$ {appointment.paid_amount.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-4">
                  <span className="text-slate-600">Restante no local</span>
                  <span className="text-slate-900">R$ {appointment.pending_amount.toFixed(2)}</span>
                </div>

                <div className="space-y-3 mt-6">
                  <div className="flex items-center gap-3 text-slate-600">
                    <Calendar className="w-5 h-5 text-cyan-600" />
                    <span>{new Date(appointment.start_time).toLocaleDateString('pt-BR')} às {new Date(appointment.start_time).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-sm" style={{minHeight: 400}}>
              {isMpInitialized ? (
                <Payment
                  initialization={{
                    amount: appointment.paid_amount,
                  }}
                  customization={{
                    paymentMethods: {
                      creditCard: 'all',
                      bankTransfer: 'all',
                    }
                  }}
                  onSubmit={handlePaymentSubmit}
                  onReady={onReady}
                  onError={onError}
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-slate-500">Inicializando pagamento...</p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
