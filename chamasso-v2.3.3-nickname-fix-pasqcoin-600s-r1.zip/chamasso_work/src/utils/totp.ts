/**
 * RFC 6238 TOTP & Base32 Implementation
 * Google Authenticator compatible with 11 Disposable Codes generator
 */

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function generateBase32Secret(length = 20): string {
  let secret = '';
  const cryptoObj = typeof window !== 'undefined' && window.crypto ? window.crypto : null;
  
  if (cryptoObj) {
    const bytes = new Uint8Array(length);
    cryptoObj.getRandomValues(bytes);
    for (let i = 0; i < length; i++) {
      secret += BASE32_ALPHABET[bytes[i] % BASE32_ALPHABET.length];
    }
  } else {
    for (let i = 0; i < length; i++) {
      secret += BASE32_ALPHABET[Math.floor(Math.random() * BASE32_ALPHABET.length)];
    }
  }
  return secret;
}

export function base32Decode(base32: string): Uint8Array {
  const cleaned = base32.toUpperCase().replace(/=+$/, '').replace(/\s+/g, '');
  let bits = 0;
  let value = 0;
  const output: number[] = [];

  for (let i = 0; i < cleaned.length; i++) {
    const char = cleaned[i];
    const val = BASE32_ALPHABET.indexOf(char);
    if (val === -1) {
      continue;
    }
    value = (value << 5) | val;
    bits += 5;

    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }

  return new Uint8Array(output);
}

// Generates 11 disposable codes (códigos descartáveis)
export function generate11DisposableCodes(): string[] {
  const codes: string[] = [];
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0, O, 1, I to avoid confusion
  
  while (codes.length < 11) {
    let part1 = '';
    let part2 = '';
    for (let i = 0; i < 4; i++) {
      part1 += chars[Math.floor(Math.random() * chars.length)];
      part2 += chars[Math.floor(Math.random() * chars.length)];
    }
    const code = `CHAM-${part1}-${part2}`;
    if (!codes.includes(code)) {
      codes.push(code);
    }
  }
  return codes;
}

export function generateTotpUri(email: string, secret: string, issuer = 'chamasso live chat'): string {
  const label = encodeURIComponent(`${issuer}:${email}`);
  const encIssuer = encodeURIComponent(issuer);
  return `otpauth://totp/${label}?secret=${secret}&issuer=${encIssuer}&algorithm=SHA1&digits=6&period=30`;
}

// Pure JS SHA1 / HMAC-SHA1 to guarantee exact RFC 6238 compatibility across server and client
function sha1(bytes: Uint8Array): Uint8Array {
  const K = [0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6];
  let H0 = 0x67452301;
  let H1 = 0xEFCDAB89;
  let H2 = 0x98BADCFE;
  let H3 = 0x10325476;
  let H4 = 0xC3D2E1F0;

  const bitLen = bytes.length * 8;
  const newLen = (((bytes.length + 8) >> 6) + 1) << 6;
  const padded = new Uint8Array(newLen);
  padded.set(bytes);
  padded[bytes.length] = 0x80;

  const view = new DataView(padded.buffer);
  view.setUint32(newLen - 4, bitLen, false);

  const W = new Uint32Array(80);

  for (let chunk = 0; chunk < newLen; chunk += 64) {
    for (let i = 0; i < 16; i++) {
      W[i] = view.getUint32(chunk + i * 4, false);
    }
    for (let i = 16; i < 80; i++) {
      const v = W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16];
      W[i] = (v << 1) | (v >>> 31);
    }

    let a = H0;
    let b = H1;
    let c = H2;
    let d = H3;
    let e = H4;

    for (let i = 0; i < 80; i++) {
      let f = 0;
      let k = 0;
      if (i < 20) {
        f = (b & c) | ((~b) & d);
        k = K[0];
      } else if (i < 40) {
        f = b ^ c ^ d;
        k = K[1];
      } else if (i < 60) {
        f = (b & c) | (b & d) | (c & d);
        k = K[2];
      } else {
        f = b ^ c ^ d;
        k = K[3];
      }

      const temp = (((a << 5) | (a >>> 27)) + f + e + k + W[i]) >>> 0;
      e = d;
      d = c;
      c = ((b << 30) | (b >>> 2)) >>> 0;
      b = a;
      a = temp;
    }

    H0 = (H0 + a) >>> 0;
    H1 = (H1 + b) >>> 0;
    H2 = (H2 + c) >>> 0;
    H3 = (H3 + d) >>> 0;
    H4 = (H4 + e) >>> 0;
  }

  const out = new Uint8Array(20);
  const outView = new DataView(out.buffer);
  outView.setUint32(0, H0, false);
  outView.setUint32(4, H1, false);
  outView.setUint32(8, H2, false);
  outView.setUint32(12, H3, false);
  outView.setUint32(16, H4, false);
  return out;
}

function hmacSha1(key: Uint8Array, message: Uint8Array): Uint8Array {
  const blockSize = 64;
  let formattedKey = key;
  if (key.length > blockSize) {
    formattedKey = sha1(key);
  }
  const paddedKey = new Uint8Array(blockSize);
  paddedKey.set(formattedKey);

  const oKeyPad = new Uint8Array(blockSize);
  const iKeyPad = new Uint8Array(blockSize);
  for (let i = 0; i < blockSize; i++) {
    oKeyPad[i] = paddedKey[i] ^ 0x5C;
    iKeyPad[i] = paddedKey[i] ^ 0x36;
  }

  const inner = new Uint8Array(blockSize + message.length);
  inner.set(iKeyPad, 0);
  inner.set(message, blockSize);
  const innerHash = sha1(inner);

  const outer = new Uint8Array(blockSize + innerHash.length);
  outer.set(oKeyPad, 0);
  outer.set(innerHash, blockSize);
  return sha1(outer);
}

export function computeTotpCode(secretBase32: string, timeStepWindow = 0): string {
  const key = base32Decode(secretBase32);
  const epoch = Math.floor(Date.now() / 1000);
  const counter = Math.floor(epoch / 30) + timeStepWindow;

  const counterBytes = new Uint8Array(8);
  const view = new DataView(counterBytes.buffer);
  // High 32 bits are 0 for timestamps up to year 2038+
  view.setUint32(0, 0, false);
  view.setUint32(4, counter, false);

  const hmac = hmacSha1(key, counterBytes);
  const offset = hmac[hmac.length - 1] & 0x0F;
  const binary =
    ((hmac[offset] & 0x7F) << 24) |
    ((hmac[offset + 1] & 0xFF) << 16) |
    ((hmac[offset + 2] & 0xFF) << 8) |
    (hmac[offset + 3] & 0xFF);

  const otp = binary % 1000000;
  return otp.toString().padStart(6, '0');
}

export function verifyTotp(secretBase32: string, token: string): boolean {
  const sanitizedToken = token.trim().replace(/\s+/g, '');
  if (!/^\d{6}$/.test(sanitizedToken)) {
    return false;
  }

  // Check current window and ±1 window (drift tolerance ±30 seconds)
  for (let window = -1; window <= 1; window++) {
    const validOtp = computeTotpCode(secretBase32, window);
    if (validOtp === sanitizedToken) {
      return true;
    }
  }
  return false;
}
