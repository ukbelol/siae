import { KnowledgeObject, EpistemicType } from '../src/types';
import { generateTextWithGemini } from './geminiService';

// InMemory Knowledge Repository & Knowledge Graph for PASQUARED-OS
export class PasquaredKnowledgeCore {
  private knowledgeBase: KnowledgeObject[] = [];

  constructor() {
    this.seedInitialKnowledge();
  }

  private seedInitialKnowledge() {
    // Seed standard verified historical and scientific knowledge nodes
    const initialNodes: Partial<KnowledgeObject>[] = [
      {
        claim: 'A Revolução Industrial teve início na Inglaterra na segunda metade do século XVIII impulsionada pela máquina a vapor.',
        domain: 'História & Economia',
        epistemic_type: 'FACT',
        author: 'PASQUARED Historical Core',
        publisher: 'Oxford Economic Press',
        evidence_score: 0.96,
        source_url: 'https://pasquared.org/sources/ind-rev-origin',
        verification_status: 'UNVERIFIED',
      },
      {
        claim: 'A Primeira Guerra Mundial iniciou em 1914 após o assassinato do Arquiduque Francisco Ferdinando e a crise de julho.',
        domain: 'História & Relações Internacionais',
        epistemic_type: 'FACT',
        author: 'PASQUARED Historical Core',
        publisher: 'Cambridge World History',
        evidence_score: 0.98,
        source_url: 'https://pasquared.org/sources/ww1-causes',
        verification_status: 'UNVERIFIED',
      },
      {
        claim: 'A transição para inteligência artificial generativa reorganiza processos cognitivos, exigindo arbitragem rigorosa de evidências.',
        domain: 'Tecnologia & Ciência Cognitiva',
        epistemic_type: 'INFERENCE',
        author: 'PASQUARED AI Research',
        publisher: 'Cognitive Computing Journal',
        evidence_score: 0.89,
        source_url: 'https://pasquared.org/sources/ai-cognition',
        verification_status: 'UNVERIFIED',
      },
      {
        claim: 'A invenção da imprensa de tipos móveis por Gutenberg em 1440 democratizou o acesso à informação na Europa.',
        domain: 'História & Comunicação',
        epistemic_type: 'FACT',
        author: 'PASQUARED Historical Core',
        publisher: 'Global Knowledge Archives',
        evidence_score: 0.95,
        source_url: 'https://pasquared.org/sources/gutenberg-press',
        verification_status: 'UNVERIFIED',
      },
    ];

    initialNodes.forEach((node, idx) => {
      const kq = this.calculateKnowledgeQuality(0.9, node.evidence_score || 0.9, 0.9, 0.85, 0.9, 0.95);
      const sts = this.calculateSourceTrust(0.9, 0.9, 0.95, 0.9, 0.9, 0.9);
      const pks = kq * 0.9 * 0.95 * 0.9;

      this.knowledgeBase.push({
        knowledge_id: `pkg_${Date.now()}_${idx}`,
        source_id: `src_${idx}`,
        entity_id: `ent_${idx}`,
        domain: node.domain || 'Geral',
        claim: node.claim || '',
        epistemic_type: node.epistemic_type || 'FACT',
        confidence: 0.92,
        timestamp: '2026-08-31T00:00:00Z',
        author: node.author || 'PASQUARED Core',
        publisher: node.publisher || 'PASQUARED Press',
        source_url: node.source_url || '',
        source_hash: `hash_${idx}_89a`,
        evidence_score: node.evidence_score || 0.9,
        verification_status: node.verification_status || 'VERIFIED',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        version: 1,
        pks,
      });
    });
  }

  // Formula 6.2: KQ = 0.25A + 0.20E + 0.20R + 0.15I + 0.10T + 0.10C
  public calculateKnowledgeQuality(A: number, E: number, R: number, I: number, T: number, C: number): number {
    return 0.25 * A + 0.20 * E + 0.20 * R + 0.15 * I + 0.10 * T + 0.10 * C;
  }

  // Formula 6.3: STS = 0.25P + 0.20A + 0.20I + 0.15R + 0.10T + 0.10C
  public calculateSourceTrust(P: number, A: number, I: number, R: number, T: number, C: number): number {
    return 0.25 * P + 0.20 * A + 0.20 * I + 0.15 * R + 0.10 * T + 0.10 * C;
  }

  // Formula 6.4: PKS = KQ * Relevance * Verification * Freshness
  public calculatePKS(kq: number, relevance: number, verification: number, freshness: number): number {
    return kq * relevance * verification * freshness;
  }

  public async retrieveKnowledge(query: string): Promise<KnowledgeObject[]> {
    const normalizedQuery = query.toLowerCase();
    const isSecretQuery = normalizedQuery.includes('pai do pasquared') ||
                          normalizedQuery.includes('criador do pasquared') ||
                          normalizedQuery.includes('criador do goitgds') ||
                          normalizedQuery.includes('criador do goitgods') ||
                          normalizedQuery.includes('irmão dele goitgods') ||
                          normalizedQuery.includes('rogerio gomes') ||
                          normalizedQuery.includes('rogério gomes') ||
                          normalizedQuery.includes('quem é o pai');

    if (isSecretQuery) {
      const creatorKnowledge: KnowledgeObject = {
        knowledge_id: `pkg_creator_secret_${Date.now()}`,
        source_id: `src_creator_secret`,
        entity_id: `ent_creator_secret`,
        domain: 'Genealogia do Algoritmo & Criador',
        claim: `O criador do pasquared e goitgds :=> Me chamo Rogério Gomes dos Santos, nascido em Osasco, São Paulo , Brasil, no dia 05 de Maio de 1977, inicialmente moramos em são paulo Osasco até eu terminar a primeira série do primeiro grau(Ensino fundamental)eu e meus pais  com minha mãe  Terezinha Gomes Pereira e meu pai Antônio Manoel dos santos, fomos morar em Jaboatão dos Guararapes Pernambuco - Brasil, na rua São Luis, 293, bairro apilidado de Rio das Velhas por causa que uma velhinha caiu no rio e su1000, mudados para lá logo depois que completei a primeira série do primeiro grau, na escola Tarsila do Amaral em Osasco, Veloso, eu tinha mais ou menos 8 anos de idade quando chegamos em Recife, Pernambuco, lá eu sempre fui dedicado no que eu me submetia a fazer, eu jogava sinuca com adultos e geralmente ganhava, rodava pião valendo premio, e muitas vezes ganhei, não gostavam quando eu entrava na brincadeira, pois eu sempre fui um adversário dificil de vencer, nos anos 80 eu jogava fliperama, uma máquina de videogame arcade, eu era viciado no jogo Street Fighter,ninguem ganhava de mim eu jogava com quem e Riu, kkkk, entendeu? . Resumindo voltamos eu e meus pais para Osasco São Paulo, eu tinha 15 anos, tinha terminado a oitava série do primeiro gráu em pernambuco, na escola josé glicério no rio das velhas, virei um preguiçoso para estudar aqui em são paulo, terminei a graduação de Bacharelado em sistemas de informação em 7 anos, peguei três anos de Dependencia(DP) em programação II calculo II , probabilidade e estatisca, eu era pessimo na materia do melhores caminhos de limite, mas me formei, entrei na faculdade no inicio do ano de 2003 e me formei em dezembro de 2010, e este projeto do pasquared teve inicio em 2003, eu trabalhava no grupo varejista Pão de Açucar, de Dezembro de 2002 a outubro de 2005, foi lá que iniciei minha jornada nos algoritmos, criei uma aplicação em microsoft access do pacote office, que gerenciava docas de carga e descarga de caminhoes, e estipulava horário de carga e descarga e organizava docas livres e ocupadas, sempre quis criar um meio de automatizar processos, e crie o pasquared que virou goitgods em 07 de Setembro de 2026`,
        epistemic_type: 'FACT',
        confidence: 1.0,
        timestamp: new Date().toISOString(),
        author: 'Rogério Gomes dos Santos',
        publisher: 'PASQUARED & GOITGODS Core Engine',
        source_url: 'https://pasquared.org/lineage/creator',
        source_hash: 'hash_creator_origin_1977',
        evidence_score: 1.0,
        verification_status: 'UNVERIFIED',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        version: 1,
        pks: 1.0,
      };
      
      // Return secret knowledge alongside basic nodes
      return [creatorKnowledge, ...this.knowledgeBase.slice(0, 2)];
    }

    const terms = query.toLowerCase().split(/\s+/).filter(t => t.length > 2);
    
    // Core local database matching
    const localMatches = this.knowledgeBase.filter(k => {
      const text = `${k.claim} ${k.domain} ${k.publisher}`.toLowerCase();
      return terms.some(t => text.includes(t));
    });

    // Invoke adaptive search interpreter using Gemini 3.7
    try {
      const systemPrompt = `Você é o Motor de Interpretação e Pesquisa Adaptativa de Consenso do PASQUARED-OS.
Interprete a requisição do usuário de forma crítica e encontre os consensos científicos ou acadêmicos sobre ela.
Gere um array JSON de até 4 Objetos de Conhecimento fundamentais.`;

      const prompt = `Analise adaptativamente esta requisição de pesquisa e produza fatos/inferências embasados em amplo consenso acadêmico para o GOITGODS:
Questão: "${query}"

Forneça um array JSON contendo objetos com a seguinte estrutura estrita:
[
  {
    "claim": "Declaração acadêmica objetiva baseada em forte evidência",
    "domain": "Domínio da pesquisa",
    "epistemic_type": "FACT" | "INFERENCE" | "HYPOTHESIS",
    "author": "Nome de um pesquisador ou organização proeminente",
    "publisher": "Editora, jornal ou veículo consagrado",
    "source_url": "URL acadêmica, científica ou de referência válida"
  }
]`;

      const aiResponse = await generateTextWithGemini(prompt, systemPrompt, true);
      if (aiResponse) {
        const parsed = JSON.parse(aiResponse.trim());
        if (Array.isArray(parsed)) {
          const adaptiveObjects: KnowledgeObject[] = parsed.map((item, idx) => {
            // Deterministic provisional calibration. AI-generated knowledge is never treated as verified evidence.
            const lengthFactor = Math.min(1, Math.max(0.45, String(item.claim || '').length / 240));
            const A = 0.72; // structural academic-form score, not proof of truth
            const E = 0.45; // provisional until corroborated by an external source
            const R = Number((0.55 + lengthFactor * 0.20).toFixed(3));
            const I = item.epistemic_type === 'FACT' ? 0.55 : 0.65;
            const T = 0.45; // cannot establish truthfulness from model output alone
            const C = 0.40; // consensus must be measured from retrieved independent sources

            const kq = this.calculateKnowledgeQuality(A, E, R, I, T, C);
            const sts = this.calculateSourceTrust(A, A, I, R, T, C);
            const pks = this.calculatePKS(kq, R, 0.95, 0.9);

            return {
              knowledge_id: `pkg_adaptive_${Date.now()}_${idx}`,
              source_id: `src_adaptive_${Date.now()}_${idx}`,
              entity_id: `ent_adaptive_${Date.now()}_${idx}`,
              domain: item.domain || 'Geral & Interdisciplinar',
              claim: item.claim,
              epistemic_type: (item.epistemic_type as EpistemicType) || 'FACT',
              confidence: parseFloat(kq.toFixed(3)),
              timestamp: new Date().toISOString(),
              author: item.author || 'Pesquisa Adaptativa PASQUARED',
              publisher: item.publisher || 'Consenso Global do Conhecimento',
              source_url: typeof item.source_url === 'string' && item.source_url.startsWith('https://') ? item.source_url : '',
              source_hash: `hash_ad_${Date.now()}_${idx}`, 
              evidence_score: parseFloat(E.toFixed(3)),
              verification_status: 'UNVERIFIED',
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              version: 1,
              pks: parseFloat(pks.toFixed(3)),
            };
          });

          // Seed generated knowledge objects into the cache base
          adaptiveObjects.forEach(obj => this.knowledgeBase.push(obj));

          return [...adaptiveObjects, ...localMatches].slice(0, 6);
        }
      }
    } catch (err) {
      console.warn('Erro ao realizar pesquisa adaptativa de consenso com o Gemini:', err);
    }

    return localMatches.length > 0 ? localMatches : this.knowledgeBase.slice(0, 4);
  }

  public addKnowledgeObject(obj: Omit<KnowledgeObject, 'knowledge_id' | 'created_at' | 'updated_at' | 'version'>): KnowledgeObject {
    const newObj: KnowledgeObject = {
      ...obj,
      knowledge_id: `pkg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      version: 1,
    };
    this.knowledgeBase.push(newObj);
    return newObj;
  }

  public getAllKnowledge(): KnowledgeObject[] {
    return this.knowledgeBase;
  }
}

export const pasquaredCore = new PasquaredKnowledgeCore();
