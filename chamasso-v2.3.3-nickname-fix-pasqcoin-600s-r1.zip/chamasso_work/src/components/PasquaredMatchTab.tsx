import React, { useEffect, useState } from 'react';
import { BrainCircuit, CheckCircle2, Heart, RefreshCw, Save, Sparkles, UserPlus, Users } from 'lucide-react';
import type { PasquaredMatchProfile, PasquaredMatchResult, User } from '../types.ts';

const QUESTIONS: Array<{key: keyof PasquaredMatchProfile; label: string; kind?: 'intent'|'scale'}> = [
  { key: 'intent', label: 'O que você procura no Chamasso?', kind: 'intent' },
  { key: 'sociability', label: 'Sou sociável e gosto de conhecer pessoas novas.', kind: 'scale' },
  { key: 'empathy', label: 'Tenho facilidade para ouvir, acolher e compreender o outro.', kind: 'scale' },
  { key: 'spontaneity', label: 'Gosto de espontaneidade, novidades e planos de última hora.', kind: 'scale' },
  { key: 'organization', label: 'Prefiro rotina, organização e combinar as coisas com antecedência.', kind: 'scale' },
  { key: 'affection', label: 'Demonstro carinho e valorizo demonstrações de afeto.', kind: 'scale' },
  { key: 'communication', label: 'Prefiro conversar abertamente quando existe um problema.', kind: 'scale' },
  { key: 'independence', label: 'Preciso de espaço e autonomia mesmo em relações próximas.', kind: 'scale' },
  { key: 'humor', label: 'Humor e leveza são muito importantes para mim.', kind: 'scale' },
  { key: 'ambition', label: 'Metas, projetos e crescimento pessoal/profissional têm grande peso na minha vida.', kind: 'scale' },
  { key: 'calmness', label: 'Em conflitos, costumo manter a calma antes de reagir.', kind: 'scale' },
  { key: 'jealousyTolerance', label: 'Lido bem com confiança, liberdade e pouca cobrança/ciúme.', kind: 'scale' },
];

const defaultProfile: PasquaredMatchProfile = {
  intent: 'both', sociability: 3, empathy: 3, spontaneity: 3, organization: 3, affection: 3,
  communication: 3, independence: 3, humor: 3, ambition: 3, calmness: 3, jealousyTolerance: 3,
  qualities: [], growthEdges: [], interests: [], enabled: true, updatedAt: '',
};

const chips = ['Lealdade','Bom humor','Empatia','Sinceridade','Carinho','Criatividade','Paciência','Responsabilidade'];
const edges = ['Timidez','Teimosia','Ansiedade social','Impaciência','Ciúme','Desorganização','Dificuldade de se abrir','Excesso de trabalho'];

export const PasquaredMatchTab: React.FC<{ currentUser: User; onOpenProfile?: (id: string) => void }> = ({ currentUser, onOpenProfile }) => {
  const [profile, setProfile] = useState<PasquaredMatchProfile>(defaultProfile);
  const [matches, setMatches] = useState<PasquaredMatchResult[]>([]);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const [p, m] = await Promise.all([
      fetch(`/api/pasquared/match/profile/${currentUser.id}`).then(r => r.json()),
      fetch(`/api/pasquared/match/list/${currentUser.id}`).then(r => r.json()),
    ]);
    if (p.profile) setProfile({ ...defaultProfile, ...p.profile });
    setMatches(m.matches || []);
  };
  useEffect(() => { load().catch(console.error); }, [currentUser.id]);

  const toggle = (field: 'qualities'|'growthEdges', value: string) => {
    setProfile(p => ({ ...p, [field]: p[field].includes(value) ? p[field].filter(x => x !== value) : [...p[field], value].slice(0, 5) }));
  };

  const save = async () => {
    setLoading(true); setMessage('');
    try {
      const res = await fetch(`/api/pasquared/match/profile/${currentUser.id}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(profile) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Falha ao salvar');
      setProfile(json.profile); setMessage('Perfil PASQUARED atualizado. A triangulação foi recalibrada.');
      await load();
    } catch (e:any) { setMessage(e.message); } finally { setLoading(false); }
  };

  return <div className="space-y-5">
    <div className="rounded-2xl border border-cyan-500/30 bg-[#0F172A] p-6 shadow-md">
      <div className="flex items-start gap-3"><BrainCircuit className="h-7 w-7 text-[#22D3EE]"/><div><h3 className="text-lg font-black text-white">PASQUARED • Perfil de Afinidades</h3><p className="mt-1 text-xs text-slate-400">UCI → EKO → MVED: suas respostas formam hipóteses de afinidade, validadas em três eixos independentes antes de gerar o ICI de compatibilidade. O resultado é uma sugestão, não uma certeza sobre pessoas.</p></div></div>
      <div className="mt-5 space-y-4">
        {QUESTIONS.map(q => <div key={String(q.key)} className="rounded-xl border border-[#1E293B] bg-[#090D16] p-4">
          <div className="text-xs font-bold text-slate-200">{q.label}</div>
          {q.kind === 'intent' ? <div className="mt-3 flex flex-wrap gap-2">{[['friendship','Amizades'],['dating','Paquera'],['both','Amizades e paqueras']].map(([v,l]) => <button key={v} onClick={() => setProfile(p => ({...p,intent:v as any}))} className={`rounded-lg px-3 py-2 text-xs font-bold border ${profile.intent===v?'border-cyan-400 bg-cyan-500/15 text-cyan-300':'border-slate-700 text-slate-400'}`}>{l}</button>)}</div>
          : <div className="mt-3 flex gap-2">{[1,2,3,4,5].map(v => <button key={v} onClick={() => setProfile(p => ({...p,[q.key]:v}))} className={`h-9 w-9 rounded-lg text-xs font-black border ${profile[q.key]===v?'border-cyan-400 bg-cyan-500/20 text-cyan-300':'border-slate-700 text-slate-500'}`}>{v}</button>)}<span className="self-center text-[10px] text-slate-500">1 discordo • 5 concordo</span></div>}
        </div>)}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-xl border border-emerald-500/20 bg-[#090D16] p-4"><h4 className="text-xs font-black text-emerald-300">Qualidades que mais me representam (até 5)</h4><div className="mt-3 flex flex-wrap gap-2">{chips.map(x => <button key={x} onClick={() => toggle('qualities',x)} className={`rounded-full border px-3 py-1.5 text-[11px] ${profile.qualities.includes(x)?'border-emerald-400 bg-emerald-500/15 text-emerald-300':'border-slate-700 text-slate-400'}`}>{x}</button>)}</div></div>
          <div className="rounded-xl border border-amber-500/20 bg-[#090D16] p-4"><h4 className="text-xs font-black text-amber-300">Pontos que estou trabalhando (até 5)</h4><div className="mt-3 flex flex-wrap gap-2">{edges.map(x => <button key={x} onClick={() => toggle('growthEdges',x)} className={`rounded-full border px-3 py-1.5 text-[11px] ${profile.growthEdges.includes(x)?'border-amber-400 bg-amber-500/15 text-amber-300':'border-slate-700 text-slate-400'}`}>{x}</button>)}</div></div>
        </div>
        <label className="block text-xs font-bold text-slate-300">Interesses (separados por vírgula)<input value={profile.interests.join(', ')} onChange={e => setProfile(p => ({...p, interests:e.target.value.split(',').map(x=>x.trim()).filter(Boolean).slice(0,20)}))} className="mt-2 w-full rounded-xl border border-slate-700 bg-[#090D16] px-3 py-2 text-white" placeholder="música, tecnologia, viagens..."/></label>
        <label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={profile.enabled} onChange={e=>setProfile(p=>({...p,enabled:e.target.checked}))}/> Participar da Lista find Match</label>
        <button onClick={save} disabled={loading} className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 px-5 py-2.5 text-xs font-black text-black"><Save className="h-4 w-4"/>{loading?'Salvando...':'Salvar e recalibrar PASQUARED'}</button>
        {message && <p className="text-xs text-cyan-300">{message}</p>}
      </div>
    </div>

    <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-md">
      <div className="flex items-center justify-between"><div><h3 className="flex items-center gap-2 text-base font-black text-white"><Sparkles className="h-5 w-5 text-fuchsia-400"/>Lista find Match</h3><p className="mt-1 text-xs text-slate-400">Possíveis amizades e paqueras agrupadas pelo ICI PASQUARED.</p></div><button onClick={()=>load()} className="rounded-lg border border-slate-700 p-2 text-cyan-300"><RefreshCw className="h-4 w-4"/></button></div>
      {!profile.updatedAt && <p className="mt-5 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-200">Preencha e salve o formulário acima para ativar a triangulação.</p>}
      <div className="mt-5 grid grid-cols-1 lg:grid-cols-2 gap-4">{matches.map(m => <div key={m.user.id} className="rounded-xl border border-[#1E293B] bg-[#090D16] p-4">
        <div className="flex gap-3"><img src={m.user.avatarUrl || '/fenix_chamas.gif'} className="h-14 w-14 rounded-xl object-cover"/><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><button onClick={()=>onOpenProfile?.(m.user.id)} className="truncate text-left text-sm font-black text-white hover:text-cyan-300">{m.user.name} {m.user.lastName}</button><span className="rounded-full bg-cyan-500/15 px-2 py-1 text-xs font-black text-cyan-300">{m.ici}%</span></div><div className="mt-1 flex gap-2 text-[10px]">{m.categories.map(c=><span key={c} className="rounded-full border border-fuchsia-500/30 px-2 py-0.5 text-fuchsia-300">{c}</span>)}</div></div></div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[10px]"><div className="rounded-lg bg-slate-900 p-2 text-slate-300">Valores<br/><b>{m.axes.values}%</b></div><div className="rounded-lg bg-slate-900 p-2 text-slate-300">Convivência<br/><b>{m.axes.lifestyle}%</b></div><div className="rounded-lg bg-slate-900 p-2 text-slate-300">Interesses<br/><b>{m.axes.interests}%</b></div></div>
        <p className="mt-3 text-[11px] text-slate-400">{m.explanation.join(' • ')}</p>
        <button onClick={()=>onOpenProfile?.(m.user.id)} className="mt-3 flex items-center gap-1 rounded-lg border border-cyan-500/30 px-3 py-1.5 text-[11px] font-bold text-cyan-300"><UserPlus className="h-3.5 w-3.5"/>Ver perfil</button>
      </div>)}</div>
      {profile.updatedAt && matches.length===0 && <p className="mt-5 text-xs text-slate-500">Ainda não há outros perfis com questionário compatível suficiente. A lista será preenchida conforme novos membros participarem.</p>}
    </div>
  </div>;
};
