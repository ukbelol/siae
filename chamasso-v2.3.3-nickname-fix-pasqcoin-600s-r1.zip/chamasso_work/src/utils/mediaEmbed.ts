import type { VideoEmbed } from '../types.ts';

export const MAX_FILE_SIZE_BYTES = 33 * 1024 * 1024; // 33 Megabytes
export const MAX_FILE_SIZE_LABEL = '33 MB';

/**
 * Detecta e converte links de plataformas populares de vídeo/stream (YouTube, Twitch, Vimeo, DailyMotion)
 * em URLs embutidas compatíveis para reprodução dentro do chat.
 */
export function extractVideoEmbed(text: string): VideoEmbed | null {
  if (!text) return null;

  // 1. YouTube
  // Formatos: youtube.com/watch?v=ID, youtu.be/ID, youtube.com/embed/ID, youtube.com/shorts/ID
  const ytMatch = text.match(
    /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i
  );
  if (ytMatch && ytMatch[1]) {
    const videoId = ytMatch[1];
    return {
      platform: 'youtube',
      url: ytMatch[0],
      embedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=0&rel=0&modestbranding=1`,
      title: 'Vídeo do YouTube',
    };
  }

  // 2. Twitch
  // Formatos: twitch.tv/canal
  const twitchMatch = text.match(
    /(?:https?:\/\/)?(?:www\.)?twitch\.tv\/([a-zA-Z0-9_]+)(?:\/v\/([0-9]+))?/i
  );
  if (twitchMatch) {
    const hostname = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
    if (twitchMatch[2]) {
      // É um vídeo/VOD
      const videoId = twitchMatch[2];
      return {
        platform: 'twitch',
        url: twitchMatch[0],
        embedUrl: `https://player.twitch.tv/?video=${videoId}&parent=${hostname}&autoplay=false`,
        title: `Twitch VOD: ${videoId}`,
      };
    } else if (twitchMatch[1] && !['directory', 'p', 'downloads', 'jobs'].includes(twitchMatch[1].toLowerCase())) {
      const channel = twitchMatch[1];
      return {
        platform: 'twitch',
        url: twitchMatch[0],
        embedUrl: `https://player.twitch.tv/?channel=${channel}&parent=${hostname}&autoplay=false`,
        title: `Twitch Stream: ${channel}`,
      };
    }
  }

  // 3. Vimeo
  const vimeoMatch = text.match(/(?:https?:\/\/)?(?:www\.)?vimeo\.com\/([0-9]+)/i);
  if (vimeoMatch && vimeoMatch[1]) {
    return {
      platform: 'vimeo',
      url: vimeoMatch[0],
      embedUrl: `https://player.vimeo.com/video/${vimeoMatch[1]}`,
      title: 'Vídeo do Vimeo',
    };
  }

  // 4. DailyMotion
  const dmMatch = text.match(/(?:https?:\/\/)?(?:www\.)?dailymotion\.com\/video\/([a-zA-Z0-9]+)/i);
  if (dmMatch && dmMatch[1]) {
    return {
      platform: 'dailymotion',
      url: dmMatch[0],
      embedUrl: `https://www.dailymotion.com/embed/video/${dmMatch[1]}`,
      title: 'Vídeo do DailyMotion',
    };
  }

  // 5. Link direto para vídeo .mp4
  const mp4Match = text.match(/(https?:\/\/[^\s]+\.mp4(\?[^\s]*)?)/i);
  if (mp4Match && mp4Match[1]) {
    return {
      platform: 'direct',
      url: mp4Match[1],
      embedUrl: mp4Match[1],
      title: 'Vídeo MP4 Direto',
    };
  }

  return null;
}

/**
 * Validação de tipo de arquivo de áudio: estritamente WAV ou MP3
 */
export function isAudioWavOrMp3(fileName: string, mimeType?: string): boolean {
  const name = fileName.toLowerCase();
  const isExtensionValid = name.endsWith('.mp3') || name.endsWith('.wav');
  if (isExtensionValid) return true;
  if (mimeType) {
    const mime = mimeType.toLowerCase();
    return mime === 'audio/mpeg' || mime === 'audio/mp3' || mime === 'audio/wav' || mime === 'audio/x-wav';
  }
  return false;
}

/**
 * Validação de imagem: PNG, GIF, JPEG/JPG
 */
export function isImageValid(fileName: string, mimeType?: string): boolean {
  const name = fileName.toLowerCase();
  const isExt = name.endsWith('.png') || name.endsWith('.gif') || name.endsWith('.jpeg') || name.endsWith('.jpg');
  if (isExt) return true;
  if (mimeType) {
    const mime = mimeType.toLowerCase();
    return mime === 'image/png' || mime === 'image/gif' || mime === 'image/jpeg';
  }
  return false;
}

/**
 * Validação de vídeo: MP4
 */
export function isVideoMp4(fileName: string, mimeType?: string): boolean {
  const name = fileName.toLowerCase();
  const isExt = name.endsWith('.mp4');
  if (isExt) return true;
  if (mimeType) {
    return mimeType.toLowerCase() === 'video/mp4';
  }
  return false;
}

/**
 * Validação de tamanho máximo de 33 MB
 */
export function isFileSizeValid(sizeInBytes: number): boolean {
  return sizeInBytes <= MAX_FILE_SIZE_BYTES;
}

/**
 * Formata bytes legíveis
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}
