import admin from 'firebase-admin';
import path from 'path';
import fs from 'fs';

// Initialize Firebase Admin with credentials from the public folder
export function initFirebase() {
  if (admin.apps.length > 0) return admin.firestore();

  try {
    const keyPath = path.join(process.cwd(), 'public', 'firebase-key.json');
    if (fs.existsSync(keyPath)) {
      const serviceAccount = JSON.parse(fs.readFileSync(keyPath, 'utf8'));
      
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
      });
      console.log('Firebase injetado para o backend de vídeo');
      return admin.firestore();
    } else {
      console.warn("firebase-key.json not found in public folder");
    }
  } catch (error) {
    console.error("Erro ao iniciar Firebase:", error);
  }
  return null;
}

export const firestore = initFirebase();
