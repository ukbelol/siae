const fs = require('fs');

let t = fs.readFileSync('src/api/index.ts', 'utf8');

// Fix remaining db.prepare(...).run/all that had newlines or were untouched
t = t.replace(/db\.prepare\((['`][\s\S]+?['`])\)\s*\.run\((.*?)\);/g, "await db.query($1, [$2]);");
t = t.replace(/db\.prepare\((['`][\s\S]+?['`])\)\s*\.all\((.*?)\);/g, "(await db.query($1, [$2]))[0]");

// Some arrays need casting:
t = t.replace(/\)\[0\];/g, ")[0] as any[];");

// Fix specific map/forEach targets
t = t.replace(/const globalAvgs = \([^]+?\)\[0\]/g, "const globalAvgs = (await db.query(`SELECT type, AVG(strftime('%s', end_time) - strftime('%s', start_time)) / 60.0 as avg_mins FROM attendances WHERE house_id = ? AND status = 'completed' AND start_time IS NOT NULL AND end_time IS NOT NULL GROUP BY type`, [houseId]))[0] as any[]");
t = t.replace(/const queueStats = \([^]+?\)\[0\]/g, "const queueStats = (await db.query(`SELECT type as serviceName, SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waitingCount, SUM(CASE WHEN status = 'in_progress' OR status = 'called' THEN 1 ELSE 0 END) as inProgressCount, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedCount FROM attendances WHERE house_id = ? AND DATE(created_at) = ? GROUP BY type`, [houseId, todayStr]))[0] as any[]");
t = t.replace(/const scheduleStats = \([^]+?\)\[0\]/g, "const scheduleStats = (await db.query(`SELECT at.name as serviceName, SUM(CASE WHEN ts.status = 'scheduled' THEN 1 ELSE 0 END) as pendingSchedules, SUM(CASE WHEN ts.status = 'completed' THEN 1 ELSE 0 END) as completedSchedules FROM treatment_schedules ts JOIN assistance_types at ON ts.assistance_type_id = at.id WHERE at.house_id = ? AND ts.scheduled_date = ? GROUP BY at.name`, [houseId, todayStr]))[0] as any[]");

// Fix map on completed / pendingTypes / activeWaiters
t = t.replace(/\.all\(houseId, assistedId, today\)\.map/g, ".all(houseId, assistedId, today) as any[]).map");
t = t.replace(/\.all\(houseId, dateStr\)\.map/g, ".all(houseId, dateStr) as any[]).map");

// If `.map` is on `(await db.query(...))[0]` we need:
t = t.replace(/\)\[0\]\.map\(/g, ")[0] as any[]).map(");

// Check lastInsertRowid
t = t.replace(/\.lastInsertRowid/g, ".insertId");

// And for those .transaction calls
t = t.replace(/db\.transaction\(\(\) => \{([\s\S]*?)\}\)\(\);/g, `await (async () => {
    const conn = await db.getConnection();
    await conn.beginTransaction();
    try {
      $1
      await conn.commit();
    } catch(e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
})();`);

t = t.replace(/db\.transaction\(async \(\) => \{([\s\S]*?)\}\)\(\);/g, `await (async () => {
    const conn = await db.getConnection();
    await conn.beginTransaction();
    try {
      $1
      await conn.commit();
    } catch(e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
})();`);

// stmtCommand not found
t = t.replace(/const stmtCommand = `\n      UPDATE houses/g, "const stmtCommand = `UPDATE houses");

t = t.replace(/stmt\.run\(/g, "await db.query(stmt, ["); // since it's `const stmt = `
t = t.replace(/\(await db\.query\(stmtCommand, \[(.*?)\]\)\)\[0\];/g, "await db.query(stmtCommand, [$1]);");

fs.writeFileSync('src/api/index.ts', t);

// Fix backup.ts
let b = fs.readFileSync('src/lib/backup.ts', 'utf8');
b = b.replace(/export function getBackupConfig/g, "export async function getBackupConfig");
b = b.replace(/export function saveBackupConfig/g, "export async function saveBackupConfig");
b = b.replace(/db\.prepare\('SELECT(.*?)'\)\.get\(\)/g, "(await db.query('SELECT$1'))[0][0]");
b = b.replace(/db\.prepare\('INSERT(.*?)'\)\.run\((.*?)\)/g, "await db.query('INSERT$1', [$2])");
fs.writeFileSync('src/lib/backup.ts', b);
