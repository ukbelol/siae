# Chamasso v2.3.2 — Campanha de boas-vindas e apresentação em slides

## Nova campanha de aquisição
- Destaque principal: **60 minutos FREE** para novos cadastros elegíveis.
- Comunicação deixa claro que o benefício é único por CPF e convertido em PASQcoin conforme a regra da plataforma.
- CTA direto para entrada/cadastro no Chamasso.

## Apresentação moderna em slides
Após a vinheta, a tela de entrada passa a apresentar um carrossel automático com transição **fade + blur**, navegação manual, indicadores e layout responsivo.

Slides incluídos:
1. Promoção de 60 minutos free.
2. Chat com texto, áudio e vídeo.
3. Salas de vídeo e interação ao vivo.
4. Perfil social, capa e galeria de fotos/vídeos.
5. Amizades e chat 1x1.
6. Transmissões ao vivo.
7. Find Match com PASQUARED.
8. Carteira e consumo PASQcoin.
9. Segurança e privacidade.
10. Chamada final: “Não é só chat. É o seu novo point.”

## Experiência
- Rotação automática a cada 6,5 segundos.
- Botões anterior/próximo e seleção direta de slide.
- Efeito visual de fade, blur e leve escala.
- Mantida a vinheta de abertura, controles de áudio e opção de pular/rever.
