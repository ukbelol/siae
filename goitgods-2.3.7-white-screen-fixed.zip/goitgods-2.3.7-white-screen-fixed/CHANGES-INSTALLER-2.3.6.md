# GOITGODS 2.3.6 — Instalador idempotente

- Usuário `goitgods` existente não passa mais por `usermod`, evitando falha quando há processos ativos.
- PM2/serviço anterior é parado antes da limpeza e do build; `.pm2` não é removido pelo rsync.
- Porta interna 3100: o instalador identifica PIDs; encerra somente processos reconhecidos como GOITGODS e recusa matar processos externos.
- Porta SSH: detecção robusta via `sshd -T`, `/usr/sbin/sshd`, `sshd_config` e fallback 22, sem abortar por `pipefail`.
- Apache recebe `ServerName goitgods.pasquared.space` global via `conf-available`, eliminando AH00558.
