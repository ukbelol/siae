# Chamasso 2.1.1 — Imagem persistente de recuperação de perfil

- Cria automaticamente uma **imagem de recuperação individual por usuário** em `/var/lib/chamasso/profile-backups/<userId>/profile-image.json`.
- A imagem guarda cadastro/perfil social, saldo PASQcoin, posts, amizades, mensagens persistidas de salas e histórico de transações PASQcoin.
- Fotos, vídeos e áudios armazenados como `data:` permanecem dentro do snapshot; arquivos locais referenciados são copiados para a pasta `media/` do usuário.
- Escrita atômica (`.tmp` + rename) para reduzir risco de snapshot incompleto.
- Na inicialização após uma nova instalação, perfis ausentes são recuperados automaticamente a partir das imagens persistentes; mídias locais ausentes são repostas.
- O instalador cria `/var/lib/chamasso/profile-backups` fora do diretório do código, portanto atualizar/reinstalar a aplicação sem apagar `/var/lib/chamasso` preserva os perfis.
- Endpoint administrativo `POST /api/admin/profile-backup/create` permite forçar a atualização de todas as imagens ou de um `userId`.

## Regra operacional importante
Uma reinstalação do aplicativo não deve formatar/apagar o disco nem remover `/var/lib/chamasso`. Para desastre de disco físico, é necessário também replicar essa pasta para outro volume/servidor/nuvem.
