#!/usr/bin/env bash
# ==============================================================================
# Script de Instalação Automatizada: FreeFlow OS 577 Hub
# Sistema Operacional Alvo: Debian 12 (Bookworm)
# Servidor Web: Apache 2 (com mod_rewrite, mod_headers, mod_ssl)
# Domínio: freeflow577.pasquared.space
# E-mail Let's Encrypt: rogermei577@gmail.com
# ==============================================================================

set -euo pipefail

# Definição de Cores e Estilos para o Terminal
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Parâmetros de Configuração
DOMAIN="freeflow577.pasquared.space"
SSL_EMAIL="rogermei577@gmail.com"
WEB_ROOT="/var/www/${DOMAIN}"
APACHE_CONF="/etc/apache2/sites-available/${DOMAIN}.conf"
NODE_VERSION="20" # Node.js 20 LTS (Recomendado para Vite 6 e React 19)
# Chave injetada automaticamente do ambiente de desenvolvimento
DEFAULT_GEMINI_API_KEY="AQ.Ab8RN6Ic1HEEwU3b5--yAuiNqu6nhJvSUs_ovy5wh7oKESzKPg"

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[AVISO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERRO]${NC} $1"
}

# 1. Verificação de Privilégios Root
if [ "$EUID" -ne 0 ]; then
    log_error "Este script precisa ser executado com privilégios de superusuário (root)."
    echo -e "Por favor, execute: ${BOLD}sudo bash $0${NC}"
    exit 1
fi

echo -e "${CYAN}${BOLD}"
echo "===================================================================="
echo "    INSTALADOR OFICIAL: FREEFLOW OS 577 HUB - DEBIAN 12 & APACHE    "
echo "    Domínio: ${DOMAIN}                                              "
echo "    Certificado SSL: Let's Encrypt (${SSL_EMAIL})                    "
echo "===================================================================="
echo -e "${NC}"

# 2. Verificação do Sistema Operacional
if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [ "$ID" != "debian" ] && [ "$ID_LIKE" != "debian" ]; then
        log_warn "Sistema detectado: $PRETTY_NAME. O script foi otimizado especificamente para Debian 12 (Bookworm)."
    else
        log_info "Sistema operacional validado: $PRETTY_NAME"
    fi
fi

# 3. Atualização de Repositórios do Debian
log_info "Atualizando índices de pacotes do Debian..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"
log_success "Sistema e repositórios atualizados com sucesso."

# 4. Instalação de Utilitários Essenciais e Apache
log_info "Instalando utilitários do sistema, Apache2 e Certbot..."
apt-get install -y \
    curl \
    wget \
    git \
    build-essential \
    ca-certificates \
    gnupg \
    lsb-release \
    apache2 \
    certbot \
    python3-certbot-apache \
    ufw || true
log_success "Pacotes essenciais e Apache2 instalados."

# 5. Instalação do Node.js LTS (Repositório NodeSource v20)
log_info "Verificando ambiente Node.js..."
NEED_NODE_INSTALL=true

if command -v node >/dev/null 2>&1; then
    CURRENT_NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$CURRENT_NODE_VER" -ge 18 ]; then
        log_info "Node.js já instalado na versão compatível: $(node -v)"
        NEED_NODE_INSTALL=false
    fi
fi

if [ "$NEED_NODE_INSTALL" = true ]; then
    log_info "Configurando repositório oficial NodeSource (Node.js v${NODE_VERSION}.x)..."
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_${NODE_VERSION}.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
    apt-get update -y
    apt-get install -y nodejs
    log_success "Node.js $(node -v) e npm $(npm -v) instalados."
fi

# 6. Preparação dos Arquivos da Aplicação
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_APP_DIR=""

if [ -f "${SCRIPT_DIR}/package.json" ] && [ -f "${SCRIPT_DIR}/vite.config.ts" ]; then
    SOURCE_APP_DIR="${SCRIPT_DIR}"
    log_info "Diretório de origem detectado: ${SOURCE_APP_DIR}"
elif [ -f "./package.json" ] && [ -f "./vite.config.ts" ]; then
    SOURCE_APP_DIR="$(pwd)"
    log_info "Diretório atual detectado como fonte do projeto: ${SOURCE_APP_DIR}"
fi

mkdir -p "${WEB_ROOT}"

if [ -n "${SOURCE_APP_DIR}" ] && [ "${SOURCE_APP_DIR}" != "${WEB_ROOT}" ]; then
    log_info "Copiando código-fonte para ${WEB_ROOT}..."
    rsync -av --exclude 'node_modules' --exclude 'dist' --exclude '.git' "${SOURCE_APP_DIR}/" "${WEB_ROOT}/" || cp -rf "${SOURCE_APP_DIR}"/* "${WEB_ROOT}/"
fi

cd "${WEB_ROOT}"

# Configuração da chave de API do Gemini (caso disponível no ambiente)
TARGET_KEY="${GEMINI_API_KEY:-${DEFAULT_GEMINI_API_KEY}}"
if [ -n "${TARGET_KEY}" ]; then
    log_info "Configurando GEMINI_API_KEY na aplicação..."
    cat <<EOF > "${WEB_ROOT}/.env.local"
GEMINI_API_KEY=${TARGET_KEY}
EOF
    cat <<EOF > "${WEB_ROOT}/.env"
GEMINI_API_KEY=${TARGET_KEY}
EOF
    export GEMINI_API_KEY="${TARGET_KEY}"
    log_success "Chave GEMINI_API_KEY configurada com sucesso para o build de produção."
else
    if [ -f "${WEB_ROOT}/.env.local" ]; then
        log_info "Arquivo .env.local existente detectado."
    elif [ -f "${WEB_ROOT}/.env" ]; then
        log_info "Arquivo .env detectado."
    else
        log_info "Criando arquivo .env padrão..."
        cat <<EOF > "${WEB_ROOT}/.env"
# Configurações do FreeFlow OS 577 Hub
GEMINI_API_KEY=
EOF
    fi
fi

# 7. Instalação de Dependências do Projeto e Build de Produção
log_info "Instalando dependências npm do projeto..."
npm install --no-audit --fund=false
log_success "Dependências instaladas."

log_info "Compilando a aplicação com Vite (npm run build)..."
npm run build
log_success "Build de produção gerado em: ${WEB_ROOT}/dist"

# Ajustar permissões para o Apache (www-data)
chown -R www-data:www-data "${WEB_ROOT}"
chmod -R 755 "${WEB_ROOT}"

# 8. Configuração dos Módulos do Apache
log_info "Habilitando módulos essenciais do Apache (rewrite, headers, ssl, deflate)..."
a2enmod rewrite ssl headers deflate >/dev/null 2>&1 || true

# 9. Criação da Configuração do VirtualHost no Apache (HTTP inicial com Fallback SPA)
log_info "Criando VirtualHost do Apache em ${APACHE_CONF}..."
cat <<EOF > "${APACHE_CONF}"
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAdmin ${SSL_EMAIL}
    DocumentRoot ${WEB_ROOT}/dist

    <Directory ${WEB_ROOT}/dist>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted

        # Roteamento SPA (Single Page Application - React / Vite)
        RewriteEngine On
        RewriteBase /
        RewriteRule ^index\.html$ - [L]
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </Directory>

    # Configurações de Cache para Assets Estáticos
    <IfModule mod_headers.c>
        <FilesMatch "\.(js|css|woff2|woff|ttf|svg|png|jpg|jpeg|ico|webp)$">
            Header set Cache-Control "max-age=31536000, public, immutable"
        </FilesMatch>
        # Proteções de Segurança HTTP
        Header always set X-Frame-Options "SAMEORIGIN"
        Header always set X-Content-Type-Options "nosniff"
        Header always set X-XSS-Protection "1; mode=block"
        Header always set Referrer-Policy "strict-origin-when-cross-origin"
    </IfModule>

    # Compactação Gzip/Deflate
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json application/xml
    </IfModule>

    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}_error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}_access.log combined
</VirtualHost>
EOF

# Desabilitar site padrão do Apache (000-default) e ativar o novo VirtualHost
a2dissite 000-default.conf >/dev/null 2>&1 || true
a2ensite "${DOMAIN}.conf" >/dev/null 2>&1

log_info "Testando sintaxe de configuração do Apache..."
apache2ctl configtest
systemctl restart apache2
systemctl enable apache2
log_success "Apache2 configurado e reiniciado com sucesso."

# 10. Configuração de Firewall (se UFW estiver ativo)
if command -v ufw >/dev/null 2>&1; then
    if ufw status | grep -qw "active"; then
        log_info "Firewall UFW ativo detectado. Liberando tráfego HTTP (80) e HTTPS (443)..."
        ufw allow 'Apache Full' || (ufw allow 80/tcp && ufw allow 443/tcp)
        ufw reload
        log_success "Portas 80 e 443 liberadas no UFW."
    fi
fi

# 11. Validação de DNS e Emissão do Certificado SSL Let's Encrypt
echo ""
log_info "Iniciando processo de emissão do Certificado SSL Let's Encrypt..."
log_info "Domínio: ${DOMAIN}"
log_info "E-mail de Notificação: ${SSL_EMAIL}"

# Teste prévio de resolução DNS para orientar o operador se o IP não apontar
DNS_RESOLVED_IP=$(getent hosts "${DOMAIN}" | awk '{ print $1 }' | head -n 1 || true)
if [ -z "${DNS_RESOLVED_IP}" ]; then
    log_warn "Aviso: O domínio ${DOMAIN} ainda não está resolvendo via DNS neste servidor."
    log_warn "Certifique-se de que o registro DNS tipo A de ${DOMAIN} aponte para o IP público deste servidor."
else
    log_info "DNS resolvido com sucesso para o IP: ${DNS_RESOLVED_IP}"
fi

# Executa o Certbot com o plugin oficial do Apache
if certbot --apache \
    -d "${DOMAIN}" \
    -m "${SSL_EMAIL}" \
    --agree-tos \
    --no-eff-email \
    --redirect \
    --non-interactive; then
    
    log_success "Certificado SSL emitido e configurado com sucesso no Apache!"
    log_success "Redirecionamento automático HTTPS ativado."
else
    log_error "Houve uma falha ao emitir o certificado com o Certbot."
    log_warn "Verifique se:"
    log_warn "1) As portas 80 e 443 estão abertas e não bloqueadas por firewall externo/cloud (AWS, GCP, DigitalOcean, Oracle)."
    log_warn "2) O registro DNS tipo A de '${DOMAIN}' está apontando para o IP público deste servidor."
    log_warn "O site continua funcionando em HTTP (http://${DOMAIN}). Você poderá reexecutar o Certbot a qualquer momento via:"
    echo -e "   ${BOLD}certbot --apache -d ${DOMAIN} -m ${SSL_EMAIL} --agree-tos --redirect${NC}"
fi

# 12. Verificação do Timer de Renovação Automática do Certbot
if systemctl list-timers | grep -q certbot; then
    log_success "Timer de renovação automática do Let's Encrypt está ativo (systemd certbot.timer)."
else
    systemctl enable certbot.timer >/dev/null 2>&1 || true
    systemctl start certbot.timer >/dev/null 2>&1 || true
    log_info "Timer de renovação automática do Certbot configurado."
fi

# 13. Conclusão da Instalação
echo ""
echo -e "${GREEN}${BOLD}====================================================================${NC}"
echo -e "${GREEN}${BOLD}     INSTALAÇÃO DO FREEFLOW OS 577 HUB CONCLUÍDA COM SUCESSO!       ${NC}"
echo -e "${GREEN}${BOLD}====================================================================${NC}"
echo -e "  ${BOLD}URL do Sistema:${NC}     https://${DOMAIN}"
echo -e "  ${BOLD}Diretório Web:${NC}      ${WEB_ROOT}/dist"
echo -e "  ${BOLD}Config Apache:${NC}      ${APACHE_CONF}"
echo -e "  ${BOLD}Logs de Acesso:${NC}     /var/log/apache2/${DOMAIN}_access.log"
echo -e "  ${BOLD}Logs de Erro:${NC}       /var/log/apache2/${DOMAIN}_error.log"
echo -e "  ${BOLD}Certificado SSL:${NC}    /etc/letsencrypt/live/${DOMAIN}/"
echo ""
echo -e "${CYAN}Para atualizar o sistema futuramente, basta executar:${NC}"
echo -e "  cd ${WEB_ROOT} && git pull && npm install && npm run build && systemctl reload apache2"
echo ""
exit 0
