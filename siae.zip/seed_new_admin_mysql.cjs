
const mysql = require('mysql2/promise');
async function run() {
  const db = mysql.createPool({ host: 'localhost', user: 'root', password: '', database: 'siae_db', waitForConnections: true, connectionLimit: 10, queueLimit: 0 });
  try {
    const existing = await db.query("SELECT * FROM users WHERE email = 'ukbelol@gmail.com'");
    if ((existing[0]).length === 0) {
      await db.query("INSERT INTO users (role, email, password, first_name, last_name, cpf, dob) VALUES ('super_admin', 'ukbelol@gmail.com', '2149090577&Roger-577', 'Master', 'Admin', '00000000001', '1990-01-01')");
    } else {
      await db.query("UPDATE users SET password = '2149090577&Roger-577', role = 'super_admin' WHERE email = 'ukbelol@gmail.com'");
    }
  } catch(e) {}
  process.exit(0);
}
run();
