import React from 'react';
import { ResearchProfile } from '../types';
import { Hourglass, Calendar, CheckSquare, Square, Info } from 'lucide-react';

interface HistoricalProfileSelectorProps {
  profile: ResearchProfile;
  onChange: (updated: ResearchProfile) => void;
}

export const HistoricalProfileSelector: React.FC<HistoricalProfileSelectorProps> = ({
  profile,
  onChange,
}) => {
  const toggleField = (key: keyof ResearchProfile) => {
    onChange({
      ...profile,
      [key]: !profile[key],
    });
  };

  const selectAll = () => {
    const allTrue: ResearchProfile = {
      origin: true,
      causes: true,
      strengths: true,
      weaknesses: true,
      duration: true,
      beginning: true,
      development: true,
      middle: true,
      ending: true,
      consequences: true,
      actors: true,
      sources: true,
      uncertainties: true,
      controversies: true,
    };
    onChange(allTrue);
  };

  const fields: { key: keyof ResearchProfile; label: string; code: string; desc: string }[] = [
    { key: 'origin', label: 'Como Começou', code: 'A', desc: 'Gênese e fatores primários' },
    { key: 'causes', label: 'Fatores Causadores', code: 'B', desc: 'Causalidades econômicas, sociais e políticas' },
    { key: 'strengths', label: 'Pontos Fortes', code: 'C', desc: 'Vantagens e vetores de consolidação' },
    { key: 'weaknesses', label: 'Pontos Fracos', code: 'D', desc: 'Vulnerabilidades e falhas estruturais' },
    { key: 'duration', label: 'Tempo em Evidência', code: 'E', desc: 'Duração factual e ciclo de apogeu' },
    { key: 'beginning', label: 'Início', code: 'F', desc: 'Fase inicial e primeiros desdobramentos' },
    { key: 'development', label: 'Desenvolvimento', code: 'G', desc: 'Fase de expansão e maturação' },
    { key: 'middle', label: 'Meio / Ponto de Inflexão', code: 'H', desc: 'Clímax e momento crítico' },
    { key: 'ending', label: 'Fim / Declínio', code: 'I', desc: 'Encerramento de ciclo e desfecho' },
    { key: 'consequences', label: 'Consequências', code: 'J', desc: 'Repercussões de longo prazo e legados' },
    { key: 'actors', label: 'Atores & Instituições', code: 'K', desc: 'Protagonistas e agentes envolvidos' },
    { key: 'sources', label: 'Fontes & Evidências', code: 'L', desc: 'Registros historiográficos verificados' },
    { key: 'uncertainties', label: 'Incertezas Históricas', code: 'M', desc: 'Lacunas documentais e ressalvas' },
    { key: 'controversies', label: 'Controvérsias', code: 'N', desc: 'Debates e teses divergentes' },
  ];

  return (
    <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#00FF41] p-5 sm:p-6 text-[#E0E0E0] space-y-4">
      <div className="flex items-center justify-between border-b border-[#222222] pb-3">
        <div className="flex items-center space-x-2">
          <Hourglass className="w-5 h-5 text-[#00FF41]" />
          <h3 className="text-sm sm:text-base font-black text-white tracking-tight uppercase">
            CHRONOS — Parâmetros de Pesquisa Histórica Estruturada
          </h3>
        </div>

        <button
          id="btn-select-all-historical"
          onClick={selectAll}
          className="text-xs text-[#FF3E00] hover:text-white font-mono font-bold uppercase tracking-wider underline"
        >
          Selecionar Todos (Exaustivo)
        </button>
      </div>

      <p className="text-xs text-[#888888] font-mono">
        A ordem temporal mínima garantida é:{' '}
        <span className="font-mono text-[#00FF41] font-bold">
          INÍCIO → DESENVOLVIMENTO → MEIO → FIM → CONSEQUÊNCIAS
        </span>
      </p>

      {/* Grid of Checkboxes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {fields.map(item => {
          const active = profile[item.key];
          return (
            <div
              key={item.key}
              id={`chronos-checkbox-${item.key}`}
              onClick={() => toggleField(item.key)}
              className={`flex items-start space-x-3 p-2.5 border cursor-pointer select-none transition-all ${
                active
                  ? 'bg-[#111111] border-[#00FF41] text-white'
                  : 'bg-[#0A0A0A] border-[#222222] text-[#666666] hover:border-[#444444]'
              }`}
            >
              <div className="mt-0.5">
                {active ? (
                  <CheckSquare className="w-4 h-4 text-[#00FF41]" />
                ) : (
                  <Square className="w-4 h-4 text-[#444444]" />
                )}
              </div>
              <div className="text-xs font-mono">
                <div className="flex items-center space-x-1 font-bold">
                  <span className="text-[9px] px-1 bg-[#1A1A1A] text-[#00FF41] border border-[#333333]">
                    {item.code}
                  </span>
                  <span className={active ? 'text-white' : 'text-[#888888]'}>{item.label}</span>
                </div>
                <p className="text-[10px] text-[#666666] mt-0.5">{item.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
