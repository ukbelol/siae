const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

console.log("Index 229:", lines[228]);
console.log("Index 239:", lines[238]);
console.log("Index 1079:", lines[1078]);
console.log("Index 1143:", lines[1142]);

let bLines = fs.readFileSync('src/lib/backup.ts', 'utf8').split('\n');
console.log("Backup 20:", bLines[19]);
