# Validação 2.3.0

Foi executado `tsc --noEmit`. O ambiente de geração não contém `node_modules`, portanto o compilador reportou módulos ausentes (React, Express, tipos Node, Vite e dependências já declaradas em `package.json`). Não foram observados erros adicionais específicos nas novas rotas/serviço antes da interrupção por dependências ausentes.

No ambiente de destino execute:

```bash
npm install
npm run lint
npm run build
```

Depois configure o Microsoft Foundry pelo Super Admin e use **Testar conexão** antes do provisionamento.
