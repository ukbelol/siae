import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../lib/db.js';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import adminRoutes from './admin.js';
import { firestore } from '../lib/firebase.js';
import admin from 'firebase-admin';
import { getClientIp, recordFailedAttempt, recordSuccessfulLogin, getBlockedIpsList, getFirewallLogsList, unblockIp, clearAllBlockedIps } from '../lib/firewall.js';

const router = Router();
router.use('/admin', adminRoutes);

const JWT_SECRET = process.env.JWT_SECRET || 'siae-super-secret-key';

// SSE Notification System
const connectedClients = new Map<number, any>();

export const notifyUser = (userId: number, type: string, message: string, data?: any) => {
  const client = connectedClients.get(userId);
  if (client) {
    client.write(`data: ${JSON.stringify({ type, message, data })}\n\n`);
  }
};

// Temp route for manual alter
router.get('/temp-alter', async (req, res) => {
  try {
    await db.query('ALTER TABLE nfc_tags MODIFY activation_date VARCHAR(50)');
    await db.query('ALTER TABLE nfc_tags MODIFY serial_number VARCHAR(60)');
    await db.query('ALTER TABLE users MODIFY nfc_tag VARCHAR(60)');
    res.json({ message: "Altered successfully" });
  } catch(e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/notifications/stream', async (req, res) => {
  // Extract userId from token or query
  const token = req.query.token as string;
  if (!token) return res.status(401).end();

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const userId = decoded.id;

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    // Keep alive pings
    const pingInterval = setInterval(() => {
      res.write(': ping\n\n');
    }, 15000);

    connectedClients.set(userId, res);

    req.on('close', () => {
      clearInterval(pingInterval);
      connectedClients.delete(userId);
    });
  } catch (error) {
    res.status(401).end();
  }
});

// Auth Routes
router.post('/auth/register', async (req, res) => {
  const { role, email, password, firstName, lastName, cpf, dob, age, religion, phone, street, number, neighborhood, city, state, country, skills, specializations, profession, photo_url } = req.body;
  
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const stmt = `
      INSERT INTO users (role, email, password, first_name, last_name, cpf, dob, age, religion, phone, street, number, neighborhood, city, state, country, skills, specializations, profession, photo_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const [info] = await db.query(stmt, [role, email, hashedPassword, firstName, lastName, cpf, dob, age, religion, phone, street, number, neighborhood, city, state, country, skills, specializations, profession, photo_url || null]) as any;

    
    const token = jwt.sign({ id: Number((info as any).insertId), role }, JWT_SECRET, { expiresIn: '1d' });
    
    res.json({ token, user: { id: Number((info as any).insertId), role, email, firstName, lastName } });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const clientIp = getClientIp(req);
  
  try {
    const user = (await db.query('SELECT * FROM users WHERE email = ?', [email]))[0][0] as any;
    
    if (!user) {
      const result = await recordFailedAttempt(clientIp, email, '/auth/login');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Credenciais inválidas (Tentativa ${result.attempts} de 2)` });
    }
    
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      const result = await recordFailedAttempt(clientIp, email, '/auth/login');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Credenciais inválidas (Tentativa ${result.attempts} de 2)` });
    }
    
    recordSuccessfulLogin(clientIp);
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1d' });
    
    res.json({ token, user: { id: user.id, role: user.role, email: user.email, firstName: user.first_name, lastName: user.last_name, phone: user.phone, city: user.city, photo_url: user.photo_url } });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/auth/login-supersu', async (req, res) => {
  const { email, password } = req.body;
  const clientIp = getClientIp(req);

  try {
    const user = (await db.query('SELECT * FROM users WHERE email = ? AND role = ?', [email, 'super_admin']))[0][0] as any;
    if (!user) {
      const result = await recordFailedAttempt(clientIp, email, '/auth/login-supersu');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Credenciais inválidas (Tentativa ${result.attempts} de 2)` });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      const result = await recordFailedAttempt(clientIp, email, '/auth/login-supersu');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Credenciais inválidas (Tentativa ${result.attempts} de 2)` });
    }

    recordSuccessfulLogin(clientIp);

    if (user.force_password_change) {
      return res.json({ forcePasswordChange: true });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1d' });
    res.json({ token, user: { id: user.id, role: user.role, email: user.email, firstName: user.first_name, lastName: user.last_name } });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/auth/change-password-supersu', async (req, res) => {
  const { email, currentPassword, newPassword } = req.body;
  const clientIp = getClientIp(req);

  try {
    const user = (await db.query('SELECT * FROM users WHERE email = ? AND role = ?', [email, 'super_admin']))[0][0] as any;
    if (!user) return res.status(401).json({ error: 'Credenciais inválidas' });

    const valid = await bcrypt.compare(currentPassword, user.password);
    if (!valid) {
      const result = await recordFailedAttempt(clientIp, email, '/auth/change-password-supersu');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Senha atual incorreta (Tentativa ${result.attempts} de 2)` });
    }

    recordSuccessfulLogin(clientIp);
    const newHashed = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE users SET password = ?, force_password_change = ? WHERE id = ?', [newHashed, 0, user.id]);

    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1d' });
    res.json({ token, user: { id: user.id, role: user.role, email: user.email, firstName: user.first_name, lastName: user.last_name } });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/auth/change-password', async (req, res) => {
  const { userId, currentPassword, newPassword } = req.body;
  const clientIp = getClientIp(req);

  try {
    const user = (await db.query('SELECT * FROM users WHERE id = ?', [userId]))[0][0] as any;
    if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

    const valid = await bcrypt.compare(currentPassword, user.password);
    if (!valid) {
      const result = await recordFailedAttempt(clientIp, user.email || 'user', '/auth/change-password');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(400).json({ error: `Senha atual incorreta (Tentativa ${result.attempts} de 2)` });
    }

    recordSuccessfulLogin(clientIp);
    const newHashed = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE users SET password = ? WHERE id = ?', [newHashed, userId]);

    res.json({ success: true, message: 'Senha alterada com sucesso!' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/auth/login-terminal', async (req, res) => {
  const { cpf, password } = req.body;
  const clientIp = getClientIp(req);

  try {
    const user = (await db.query('SELECT * FROM users WHERE cpf = ? AND role = ?', [cpf, 'representative']))[0][0] as any;
    if (!user) {
      const result = await recordFailedAttempt(clientIp, cpf, '/auth/login-terminal');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Credenciais inválidas (Tentativa ${result.attempts} de 2)` });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      const result = await recordFailedAttempt(clientIp, cpf, '/auth/login-terminal');
      if (result.isBlocked) {
        return res.status(403).json({
          error: `[FIREWALL SIAE] IP (${clientIp}) BLOQUEADO! O sistema detectou 2 tentativas incorretas de senha.`,
          firewallBlocked: true
        });
      }
      return res.status(401).json({ error: `Credenciais inválidas (Tentativa ${result.attempts} de 2)` });
    }

    recordSuccessfulLogin(clientIp);

    const house = (await db.query('SELECT id, name FROM houses WHERE representative_id = ?', [user.id]))[0][0] as any;
    if (!house) return res.status(400).json({ error: 'Nenhuma casa espírita vinculada a este representante' });

    const token = jwt.sign({ id: user.id, role: 'terminal', houseId: house.id }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, houseId: house.id, houseName: house.name });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Firewall Security Management Endpoints
router.get('/admin/firewall/status', async (req, res) => {
  try {
    const blockedIps = await getBlockedIpsList();
    const logs = await getFirewallLogsList(50);
    res.json({
      active: true,
      maxAttempts: 2,
      blockedCount: blockedIps.length,
      blockedIps,
      logs
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/admin/firewall/unblock', async (req, res) => {
  try {
    const { ip } = req.body;
    if (!ip) return res.status(400).json({ error: 'Endereço IP é obrigatório' });
    await unblockIp(ip);
    res.json({ success: true, message: `IP ${ip} desbloqueado com sucesso!` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/admin/firewall/clear', async (req, res) => {
  try {
    await clearAllBlockedIps();
    res.json({ success: true, message: 'Todos os IPs foram desbloqueados com sucesso!' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Houses Routes
router.get('/houses/search', async (req, res) => {
  try {
    const { term, service, time } = req.query;
    let query = 'SELECT DISTINCT h.* FROM houses h WHERE 1=1';
    const params: any[] = [];

    if (term) {
      query += ` AND (h.name LIKE ? OR h.neighborhood LIKE ? OR h.city LIKE ? OR h.state LIKE ? OR h.country LIKE ?)`;
      for(let i=0; i<5; i++) params.push(`%${term}%`);
    }

    if (service) {
      query += ` AND h.services LIKE ?`;
      params.push(`%${service}%`);
    }

    if (time) {
      query += ` AND h.operating_hours LIKE ?`;
      params.push(`%${time}%`);
    }

    const houses = (await db.query(query, params))[0] as any[];
    res.json(houses);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/workers/link', async (req, res) => {
  try {
    const { workerId } = req.body;
    await db.query('INSERT IGNORE INTO house_workers (house_id, worker_id, status) VALUES (?, ?, ?)', [req.params.houseId, workerId, 'pending']);

    res.json({ success: true, message: 'Solicitação de vínculo enviada.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/assisted/link', async (req, res) => {
  try {
    const { assistedId } = req.body;
    await db.query('INSERT IGNORE INTO house_assisted (house_id, assisted_id, status) VALUES (?, ?, ?)', [req.params.houseId, assistedId, 'active']);
    res.json({ success: true, message: 'Associação realizada com sucesso.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Worker Sessions (Ponto)
router.post('/worker/session/nfc', async (req, res) => {
  try {
    const { houseId, nfcTag, workerId } = req.body;
    
    // Find worker by NFC or ID
    let worker;
    if (nfcTag) {
      worker = (await db.query('SELECT id, first_name, role FROM users WHERE nfc_tag = ?', [nfcTag]))[0][0] as any;
    } else if (workerId) {
      worker = (await db.query('SELECT id, first_name, role FROM users WHERE id = ?', [workerId]))[0][0] as any;
    }

    if (!worker || worker.role !== 'worker') {
      return res.status(404).json({ error: 'Trabalhador não encontrado.' });
    }

    // Check active session
    const session = (await db.query('SELECT * FROM worker_sessions WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL', [worker.id, houseId]))[0][0] as any;

    if (!session) {
      // Clock in
      const [info] = await db.query('INSERT INTO worker_sessions (worker_id, house_id, status) VALUES (?, ?, ?)', [worker.id, houseId, 'offline']); // Starts offline, needs to confirm availability
      return res.json({ action: 'clock_in', sessionId: Number((info as any).insertId), worker });
    } else {
      // Already clocked in, prompt for status change or clock out
      return res.json({ action: 'prompt_status', session, worker });
    }
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});



// Reports (Relatos) and Triage
router.post('/houses/:houseId/assisted/:assistedId/reports', async (req, res) => {
  try {
    const { problemDescription } = req.body;
    const [info] = await db.query('INSERT INTO assistance_requests (house_id, assisted_id, problem_description, duration, status) VALUES (?, ?, ?, ?, ?)', [req.params.houseId, req.params.assistedId, problemDescription, 'N/A', 'pending']);
    res.json({ id: Number((info as any).insertId), success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/assisted/:assistedId/reports', async (req, res) => {
  try {
    const reports = (await db.query('SELECT * FROM assistance_requests WHERE house_id = ? AND assisted_id = ? ORDER BY created_at DESC', [req.params.houseId, req.params.assistedId]))[0] as any[];

    res.json(reports);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/pending-reports', async (req, res) => {
  try {
    const reports = (await db.query(`
      SELECT ar.*, u.first_name, u.last_name, u.email, u.phone 
      FROM assistance_requests ar
      JOIN users u ON ar.assisted_id = u.id
      WHERE ar.house_id = ? AND ar.status = 'pending'
      ORDER BY ar.created_at ASC
    `, [req.params.houseId]))[0] as any[];
    res.json(reports);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/reports/:reportId/triage', async (req, res) => {
  try {
    const { status, treatmentPlan, totalSessions, targetTreatments } = req.body;
    await db.query('UPDATE assistance_requests SET status = ?, treatment_plan = ?, total_sessions = ?, target_treatments = ? WHERE id = ? AND house_id = ?', [status, treatmentPlan, totalSessions || 1, targetTreatments || null, req.params.reportId, req.params.houseId]);
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/reports/:reportId/schedule', async (req, res) => {
  try {
    const { assistanceTypeId, scheduledDate, scheduledTime } = req.body;
    const [info] = await db.query('INSERT INTO treatment_schedules (assistance_request_id, assistance_type_id, scheduled_date, scheduled_time) VALUES (?, ?, ?, ?)', [req.params.reportId, assistanceTypeId, scheduledDate, scheduledTime]);
    res.json({ id: Number((info as any).insertId), success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/rep/:repId', async (req, res) => {
  try {
    const house = (await db.query('SELECT * FROM houses WHERE representative_id = ?', [req.params.repId]))[0][0];
    res.json(house || null);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/realtime-stats', async (req, res) => {
  try {
    const today = new Date().toLocaleString("en-US", {timeZone: "America/Sao_Paulo"}).split(',')[0].split('/').reverse().join('-'); // rough format, but let's use standard Date ISO better
    
    // Better way to get YYYY-MM-DD
    const d = new Date();
    const todayStr = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');

    const { houseId } = req.params;

    // 1. Get average times globally for each service as a baseline
    // strftime('%s', end_time) - strftime('%s', start_time) is time in seconds
    const globalAvgs = (await db.query(`SELECT type, AVG(strftime('%s', end_time) - strftime('%s', start_time)) / 60.0 as avg_mins FROM attendances WHERE house_id = ? AND status = 'completed' AND start_time IS NOT NULL AND end_time IS NOT NULL GROUP BY type`, [houseId]))[0] as any[] as any[];
    
    const avgMap = new Map();
    globalAvgs.forEach((row: any) => avgMap.set(row.type, row.avg_mins || 15)); // Default 15 min

    // 2. Queue stats by service (using attendances for today)
    const queueStats = (await db.query(`SELECT type as serviceName, SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waitingCount, SUM(CASE WHEN status = 'in_progress' OR status = 'called' THEN 1 ELSE 0 END) as inProgressCount, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedCount FROM attendances WHERE house_id = ? AND DATE(created_at) = ? GROUP BY type`, [houseId, todayStr]))[0] as any[] as any[];

    // 3. Treatment schedules for today
    const scheduleStats = (await db.query(`SELECT at.name as serviceName, SUM(CASE WHEN ts.status = 'scheduled' THEN 1 ELSE 0 END) as pendingSchedules, SUM(CASE WHEN ts.status = 'completed' THEN 1 ELSE 0 END) as completedSchedules FROM treatment_schedules ts JOIN assistance_types at ON ts.assistance_type_id = at.id WHERE at.house_id = ? AND ts.scheduled_date = ? GROUP BY at.name`, [houseId, todayStr]))[0] as any[] as any[];

    // Combine data
    const servicesMap = new Map<string, any>();
    
    // Initialize with assistance_types to make sure all active services show up
    const allTypes = (await db.query('SELECT name FROM assistance_types WHERE house_id = ?', [houseId]))[0] as any[];
    allTypes.forEach((t: any) => {
      servicesMap.set(t.name, {
        serviceName: t.name,
        waitingCount: 0,
        inProgressCount: 0,
        completedCount: 0,
        pendingSchedules: 0,
        completedSchedules: 0,
        avgTimeMinutes: avgMap.get(t.name) || 15
      });
    });

    queueStats.forEach((q: any) => {
      if (!servicesMap.has(q.serviceName)) {
        servicesMap.set(q.serviceName, {
          serviceName: q.serviceName,
          waitingCount: 0,
          inProgressCount: 0,
          completedCount: 0,
          pendingSchedules: 0,
          completedSchedules: 0,
          avgTimeMinutes: avgMap.get(q.serviceName) || 15
        });
      }
      const s = servicesMap.get(q.serviceName);
      s.waitingCount = q.waitingCount || 0;
      s.inProgressCount = q.inProgressCount || 0;
      s.completedCount = q.completedCount || 0;
    });

    scheduleStats.forEach((s: any) => {
      if (servicesMap.has(s.serviceName)) {
        const item = servicesMap.get(s.serviceName);
        item.pendingSchedules = s.pendingSchedules || 0;
        item.completedSchedules = s.completedSchedules || 0;
      }
    });

    const services = Array.from(servicesMap.values()).map(s => ({
      ...s,
      estimatedWaitTime: s.waitingCount * Math.round(s.avgTimeMinutes)
    }));

    const totalWaiting = services.reduce((acc, curr) => acc + curr.waitingCount, 0);
    const totalPendingSchedules = services.reduce((acc, curr) => acc + curr.pendingSchedules, 0);

    res.json({
      totalWaiting,
      totalPendingSchedules,
      services
    });

  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/users/:userId/houses', async (req, res) => {
  try {
    const userRole = (await db.query('SELECT role FROM users WHERE id = ?', [req.params.userId]))[0][0] as { role: string };
    if (userRole?.role === 'assisted') {
      const houses = (await db.query(`
        SELECT h.* FROM houses h
        JOIN house_assisted ha ON h.id = ha.house_id
        WHERE ha.assisted_id = ? AND ha.status = 'active'
      `, [req.params.userId]))[0] as any[];
      return res.json(houses);
    } else {
      const houses = (await db.query(`
        SELECT h.* FROM houses h
        JOIN house_workers hw ON h.id = hw.house_id
        WHERE hw.worker_id = ? AND hw.status = 'active'
      `, [req.params.userId]))[0] as any[];
      return res.json(houses);
    }
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/workers', async (req, res) => {
  try {
    const workers = (await db.query(`
      SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.skills, u.specializations, u.dob, u.street, u.city, u.state, hw.status,
      (SELECT COUNT(*) FROM attendances a WHERE a.worker_id = u.id AND a.house_id = ?) as attendances_count
      FROM users u
      JOIN house_workers hw ON u.id = hw.worker_id
      WHERE hw.house_id = ?
    `, [req.params.houseId, req.params.houseId]))[0] as any[];
    res.json(workers);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/workers/:workerId/status', async (req, res) => {
  try {
    await db.query('UPDATE house_workers SET status = ? WHERE house_id = ? AND worker_id = ?', [req.body.status, req.params.houseId, req.params.workerId]);
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/assisted', async (req, res) => {
  try {
    const assisted = (await db.query(`
      SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.dob, u.street, u.city, u.state, ha.status
      FROM users u
      JOIN house_assisted ha ON u.id = ha.assisted_id
      WHERE ha.house_id = ?
    `, [req.params.houseId]))[0] as any[];
    res.json(assisted);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/users/:id', async (req, res) => {
  try {
    const user = (await db.query('SELECT id, first_name, last_name, role, email, recommendations FROM users WHERE id = ?', [req.params.id]))[0][0];
    res.json(user);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/assisted/:assistedId/recommendations', async (req, res) => {
  try {
    const { recommendations } = req.body;
    (await db.query('UPDATE users SET recommendations = ? WHERE id = ?', [recommendations || null, req.params.assistedId]))[0] as any[];
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/assisted/:assistedId/status', async (req, res) => {
  try {
    await db.query('UPDATE house_assisted SET status = ? WHERE house_id = ? AND assisted_id = ?', [req.body.status, req.params.houseId, req.params.assistedId]);
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/assisted/:assistedId/history', async (req, res) => {
  try {
    const history = (await db.query(`
      SELECT a.*, w.first_name as worker_first, w.last_name as worker_last,
             ar.total_sessions, ar.completed_sessions
      FROM attendances a
      LEFT JOIN users w ON a.worker_id = w.id
      LEFT JOIN assistance_requests ar ON a.assistance_request_id = ar.id
      WHERE a.house_id = ? AND a.assisted_id = ?
      ORDER BY a.created_at DESC
    `, [req.params.houseId, req.params.assistedId]))[0] as any[];
    res.json(history);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/users/:workerId/worker-attendances', async (req, res) => {
  try {
    const history = (await db.query(`
      SELECT a.*, asd.first_name as assisted_first, asd.last_name as assisted_last,
             ar.total_sessions, ar.completed_sessions
      FROM attendances a
      LEFT JOIN users asd ON a.assisted_id = asd.id
      LEFT JOIN assistance_requests ar ON a.assistance_request_id = ar.id
      WHERE a.worker_id = ? AND a.status = 'completed'
      ORDER BY a.created_at DESC
    `, [req.params.workerId]))[0] as any[];
    res.json(history);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/users/:assistedId/treatment-plan', async (req, res) => {
  try {
    const request = (await db.query(`
      SELECT target_treatments, treatment_plan
      FROM assistance_requests
      WHERE assisted_id = ? AND (status = 'in_treatment' OR status = 'analyzed')
      ORDER BY created_at DESC LIMIT 1
    `, [req.params.assistedId]))[0][0] as any;
    
    if (!request || !request.target_treatments) {
      return res.json([]);
    }

    const targetTreatments = JSON.parse(request.target_treatments);
    const types = [];
    for (const treatment of targetTreatments) {
      if (treatment.typeId) {
        const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [treatment.typeId]))[0][0] as any;
        if (typeInfo) {
          types.push(typeInfo.name);
        }
      }
    }
    
    res.json(types);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/users/:assistedId/assisted-attendances', async (req, res) => {
  try {
    const history = (await db.query(`
      SELECT a.*, w.first_name as worker_first, w.last_name as worker_last,
             ar.total_sessions, ar.completed_sessions
      FROM attendances a
      LEFT JOIN users w ON a.worker_id = w.id
      LEFT JOIN assistance_requests ar ON a.assistance_request_id = ar.id
      WHERE a.assisted_id = ? AND a.status = 'completed'
      ORDER BY a.created_at DESC
    `, [req.params.assistedId]))[0] as any[];
    res.json(history);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/queue-count', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const count = (await db.query(`
      SELECT COUNT(*) as count FROM attendances 
      WHERE house_id = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?
    `, [req.params.houseId, today]))[0][0] as any;
    res.json({ count: count.count });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses', async (req, res) => {
  try {
    const houses = (await db.query('SELECT * FROM houses'))[0] as any[];
    res.json(houses);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses', async (req, res) => {
  const { representativeId, name, cnpj, cep, street, number, neighborhood, city, state, country, email, phone, photo_url } = req.body;
  
  try {
    const stmt = `
      INSERT INTO houses (representative_id, name, cnpj, email, phone, cep, street, number, neighborhood, city, state, country, photo_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const [info] = await db.query(stmt, [representativeId, name, cnpj, email || null, phone || null, cep || null, street, number, neighborhood, city, state, country, photo_url || null]) as any;
    res.json({ id: Number((info as any).insertId) });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// House Configuration Routes (Assistance Types, Days)
router.get('/houses/:houseId/assistance-types', async (req, res) => {
  try {
    const types = (await db.query('SELECT * FROM assistance_types WHERE house_id = ?', [req.params.houseId]))[0] as any[];
    res.json(types);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/assistance-types', async (req, res) => {
  try {
    const [info] = await db.query('INSERT INTO assistance_types (house_id, name, description, status) VALUES (?, ?, ?, ?)', [req.params.houseId, req.body.name, req.body.description, req.body.status || 'active']);
    res.json({ id: Number((info as any).insertId) });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/assistance-types/:typeId', async (req, res) => {
  try {
    await db.query('UPDATE assistance_types SET name = ?, description = ?, status = ? WHERE id = ? AND house_id = ?', [req.body.name, req.body.description, req.body.status, req.params.typeId, req.params.houseId]);
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/houses/:houseId/assistance-types/:typeId', async (req, res) => {
  try {
    (await db.query('DELETE FROM assistance_types WHERE id = ? AND house_id = ?', [req.params.typeId, req.params.houseId]))[0] as any[];
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/operating-days', async (req, res) => {
  try {
    const days = (await db.query('SELECT * FROM house_operating_days WHERE house_id = ? ORDER BY day_of_week ASC', [req.params.houseId]))[0] as any[];
    res.json(days);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/operating-days', async (req, res) => {
  try {
    const [info] = await db.query('INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time) VALUES (?, ?, ?, ?)', [req.params.houseId, req.body.dayOfWeek, req.body.openTime, req.body.closeTime]);
    res.json({ id: Number((info as any).insertId) });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/houses/:houseId/operating-days/:dayId', async (req, res) => {
  try {
    (await db.query('DELETE FROM house_operating_days WHERE id = ? AND house_id = ?', [req.params.dayId, req.params.houseId]))[0] as any[];
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/houses/:houseId/workers/:workerId', async (req, res) => {
  try {
    (await db.query('DELETE FROM house_workers WHERE house_id = ? AND worker_id = ?', [req.params.houseId, req.params.workerId]))[0] as any[];
    res.json({ message: 'Trabalhador desvinculado com sucesso.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/houses/:houseId/assisted/:assistedId', async (req, res) => {
  try {
    (await db.query('DELETE FROM house_assisted WHERE house_id = ? AND assisted_id = ?', [req.params.houseId, req.params.assistedId]))[0] as any[];
    res.json({ message: 'Trabalhador/Assistido desvinculado com sucesso.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/day-assistances', async (req, res) => {
  try {
    const assistances = (await db.query(`
      SELECT hda.*, at.name as assistance_name 
      FROM house_day_assistances hda
      JOIN assistance_types at ON hda.assistance_type_id = at.id
      WHERE hda.house_id = ?
    `, [req.params.houseId]))[0] as any[];
    res.json(assistances);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/day-assistances', async (req, res) => {
  try {
    const [info] = await db.query('INSERT INTO house_day_assistances (house_id, day_of_week, assistance_type_id) VALUES (?, ?, ?)', [req.params.houseId, req.body.dayOfWeek, req.body.assistanceTypeId]);
    res.json({ id: Number((info as any).insertId) });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/houses/:houseId/day-assistances/:id', async (req, res) => {
  try {
    (await db.query('DELETE FROM house_day_assistances WHERE id = ? AND house_id = ?', [req.params.id, req.params.houseId]))[0] as any[];
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Queue/Attendances Routes
router.post('/queue/checkin', async (req, res) => {
  const { houseId, assistedId } = req.body;
  
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Fetch user requiredTypes from backend
    let requiredTypes: string[] = [];
    const request = (await db.query(`SELECT target_treatments FROM assistance_requests WHERE assisted_id = ? AND status = 'in_treatment' ORDER BY created_at DESC LIMIT 1`, [assistedId]))[0][0] as any;
    if (request && request.target_treatments) {
      const targetTreatments = JSON.parse(request.target_treatments);
      for (const treatment of targetTreatments) {
        if (treatment.typeId) {
          const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [treatment.typeId]))[0][0] as any;
          if (typeInfo) requiredTypes.push(typeInfo.name);
        }
      }
    }
    
    // Fallback to manual selection from terminal if no active treatment plan is found
    if (requiredTypes.length === 0 && req.body.requiredTypes && req.body.requiredTypes.length > 0) {
      requiredTypes = req.body.requiredTypes;
    }
    // Link assisted to house if not linked
    (await db.query('INSERT IGNORE INTO house_assisted (house_id, assisted_id) VALUES (?, ?)', [houseId, assistedId]))[0] as any[];

    // Check if already waiting or in progress
    const active = (await db.query(`
      SELECT * FROM attendances 
      WHERE house_id = ? AND assisted_id = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?
    `, [houseId, assistedId, today]))[0][0];
    
    if (active) {
      return res.status(400).json({ error: 'Você já está na fila ou em atendimento.' });
    }

    // Find completed types today
    const completed = ((await db.query(`
      SELECT type FROM attendances 
      WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?
    `, [houseId, assistedId, today]))[0] as any[]).map((r: any) => r.type);

    const pendingTypes = requiredTypes.filter((t: string) => !completed.includes(t));

    if (pendingTypes.length === 0) {
      return res.json({ message: 'Todos os atendimentos concluídos por hoje!' });
    }

    // Load balancing: find the queue with the minimum people waiting
    let bestType = pendingTypes[0];
    let minQueue = Infinity;
    let bestHasWorkers = false;

    for (const type of pendingTypes) {
      const count = (await db.query(`
        SELECT COUNT(*) as count FROM attendances 
        WHERE house_id = ? AND type = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?
      `, [houseId, type, today]))[0][0] as any;
      const workersCount = (await db.query(`SELECT COUNT(*) as count FROM worker_sessions WHERE house_id = ? AND current_assistance_type = ? AND clock_out IS NULL AND status != 'offline'`, [houseId, type]))[0][0] as any;
      const hasWorkers = workersCount.count > 0;

      if (hasWorkers && !bestHasWorkers) {
         bestType = type;
         minQueue = count.count;
         bestHasWorkers = true;
      } else if (hasWorkers === bestHasWorkers) {
         if (count.count < minQueue) {
           minQueue = count.count;
           bestType = type;
         }
      }
    }

    // Generate ticket number
    const ticketCount = (await db.query(`
      SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND DATE(created_at) = ?
    `, [houseId, today]))[0][0] as any;
    const ticketNumber = `${bestType.substring(0, 1).toUpperCase()}${(ticketCount.count + 1).toString().padStart(3, '0')}`;

    // Look for active assistance request to link (for session tracking)
    const activeReq = (await db.query(`SELECT id FROM assistance_requests 
      WHERE assisted_id = ? AND house_id = ? AND status IN ('analyzed', 'in_treatment')
      ORDER BY id DESC LIMIT 1`, [assistedId, houseId]))[0][0] as any;
    const reqId = activeReq ? activeReq.id : null;

    const stmt = `
      INSERT INTO attendances (house_id, assisted_id, type, status, check_in_time, ticket_number, assistance_request_id)
      VALUES (?, ?, ?, 'waiting', CURRENT_TIMESTAMP, ?, ?)
    `;
    const [info] = await db.query(stmt, [houseId, assistedId, bestType, ticketNumber, reqId]) as any;

    notifyUser(assistedId, 'queue_joined', `Check-in confirmado para a trilha ${bestType}. Sua senha é ${ticketNumber}.`, { ticketNumber });

    res.json({ id: Number((info as any).insertId), type: bestType, ticketNumber, message: `Encaminhado para a fila de ${bestType}` });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/queue/call-next', async (req, res) => {
  const { houseId, workerId, type } = req.body;
  
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Link worker to house if not linked
    (await db.query('INSERT IGNORE INTO house_workers (house_id, worker_id) VALUES (?, ?)', [houseId, workerId]))[0] as any[];

    // Check if worker already has an active attendance
    const active = (await db.query(`
      SELECT * FROM attendances WHERE worker_id = ? AND status IN ('called', 'in_progress') AND DATE(created_at) = ?
    `, [workerId, today]))[0][0];
    
    if (active) {
      return res.status(400).json({ error: 'Você já possui um atendimento em andamento ou aguardando o assistido chegar.' });
    }

    // Find next in line for this type
    const next = (await db.query(`
      SELECT * FROM attendances 
      WHERE house_id = ? AND type = ? AND status = 'waiting' AND DATE(created_at) = ?
      ORDER BY check_in_time ASC LIMIT 1
    `, [houseId, type, today]))[0][0] as any;

    if (!next) {
      return res.status(404).json({ error: 'Fila vazia para este tipo de atendimento.' });
    }

    // Update to called (awaiting assisted scan to change to in_progress)
    (await db.query(`
      UPDATE attendances SET status = 'called', worker_id = ?, called_at = CURRENT_TIMESTAMP, call_count = 1 WHERE id = ?
    `, [workerId, next.id]))[0] as any[];

    // Fetch details for notification
    const assistedInfo = (await db.query('SELECT first_name FROM users WHERE id = ?', [next.assisted_id]))[0][0] as any;
    const workerInfo = (await db.query('SELECT first_name FROM users WHERE id = ?', [workerId]))[0][0] as any;

    // Send SSE notifications
    notifyUser(next.assisted_id, 'queue_called', `Chegou sua vez! O trabalhador ${workerInfo?.first_name || ''} está aguardando você.`, next);
    notifyUser(workerId, 'worker_called', `Você chamou ${assistedInfo?.first_name || 'Alguém'}. Aguarde o assistido chegar na sala.`, next);

    res.json({ message: 'Assistido chamado', attendance: next });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/queue/complete', async (req, res) => {
  const { attendanceId, additionalTreatments } = req.body;
  
  try {
    const attendance = (await db.query('SELECT * FROM attendances WHERE id = ?', [attendanceId]))[0][0] as any;
    if (!attendance) return res.status(404).json({ error: 'Atendimento não encontrado.' });

    // Fetch user requiredTypes from backend
    let requiredTypes: string[] = [];
    const request = (await db.query(`SELECT id, target_treatments FROM assistance_requests WHERE assisted_id = ? AND status = 'in_treatment' ORDER BY created_at DESC LIMIT 1`, [attendance.assisted_id]))[0][0] as any;
    
    // Append additional target treatments if requested
    if (request && additionalTreatments && Array.isArray(additionalTreatments) && additionalTreatments.length > 0) {
      let currentTreatments = request.target_treatments ? JSON.parse(request.target_treatments) : [];
      let updatedTreatments = [...currentTreatments];
      for (const typeId of additionalTreatments) {
         if (!updatedTreatments.some(t => String(t.typeId) === String(typeId))) {
            updatedTreatments.push({ typeId: String(typeId), sessions: 1 });
         }
      }
      await db.query(`UPDATE assistance_requests SET target_treatments = ? WHERE id = ?`, [JSON.stringify(updatedTreatments), request.id]);
      request.target_treatments = JSON.stringify(updatedTreatments);
    }

    if (request && request.target_treatments) {
      const targetTreatments = JSON.parse(request.target_treatments);
      for (const treatment of targetTreatments) {
        if (treatment.typeId) {
          const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [treatment.typeId]))[0][0] as any;
          if (typeInfo) requiredTypes.push(typeInfo.name);
        }
      }
    }

    // Mark as completed
    (await db.query(`
      UPDATE attendances SET status = 'completed', end_time = CURRENT_TIMESTAMP WHERE id = ?
    `, [attendanceId]))[0] as any[];

    if (attendance.assistance_request_id) {
        (await db.query('UPDATE assistance_requests SET completed_sessions = completed_sessions + 1 WHERE id = ?', [attendance.assistance_request_id]))[0] as any[];
    }
    
    // Set worker back to offline so they can be available again
    if (attendance.worker_id) {
        (await db.query('UPDATE worker_sessions SET status = "offline" WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL', [attendance.worker_id, attendance.house_id]))[0] as any[];
    }

    // Automatically check-in to the next available type if needed
    if (requiredTypes && requiredTypes.length > 0) {
      const today = new Date().toISOString().split('T')[0];
      const completed = ((await db.query(`
        SELECT type FROM attendances 
        WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?
      `, [attendance.house_id, attendance.assisted_id, today]))[0] as any[]).map((r: any) => r.type);

      const pendingTypes = requiredTypes.filter((t: string) => !completed.includes(t));

      if (pendingTypes.length > 0) {
        let bestType = pendingTypes[0];
        let minQueue = Infinity;
        let bestHasWorkers = false;

        for (const type of pendingTypes) {
          const count = (await db.query(`
            SELECT COUNT(*) as count FROM attendances 
            WHERE house_id = ? AND type = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?
          `, [attendance.house_id, type, today]))[0][0] as any;
          const workersCount = (await db.query(`SELECT COUNT(*) as count FROM worker_sessions WHERE house_id = ? AND current_assistance_type = ? AND clock_out IS NULL AND status != 'offline'`, [attendance.house_id, type]))[0][0] as any;
          const hasWorkers = workersCount.count > 0;

          if (hasWorkers && !bestHasWorkers) {
             bestType = type;
             minQueue = count.count;
             bestHasWorkers = true;
          } else if (hasWorkers === bestHasWorkers) {
             if (count.count < minQueue) {
               minQueue = count.count;
               bestType = type;
             }
          }
        }

        const ticketCount = (await db.query(`
          SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND DATE(created_at) = ?
        `, [attendance.house_id, today]))[0][0] as any;
        const ticketNumber = `${bestType.substring(0, 1).toUpperCase()}${(ticketCount.count + 1).toString().padStart(3, '0')}`;

        (await db.query(`
          INSERT INTO attendances (house_id, assisted_id, type, status, check_in_time, ticket_number, assistance_request_id)
          VALUES (?, ?, ?, 'waiting', CURRENT_TIMESTAMP, ?, ?)
        `, [attendance.house_id, attendance.assisted_id, bestType, ticketNumber, attendance.assistance_request_id]))[0] as any[];
        
        notifyUser(attendance.assisted_id, 'queue_requeued', `Sua rota continua! Você foi encaminhado para a fila de ${bestType}. Senha: ${ticketNumber}`, { ticketNumber, type: bestType });

        return res.json({ message: `Atendimento concluído. Assistido encaminhado para ${bestType}.`, hasMore: true, nextType: bestType });
      }
    }

    notifyUser(attendance.assisted_id, 'attendance_completed', `Atendimentos finalizados por hoje. Obrigado por comparecer à casa espírita!`);

    res.json({ message: 'Atendimento concluído. Todos os tratamentos do dia foram finalizados.', hasMore: false });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/queue/panel/:houseId', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Get the most recently called or in_progress (fallback or general)
    const currentCall = (await db.query(`
      SELECT a.*, u.first_name, u.last_name 
      FROM attendances a
      JOIN users u ON a.assisted_id = u.id
      WHERE a.house_id = ? AND a.status IN ('called', 'in_progress') AND date(a.created_at) = ?
      ORDER BY COALESCE(a.start_time, a.created_at) DESC LIMIT 1
    `, [req.params.houseId, today]))[0][0];

    // Get next in line (waiting)
    const nextInLine = (await db.query(`
      SELECT a.*, u.first_name, u.last_name 
      FROM attendances a
      JOIN users u ON a.assisted_id = u.id
      WHERE a.house_id = ? AND a.status = 'waiting' AND date(a.created_at) = ?
      ORDER BY a.check_in_time ASC LIMIT 10
    `, [req.params.houseId, today]))[0] as any[];
    
    // Get last 6 attended
    const lastAttended = (await db.query(`
      SELECT a.*, u.first_name, u.last_name 
      FROM attendances a
      JOIN users u ON a.assisted_id = u.id
      WHERE a.house_id = ? AND a.status IN ('in_progress', 'completed') AND date(a.created_at) = ?
      ORDER BY COALESCE(a.start_time, a.created_at) DESC LIMIT 6
    `, [req.params.houseId, today]))[0] as any[];
    
    // Fetch types currently offered by active workers in this house (where worker has chosen/logged in to this type)
    const workerTypesRes = await db.query(`
      SELECT DISTINCT current_assistance_type 
      FROM worker_sessions 
      WHERE house_id = ? AND clock_out IS NULL AND status != 'offline' AND current_assistance_type IS NOT NULL
    `, [req.params.houseId]);
    let activeTypes = (workerTypesRes[0] as any[]).map(t => t.current_assistance_type);
    
    const byType = [];
    for (const type of activeTypes) {
      const tCall = (await db.query(`
        SELECT a.*, u.first_name, u.last_name, ws.room_number 
        FROM attendances a
        JOIN users u ON a.assisted_id = u.id
        LEFT JOIN worker_sessions ws ON a.worker_id = ws.worker_id AND ws.house_id = a.house_id AND ws.clock_out IS NULL
        WHERE a.house_id = ? AND a.status IN ('called', 'in_progress') AND a.type = ? AND date(a.created_at) = ?
        ORDER BY COALESCE(a.start_time, a.created_at) DESC LIMIT 1
      `, [req.params.houseId, type, today]))[0][0];

      const tNext = (await db.query(`
        SELECT a.*, u.first_name, u.last_name 
        FROM attendances a
        JOIN users u ON a.assisted_id = u.id
        WHERE a.house_id = ? AND a.status = 'waiting' AND a.type = ? AND date(a.created_at) = ?
        ORDER BY a.check_in_time ASC LIMIT 7
      `, [req.params.houseId, type, today]))[0] as any[];

      const workersCountRes = await db.query(`
        SELECT COUNT(*) as count 
        FROM worker_sessions 
        WHERE house_id = ? AND current_assistance_type = ? AND clock_out IS NULL AND status != 'offline'
      `, [req.params.houseId, type]);
      const workersCount = (workersCountRes[0] as any[])[0]?.count || 0;

      byType.push({
        type,
        currentCall: tCall || null,
        nextInLine: tNext || [],
        workersCount
      });
    }
    
    res.json({ currentCall, nextInLine, lastAttended, byType });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/queue/worker/active/:workerId', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const active = (await db.query(`
      SELECT a.*, u.first_name, u.last_name 
      FROM attendances a
      JOIN users u ON a.assisted_id = u.id
      WHERE a.worker_id = ? AND a.status IN ('called', 'in_progress') AND date(a.created_at) = ?
    `, [req.params.workerId, today]))[0][0];
    
    res.json(active || null);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/queue/assisted/active/:assistedId', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const active = (await db.query(`
      SELECT * FROM attendances 
      WHERE assisted_id = ? AND status IN ('waiting', 'called', 'in_progress') AND DATE(created_at) = ?
    `, [req.params.assistedId, today]))[0][0];
    
    res.json(active || null);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/terminal/nfc-scan', async (req, res) => {
  const { houseId, cpf, p_serial, p_timestamp } = req.body; // p_serial is the actual serial generated, p_timestamp is from ndef
  try {
    let searchCpf = cpf;
    if (p_serial) searchCpf = p_serial; // If Web NFC, look by the generated serial
    
    // Strict Validation: Ensure physical tag's payload matches our DB
    if (p_serial) {
      const tagRecord = (await db.query('SELECT * FROM nfc_tags WHERE serial_number = ?', [p_serial]))[0][0] as any;
      if (!tagRecord) {
        return res.status(401).json({ error: 'NFC SERIAL inválido ou não registrado. Procure a recepção.' });
      }
      if (tagRecord.status !== 'active') {
        return res.status(401).json({ error: 'NFC Tag desativada.' });
      }
      
      // Timestamp Integrity Check
      if (p_timestamp) {
         // tagRecord.activation_date might be Date object or string depending on sqlite driver config
         let dbTimestamp = "";
         if (tagRecord.activation_date instanceof Date) {
            dbTimestamp = tagRecord.activation_date.toISOString();
         } else {
            dbTimestamp = new Date(tagRecord.activation_date).toISOString();
         }
         
         const passedTimestamp = new Date(p_timestamp).toISOString();
         
         // To avoid ms precision mismatches, we can just compare substring (seconds)
         if (dbTimestamp.substring(0, 19) !== passedTimestamp.substring(0, 19)) {
            return res.status(401).json({ error: 'Falha na integridade da Tag (Cópia detectada). Selo de tempo não confere.' });
         }
      } else {
         return res.status(401).json({ error: 'Falha na integridade da Tag (Sem selo temporal).' });
      }
    }

    const user = (await db.query('SELECT id, first_name, last_name, role, nfc_tag, cpf FROM users WHERE cpf = ? OR nfc_tag = ?', [searchCpf, searchCpf]))[0][0] as any;
    
    if (!user) {
      // If we provided a valid tag but no user is bound
      if (p_serial) return res.status(404).json({ error: 'Tag válida, mas sem usuário vinculado. Procure a recepção.' });
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    const accessedViaCpf = searchCpf === user.cpf && !p_serial;
    const hasNfcTag = Boolean(user.nfc_tag);

    if (user.role === 'worker') {
      const session = (await db.query('SELECT * FROM worker_sessions WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL', [user.id, houseId]))[0][0] as any;

      if (!session) {
        // Clock in (1st read)
        const [info] = await db.query('INSERT INTO worker_sessions (worker_id, house_id, status) VALUES (?, ?, ?)', [user.id, houseId, 'offline']);
        return res.json({ action: 'worker_clocked_in', sessionId: Number((info as any).insertId), user, accessedViaCpf, hasNfcTag });
      }

      // Check if worker has an active attendance in progress
      const activeAttendance = (await db.query('SELECT * FROM attendances WHERE worker_id = ? AND house_id = ? AND status = \'in_progress\'', [user.id, houseId]))[0][0] as any;

      if (activeAttendance) {
        // End attendance (3rd read logic)
        await db.query('UPDATE attendances SET status = \'completed\', end_time = CURRENT_TIMESTAMP WHERE id = ?', [activeAttendance.id]);
        
        // Decrement sessions or increment completed sessions if linked to a request
        if (activeAttendance.assistance_request_id) {
            (await db.query('UPDATE assistance_requests SET completed_sessions = completed_sessions + 1 WHERE id = ?', [activeAttendance.assistance_request_id]))[0] as any[];
        }
        
        // Auto-enqueue assisted for next treatment if they have pending treatments
        const today = new Date().toISOString().split('T')[0];
        const assistedId = activeAttendance.assisted_id;
        
        let requiredTypes: {name: string, requiredSessions: number}[] = [];
        const request = (await db.query(`SELECT id, target_treatments FROM assistance_requests WHERE assisted_id = ? AND status = 'in_treatment' ORDER BY created_at DESC LIMIT 1`, [assistedId]))[0][0] as any;
        let treatmentRequestId = null;
        if (request && request.target_treatments) {
          treatmentRequestId = request.id;
          let targetTreatments = [];
          try { targetTreatments = JSON.parse(request.target_treatments); } catch(e){}
          for (const treatment of targetTreatments) {
             if (treatment.typeId) {
                const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [treatment.typeId]))[0][0] as any;
                if (typeInfo) requiredTypes.push({ name: typeInfo.name, requiredSessions: treatment.sessions || 1 });
             }
          }
        }

        const stats = ((await db.query(`SELECT type, status FROM attendances WHERE assistance_request_id = ?`, [treatmentRequestId]))[0] as any[]);
        
        let pendingTypes: string[] = [];
        for (const reqType of requiredTypes) {
           const completedOrActive = stats.filter(s => s.type === reqType.name && s.status !== 'cancelled').length;
           if (completedOrActive < reqType.requiredSessions) {
              pendingTypes.push(reqType.name);
           }
        }
        
        // Also ensure not scheduled today for the exact same treatment? We assume yes, or we let them do multiple? 'até que conclua a quantidade... por dia'. Actually, the prompt says 'alocar automaticamente um deles na fila... até que conclua a quantidade' this means we just check if it's not completed overall. To prevent infinite loops in one day, we filter out types they already did today!
        const completedToday = stats.filter(s => s.status === 'completed' && new Date().toISOString().split('T')[0] === today).map(s => s.type);
        // Prompt says: 'até que conclua a quantidade de sessões sugeridas por dia'. We will assume 1 session of each type per day!
        pendingTypes = pendingTypes.filter(t => !completedToday.includes(t));

        let nextAttendanceScheduled = false;
        
        if (pendingTypes.length > 0) {
          let bestType = pendingTypes[0];
          let minQueue = Infinity;
          let bestHasWorkers = false;

          for (const type of pendingTypes) {
            const count = (await db.query(`SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND type = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?`, [houseId, type, today]))[0][0] as any;
            const workersCount = (await db.query(`SELECT COUNT(*) as count FROM worker_sessions WHERE house_id = ? AND current_assistance_type = ? AND clock_out IS NULL AND status != 'offline'`, [houseId, type]))[0][0] as any;
            const hasWorkers = workersCount.count > 0;

            if (hasWorkers && !bestHasWorkers) {
               bestType = type;
               minQueue = count.count;
               bestHasWorkers = true;
            } else if (hasWorkers === bestHasWorkers) {
               if (count.count < minQueue) {
                 minQueue = count.count;
                 bestType = type;
               }
            }
          }

          const ticketCount = (await db.query(`SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND DATE(created_at) = ?`, [houseId, today]))[0][0] as any;
          const ticketNumber = `${bestType.substring(0, 1).toUpperCase()}${(ticketCount.count + 1).toString().padStart(3, '0')}`;

          (await db.query(`INSERT INTO attendances (house_id, assisted_id, type, status, check_in_time, ticket_number, assistance_request_id) VALUES (?, ?, ?, 'waiting', CURRENT_TIMESTAMP, ?, ?)`, [houseId, assistedId, bestType, ticketNumber, activeAttendance.assistance_request_id]))[0] as any[];

          nextAttendanceScheduled = true;
          notifyUser(assistedId, 'queue_joined', `Check-in automático para a trilha ${bestType}. Sua senha é ${ticketNumber}.`, { ticketNumber });
        }

        // Put worker back on hold
        (await db.query('UPDATE worker_sessions SET status = "offline" WHERE id = ?', [session.id]))[0] as any[];
        return res.json({ action: 'worker_attendance_finished', session, user, accessedViaCpf, hasNfcTag, nextAttendanceScheduled });
      } else {
        // Prompt for status change (2nd read logic)
        return res.json({ action: 'worker_prompt_status', session, user, accessedViaCpf, hasNfcTag });
      }
    } else if (user.role === 'assisted') {
      const today = new Date().toISOString().split('T')[0];
      const active = (await db.query(`
        SELECT * FROM attendances 
        WHERE house_id = ? AND assisted_id = ? AND status IN ('waiting', 'called', 'in_progress') AND DATE(created_at) = ?
        ORDER BY id DESC LIMIT 1
      `, [houseId, user.id, today]))[0][0] as any;

      if (!active || active.status === 'in_progress') {
        // Either not in queue or already in progress (let them check in to queue again if needed, or deny)
        if (active && active.status === 'in_progress') {
            return res.json({ action: 'assisted_already_in_progress', user, attendance: active, accessedViaCpf, hasNfcTag });
        }
        // Check if they have an active treatment plan
        let requiredTypes: {name: string, requiredSessions: number}[] = [];
        let treatmentRequestId = null;
        const request = (await db.query(`SELECT id, target_treatments FROM assistance_requests WHERE assisted_id = ? AND status = 'in_treatment' ORDER BY created_at DESC LIMIT 1`, [user.id]))[0][0] as any;
        if (request && request.target_treatments) {
          treatmentRequestId = request.id;
          let targetTreatments = [];
          try { targetTreatments = JSON.parse(request.target_treatments); } catch(e){}
          for (const treatment of targetTreatments) {
            if (treatment.typeId) {
              const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [treatment.typeId]))[0][0] as any;
              if (typeInfo) requiredTypes.push({ name: typeInfo.name, requiredSessions: treatment.sessions || 1 });
            }
          }
        }

        const stats = ((await db.query(`SELECT type, status, created_at FROM attendances WHERE assistance_request_id = ?`, [treatmentRequestId]))[0] as any[]);
        let pendingTypes: string[] = [];
        for (const reqType of requiredTypes) {
           const completedOrActive = stats.filter(s => s.type === reqType.name && s.status !== 'cancelled').length;
           if (completedOrActive < reqType.requiredSessions) {
              pendingTypes.push(reqType.name);
           }
        }
        
        const completedToday = stats.filter(s => s.status === 'completed' && new Date(s.created_at).toISOString().split('T')[0] === today).map(s => s.type);
        pendingTypes = pendingTypes.filter(t => !completedToday.includes(t));

        if (pendingTypes.length > 0) {
          let bestType = pendingTypes[0];
          let minQueue = Infinity;
          let bestHasWorkers = false;

          for (const type of pendingTypes) {
            const count = (await db.query(`SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND type = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?`, [houseId, type, today]))[0][0] as any;
            const workersCount = (await db.query(`SELECT COUNT(*) as count FROM worker_sessions WHERE house_id = ? AND current_assistance_type = ? AND clock_out IS NULL AND status != 'offline'`, [houseId, type]))[0][0] as any;
            const hasWorkers = workersCount.count > 0;

            if (hasWorkers && !bestHasWorkers) {
               bestType = type;
               minQueue = count.count;
               bestHasWorkers = true;
            } else if (hasWorkers === bestHasWorkers) {
               if (count.count < minQueue) {
                 minQueue = count.count;
                 bestType = type;
               }
            }
          }

          const ticketCount = (await db.query(`SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND DATE(created_at) = ?`, [houseId, today]))[0][0] as any;
          const ticketNumber = `${bestType.substring(0, 1).toUpperCase()}${(ticketCount.count + 1).toString().padStart(3, '0')}`;

          const attendanceInfo = (await db.query(`INSERT INTO attendances (house_id, assisted_id, type, status, check_in_time, ticket_number, assistance_request_id) VALUES (?, ?, ?, 'waiting', CURRENT_TIMESTAMP, ?, ?)`, [houseId, user.id, bestType, ticketNumber, treatmentRequestId]))[0] as any[];
          const activeAttendance = (await db.query('SELECT * FROM attendances WHERE id = ?', [(attendanceInfo as any).insertId]))[0][0] as any;
          
          notifyUser(user.id, 'queue_joined', `Check-in automático para a trilha ${bestType}. Sua senha é ${ticketNumber}.`, { ticketNumber });
          
          return res.json({ action: 'assisted_already_in_queue', user, attendance: activeAttendance, accessedViaCpf, hasNfcTag });
        }

        return res.json({ action: 'assisted_prompt_checkin', user, accessedViaCpf, hasNfcTag });
      } else if (active.status === 'called') {
        // Leaves queue, enters attendance
        (await db.query('UPDATE attendances SET status = !!in_progress!!, start_time = CURRENT_TIMESTAMP WHERE id = ?'.replace(/!!/g, "'"), [active.id]))[0] as any[];
        // Mark the worker as busy
        if (active.worker_id) {
          (await db.query('UPDATE worker_sessions SET status = "busy" WHERE worker_id = ? AND clock_out IS NULL', [active.worker_id]))[0] as any[];
          notifyUser(active.worker_id, 'worker_started', `O assistido entrou na sala. Bom atendimento.`, active);
        }
        notifyUser(user.id, 'assisted_started', `Atendimento iniciado. Pode entrar.`, active);
        
        return res.json({ action: 'assisted_started_attendance', user, attendance: active, accessedViaCpf, hasNfcTag });
      } else {
        return res.json({ action: 'assisted_already_in_queue', user, attendance: active, accessedViaCpf, hasNfcTag });
      }
    }

    res.json({ user, status: 'recognized', accessedViaCpf, hasNfcTag });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/terminal/verify-cpf', async (req, res) => {
  const { cpf } = req.body;
  try {
    const user = (await db.query('SELECT id, first_name, last_name, role FROM users WHERE cpf = ?', [cpf]))[0][0] as any;
    if (!user) {
      return res.status(404).json({ error: 'Nenhum usuário encontrado com este CPF.' });
    }
    res.json({ user });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/terminal/validate-tag-serial', async (req, res) => {
  const { serialNumber } = req.body;
  if (!serialNumber) {
    return res.json({ status: 'invalid' });
  }
  
  try {
    let tag = (await db.query('SELECT * FROM nfc_tags WHERE serial_number = ?', [serialNumber]))[0][0] as any;
    if (!tag) {
      // Auto-insert new tags as active so they can be used
      await db.query('INSERT INTO nfc_tags (serial_number, status) VALUES (?, "active")', [serialNumber]);
      tag = { status: 'active' };
    }
    res.json({ status: tag.status });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/terminal/write-tag', async (req, res) => {
  const { userId, nfcTag } = req.body;
  try {
    // Check if another active tag is already registered to this userId
    const [existing] = await db.query("SELECT * FROM nfc_tags WHERE user_id = ? AND status = 'active' AND serial_number != ?", [userId, nfcTag]) as any[];
    if (existing && existing.length > 0) {
       return res.status(400).json({ error: "Já existe uma tag gravada com este CPF. Por favor, peça para o administrador desabilitar a tag atual." });
    }

    // Dissociate other tags linked to this userId
    await db.query("UPDATE nfc_tags SET user_id = NULL WHERE user_id = ? AND serial_number != ?", [userId, nfcTag]);

    // Clear tag mapping for prior users sharing this tag serial physically
    await db.query("UPDATE users SET nfc_tag = NULL WHERE nfc_tag = ? AND id != ?", [nfcTag, userId]);

    await db.query('UPDATE users SET nfc_tag = ? WHERE id = ?', [nfcTag, userId]);
    // Sync to nfc_tags so admin panel shows correctly
    await db.query('UPDATE nfc_tags SET user_id = ? WHERE serial_number = ?', [userId, nfcTag]);
    res.json({ message: 'Tag vinculada ao usuário com sucesso!' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/worker/session/:sessionId/status', async (req, res) => {
  const { sessionId } = req.params;
  const { status, clockOut, currentAssistanceType, roomNumber } = req.body;

  try {
    if (clockOut) {
      (await db.query('UPDATE worker_sessions SET status = "offline", clock_out = CURRENT_TIMESTAMP, room_number = NULL WHERE id = ?', [sessionId]))[0] as any[];
    } else {
      if (currentAssistanceType) {
        (await db.query('UPDATE worker_sessions SET status = ?, current_assistance_type = ?, room_number = ? WHERE id = ?', [status, currentAssistanceType, roomNumber || null, sessionId]))[0] as any[];
        
        // Dynamically add this assistance type to the house's assistance_types if it's new
        const sessionRes = await db.query('SELECT house_id FROM worker_sessions WHERE id = ?', [sessionId]);
        const sessionObj = sessionRes[0] && (sessionRes[0] as any[])[0];
        if (sessionObj && sessionObj.house_id) {
          const houseId = sessionObj.house_id;
          const exists = await db.query(
            'SELECT id FROM assistance_types WHERE house_id = ? AND name = ?',
            [houseId, currentAssistanceType]
          );
          if (!(exists[0] && (exists[0] as any[]).length > 0)) {
            await db.query(
              'INSERT INTO assistance_types (house_id, name, status) VALUES (?, ?, "active")',
              [houseId, currentAssistanceType]
            );
          }
        }
      } else {
        (await db.query('UPDATE worker_sessions SET status = ?, room_number = COALESCE(?, room_number) WHERE id = ?', [status, roomNumber || null, sessionId]))[0] as any[];
      }
    }
    
    res.json({ message: 'Status atualizado com sucesso' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// --- AUTONOMOUS GOOGLE MEET-LOOKING SYSTEM SIGNALING ENGINE ---
interface MeetPeer {
  peerId: string;
  userName: string;
  userId: number;
  lastActive: number;
  avatarUrl?: string;
  city?: string;
  phone?: string;
}

interface MeetSignal {
  id: string;
  room: string;
  senderId: string;
  targetId: string; // 'all' or a specific peerId
  type: string;
  payload: any;
  timestamp: number;
}

interface MeetFile {
  id: string;
  room: string;
  fileName: string;
  fileSize: number;
  fileUrl: string;
  senderName: string;
  timestamp: number;
}

const activeMeetPeers: { [room: string]: MeetPeer[] } = {};
let meetSignals: MeetSignal[] = [];
const meetFiles: { [room: string]: MeetFile[] } = {};

// Auto-clean old signals (> 45s) and stale peers (no ping for 15s) every 10 seconds
setInterval(() => {
  const now = Date.now();
  meetSignals = meetSignals.filter(sig => now - sig.timestamp < 45000);

  for (const r in activeMeetPeers) {
    activeMeetPeers[r] = activeMeetPeers[r].filter(peer => now - peer.lastActive < 15000);
    if (activeMeetPeers[r].length === 0) {
      delete activeMeetPeers[r];
    }
  }
}, 10000);

// SIGNALING ENDPOINTS:
// 1. Join a meet room
router.post('/conferences/room/:roomName/join', async (req: any, res: any) => {
  try {
    const { roomName } = req.params;
    const { peerId, userName, userId } = req.body;
    if (!peerId || !userName) {
      return res.status(400).json({ error: 'peerId e userName sao obrigatorios' });
    }

    if (!activeMeetPeers[roomName]) {
      activeMeetPeers[roomName] = [];
    }

    // Remove duplicates
    activeMeetPeers[roomName] = activeMeetPeers[roomName].filter(p => p.peerId !== peerId);

    let dbAvatarUrl: string | undefined = undefined;
    let dbCity: string | undefined = undefined;
    let dbPhone: string | undefined = undefined;

    if (userId) {
      try {
        const [usrRes] = await db.query('SELECT photo_url, phone, city FROM users WHERE id = ?', [Number(userId)]) as any[];
        if (usrRes && usrRes[0]) {
          dbAvatarUrl = usrRes[0].photo_url || undefined;
          dbCity = usrRes[0].city || undefined;
          dbPhone = usrRes[0].phone || undefined;
        }
      } catch (err) {
        console.error('Error fetching peer details on join:', err);
      }
    }

    activeMeetPeers[roomName].push({
      peerId,
      userName,
      userId: Number(userId || 0),
      lastActive: Date.now(),
      avatarUrl: dbAvatarUrl,
      city: dbCity,
      phone: dbPhone
    });

    res.json({ success: true, peers: activeMeetPeers[roomName] });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 2. Submit signal (WebRTC Offer/Answer/ICE)
router.post('/conferences/room/:roomName/signal', async (req: any, res: any) => {
  try {
    const { roomName } = req.params;
    const { senderId, targetId, type, payload } = req.body;

    const newSignal: MeetSignal = {
      id: Math.random().toString(36).substring(2, 11),
      room: roomName,
      senderId,
      targetId: targetId || 'all',
      type,
      payload,
      timestamp: Date.now()
    };

    meetSignals.push(newSignal);
    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 3. Poll signaling status (heartbeat + fetch signals/peers/files)
router.post('/conferences/room/:roomName/poll', async (req: any, res: any) => {
  try {
    const { roomName } = req.params;
    const { peerId, userName, userId, since } = req.body;
    if (!peerId) {
      return res.status(400).json({ error: 'peerId eh obrigatorio' });
    }

    const now = Date.now();
    
    // Register/Update peer activity
    if (!activeMeetPeers[roomName]) {
      activeMeetPeers[roomName] = [];
    }

    let p = activeMeetPeers[roomName].find(x => x.peerId === peerId);
    if (p) {
      p.lastActive = now;
    } else {
      let dbAvatarUrl: string | undefined = undefined;
      let dbCity: string | undefined = undefined;
      let dbPhone: string | undefined = undefined;

      if (userId) {
        try {
          const [usrRes] = await db.query('SELECT photo_url, phone, city FROM users WHERE id = ?', [Number(userId)]) as any[];
          if (usrRes && usrRes[0]) {
            dbAvatarUrl = usrRes[0].photo_url || undefined;
            dbCity = usrRes[0].city || undefined;
            dbPhone = usrRes[0].phone || undefined;
          }
        } catch (err) {
          console.error('Error fetching peer details on poll:', err);
        }
      }

      activeMeetPeers[roomName].push({
        peerId,
        userName: userName || 'Participante',
        userId: Number(userId || 0),
        lastActive: now,
        avatarUrl: dbAvatarUrl,
        city: dbCity,
        phone: dbPhone
      });
    }

    // Clean up dead peers
    activeMeetPeers[roomName] = activeMeetPeers[roomName].filter(x => now - x.lastActive < 15500);

    // Filter relevant unread signals for peerId
    const sinceTime = Number(since) || 0;
    const signals = meetSignals.filter(sig => 
      sig.room === roomName && 
      sig.senderId !== peerId && 
      sig.timestamp > sinceTime && 
      (sig.targetId === 'all' || sig.targetId === peerId)
    );

    res.json({
      success: true,
      peers: activeMeetPeers[roomName],
      signals,
      files: meetFiles[roomName] || [],
      timestamp: now
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// 4. Submit and broadcast Shared File inside room
router.post('/conferences/room/:roomName/upload', upload.single('file'), async (req: any, res: any) => {
  try {
    const { roomName } = req.params;
    const { senderName } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
    }

    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const filename = 'roomfile-' + uniqueSuffix + path.extname(file.originalname);
    const localFilePath = path.join(uploadDir, filename);

    fs.writeFileSync(localFilePath, file.buffer);
    const fileUrl = `/uploads/${filename}`;

    if (!meetFiles[roomName]) {
      meetFiles[roomName] = [];
    }

    const newFile: MeetFile = {
      id: Math.random().toString(36).substring(2, 11),
      room: roomName,
      fileName: file.originalname,
      fileSize: file.size,
      fileUrl,
      senderName: senderName || 'Desconhecido',
      timestamp: Date.now()
    };

    meetFiles[roomName].push(newFile);

    // Save as chat signal too so clients can display and flash immediate notification
    meetSignals.push({
      id: Math.random().toString(36).substring(2, 11),
      room: roomName,
      senderId: 'system',
      targetId: 'all',
      type: 'chat',
      payload: { 
        text: `Compartilhou o arquivo "${file.originalname}" no canal de arquivos da sala.`, 
        senderName: senderName || 'Sistema',
        timestamp: Date.now(),
        isFileNotify: true
      },
      timestamp: Date.now()
    });

    res.json({ success: true, file: newFile });
  } catch (error: any) {
    console.error('Error uploading room file:', error);
    res.status(500).json({ error: 'Erro ao processar arquivo: ' + error.message });
  }
});

// 5. Direct system wide text chat signaling inside room (fast and simple fallback to avoid WebRTC data channel drops in low-end connections)
router.post('/conferences/room/:roomName/chat', async (req: any, res: any) => {
  try {
    const { roomName } = req.params;
    const { senderId, senderName, text } = req.body;

    const chatSignal: MeetSignal = {
      id: Math.random().toString(36).substring(2, 11),
      room: roomName,
      senderId,
      targetId: 'all',
      type: 'chat',
      payload: {
        text,
        senderName,
        timestamp: Date.now()
      },
      timestamp: Date.now()
    };

    meetSignals.push(chatSignal);
    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// Conferences API
router.get('/houses/:houseId/conferences', async (req, res) => {
  try {
    const conferences = (await db.query('SELECT * FROM conferences WHERE house_id = ? ORDER BY scheduled_date DESC, scheduled_time DESC', [req.params.houseId]))[0] as any[];
    
    // Add participants
    for (const conf of conferences) {
      conf.participants = (await db.query('SELECT u.id, u.first_name, u.last_name FROM users u JOIN conference_participants cp ON u.id = cp.user_id WHERE cp.conference_id = ?', [conf.id]))[0] as any[];
    }
    res.json(conferences);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/conferences', async (req, res) => {
  try {
    const { title, description, theme, scheduledDate, scheduledTime, participantIds } = req.body;
    
    // Buscar CEP e número da casa espírita correspondente
    const [houses] = await db.query('SELECT cep, number FROM houses WHERE id = ?', [req.params.houseId]) as any[];
    const house = houses && houses[0] ? houses[0] : null;
    
    let rawCep = (house && house.cep) ? String(house.cep).replace(/[^a-zA-Z0-9]/g, '') : '00000000';
    let rawNumber = (house && house.number) ? String(house.number).replace(/[^a-zA-Z0-9-]/g, '') : 'SN';
    if (!rawCep || rawCep.trim() === '') rawCep = '00000000';
    if (!rawNumber || rawNumber.trim() === '') rawNumber = 'SN';
    
    // Gerando um código aleatório de 4 caracteres
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let randCode = '';
    for (let i = 0; i < 4; i++) {
      randCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    const roomName = `${rawCep}-${rawNumber}-${randCode}`;

    // --- AUTONOMOUS NEW SIAE MEET INTEGRATION ---
    const localRoomLink = `/room/${roomName}`;
    
    const [info] = await db.query('INSERT INTO conferences (house_id, title, description, theme, scheduled_date, scheduled_time, room_name, mirotalk_link, mirotalk_room_id, openmeetings_link, openmeetings_room_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [req.params.houseId, title, description, theme || 'Escuro', scheduledDate, scheduledTime, roomName, localRoomLink, null, localRoomLink, null]);
      
    if (participantIds && Array.isArray(participantIds)) {
      const insertParticipantCmd = 'INSERT INTO conference_participants (conference_id, user_id) VALUES (?, ?)';
      for (const userId of participantIds) {
         await db.query(insertParticipantCmd, [Number((info as any).insertId), userId]);
      }
    }

    if (firestore) {
      try {
        await firestore.collection('conferences').doc(roomName).set({
          houseId: req.params.houseId,
          title,
          description,
          theme: theme || 'Escuro',
          scheduledDate,
          scheduledTime,
          roomName,
          mirotalkLink: localRoomLink,
          openmeetingsLink: localRoomLink,
          participants: participantIds || [],
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });
      } catch (fsError) {
        console.error("Failed syncing conference to Firebase:", fsError);
      }
    }
    
    res.json({ success: true, id: Number((info as any).insertId), roomName });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/conferences/room/:roomName', async (req, res) => {
  try {
    const { roomName } = req.params;
    const [confs] = await db.query('SELECT * FROM conferences WHERE room_name = ?', [roomName]) as any[];
    if (!confs || confs.length === 0) {
      return res.status(404).json({ error: 'Sala não encontrada' });
    }
    res.json(confs[0]);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.delete('/houses/:houseId/conferences/:conferenceId', async (req, res) => {
  try {
    (await db.query('DELETE FROM conference_participants WHERE conference_id = ?', [req.params.conferenceId]))[0] as any[];
    (await db.query('DELETE FROM conferences WHERE id = ?', [req.params.conferenceId]))[0] as any[];
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/users/:userId/conferences', async (req, res) => {
  try {
    const conferences = (await db.query(`
      SELECT c.* 
      FROM conferences c
      JOIN conference_participants cp ON c.id = cp.conference_id
      WHERE cp.user_id = ?
      ORDER BY c.scheduled_date ASC, c.scheduled_time ASC
    `, [req.params.userId]))[0] as any[];
    res.json(conferences);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId', async (req, res) => {
  const { name, cnpj, cep, street, number, neighborhood, city, state, country, email, phone } = req.body;
  
  try {
    const stmt = `
      UPDATE houses 
      SET name = ?, cnpj = ?, email = ?, phone = ?, cep = ?, street = ?, number = ?, neighborhood = ?, city = ?, state = ?, country = ?
      WHERE id = ?
    `;
    (await db.query(stmt, [name, cnpj, email || null, phone || null, cep || null, street, number, neighborhood, city, state, country, req.params.houseId]))[0] as any[];
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/operating-days/bulk', async (req, res) => {
  try {
    const { timeBlocks } = req.body;
    await (async () => {
    const conn = await db.getConnection();
    await conn.beginTransaction();
    try {
      
      (await db.query('DELETE FROM house_operating_days WHERE house_id = ?', [req.params.houseId]))[0] as any[];
      const insertCmd = 'INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time) VALUES (?, ?, ?, ?)';
      for (const block of timeBlocks) {
        for (const day of block.days) {
          await conn.query(insertCmd, [req.params.houseId, day, block.openTime, block.closeTime]);
        }
      }
    
      await conn.commit();
    } catch(e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
})();
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/houses/:houseId/day-assistances/bulk', async (req, res) => {
  try {
    const { links } = req.body;
    await (async () => {
    const conn = await db.getConnection();
    await conn.beginTransaction();
    try {
      
      (await db.query('DELETE FROM house_day_assistances WHERE house_id = ?', [req.params.houseId]))[0] as any[];
      const insertCmd = 'INSERT INTO house_day_assistances (house_id, day_of_week, assistance_type_id) VALUES (?, ?, ?)';
      for (const link of links) {
        for (const day of link.days) {
          await conn.query(insertCmd, [req.params.houseId, day, link.assistanceTypeId]);
        }
      }
    
      await conn.commit();
    } catch(e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
})();
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/upload', upload.single('photo'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Nenhum arquivo enviado.' });
  }

  try {
    const file = req.file;
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const filename = file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname);

    const localFilePath = path.join(uploadDir, filename);
    fs.writeFileSync(localFilePath, file.buffer);
    const photoUrl = `/uploads/${filename}`;
    return res.json({ photoUrl });
  } catch (error: any) {
    console.error('Error uploading file:', error);
    res.status(500).json({ error: 'Erro ao fazer upload da imagem: ' + error.message });
  }
});

// --- STORE & MERCADOPAGO CONFIG ---
router.get('/config/mercadopago', async (req, res) => {
  try {
    const config = (await db.query('SELECT * FROM mercadopago_config LIMIT 1'))[0][0];
    res.json(config || null);
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.post('/config/mercadopago', async (req, res) => {
  try {
    const { 
      env, test_access_token, test_public_key, test_client_id, test_client_secret, 
      access_token, public_key, client_id, client_secret, redirect_url,
      enable_pix_qr_code, enable_pix_copia_cola, enable_card, max_qty_per_order, unit_price
    } = req.body;
    
    const existing: any = (await db.query('SELECT * FROM mercadopago_config LIMIT 1'))[0][0];
    
    const valPixQR = enable_pix_qr_code !== undefined ? Number(enable_pix_qr_code) : 1;
    const valPixCopia = enable_pix_copia_cola !== undefined ? Number(enable_pix_copia_cola) : 1;
    const valCard = enable_card !== undefined ? Number(enable_card) : 1;
    const valMaxQty = max_qty_per_order !== undefined ? Number(max_qty_per_order) : 10;
    const valPrice = unit_price !== undefined ? parseFloat(unit_price) : 15.00;

    if (existing) {
      await db.query(`UPDATE mercadopago_config SET 
        env=?, test_access_token=?, test_public_key=?, test_client_id=?, test_client_secret=?, 
        access_token=?, public_key=?, client_id=?, client_secret=?, redirect_url=?,
        enable_pix_qr_code=?, enable_pix_copia_cola=?, enable_card=?, max_qty_per_order=?, unit_price=? 
        WHERE id=?`, 
        [
          env, test_access_token, test_public_key, test_client_id, test_client_secret, 
          access_token, public_key, client_id, client_secret, redirect_url,
          valPixQR, valPixCopia, valCard, valMaxQty, valPrice, existing.id
        ]);
    } else {
      await db.query(`INSERT INTO mercadopago_config (
        env, test_access_token, test_public_key, test_client_id, test_client_secret, 
        access_token, public_key, client_id, client_secret, redirect_url,
        enable_pix_qr_code, enable_pix_copia_cola, enable_card, max_qty_per_order, unit_price
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          env, test_access_token, test_public_key, test_client_id, test_client_secret, 
          access_token, public_key, client_id, client_secret, redirect_url,
          valPixQR, valPixCopia, valCard, valMaxQty, valPrice
        ]);
    }

    // Synchronize price with Chaveiro product in database so general listings update
    if (valPrice) {
      await db.query("UPDATE products SET price = ? WHERE name LIKE '%Chaveiro%'", [valPrice]);
    }

    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.get('/products', async (req, res) => {
  try {
    const products = (await db.query("SELECT * FROM products"))[0];
    res.json(products);
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.post('/products', async (req, res) => {
  try {
    const { name, description, price, stock, image_url, status } = req.body;
    await db.query('INSERT INTO products (name, description, price, stock, image_url, status) VALUES (?, ?, ?, ?, ?, ?)', 
      [name, description, price, stock, image_url, status || 'active']);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.put('/products/:id', async (req, res) => {
  try {
    const { name, description, price, stock, image_url, status } = req.body;
    await db.query('UPDATE products SET name=?, description=?, price=?, stock=?, image_url=?, status=? WHERE id=?', 
      [name, description, price, stock, image_url, status, req.params.id]);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.delete('/products/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM products WHERE id=?', [req.params.id]);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.post('/store/buy', async (req, res) => {
  try {
    const { userId, houseId, productId, quantity } = req.body;
    const product = (await db.query('SELECT * FROM products WHERE id = ?', [productId]))[0][0];
    if (!product || product.stock < quantity) {
      return res.status(400).json({error: 'Produto indisponível ou estoque insuficiente'});
    }

    // Config MP
    const config: any = (await db.query('SELECT * FROM mercadopago_config LIMIT 1'))[0][0];

    // Enforce configurations
    if (config) {
      const isChaveiro = product.name.includes('Chaveiro');
      if (isChaveiro) {
        const maxQty = config.max_qty_per_order !== undefined ? Number(config.max_qty_per_order) : 10;
        if (Number(quantity) > maxQty) {
          return res.status(400).json({ error: `A quantidade máxima de compra permitida para o chaveiro é de ${maxQty} unidades por pedido.` });
        }
      }
    }

    const priceToUse = (product.name.includes('Chaveiro') && config?.unit_price !== undefined) 
      ? Number(config.unit_price) 
      : Number(product.price);

    const totalAmount = priceToUse * quantity;
    
    let qr_code = '';
    let qr_code_base64 = '';
    let payment_id = '';
    
    const mpToken = config ? (config.env === 'test' ? (config.test_access_token || config.access_token) : config.access_token) : null;
    
    if (config && mpToken) {
      // Create PIX transaction in MP
      const idempotencyKey = Math.random().toString(36).substring(7);
      const mpres = await fetch('https://api.mercadopago.com/v1/payments', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${mpToken}`,
          'Content-Type': 'application/json',
          'X-Idempotency-Key': idempotencyKey
        },
        body: JSON.stringify({
          transaction_amount: Number(totalAmount),
          description: `Pedido de ${quantity}x ${product.name}`,
          payment_method_id: 'pix',
          payer: {
             email: 'comprador@siae.space' // mock or get user email
          }
        })
      });
      const data = await mpres.json();
      if (data.point_of_interaction?.transaction_data) {
        qr_code = data.point_of_interaction.transaction_data.qr_code;
        qr_code_base64 = data.point_of_interaction.transaction_data.qr_code_base64;
        payment_id = data.id.toString();
      }
    } else {
       // Mock for development if not configured
       qr_code = '00020126...mockpix...00000000';
       qr_code_base64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAMSURBVBhXY3jh4AMAA1sBydZ7Y/kAAAAASUVORK5CYII=';
       payment_id = 'mock_' + Math.random().toString(36).substring(7);
    }
    
    // Decrement stock
    await db.query('UPDATE products SET stock = stock - ? WHERE id = ?', [quantity, productId]);
    
    // Insert order
    const orderRaw = await db.query('INSERT INTO orders (user_id, house_id, product_id, quantity, total_amount, status, payment_id, qr_code, qr_code_base64) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
       [userId, houseId || null, productId, quantity, totalAmount, 'pending', payment_id, qr_code, qr_code_base64]);
       
    res.json({
       success: true,
       orderId: (orderRaw[0] as any).insertId || 1,
       qr_code,
       qr_code_base64,
       totalAmount
    });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

// --- SIAE WORKER CALLING, DISCO PRESENCE & AUTO TIMEOUT ENDPOINTS ---

router.post('/presence/heartbeat', async (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ error: 'userId é obrigatório' });
  try {
    await db.query(`
      UPDATE users 
      SET online_status = 'online', last_seen_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `, [Number(userId)]);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/worker/session/active/:workerId', async (req, res) => {
  try {
    const session = (await db.query(`
      SELECT * FROM worker_sessions 
      WHERE worker_id = ? AND clock_out IS NULL 
      ORDER BY id DESC LIMIT 1
    `, [req.params.workerId]))[0][0] as any;
    res.json(session || null);
  } catch(error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/worker/clock-in', async (req, res) => {
  const { workerId, houseId, type, roomNumber } = req.body;
  if (!workerId || !houseId || !type || !roomNumber) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
  }
  try {
    // Check if worker is active and queue_enabled = 1
    const [link] = await db.query('SELECT status, queue_enabled FROM house_workers WHERE house_id = ? AND worker_id = ?', [houseId, workerId]) as any[];
    const isApproved = link && link[0] && link[0].status === 'active';
    const queueEnabled = link && link[0] && link[0].queue_enabled === 1;

    if (!isApproved || !queueEnabled) {
      return res.status(403).json({ error: 'Acesso à fila desabilitado para você nesta casa. O representante precisa habilitar sob o painel administrativo.' });
    }

    // Check if worker already has an active open session
    let session = (await db.query('SELECT * FROM worker_sessions WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL', [workerId, houseId]))[0][0] as any;
    if (!session) {
      const [info] = await db.query(
        'INSERT INTO worker_sessions (worker_id, house_id, status, current_assistance_type, room_number) VALUES (?, ?, ?, ?, ?)',
        [workerId, houseId, 'offline', type, roomNumber]
      );
      session = { id: Number((info as any).insertId), worker_id: workerId, house_id: houseId, status: 'offline', current_assistance_type: type, room_number: roomNumber };
    } else {
      await db.query(
        'UPDATE worker_sessions SET status = "offline", current_assistance_type = ?, room_number = ? WHERE id = ?',
        [type, roomNumber, session.id]
      );
    }
    res.json({ success: true, session });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/worker/clock-out', async (req, res) => {
  const { workerId, houseId } = req.body;
  if (!workerId || !houseId) {
    return res.status(400).json({ error: 'Campos workerId e houseId são obrigatórios' });
  }
  try {
    await db.query(
      'UPDATE worker_sessions SET clock_out = CURRENT_TIMESTAMP, status = "offline", room_number = NULL, current_assistance_type = NULL WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL',
      [workerId, houseId]
    );
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/worker/toggle-pause', async (req, res) => {
  const { workerId, houseId } = req.body;
  if (!workerId || !houseId) {
    return res.status(400).json({ error: 'Campos workerId e houseId são obrigatórios' });
  }
  try {
    const session = (await db.query('SELECT * FROM worker_sessions WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL', [workerId, houseId]))[0][0] as any;
    if (!session) {
      return res.status(400).json({ error: "Sessão ativa não encontrada." });
    }
    const newStatus = session.status === 'offline' ? 'available' : 'offline';
    await db.query('UPDATE worker_sessions SET status = ? WHERE id = ?', [newStatus, session.id]);
    res.json({ success: true, status: newStatus });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/queue/assisted/:assistedId/ahead', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const active = (await db.query(`
      SELECT * FROM attendances 
      WHERE assisted_id = ? AND status = 'waiting' AND DATE(created_at) = ?
      ORDER BY id DESC LIMIT 1
    `, [req.params.assistedId, today]))[0][0] as any;

    if (!active) {
      return res.json([]);
    }

    const ahead = (await db.query(`
      SELECT a.ticket_number, u.first_name, u.last_name, u.online_status
      FROM attendances a
      JOIN users u ON a.assisted_id = u.id
      WHERE a.house_id = ? AND a.type = ? AND a.status = 'waiting' AND DATE(a.created_at) = ? AND a.check_in_time < ?
      ORDER BY a.check_in_time DESC LIMIT 7
    `, [active.house_id, active.type, today, active.check_in_time]))[0] as any[];

    res.json(ahead.reverse());
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.post('/houses/:houseId/workers/:workerId/toggle-queue', async (req, res) => {
  const { houseId, workerId } = req.params;
  const { enabled } = req.body;
  try {
    await db.query(`
      UPDATE house_workers 
      SET queue_enabled = ? 
      WHERE house_id = ? AND worker_id = ?
    `, [enabled ? 1 : 0, Number(houseId), Number(workerId)]);
    res.json({ success: true, message: 'Status de fila do trabalhador atualizado' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/houses/:houseId/queue-detail', async (req, res) => {
  try {
    const houseId = req.params.houseId;
    const today = new Date().toISOString().split('T')[0];

    const typesRes = await db.query('SELECT * FROM assistance_types WHERE house_id = ? AND status = "active"', [houseId]);
    const types = typesRes[0] as any[];

    const detail = [];
    for (const t of types) {
      const waiting = (await db.query(`
        SELECT a.id, a.ticket_number, a.check_in_time, u.first_name, u.last_name, u.online_status
        FROM attendances a
        JOIN users u ON a.assisted_id = u.id
        WHERE a.house_id = ? AND a.type = ? AND a.status = 'waiting' AND DATE(a.created_at) = ?
        ORDER BY a.check_in_time ASC
      `, [houseId, t.name, today]))[0] as any[];

      const active = (await db.query(`
        SELECT a.id, a.ticket_number, a.status, u.first_name, u.last_name, u.online_status, ws.room_number, w.first_name as worker_first, w.last_name as worker_last
        FROM attendances a
        JOIN users u ON a.assisted_id = u.id
        LEFT JOIN users w ON a.worker_id = w.id
        LEFT JOIN worker_sessions ws ON a.worker_id = ws.worker_id AND ws.house_id = a.house_id AND ws.clock_out IS NULL
        WHERE a.house_id = ? AND a.type = ? AND a.status IN ('called', 'in_progress') AND DATE(a.created_at) = ?
      `, [houseId, t.name, today]))[0] as any[];

      const workers = (await db.query(`
        SELECT ws.id, ws.room_number, ws.status as session_status, u.first_name, u.last_name, u.online_status
        FROM worker_sessions ws
        JOIN users u ON ws.worker_id = u.id
        WHERE ws.house_id = ? AND ws.current_assistance_type = ? AND ws.clock_out IS NULL
      `, [houseId, t.name]))[0] as any[];

      detail.push({
        assistance: t.name,
        waitingCount: waiting.length,
        waitingList: waiting,
        activeList: active,
        workersList: workers
      });
    }

    res.json(detail);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// --- SWEEP ENGINE FOR NO-SHOW DE-ENQUEUING AND ONLINE RE-SCANS ---
const runBgChecksAll = async () => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // 1. Mark offline if not seen for > 45s
    await db.query(`
      UPDATE users 
      SET online_status = 'offline' 
      WHERE last_seen_at < SUBDATE(CURRENT_TIMESTAMP, INTERVAL 45 SECOND) 
        AND online_status = 'online'
    `);

    // 2. Timeout and auto-allocate cancelled called tickets
    const calledAttendancesResult = await db.query(`
      SELECT * FROM attendances 
      WHERE status = 'called' AND called_at IS NOT NULL
    `);
    const calledAttendances = (calledAttendancesResult && Array.isArray(calledAttendancesResult[0]) ? calledAttendancesResult[0] : []) as any[];

    for (const att of calledAttendances) {
      const calledAtTime = new Date(att.called_at).getTime();
      const elapsedSeconds = (Date.now() - calledAtTime) / 1000;

      if (elapsedSeconds >= 280) {
        console.log(`[Queue Timeout - No Show] Cancelling attendance ${att.id} (Ticket ${att.ticket_number})`);

        await db.query(`
          UPDATE attendances 
          SET status = 'cancelled', end_time = CURRENT_TIMESTAMP 
          WHERE id = ?
        `, [att.id]);

        if (att.worker_id) {
          await db.query(`
            UPDATE worker_sessions 
            SET status = 'offline' 
            WHERE worker_id = ? AND house_id = ? AND clock_out IS NULL
          `, [att.worker_id, att.house_id]);

          notifyUser(att.worker_id, 'worker_called_timeout', `O assistido ${att.ticket_number} não compareceu e o atendimento foi liberado.`, att);
        }

        notifyUser(att.assisted_id, 'attendance_cancelled_noshow', `Seu chamado para ${att.type} expirou por falta de presença.`);

        // Auto-allocate next recommended queues
        let requiredTypes: string[] = [];
        const request = (await db.query(`
          SELECT id, target_treatments 
          FROM assistance_requests 
          WHERE assisted_id = ? AND status = 'in_treatment' 
          ORDER BY created_at DESC LIMIT 1
        `, [att.assisted_id]))[0][0] as any;

        if (request && request.target_treatments) {
          let targetTreatments = [];
          try { targetTreatments = JSON.parse(request.target_treatments); } catch(e){}
          for (const treatment of targetTreatments) {
            if (treatment.typeId) {
              const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [treatment.typeId]))[0][0] as any;
              if (typeInfo) requiredTypes.push(typeInfo.name);
            }
          }
        }

        const completed = ((await db.query(`
          SELECT type FROM attendances 
          WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?
        `, [att.house_id, att.assisted_id, today]))[0] as any[]).map((r: any) => r.type);

        const pendingTypes = requiredTypes.filter((t: string) => t !== att.type && !completed.includes(t));

        if (pendingTypes.length > 0) {
          let bestType = pendingTypes[0];
          let minQueue = Infinity;
          let bestHasWorkers = false;

          for (const type of pendingTypes) {
            const count = (await db.query(`
              SELECT COUNT(*) as count FROM attendances 
              WHERE house_id = ? AND type = ? AND status IN ('waiting', 'in_progress') AND DATE(created_at) = ?
            `, [att.house_id, type, today]))[0][0] as any;
            const workersCount = (await db.query(`
              SELECT COUNT(*) as count 
              FROM worker_sessions 
              WHERE house_id = ? AND current_assistance_type = ? AND clock_out IS NULL AND status != 'offline'
            `, [att.house_id, type]))[0][0] as any;
            const hasWorkers = workersCount.count > 0;

            if (hasWorkers && !bestHasWorkers) {
               bestType = type;
               minQueue = count.count;
               bestHasWorkers = true;
            } else if (hasWorkers === bestHasWorkers) {
               if (count.count < minQueue) {
                 minQueue = count.count;
                 bestType = type;
               }
            }
          }

          const ticketCount = (await db.query(`
            SELECT COUNT(*) as count FROM attendances WHERE house_id = ? AND DATE(created_at) = ?
          `, [att.house_id, today]))[0][0] as any;
          const ticketNumber = `${bestType.substring(0, 1).toUpperCase()}${(ticketCount.count + 1).toString().padStart(3, '0')}`;

          await db.query(`
            INSERT INTO attendances (house_id, assisted_id, type, status, check_in_time, ticket_number, assistance_request_id)
            VALUES (?, ?, ?, 'waiting', CURRENT_TIMESTAMP, ?, ?)
          `, [att.house_id, att.assisted_id, bestType, ticketNumber, att.assistance_request_id]);

          notifyUser(att.assisted_id, 'queue_requeued', `Fila cancelada por no-show. Você foi alocado automaticamente na fila de ${bestType} (nova senha: ${ticketNumber}).`, { ticketNumber, type: bestType });
        }
      }
    }
  } catch(e) {
    console.error('Error in runBgChecksAll:', e);
  }
};

setInterval(runBgChecksAll, 10000);

// --- OPENMEETINGS CONFIGURATION ENDPOINTS (LEGACY PATHS FOR COMPATIBILITY) ---
router.get('/config/mirotalk', async (req, res) => {
  try {
    const [configUrl] = await db.query('SELECT value FROM system_settings WHERE `key` = ?', ['mirotalk_api_url']) as any[];
    const [configToken] = await db.query('SELECT value FROM system_settings WHERE `key` = ?', ['mirotalk_api_token']) as any[];

    res.json({
      mirotalk_api_url: configUrl && configUrl[0] ? configUrl[0].value : 'https://meet.appa.siae.space/openmeetings',
      mirotalk_api_token: configToken && configToken[0] ? configToken[0].value : ''
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/config/mirotalk', async (req, res) => {
  try {
    const { mirotalk_api_url, mirotalk_api_token } = req.body;

    const setSetting = async (key: string, value: string) => {
      const [existing] = await db.query('SELECT * FROM system_settings WHERE `key` = ?', [key]) as any[];
      if (existing && existing.length > 0) {
        await db.query('UPDATE system_settings SET value = ? WHERE `key` = ?', [value, key]);
      } else {
        await db.query('INSERT INTO system_settings (`key`, value) VALUES (?, ?)', [key, value]);
      }
    };

    await setSetting('mirotalk_api_url', mirotalk_api_url || 'https://meet.appa.siae.space/openmeetings');
    await setSetting('mirotalk_api_token', mirotalk_api_token || '');
    await setSetting('openmeetings_url', mirotalk_api_url || 'https://meet.appa.siae.space/openmeetings');

    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/config/mirotalk/test', async (req, res) => {
  try {
    return res.json({ 
      success: true, 
      details: 'SIAE Meet autônomo está totalmente operacional! Servidores de sinalização integrados com sucesso na porta principal (3000).' 
    });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

export default router;
