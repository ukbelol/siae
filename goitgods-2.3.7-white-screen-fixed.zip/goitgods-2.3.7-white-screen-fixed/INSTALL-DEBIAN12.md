# Instalação GOITGODS + PASQUARED no Debian 12

Pré-requisito externo: o DNS de `goitgods.pasquared.space` deve apontar para o IP público do servidor.

```bash
unzip goitgods-2.3.4-full-installer.zip -d goitgods-2.3.4
cd goitgods-2.3.4/goitgods-2.3.4-full-installer
chmod +x install-gods.sh
sudo ./install-gods.sh --certbot-email voce@dominio.com
```

O instalador cuida de APT, Node.js 24 LTS, npm, PM2, build, MariaDB, Apache, proxy `/api`, Certbot/Let's Encrypt e testes de saúde.

Após a instalação:

```bash
sudo goitgods-status
runuser -u goitgods -- env HOME=/opt/goitgods pm2 status
curl https://goitgods.pasquared.space/api/v2/health
```
