const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

lines[1140] = "    // Add participants";
lines[1141] = "    for (const conf of conferences) {";
lines[1142] = "      conf.participants = (await db.query('SELECT u.id, u.first_name, u.last_name FROM users u JOIN conference_participants cp ON u.id = cp.user_id WHERE cp.conference_id = ?', [conf.id]))[0] as any[];";
lines[1143] = "    }";
lines[1144] = "    res.json(conferences);";
lines[1145] = "  } catch (error: any) {";
lines[1146] = "    res.status(400).json({ error: error.message });";
lines[1147] = "  }";
lines[1148] = "});";
// Clean up the rest down to 1150
lines[1149] = "";
lines[1150] = "router.post('/houses/:houseId/conferences', async (req, res) => {"; // wait, need to check if 1150 is the right one! I will just erase the lines that don't match. 

fs.writeFileSync('src/api/index.ts', lines.join('\n'));
