# SIAE - Sistema Integrado de Assistência Espírita

Este documento descreve detalhadamente as funcionalidades do SIAE, a lógica da sequência de cadastros e o funcionamento prático e sistematizado da fila de atendimento, focando tanto na ótica do assistido quanto do trabalhador (médium/atendente).

---

## 1. Funcionalidades do Sistema (SIAE)

- **Gestão de Múltiplos Perfis (Roles):** Super Administrador, Representante da Casa, Trabalhadores (Médiuns, Entrevistadores, etc) e Assistidos.
- **Multitenancy (Múltiplas Casas Espíritas):** Permite controlar e gerenciar diversas instituições filantrópicas ou centros em um único banco de dados.
- **Painel de Triagem e Solicitação de Tratamentos:** Captura de relatos, análises doutrinárias e geração de planos de tratamento sugeridos por equipe responsável.
- **Gerenciador de Chaveiros e Tags NFC:** Ativação, administração e atribuição de devices físicos (Tags) para um fluxo de entrada (check-in) expresso sem dependência de celular pelo assistido.
- **Filas de Atendimento e Salas:** Módulo inteligente em tempo real que roteia os assistidos e distribui aos trabalhadores logados dependendo do tipo da assistência no dia (Entrevista, Passes, Desobsessão).
- **Módulo de Ponto do Trabalhador:** Função de Clock-in e Clock-out para o controle da carga e presença do staff mediúnico nas reuniões e painéis de atendimento.
- **Loja, Boletos e Doações:** Gateway completo configurável em painel com a sub-adquirência Mercado Pago, permitindo venda de itens (ex: o próprio Chaveiro NFC, águas fluidificadas) ou captação de dízimos/doações via Pix automáticos.
- **Videochamadas Integradas:** Estruturação para reuniões online (estudos, tratamentos à distância).
- **Backup via Painel:** Módulo SuperAdmin permite gestão e extração/restauração da base de dados e de recursos de software para evitar perdas (SIAE local vs nuvem).

---

## 2. Lógica da Sequência de Cadastro e Adoção

O processo gradual para a entidade e novos frequentadores é fundamentado da seguinte maneira:

1. **Setup da Casa (Representante):** O responsável (Representante) faz a submissão e o painel SuperAdmin aprova. O Representante entra, define quais são as modalidades das atividades (Trilhas de Tratamento), departamentos e horários de funcionamento.
2. **Setup da Equipe (Trabalhador):** O Trabalhador (médium, atendente ou voluntário) cria sua conta por celular ou terminal. Ele solicita associação para trabalhar em uma ou mais Casas ativas e seleciona suas especialidades.
3. **Validação da Equipe:** O Representante da respectiva Casa avalia a solicitação do Trabalhador e autoriza (Setado para Aprovado). A partir desse momento, esse membro da equipe tem login válido para atuar na Casa.
4. **Entrada do Assistido:** O paciente/assistido cria sua conta pelo próprio smartphone ao ler o QRCode de entrada, ou na recepção com os voluntários.
5. **Acolhimento e Relato:** Para iniciar ajuda de cunho espiritual ou físico, o assistido responde no sistema (ou em entrevista guiada com um atendente preenchendo os dados dele) com base em seu "Relato de Problema". Baseado no cenário, é construído a sua jornada, indicando que tratamentos ele fará.

---

## 3. Lógica da Fila de Atendimento (Perspectiva do Assistido)

Para a fluidez na recepção e salão e evitar constrangimento oral na hora de se expor, a jornada projetada para quem é auxiliado (assistido):

1. **Chegada e Check-in Expresso:** Ao entrar no pátio ou salão presencial no dia do seu atendimento programado, se o assistido possuir seu prático **Chaveiro SIAE NFC**, basta aproximar do totem de entrada. Sem chaveiro, ele poderá fazer o check-in por CPF na recepção e/ou ler um QRCode.
2. **Registro de Senha / Ticket:** O SIAE instantaneamente acusa leitura, confirma que ele está apto ao tratamento agendado e entrega virtualmente ou num display um "Ticket/Senha de Chamada" de fila (Exemplo: "Dirija-se a Sala 4 - Entrevista Fraterna"). O Status do registro torna-se `Aguardando` na Fila do Tratamento.
3. **Atendimento Roteado:** Quando sua senha e nome aparecem no monitor (se houver), ou ele é notificado no telefone pessoal, ele se encaminha até o recinto designado do servidor.
4. **Circuito de Continuidade:** Diferencial de automação — caso a entrevista indique a necessidade de um *Passe* no mesmo dia, o término do diálogo na mesa faz com que o sistema, nos bastidores, o adicione no "final da próxima fila" (Passe) automaticamente. O assistido apenas segue as setas ou displays para o próximo ambiente de espera sem ter que passar novamente pela recepção central.
5. **Check-out e Liberação:** Ao passar pela sua última etapa no circuito, a sua ida é completada no banco de dados e ele tem o aval de dispensa.

---

## 4. Lógica da Fila de Atendimento (Perspectiva do Trabalhador)

Para o voluntário (médium / curador / passista / doutrinador) que dispensa sua caridade sem estresse no fluxo:

1. **Ativação da Escala (Clock-In):** O trabalhador entra na sala de auxílio, abre seu painel no dispositivo ou notebook e deve pressionar "Iniciar Sessão". Somente a partir disso seu status interno vira `Available` (Pronto).
2. **Monitoramento e Visualização de Demanda:** O Painel de Atendimento filtra quem está em modo `Waiting` aguardando especificamente as atribuições das quais aquele trabalhador cuida (por ex: ele tem skill de Passes de Limpeza).
3. **Ato de Evocar o Assistido (Call):** O Voluntário clica em **"Chamar Próximo"**. O SIAE piscará a chamada com o nome/senha nas visualizações (do salão ou online).
4. **Etapa "In-Progress":** Com o paciente na sua frente (ou na sala virtual), o Atendente fica setado para `Busy` (livrando dos cálculos da média de espera). Se ele tiver permissões (é um entrevistador), verá na tela o relato doloroso preenchido semanas atrás e qual o objetivo ou orientações dadas pelos Diretores Espirituais sem ter que ficar fazendo repetidas perguntas de cunho sensível.
5. **Conclusão:** O Atendente finaliza o ciclo de passe, irradiação ou triagem clicando em **"Finalizar"**. Ele opcionalmente redige uma nota rápida do caso e o sistema muda a ponta daquele evento e encaminha o assistido pra próxima estação. Imediatamente o Trabalhador volta a ficar `Available` e pode chamar outra senha em seu Painel.
6. **Encerramento de Escala:** Ao fim dos turnos, clica-se em **Clock-Out**, se desconectando das estatísticas e registrando um fim da jornada do voluntariado em seu histórico institucional pessoal de pontos.

