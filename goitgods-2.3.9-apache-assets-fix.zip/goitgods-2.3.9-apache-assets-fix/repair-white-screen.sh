#!/usr/bin/env bash
set -Eeuo pipefail
INSTALL_DIR="${INSTALL_DIR:-/opt/goitgods}"
APP_NAME="${APP_NAME:-goitgods}"
DOMAIN_NAME="${DOMAIN_NAME:-goitgods.pasquared.space}"
SYS_USER="${SYS_USER:-goitgods}"
ENV_FILE="$INSTALL_DIR/.env"
PORT="${PORT:-}"
[[ -z "$PORT" && -f "$ENV_FILE" ]] && PORT="$(grep '^PORT=' "$ENV_FILE" | tail -1 | cut -d= -f2- || true)"
PORT="${PORT:-3100}"
red='\033[0;31m'; green='\033[0;32m'; yellow='\033[1;33m'; nc='\033[0m'
info(){ echo -e "${yellow}[GOITGODS]${nc} $*"; }
ok(){ echo -e "${green}[OK]${nc} $*"; }
fail(){ echo -e "${red}[ERRO]${nc} $*" >&2; exit 1; }
run_app(){ runuser -u "$SYS_USER" -- env HOME="$INSTALL_DIR" PATH="/usr/local/bin:/usr/bin:/bin" "$@"; }
[[ ${EUID:-$(id -u)} -eq 0 ]] || fail "Execute como root: sudo ./repair-white-screen.sh"
[[ -f "$INSTALL_DIR/package.json" ]] || fail "package.json não encontrado em $INSTALL_DIR"
for c in node npm pm2 curl jq; do command -v "$c" >/dev/null || fail "$c não encontrado"; done
cd "$INSTALL_DIR"
info "Node: $(node -v) | npm: $(npm -v) | porta: $PORT"
info "Instalando dependências de build..."
if [[ -f package-lock.json ]]; then run_app npm ci --include=dev --no-audit --no-fund; else run_app npm install --include=dev --no-audit --no-fund; fi
info "Reconstruindo dist/..."
rm -rf dist
run_app env NODE_ENV=production npm run build
[[ -s dist/index.html ]] || fail "dist/index.html não foi gerado"
[[ -s dist/server.cjs ]] || fail "dist/server.cjs não foi gerado"
find dist/assets -maxdepth 1 -type f -name '*.js' -print -quit | grep -q . || fail "bundle JavaScript ausente"
ok "Build de produção íntegro"
info "Reiniciando PM2..."
run_app pm2 delete "$APP_NAME" >/dev/null 2>&1 || true
run_app env PORT="$PORT" NODE_ENV=production pm2 start "$INSTALL_DIR/dist/server.cjs" --name "$APP_NAME" --cwd "$INSTALL_DIR" --interpreter node --update-env
run_app pm2 save
sleep 2
curl -fsS "http://127.0.0.1:$PORT/api/v2/health" | jq -e '.status == "ok"' >/dev/null || { run_app pm2 logs "$APP_NAME" --lines 100 --nostream || true; fail "API direta não respondeu"; }
ok "API direta em :$PORT"
apache2ctl configtest
systemctl reload apache2
INDEX_HTTP="$(curl -fsS -H "Host: $DOMAIN_NAME" -H 'Cache-Control: no-cache' http://127.0.0.1/)"
echo "$INDEX_HTTP" | grep -q 'id="root"' || fail "Apache não entregou o frontend"
curl -fsS -H "Host: $DOMAIN_NAME" http://127.0.0.1/api/v2/health | jq -e '.status == "ok"' >/dev/null || fail "Proxy Apache /api falhou"
ASSET_PATHS="$(printf '%s' "$INDEX_HTTP" | grep -oE '(src|href)="/assets/[^"]+\.(js|css)"' | sed -E 's/^(src|href)="([^"]+)"/\2/' | sort -u || true)"
[[ -n "$ASSET_PATHS" ]] || fail "index.html não referencia bundles /assets"
while IFS= read -r asset; do
  [[ -n "$asset" ]] || continue
  headers=/tmp/goitgods-repair-headers
  code="$(curl -sS -D "$headers" -o /tmp/goitgods-repair-asset -w '%{http_code}' -H "Host: $DOMAIN_NAME" "http://127.0.0.1$asset")"
  [[ "$code" == 200 && -s /tmp/goitgods-repair-asset ]] || fail "Asset $asset inválido (HTTP $code)"
  ctype="$(awk 'BEGIN{IGNORECASE=1} /^Content-Type:/{gsub(/\r/,""); print tolower($2); exit}' "$headers")"
  case "$asset" in
    *.js) [[ "$ctype" == *javascript* ]] || fail "Asset JS $asset recebeu '$ctype' em vez de JavaScript" ;;
    *.css) [[ "$ctype" == text/css* ]] || fail "Asset CSS $asset recebeu '$ctype' em vez de text/css" ;;
  esac
done <<< "$ASSET_PATHS"
rm -f /tmp/goitgods-repair-asset /tmp/goitgods-repair-headers
ok "Frontend + API + bundles HTTP"
if [[ -s "/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem" ]]; then
  curl -fsS --resolve "$DOMAIN_NAME:443:127.0.0.1" "https://$DOMAIN_NAME/" | grep -q 'id="root"' || fail "Frontend HTTPS falhou"
  curl -fsS --resolve "$DOMAIN_NAME:443:127.0.0.1" "https://$DOMAIN_NAME/api/v2/health" | jq -e '.status == "ok"' >/dev/null || fail "API HTTPS falhou"
  ok "HTTPS + API validados"
fi
ok "Reparo concluído. Abra https://$DOMAIN_NAME/ com Ctrl+F5."
