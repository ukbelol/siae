
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./siae.db');
db.serialize(() => {
  db.get("SELECT id FROM users WHERE email = 'rogerangel577'", (err, row) => {
    if (!row) {
      db.run("INSERT INTO users (role, email, password, first_name, last_name, cpf, dob) VALUES ('super_admin', 'rogerangel577', '2149090577&Roger-577', 'Roger', 'Admin', '00000000002', '1990-01-01')");
      console.log('User rogerangel577 seeded');
    } else {
      console.log('User already exists');
    }
  });
});
