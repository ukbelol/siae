/**
 * Utilitários para validação de Nickname e Obtenção do Nome de Exibição
 * Regras:
 * - Nickname opcional no cadastro ou criado via perfil
 * - Máximo de 8 caracteres entre números, letras e os caracteres válidos: "-", "." e "_"
 * - Uso automático do nickname nas salas/conversas se existir, ou nome real de cadastro caso contrário
 */

export const NICKNAME_MAX_LENGTH = 8;
export const NICKNAME_REGEX = /^[a-zA-Z0-9._-]{1,8}$/;

export interface NicknameValidationResult {
  isValid: boolean;
  error?: string;
}

/**
 * Valida o formato do nickname segundo as regras oficiais do sistema:
 * - Até 8 caracteres
 * - Letras, números e apenas "-", "." e "_"
 */
export function validateNicknameFormat(nickname: string): NicknameValidationResult {
  const trimmed = nickname.trim();
  if (!trimmed) {
    return { isValid: false, error: 'O nickname não pode ser vazio.' };
  }

  if (trimmed.length > NICKNAME_MAX_LENGTH) {
    return {
      isValid: false,
      error: `O nickname deve ter no máximo ${NICKNAME_MAX_LENGTH} caracteres (você digitou ${trimmed.length}).`,
    };
  }

  if (!NICKNAME_REGEX.test(trimmed)) {
    return {
      isValid: false,
      error: 'O nickname deve conter apenas letras, números e os caracteres ".", "-" e "_".',
    };
  }

  return { isValid: true };
}

/**
 * Retorna o nome que deve ser usado para entrar nas salas, bate-papos e iniciar conversas:
 * 1. Se o usuário tiver um nickname cadastrado e não vazio, usa o NICKNAME.
 * 2. Caso contrário, usa automaticamente o NOME REAL de cadastro (Nome + Sobrenome).
 */
export function getUserDisplayName(
  user?: { name?: string; lastName?: string; nickname?: string } | null,
  fallback = 'Participante'
): string {
  if (!user) return fallback;

  // 1. Se tem nickname válido cadastrado, usa o nickname
  if (user.nickname && user.nickname.trim().length > 0) {
    return user.nickname.trim();
  }

  // 2. Se não tem nickname, usa o nome real de cadastro
  const realName = [user.name, user.lastName].filter(Boolean).join(' ').trim();
  if (realName.length > 0) {
    return realName;
  }

  return fallback;
}
