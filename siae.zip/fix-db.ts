import mysql from 'mysql2/promise';

async function fix() {
  const db = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'siae_user',
    password: process.env.DB_PASSWORD || 'siae_password',
    database: process.env.DB_NAME || 'siae_db'
  });
  
  try {
    await db.query('ALTER TABLE nfc_tags MODIFY activation_date VARCHAR(50)');
    await db.query('ALTER TABLE nfc_tags MODIFY serial_number VARCHAR(60)');
    await db.query('ALTER TABLE users MODIFY nfc_tag VARCHAR(60)');
    console.log("Altered successfully");
  } catch (e: any) {
    console.log("Alter Error:", e.message);
  }
  process.exit(0);
}
fix();
