#!/bin/bash
npx tsx update_admin.ts
