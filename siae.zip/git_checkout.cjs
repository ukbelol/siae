const { execSync } = require('child_process');
execSync('git checkout src/api/index.ts src/api/admin.ts src/lib/backup.ts src/lib/schema.ts', { stdio: 'inherit' });
