const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');
lines[1150] = "";
fs.writeFileSync('src/api/index.ts', lines.join('\n'));
