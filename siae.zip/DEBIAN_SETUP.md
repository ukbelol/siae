# Guia de Instalação S.I.A.E - Debian 12 + Apache2 + SSL/TLS

Este guia descreve os passos para implantar o **S.I.A.E (Sistema Integrado de Assistência Espírita)** em um servidor Linux Debian 12, utilizando Apache2 como proxy reverso e Let's Encrypt para SSL/TLS automático.

## Pré-requisitos
- Servidor com Debian 12 instalado.
- Acesso root ou usuário com privilégios `sudo`.
- Um domínio apontado para o IP do servidor (ex: `siae.seusite.com`).

---

## 1. Atualizar o Sistema e Instalar Dependências

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install curl git build-essential apache2 certbot python3-certbot-apache -y
```

## 2. Instalar o Node.js (Versão 20 LTS)

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

## 3. Clonar e Configurar o Projeto

```bash
# Navegue até o diretório web
cd /var/www

# Clone o seu repositório (substitua pela URL real)
sudo git clone https://github.com/seu-usuario/siae.git
cd siae

# Instale as dependências do projeto
sudo npm install

# Faça o build da aplicação (Vite + React)
sudo npm run build
```

## 4. Configurar o PM2 (Gerenciador de Processos Node.js)
O PM2 manterá o servidor Node.js rodando em segundo plano e reiniciará automaticamente em caso de falhas ou reinicialização do servidor.

```bash
sudo npm install -g pm2
sudo pm2 start npm --name "siae" -- run start
sudo pm2 startup
sudo pm2 save
```
> **Nota:** O banco de dados SQLite (`siae.db`) será criado automaticamente na raiz do projeto e os dados serão persistentes.

## 5. Configurar o Apache2 como Proxy Reverso

Habilite os módulos necessários do Apache:
```bash
sudo a2enmod proxy proxy_http headers rewrite
```

Crie o arquivo de Virtual Host:
```bash
sudo nano /etc/apache2/sites-available/siae.conf
```

Cole a seguinte configuração (substitua `siae.seusite.com` pelo seu domínio):

```apache
<VirtualHost *:80>
    ServerName siae.seusite.com
    ServerAdmin webmaster@seusite.com

    # Redireciona o tráfego para o servidor Node.js rodando na porta 3000
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/

    ErrorLog ${APACHE_LOG_DIR}/siae_error.log
    CustomLog ${APACHE_LOG_DIR}/siae_access.log combined
</VirtualHost>
```

Ative o site e reinicie o Apache:
```bash
sudo a2ensite siae.conf
sudo systemctl restart apache2
```

## 6. Configurar SSL/TLS Automático com Certbot

Execute o Certbot para gerar e instalar o certificado SSL automaticamente:

```bash
sudo certbot --apache -d siae.seusite.com
```

Siga as instruções na tela. O Certbot irá modificar automaticamente o seu arquivo `siae.conf` para redirecionar o tráfego HTTP para HTTPS e configurar os certificados.

## 7. Verificação
Acesse `https://siae.seusite.com` no seu navegador. O sistema S.I.A.E deve estar online, seguro com HTTPS, e com os dados persistidos no SQLite.
