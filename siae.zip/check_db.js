import Database from 'better-sqlite3';
const db = new Database('./siae.db');
const schema = db.prepare("SELECT sql FROM sqlite_master WHERE name = 'assistance_types'").get();
console.log(schema.sql);
