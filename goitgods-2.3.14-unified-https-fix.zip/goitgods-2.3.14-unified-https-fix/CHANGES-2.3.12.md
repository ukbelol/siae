# GOITGODS 2.3.12 — Black Screen Fix

- Loader HTML estático visível antes do React.
- Bootstrap inline captura erros mesmo se o arquivo auxiliar falhar.
- O boot só é marcado como concluído após o React produzir DOM real.
- Watchdog transforma tela preta/vazia em diagnóstico visível.
- Mantém as correções acumuladas de Apache, assets, PM2, porta 3100, rsync, UFW/SSH e reinstalação idempotente.
