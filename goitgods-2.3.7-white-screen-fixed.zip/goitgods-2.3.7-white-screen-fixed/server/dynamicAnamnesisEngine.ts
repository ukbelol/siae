import type {
  AcademicLevel,
  DynamicAnamnesisQuestion,
  DynamicAnamnesisSession,
  DynamicAnamnesisStepResponse,
  KnowledgeDomainId,
  ResearchAnamnesisInput,
} from '../src/types';
import { academicSourceService } from './academicSourceService';

const COMMON_QUESTIONS: DynamicAnamnesisQuestion[] = [
  { id: 'topic', stage: 'FOCO', question: 'Qual tema específico você quer investigar dentro dessa área?', required: true, kind: 'textarea', help: 'Quanto mais específico o tema, melhor será a busca acadêmica.' },
  { id: 'motivation', stage: 'FOCO', question: 'O que você quer entender, explicar, comparar, testar ou resolver com essa pesquisa?', required: true, kind: 'textarea' },
  { id: 'problem', stage: 'PROBLEMA', question: 'Transforme sua dúvida principal em uma pergunta de pesquisa. Qual pergunta o trabalho precisa responder?', required: true, kind: 'textarea' },
  { id: 'scope', stage: 'RECORTE', question: 'Qual recorte deve limitar a investigação: período, local, população, fenômeno, tecnologia, autor, norma ou contexto?', required: false, kind: 'textarea' },
  { id: 'premises', stage: 'PREMISSAS', question: 'Quais hipóteses ou premissas você acredita que podem ser verdadeiras e deseja colocar à prova?', required: false, kind: 'textarea', help: 'O PASQUARED estruturará cada premissa e o GOITGODS tentará sustentá-la, limitá-la ou refutá-la.' },
  { id: 'knownFacts', stage: 'EVIDENCIAS', question: 'Que fatos, dados, autores, estudos, leis ou fontes você já conhece?', required: false, kind: 'textarea' },
  { id: 'generalObjective', stage: 'OBJETIVOS', question: 'Qual deve ser o objetivo geral da pesquisa?', required: true, kind: 'textarea' },
  { id: 'specificObjectives', stage: 'OBJETIVOS', question: 'Quais etapas ou objetivos específicos precisam ser cumpridos para responder ao problema?', required: false, kind: 'textarea' },
  { id: 'methodPreference', stage: 'METODO', question: 'Há uma metodologia exigida ou preferida?', required: false, kind: 'textarea', help: 'Ex.: revisão bibliográfica, revisão sistemática, estudo de caso, documental, qualitativa, quantitativa, experimental.' },
  { id: 'sourceRequirements', stage: 'FONTES', question: 'Há autores, bases, tipos de fonte, idioma ou período de publicação obrigatórios?', required: false, kind: 'textarea' },
  { id: 'constraints', stage: 'LIMITES', question: 'Quais limites e normas devo respeitar?', required: false, kind: 'textarea', help: 'Ex.: ABNT/APA, número de páginas, prazo, idioma, proibição de certas fontes.' },
  { id: 'outputType', stage: 'ENTREGA', question: 'Qual deve ser o produto final?', required: true, kind: 'select', options: ['Pesquisa escolar','Trabalho acadêmico','Artigo','TCC','Monografia','Dissertação','Tese','Relatório técnico','Livro/E-book','Outro'] },
];

const DOMAIN_QUESTIONS: Partial<Record<KnowledgeDomainId, DynamicAnamnesisQuestion[]>> = {
  MEDICINE: [
    { id: 'populationContext', stage: 'RECORTE_CLINICO', question: 'A pesquisa envolve qual população, condição clínica, faixa etária ou contexto de cuidado?', required: false, kind: 'textarea' },
    { id: 'clinicalQuestionType', stage: 'METODO_CLINICO', question: 'A questão é principalmente sobre diagnóstico, tratamento, prognóstico, prevenção, epidemiologia ou outro aspecto?', required: false, kind: 'select', options: ['Diagnóstico','Tratamento','Prognóstico','Prevenção','Epidemiologia','Etiologia','Outro'] },
  ],
  RADIOLOGY: [
    { id: 'imagingModality', stage: 'RECORTE_RADIOLOGICO', question: 'Qual modalidade de imagem está em foco?', required: false, kind: 'select', options: ['Radiografia','Tomografia','Ressonância magnética','Ultrassonografia','Medicina nuclear','Multimodal','Outra'] },
    { id: 'populationContext', stage: 'RECORTE_RADIOLOGICO', question: 'Qual condição, órgão, população ou cenário diagnóstico deve ser considerado?', required: false, kind: 'textarea' },
  ],
  LAW: [
    { id: 'jurisdiction', stage: 'RECORTE_JURIDICO', question: 'Qual jurisdição é relevante (Brasil, estado/município, outro país ou direito internacional)?', required: true, kind: 'text' },
    { id: 'legalMaterial', stage: 'RECORTE_JURIDICO', question: 'A pesquisa deve priorizar legislação, jurisprudência, doutrina, tratados, atos administrativos ou comparação entre eles?', required: false, kind: 'textarea' },
  ],
  PSYCHOLOGY: [
    { id: 'populationContext', stage: 'RECORTE_PSICOLOGICO', question: 'Qual população, faixa etária ou contexto psicológico/educacional/clínico está em foco?', required: false, kind: 'textarea' },
    { id: 'psychApproach', stage: 'REFERENCIAL', question: 'Existe abordagem psicológica ou referencial teórico prioritário?', required: false, kind: 'textarea' },
  ],
  PSYCHOANALYSIS: [
    { id: 'psychApproach', stage: 'REFERENCIAL', question: 'Qual tradição ou autor psicanalítico deve orientar o recorte (por exemplo Freud, Klein, Winnicott, Lacan ou abordagem comparativa)?', required: false, kind: 'textarea' },
    { id: 'conceptualCorpus', stage: 'CORPUS', question: 'A pesquisa analisará conceitos, textos teóricos, casos publicados, história da psicanálise ou diálogo com evidência empírica?', required: false, kind: 'textarea' },
  ],
  EXACT_SCIENCES: [
    { id: 'formalVariables', stage: 'MODELAGEM', question: 'Quais variáveis, grandezas, estruturas matemáticas ou relações formais são centrais?', required: false, kind: 'textarea' },
    { id: 'validationMode', stage: 'VALIDACAO', question: 'A validação será teórica, por demonstração, simulação, experimento, dados observacionais ou combinação?', required: false, kind: 'textarea' },
  ],
  BIOLOGICAL_SCIENCES: [
    { id: 'biologicalLevel', stage: 'RECORTE_BIOLOGICO', question: 'Qual nível biológico está em foco: molecular, celular, organismo, população, comunidade ou ecossistema?', required: false, kind: 'select', options: ['Molecular','Celular','Organismo','População','Comunidade','Ecossistema','Multinível'] },
  ],
  ENGINEERING_TECHNOLOGY: [
    { id: 'systemContext', stage: 'REQUISITOS', question: 'Qual sistema, tecnologia, ambiente ou requisito técnico será analisado?', required: false, kind: 'textarea' },
    { id: 'validationMode', stage: 'VALIDACAO', question: 'Como a solução ou hipótese deve ser validada: benchmark, protótipo, simulação, teste de campo, experimento ou revisão técnica?', required: false, kind: 'textarea' },
  ],
};

export class DynamicAnamnesisEngine {
  private sessions = new Map<string, DynamicAnamnesisSession>();

  public start(input: { subjectArea: string; academicLevel: AcademicLevel; schoolYear?: string }): DynamicAnamnesisStepResponse {
    if (!input.subjectArea?.trim()) throw new Error('Informe a matéria/área do conhecimento.');
    if (!input.academicLevel) throw new Error('Informe o nível acadêmico.');
    const domain = academicSourceService.detectDomain(input.subjectArea, '');
    const now = new Date().toISOString();
    const session: DynamicAnamnesisSession = {
      sessionId: `dyn_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
      subjectArea: input.subjectArea.trim(), academicLevel: input.academicLevel, schoolYear: input.schoolYear?.trim(),
      detectedDomain: domain, answers: {}, answeredQuestions: [], currentQuestion: null, complete: false, createdAt: now, updatedAt: now,
    };
    session.currentQuestion = this.nextQuestion(session);
    this.sessions.set(session.sessionId, session);
    return { session, nextQuestion: session.currentQuestion, completed: false };
  }

  public answer(sessionId: string, questionId: string, answer: string): DynamicAnamnesisStepResponse {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error('Sessão de anamnese não encontrada ou expirada.');
    if (!session.currentQuestion || session.currentQuestion.id !== questionId) throw new Error('A resposta não corresponde à pergunta atual.');
    if (session.currentQuestion.required && !answer?.trim()) throw new Error('Esta pergunta exige uma resposta.');
    session.answers[questionId] = answer?.trim() || '';
    if (!session.answeredQuestions.includes(questionId)) session.answeredQuestions.push(questionId);

    if (questionId === 'topic') {
      session.detectedDomain = academicSourceService.detectDomain(session.subjectArea, answer);
    }

    session.updatedAt = new Date().toISOString();
    const next = this.nextQuestion(session);
    session.currentQuestion = next;
    session.complete = !next;
    this.sessions.set(sessionId, session);
    const synthesizedInput = session.complete ? this.toResearchInput(session) : undefined;
    return { session, nextQuestion: next, completed: session.complete, synthesizedInput };
  }

  public get(sessionId: string) { return this.sessions.get(sessionId) || null; }

  private nextQuestion(session: DynamicAnamnesisSession): DynamicAnamnesisQuestion | null {
    const domainSpecific = DOMAIN_QUESTIONS[session.detectedDomain] || [];
    const sequence: DynamicAnamnesisQuestion[] = [];
    // Domain-specific questions are inserted after the problem is known, so they can sharpen the search packet.
    for (const q of COMMON_QUESTIONS) {
      sequence.push(q);
      if (q.id === 'problem') sequence.push(...domainSpecific);
    }
    return sequence.find(q => !session.answeredQuestions.includes(q.id)) || null;
  }

  private toResearchInput(s: DynamicAnamnesisSession): ResearchAnamnesisInput {
    const a = s.answers;
    const domainContext = [a.jurisdiction, a.legalMaterial, a.populationContext, a.clinicalQuestionType, a.imagingModality, a.psychApproach, a.conceptualCorpus, a.formalVariables, a.biologicalLevel, a.systemContext, a.validationMode].filter(Boolean).join('; ');
    const scope = [a.scope, domainContext].filter(Boolean).join(' | ');
    return {
      subjectArea: s.subjectArea, academicLevel: s.academicLevel, schoolYear: s.schoolYear,
      topic: a.topic || '', problem: a.problem || a.motivation || '', scope,
      generalObjective: a.generalObjective || `Investigar ${a.topic || s.subjectArea} de forma estruturada e baseada em evidências.`,
      specificObjectives: a.specificObjectives || '', premises: a.premises || '', knownFacts: a.knownFacts || '',
      sourceRequirements: a.sourceRequirements || '', methodPreference: a.methodPreference || '', constraints: a.constraints || '',
      outputType: a.outputType || 'Trabalho acadêmico',
    };
  }
}

export const dynamicAnamnesisEngine = new DynamicAnamnesisEngine();
