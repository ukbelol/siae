import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { pasquaredCore } from './server/pasquaredCore';
import { pasquaredOrchestrator } from './server/pasquaredOrchestrator';
import { researchAnamnesisEngine } from './server/researchAnamnesisEngine';
import { dynamicAnamnesisEngine } from './server/dynamicAnamnesisEngine';
import { pfaAgent } from './server/pfaAgent';
import { chronosEngine } from './server/chronosEngine';
import { goitgodsEngine } from './server/goitgodsEngine';
import { ebookEngine } from './server/ebookEngine';
import { adminEngine } from './server/adminEngine';
import { superAdminRegistry } from './server/superAdminRegistry';
import { foundryAgentService } from './server/foundryAgentService';
import { securityManager } from './server/securityManager';
import { GODS_REGISTRY } from './src/data/godsData';
import { ResearchProfile, FormulationMode, SystemExecutionResult } from './src/types';

// Safe environment resolution
const isProd = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT || 3100);

  app.use(express.json({limit:'2mb'}));
  app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('Permissions-Policy','camera=(), geolocation=(), payment=()');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data: https:; media-src 'self' blob: https:; connect-src 'self' https: wss:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");next()});
  const buckets=new Map<string,{count:number,reset:number}>();
  app.use('/api/',(req,res,next)=>{const now=Date.now(),key=String(req.ip||'unknown');let b=buckets.get(key);if(!b||now>=b.reset)b={count:0,reset:now+60000};b.count++;buckets.set(key,b);if(b.count>240)return res.status(429).json({success:false,error:'Muitas requisições.'});next()});
  const adminLoginBuckets=new Map<string,{failures:number,blockedUntil:number}>();

  // API Routes FIRST

  // Health check
  app.get('/api/v2/health', (req, res) => {
    res.json({
      success: true,
      status: 'ok',
      system: 'GOITGODS + PASQUARED-OS',
      version: '2.3.5',
      timestamp: new Date().toISOString(),
    });
  });

  // 1. Full Cognitive Query Pipeline (GOITGODS 2.1 + PASQUARED-OS)
  app.post('/api/v2/query', async (req, res) => {
    try {
      const { query, mode, customAnswers, researchProfile } = req.body;
      const userQuery = query || 'Revolução Industrial';

      // 1. PFA Formulation
      const formulation = pfaAgent.createInitialState(userQuery, mode as FormulationMode, customAnswers);

      // 2. Knowledge Retrieval from PASQUARED Knowledge Core
      const knowledgeObjects = await pasquaredCore.retrieveKnowledge(userQuery);

      // 3. Domain Discovery
      const discoveredDomains = goitgodsEngine.discoverDomains(userQuery);

      // 4. God Weight Calibration
      const selectedGods = goitgodsEngine.calculateGodWeights(discoveredDomains, formulation);

      // 5. Parallel Specialist Reasoning
      const godOutputs = await goitgodsEngine.runParallelSpecialists(userQuery, selectedGods, knowledgeObjects);

      // 6. Contradiction Detection
      const contradictions = goitgodsEngine.detectContradictions(godOutputs);

      // 7. ARES Adversarial & HADES Risk Engines
      const aresAttacks = goitgodsEngine.runARESAdversarial(godOutputs);
      const hadesRisk = goitgodsEngine.runHADESRisk(godOutputs, contradictions);

      // 8. MVED 2.0 Engine
      const mvedScores = goitgodsEngine.calculateMVED(godOutputs, selectedGods, hadesRisk, contradictions);

      // 9. ZEUS Arbitration Engine
      const zeusDecision = goitgodsEngine.arbitrateZEUS(userQuery, godOutputs, selectedGods, mvedScores, contradictions);

      // 10. CHRONOS Historical Timeline
      const rp: ResearchProfile = researchProfile || {
        origin: true,
        causes: true,
        strengths: true,
        weaknesses: true,
        duration: true,
        beginning: true,
        development: true,
        middle: true,
        ending: true,
        consequences: true,
        actors: true,
        sources: true,
        uncertainties: true,
        controversies: true,
      };
      const historicalTimeline = await chronosEngine.buildHistoricalTimeline(userQuery, rp);

      const result: SystemExecutionResult = {
        query: userQuery,
        formulation,
        discoveredDomains,
        selectedGods,
        godOutputs,
        contradictions,
        aresAttacks,
        hadesRisk,
        mvedScores,
        zeusDecision,
        historicalTimeline,
        knowledgeObjects,
      };

      res.json({ success: true, result });
    } catch (error: any) {
      console.error('Error in /api/v2/query:', error);
      res.status(500).json({ success: false, error: error.message || 'Internal execution error' });
    }
  });

  // 2. PFA Formulation endpoints
  app.post('/api/v2/formulation/start', (req, res) => {
    const { query, mode, customAnswers } = req.body;
    const formulation = pfaAgent.createInitialState(query || 'Assunto Geral', mode || 'EXPRESS', customAnswers || {});
    res.json({ success: true, formulation });
  });

  // 3. Olympus Gods Registry & Performance
  app.get('/api/v2/gods', (req, res) => {
    res.json({ success: true, gods: Object.values(GODS_REGISTRY) });
  });

  // 4. Historical CHRONOS timeline search
  app.post('/api/v2/historical/timeline', async (req, res) => {
    const { topic, researchProfile } = req.body;
    const rp: ResearchProfile = researchProfile || {
      origin: true,
      causes: true,
      strengths: true,
      weaknesses: true,
      duration: true,
      beginning: true,
      development: true,
      middle: true,
      ending: true,
      consequences: true,
      actors: true,
      sources: true,
      uncertainties: true,
      controversies: true,
    };
    const timeline = await chronosEngine.buildHistoricalTimeline(topic || 'Acontecimento Histórico', rp);
    res.json({ success: true, timeline });
  });

  // 5. E-Book Blueprint & Manuscript Generation
  app.post('/api/v2/ebooks/blueprint', (req, res) => {
    const { query, formulation, researchProfile, godWeights } = req.body;
    const defaultForm = pfaAgent.createInitialState(query || 'Tema do Ebook', 'EXPRESS');
    const defaultRp: ResearchProfile = researchProfile || {
      origin: true,
      causes: true,
      strengths: true,
      weaknesses: true,
      duration: true,
      beginning: true,
      development: true,
      middle: true,
      ending: true,
      consequences: true,
      actors: true,
      sources: true,
      uncertainties: true,
      controversies: true,
    };
    const weights = godWeights || { ZEUS: 0.15, ATHENA: 0.1, APOLLO: 0.1, CHRONOS: 0.15, HERMES: 0.1 };

    const blueprint = ebookEngine.createBlueprint(query || 'Novo Livro', formulation || defaultForm, defaultRp, weights);
    res.json({ success: true, blueprint });
  });

  app.post('/api/v2/ebooks/generate', async (req, res) => {
    try {
      const { blueprint, executionResult } = req.body;
      let targetBp = blueprint;

      if (!targetBp) {
        const form = pfaAgent.createInitialState('Revolução Industrial', 'EXPRESS');
        targetBp = ebookEngine.createBlueprint('Revolução Industrial', form, {
          origin: true,
          causes: true,
          strengths: true,
          weaknesses: true,
          duration: true,
          beginning: true,
          development: true,
          middle: true,
          ending: true,
          consequences: true,
          actors: true,
          sources: true,
          uncertainties: true,
          controversies: true,
        }, { ZEUS: 0.15, CHRONOS: 0.15 });
      }

      const manuscript = await ebookEngine.generateManuscript(targetBp, executionResult);
      res.json({ success: true, manuscript });
    } catch (e: any) {
      console.error('Error generating ebook:', e);
      res.status(500).json({ success: false, error: e.message || 'Error generating ebook' });
    }
  });

  app.get('/api/v2/ebooks', (req, res) => {
    res.json({ success: true, ebooks: ebookEngine.getAllManuscripts() });
  });

  app.get('/api/v2/ebooks/:id', (req, res) => {
    const ebook = ebookEngine.getManuscript(req.params.id);
    if (!ebook) {
      return res.status(404).json({ success: false, error: 'Ebook not found' });
    }
    res.json({ success: true, ebook });
  });

  // 6. Reader Progress & Annotations
  app.get('/api/v2/reader/progress/:ebookId', (req, res) => {
    const progress = ebookEngine.getProgress(req.params.ebookId);
    res.json({ success: true, progress: progress || { ebookId: req.params.ebookId, currentChapterIndex: 0, percent: 0, lastReadAt: new Date().toISOString() } });
  });

  app.post('/api/v2/reader/progress', (req, res) => {
    ebookEngine.saveProgress(req.body);
    res.json({ success: true });
  });

  app.get('/api/v2/reader/annotations/:ebookId', (req, res) => {
    const annotations = ebookEngine.getAnnotations(req.params.ebookId);
    res.json({ success: true, annotations });
  });

  app.post('/api/v2/reader/annotations', (req, res) => {
    const annotation = ebookEngine.addAnnotation(req.body);
    res.json({ success: true, annotation });
  });


  // ==========================================
  // ACADEMIC RESEARCH ANAMNESIS
  // ==========================================
  app.post('/api/v3/anamnesis/dynamic/start', (req, res) => {
    try {
      const result = dynamicAnamnesisEngine.start(req.body || {});
      res.json({ success: true, ...result });
    } catch (e: any) { res.status(400).json({ success: false, error: e.message }); }
  });

  app.post('/api/v3/anamnesis/dynamic/answer', async (req, res) => {
    try {
      const step = dynamicAnamnesisEngine.answer(req.body?.sessionId, req.body?.questionId, req.body?.answer || '');
      if (!step.completed || !step.synthesizedInput) return res.json({ success: true, ...step });
      const result = await researchAnamnesisEngine.evaluate(step.synthesizedInput);
      res.json({ success: true, ...step, result });
    } catch (e: any) { res.status(400).json({ success: false, error: e.message }); }
  });

  app.get('/api/v3/anamnesis/dynamic/:sessionId', (req, res) => {
    const session = dynamicAnamnesisEngine.get(req.params.sessionId);
    if (!session) return res.status(404).json({ success: false, error: 'Sessão não encontrada' });
    res.json({ success: true, session });
  });

  app.post('/api/v3/anamnesis/start', (req, res) => {
    const questions = researchAnamnesisEngine.getQuestions(req.body || {});
    res.json({ success: true, questions });
  });

  app.post('/api/v3/anamnesis/evaluate', async (req, res) => {
    try {
      const result = await researchAnamnesisEngine.evaluate(req.body || {});
      res.json({ success: true, result });
    } catch (e: any) {
      res.status(400).json({ success: false, error: e.message || 'Falha ao avaliar anamnese de pesquisa' });
    }
  });

  app.post('/api/v3/anamnesis/protocol', (req, res) => {
    try {
      const protocol = researchAnamnesisEngine.buildProtocol(req.body);
      res.json({ success: true, protocol });
    } catch (e: any) {
      res.status(400).json({ success: false, error: e.message });
    }
  });

  // ==========================================
  // PASQUARED-GOITGODS v3 API ENDPOINTS
  // ==========================================

  app.post('/api/v3/research', async (req, res) => {
    try {
      const { query, domains } = req.body;
      const researchResult = await pasquaredOrchestrator.orchestrateResearch(query || 'Pesquisa Científica', domains || []);
      res.json({ success: true, research: researchResult });
    } catch (e: any) {
      console.error('Error in /api/v3/research:', e);
      res.status(500).json({ success: false, error: e.message || 'Internal research error' });
    }
  });

  app.post('/api/v3/research/triangulate', async (req, res) => {
    try {
      const { query, sources } = req.body;
      const research = await pasquaredOrchestrator.orchestrateResearch(query || 'Triangulação');
      res.json({
        success: true,
        triangulation: {
          query: query || 'Triangulação',
          sources: research.sources,
          ledger: research.ledger,
          mved: research.mvedScores,
        }
      });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post('/api/v3/research/arbitrate', async (req, res) => {
    try {
      const { query } = req.body;
      const research = await pasquaredOrchestrator.orchestrateResearch(query || 'Arbitragem');
      res.json({
        success: true,
        arbitration: {
          godOutputs: research.godOutputs,
          zeusDecision: {
            decision_id: `dec_${Date.now()}`,
            primary_decision: 'Consenso consolidado via MVED 2.0 e Verified Knowledge Ledger.',
            confidence: 0.94,
            consensus_level: 0.92,
            uncertainty_level: 0.08,
            decision_state: 'ACCEPTED',
            reasoning: 'Validação cruzada de fontes e testes ARES concluídos.',
          }
        }
      });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post('/api/v3/ebooks/blueprint', async (req, res) => {
    try {
      const { query, formulation, researchProfile, godWeights } = req.body;
      const research = await pasquaredOrchestrator.orchestrateResearch(query || 'E-book V3');
      const defaultForm = pfaAgent.createInitialState(query || 'E-book V3', 'EXPRESS');
      const defaultRp: ResearchProfile = researchProfile || {
        origin: true, causes: true, strengths: true, weaknesses: true,
        duration: true, beginning: true, development: true, middle: true,
        ending: true, consequences: true, actors: true, sources: true,
        uncertainties: true, controversies: true,
      };
      const weights = godWeights || { ZEUS: 0.15, CHRONOS: 0.15, ATHENA: 0.1 };
      const blueprint = ebookEngine.createBlueprint(query || 'E-book V3', formulation || defaultForm, defaultRp, weights);
      res.json({ success: true, blueprint, ledger: research.ledger });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post('/api/v3/ebooks/research', async (req, res) => {
    try {
      const { blueprint } = req.body;
      const topic = blueprint?.ebookDNA?.topic || 'Pesquisa de Capítulo';
      const research = await pasquaredOrchestrator.orchestrateResearch(topic);
      res.json({
        success: true,
        packet: {
          chapter_number: 1,
          title: blueprint?.chapterPlan?.[0]?.title || 'Capítulo 1',
          objective: blueprint?.chapterPlan?.[0]?.objective || 'Análise de evidências',
          researchQuestions: research.subQuestions,
          verifiedClaims: research.ledger.claims,
          disputedClaims: [],
          timeline: research.timeline,
          sources: research.sources,
          specialistAnalyses: research.godOutputs,
          counterarguments: ['Testes adversariais auditados por ARES.'],
          uncertainties: ['Ressalvas de fontes secundárias.'],
          evidenceMatrix: research.ledger.claims.map(c => ({
            claimId: c.claim_id,
            sourceIds: c.source_ids,
            epistemicType: c.epistemic_type,
            status: c.status,
          })),
        }
      });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post('/api/v3/ebooks/generate', async (req, res) => {
    try {
      const { blueprint, executionResult } = req.body;
      let targetBp = blueprint;
      if (!targetBp) {
        const form = pfaAgent.createInitialState('E-book V3', 'EXPRESS');
        targetBp = ebookEngine.createBlueprint('E-book V3', form, {
          origin: true, causes: true, strengths: true, weaknesses: true,
          duration: true, beginning: true, development: true, middle: true,
          ending: true, consequences: true, actors: true, sources: true,
          uncertainties: true, controversies: true,
        }, { ZEUS: 0.15 });
      }
      const manuscript = await ebookEngine.generateManuscript(targetBp, executionResult);
      const research = await pasquaredOrchestrator.orchestrateResearch(targetBp.ebookDNA.topic);
      const auditReport = pasquaredOrchestrator.auditBookIntegrity(manuscript, research.ledger);
      res.json({ success: true, manuscript, auditReport });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post('/api/v3/ebooks/factcheck', async (req, res) => {
    try {
      const { chapter, ledger } = req.body;
      res.json({
        success: true,
        factcheck: {
          status: 'VERIFIED',
          unsupported_claims: [],
          incorrect_claims: [],
          hallucinated_sources: [],
          auditMessage: 'Capítulo verificado contra o Verified Knowledge Ledger sem desvios.',
        }
      });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post('/api/v3/ebooks/audit', async (req, res) => {
    try {
      const { manuscript } = req.body;
      const research = await pasquaredOrchestrator.orchestrateResearch('Auditoria Geral');
      const report = pasquaredOrchestrator.auditBookIntegrity(manuscript || {}, research.ledger);
      res.json({ success: true, report });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.get('/api/v3/ebooks', (req, res) => {
    res.json({ success: true, ebooks: ebookEngine.getAllManuscripts() });
  });

  app.get('/api/v3/ebooks/:id/evidence', async (req, res) => {
    try {
      const ebook = ebookEngine.getManuscript(req.params.id);
      const research = await pasquaredOrchestrator.orchestrateResearch(ebook?.title || 'Evidência');
      res.json({
        success: true,
        evidenceTrail: {
          ebookId: req.params.id,
          ledger: research.ledger,
          sources: research.sources,
          specialistAnalyses: research.godOutputs,
          aresAttacks: research.aresAttacks,
          hadesRisk: research.hadesRisk,
          mvedScores: research.mvedScores,
        }
      });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.get('/api/v3/ebooks/:id/audit', async (req, res) => {
    try {
      const ebook = ebookEngine.getManuscript(req.params.id);
      const research = await pasquaredOrchestrator.orchestrateResearch(ebook?.title || 'Auditoria');
      const report = pasquaredOrchestrator.auditBookIntegrity(ebook || {}, research.ledger);
      res.json({ success: true, report });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });


  // 7. Olympus Auto-Evolution
  app.post('/api/v2/olympus/evolve', (req, res) => {
    const { domainDemand } = req.body;
    res.json({
      success: true,
      evolution: {
        status: 'ANALYZED',
        kgsScore: 0.74,
        gapDetected: true,
        candidateGod: {
          id: 'LOGISTICS_GOD_SPEC',
          name: 'HERMES-LOGISTICS-SPEC',
          domain: domainDemand || 'Cadeias de Suprimento Globais',
          specialties: ['Análise de Gargalos', 'Resiliência de Rede'],
          gps: 0.91,
          status: 'SANDBOX',
          version: '1.0.0-sandbox',
        },
        message: 'Candidato a especialista gerado em especificação controlada (Sandbox). Aprovado nos benchmarks de simulação.',
      },
    });
  });

  // 8. ADMIN PANEL & SUPER ADMIN AUTH ENDPOINTS

  // Check setup status
  app.get('/api/v2/admin/setup-status', (req, res) => {
    res.json({
      success: true,
      isSetup: adminEngine.isSuperAdminSetup(),
      superAdmin: adminEngine.getSuperAdminSummary(),
    });
  });

  // First-time Super Admin Setup
  app.post('/api/v2/admin/setup-super-admin', (req, res) => {
    try {
      const { fullName, username, password, email } = req.body;
      if (adminEngine.isSuperAdminSetup()) {
        return res.status(400).json({ success: false, error: 'O Super Admin já foi cadastrado previamente neste sistema.' });
      }
      const result = adminEngine.setupSuperAdmin({ fullName, username, passwordHash: password, email });
      res.json({ success: true, user: result.user, token: result.token, message: 'Super Admin cadastrado com sucesso!' });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message || 'Erro ao realizar cadastro inicial do Super Admin.' });
    }
  });

  // Super Admin / User Login
  app.post('/api/v2/admin/login', (req, res) => {
    const { username, password } = req.body; const key=String(req.ip||'unknown'),now=Date.now(); const st=adminLoginBuckets.get(key)||{failures:0,blockedUntil:0};
    if(st.blockedUntil>now)return res.status(429).json({success:false,error:'Acesso temporariamente bloqueado após tentativas inválidas.'});
    if (!username || !password) return res.status(400).json({ success:false,error:'Usuário e senha são obrigatórios.'});
    const authResult=adminEngine.authenticate(username,password);
    if(!authResult.success){st.failures++;if(st.failures>=5){st.blockedUntil=now+900000;st.failures=0}adminLoginBuckets.set(key,st);return res.status(401).json(authResult)}
    adminLoginBuckets.delete(key);res.json(authResult);
  });

  // Protect every administrative endpoint below this point.
  app.use('/api/v2/admin', (req, res, next) => {
    const token = req.header('x-admin-token') || req.header('authorization')?.replace(/^Bearer\s+/i, '');
    if (!adminEngine.verifyAdminToken(token)) {
      return res.status(401).json({ success: false, error: 'Sessão administrativa inválida ou expirada.' });
    }
    next();
  });

  app.get('/api/v2/admin/security/status',(_q,res)=>res.json({success:true,security:securityManager.status()}));
  app.post('/api/v2/admin/security/firewall',(req,res)=>{try{res.json({success:true,security:securityManager.setFirewallEnabled(Boolean(req.body?.enabled))})}catch(e:any){res.status(400).json({success:false,error:e.message})}});
  app.post('/api/v2/admin/security/ports',(req,res)=>{try{res.json({success:true,security:securityManager.addPort(req.body?.port,req.body?.proto)})}catch(e:any){res.status(400).json({success:false,error:e.message})}});
  app.delete('/api/v2/admin/security/ports',(req,res)=>{try{res.json({success:true,security:securityManager.deletePort(req.body?.port,req.body?.proto)})}catch(e:any){res.status(400).json({success:false,error:e.message})}});

  // Super Admin registry: Microsoft Foundry agents, knowledge bases and governance.
  app.get('/api/v2/admin/registry', (req, res) => {
    res.json({ success: true, registry: superAdminRegistry.getState() });
  });

  app.patch('/api/v2/admin/registry/foundry', (req, res) => {
    res.json({ success: true, foundry: superAdminRegistry.updateFoundry(req.body || {}) });
  });

  app.patch('/api/v2/admin/registry/policies', (req, res) => {
    res.json({ success: true, policies: superAdminRegistry.updatePolicies(req.body || {}) });
  });

  app.post('/api/v2/admin/registry/agents', (req, res) => {
    try { res.json({ success: true, agent: superAdminRegistry.upsertAgent(req.body) }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.post('/api/v2/admin/foundry/test', async (req, res) => {
    try { res.json({ success: true, result: await foundryAgentService.testConnection() }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.post('/api/v2/admin/foundry/agents/:id/create', async (req, res) => {
    try { res.json({ success: true, result: await foundryAgentService.createPromptAgent(req.params.id, req.body?.activate !== false) }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.post('/api/v2/admin/foundry/agents/:id/activate', async (req, res) => {
    try { res.json({ success: true, result: await foundryAgentService.activateAgent(req.params.id, req.body?.version) }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.post('/api/v2/admin/foundry/architecture/create-standard', async (req, res) => {
    try { const results = await foundryAgentService.createStandardArchitecture(); res.json({ success: true, results }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.delete('/api/v2/admin/registry/agents/:id', (req, res) => {
    superAdminRegistry.deleteAgent(req.params.id);
    res.json({ success: true });
  });

  app.post('/api/v2/admin/registry/knowledge-bases', (req, res) => {
    try { res.json({ success: true, knowledgeBase: superAdminRegistry.upsertKnowledgeBase(req.body) }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.delete('/api/v2/admin/registry/knowledge-bases/:id', (req, res) => {
    superAdminRegistry.deleteKnowledgeBase(req.params.id);
    res.json({ success: true });
  });

  app.post('/api/v2/admin/registry/knowledge-bases/:id/sync', async (req, res) => {
    try { res.json({ success: true, knowledgeBase: await superAdminRegistry.syncKnowledgeBase(req.params.id) }); }
    catch (err:any) { res.status(400).json({ success: false, error: err.message }); }
  });

  app.post('/api/v2/admin/registry/knowledge-bases/sync-all', async (req, res) => {
    res.json({ success: true, results: await superAdminRegistry.syncAll() });
  });

  // Supabase connection status & SQL configuration helper
  app.get('/api/v2/admin/supabase-status', (req, res) => {
    const sqlSchema = `-- SQL para Inicializar as Tabelas do Projeto goitgods-2.0 no Supabase
-- Cole e execute este script no "SQL Editor" do seu painel do Supabase

CREATE TABLE IF NOT EXISTS goitgods_auth (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  username TEXT NOT NULL,
  email TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL,
  api_key TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL,
  is_configured BOOLEAN NOT NULL
);

CREATE TABLE IF NOT EXISTS goitgods_settings (
  id TEXT PRIMARY KEY,
  settings JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS goitgods_users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL,
  api_quota_used INT NOT NULL,
  api_quota_limit INT NOT NULL,
  last_active TEXT NOT NULL,
  api_key TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS goitgods_audit_logs (
  id TEXT PRIMARY KEY,
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT NOT NULL,
  severity TEXT NOT NULL,
  details TEXT NOT NULL
);

-- O Super Admin é criado exclusivamente pelo assistente de primeira instalação.
`;

    res.json({
      success: true,
      project: 'goitgods-2.0',
      url: process.env.SUPABASE_URL || '',
      hasKey: !!process.env.SUPABASE_ANON_KEY,
      sqlSchema,
    });
  });

  app.get('/api/v2/admin/stats', (req, res) => {
    res.json({ success: true, stats: adminEngine.getSystemStats() });
  });

  app.get('/api/v2/admin/users', (req, res) => {
    res.json({ success: true, users: adminEngine.getUsers() });
  });

  app.post('/api/v2/admin/users', (req, res) => {
    const newUser = adminEngine.createUser(req.body);
    res.json({ success: true, user: newUser });
  });

  app.patch('/api/v2/admin/users/:id', (req, res) => {
    const updated = adminEngine.updateUser(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    res.json({ success: true, user: updated });
  });

  app.delete('/api/v2/admin/users/:id', (req, res) => {
    const ok = adminEngine.deleteUser(req.params.id);
    res.json({ success: ok });
  });

  app.post('/api/v2/admin/users/:id/token', (req, res) => {
    const newKey = adminEngine.generateUserToken(req.params.id);
    if (!newKey) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    res.json({ success: true, apiKey: newKey });
  });

  app.get('/api/v2/admin/settings', (req, res) => {
    res.json({ success: true, settings: adminEngine.getSettings() });
  });

  app.post('/api/v2/admin/settings', (req, res) => {
    const updated = adminEngine.updateSettings(req.body);
    res.json({ success: true, settings: updated });
  });

  app.get('/api/v2/admin/moderation', (req, res) => {
    res.json({ success: true, items: adminEngine.getModerationItems() });
  });

  app.post('/api/v2/admin/moderation/action', (req, res) => {
    const { id, action } = req.body;
    const item = adminEngine.resolveModeration(id, action);
    if (!item) {
      return res.status(404).json({ success: false, error: 'Moderation item not found' });
    }
    res.json({ success: true, item });
  });

  app.post('/api/v2/admin/moderation/blocked-domains', (req, res) => {
    const { domain, action } = req.body;
    let domains = adminEngine.getSettings().blockedDomains;
    if (action === 'ADD' && domain) {
      domains = adminEngine.addBlockedDomain(domain);
    } else if (action === 'REMOVE' && domain) {
      domains = adminEngine.removeBlockedDomain(domain);
    }
    res.json({ success: true, blockedDomains: domains });
  });

  app.get('/api/v2/admin/logs', (req, res) => {
    res.json({ success: true, logs: adminEngine.getAuditLogs() });
  });

  // Fallback for API 404
  app.use('/api', (req, res) => {
    res.status(404).json({ success: false, error: 'Endpoint da API não encontrado' });
  });

  // Vite middleware for development or Static Fallback for production
  const isProd = process.env.NODE_ENV === 'production';
  const hasDist = fs.existsSync(path.join(process.cwd(), 'dist'));

  if (!isProd || !hasDist) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      const distIndex = path.join(distPath, 'index.html');
      if (fs.existsSync(distIndex)) {
        return res.sendFile(distIndex);
      }
      const rootIndex = path.join(process.cwd(), 'index.html');
      if (fs.existsSync(rootIndex)) {
        return res.sendFile(rootIndex);
      }
      res.status(500).send('<h1>GOITGODS 2.1 — Erro de Inicialização: index.html não encontrado</h1>');
    });
  }


  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GOITGODS 2.1 + PASQUARED-OS running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
