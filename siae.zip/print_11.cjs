const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');
// We need to restore `lines` at 1140-1150 and make sure of parentheses.
for (let i = 1135; i < 1150; i++) console.log(i+1, lines[i]);
