import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Ban,
  Unlock,
  AlertTriangle,
  Radio,
  RefreshCw,
  Search,
  Activity,
  Zap,
  Globe,
  Lock,
  CheckCircle,
} from 'lucide-react';

interface BlockedIpRecord {
  ip: string;
  reason: string;
  blockedAt: string;
  expiresAt: string;
  permanent: boolean;
}

interface SuspiciousEvent {
  id: string;
  timestamp: string;
  ip: string;
  type: string;
  details: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  blocked: boolean;
}

interface FirewallStatus {
  enabled: boolean;
  activeBlockedIpsCount: number;
  totalBlockedHistorical: number;
  totalRequestsTracked: number;
  suspiciousEventsCount: number;
  rateLimitPerMinute: number;
  maxFailedLoginsBeforeBlock: number;
  blockedIps: BlockedIpRecord[];
  recentEvents: SuspiciousEvent[];
}

export const FirewallAdminTab: React.FC = () => {
  const [status, setStatus] = useState<FirewallStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchIp, setSearchIp] = useState('');
  const [manualIp, setManualIp] = useState('');
  const [manualReason, setManualReason] = useState('Bloqueio preventivo pelo administrador');
  const [manualDuration, setManualDuration] = useState('60'); // minutos

  const fetchFirewallStatus = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/firewall/status');
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
      }
    } catch (err) {
      console.error('Erro ao buscar status do firewall:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFirewallStatus();
    const interval = setInterval(fetchFirewallStatus, 8000); // Polling online a cada 8s
    return () => clearInterval(interval);
  }, []);

  const handleUnblockIp = async (ip: string) => {
    if (!confirm(`Deseja desbloquear imediatamente o IP ${ip}?`)) return;
    try {
      const res = await fetch('/api/admin/firewall/unblock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip }),
      });
      if (!res.ok) throw new Error('Falha ao desbloquear IP');
      fetchFirewallStatus();
    } catch (err: any) {
      alert(err.message || 'Erro ao desbloquear IP');
    }
  };

  const handleManualBlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualIp.trim()) return;

    try {
      const res = await fetch('/api/admin/firewall/block', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ip: manualIp.trim(),
          reason: manualReason.trim(),
          durationMinutes: parseInt(manualDuration, 10) || 60,
        }),
      });
      if (!res.ok) throw new Error('Falha ao bloquear IP');
      setManualIp('');
      fetchFirewallStatus();
    } catch (err: any) {
      alert(err.message || 'Erro ao bloquear IP');
    }
  };

  const filteredBlockedIps = status?.blockedIps.filter((b) =>
    b.ip.toLowerCase().includes(searchIp.toLowerCase()) || b.reason.toLowerCase().includes(searchIp.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6">
      {/* Header & Status Online */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#1E293B] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-rose-400" />
              Painel de Monitoramento Online do Firewall
            </h2>
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              ONLINE & PROTEGIDO
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Defesa ativa em tempo real contra ataques de <strong>DDoS</strong>, <strong>Phishing</strong> e <strong>Brute-Force</strong>.
          </p>
        </div>

        <button
          onClick={fetchFirewallStatus}
          disabled={loading}
          className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin text-[#22D3EE]' : ''}`} />
          <span>Atualizar Monitoramento</span>
        </button>
      </div>

      {/* 3 Pilares de Defesa Ativa */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Anti-DDoS */}
        <div className="rounded-2xl border border-rose-500/30 bg-[#0F172A] p-4 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-500/20 text-rose-400 font-black">
                <Zap className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-xs font-black uppercase text-rose-300">Proteção Anti-DDoS</h4>
                <span className="text-[10px] text-slate-400">Rate-Limiting Ativo</span>
              </div>
            </div>
            <span className="rounded bg-rose-950 border border-rose-800 px-2 py-0.5 text-[9px] font-black uppercase text-rose-300">
              ATIVO
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-3 leading-relaxed">
            Monitora requisições por segundo/minuto. Bloqueia rajadas anômalas acima de <strong>120 req/min</strong> por IP.
          </p>
          <div className="mt-3 pt-2 border-t border-[#1E293B] flex items-center justify-between text-[11px] text-slate-400">
            <span>Limite seguro:</span>
            <span className="font-mono font-bold text-white">120 req / min</span>
          </div>
        </div>

        {/* Anti-Phishing & Payload */}
        <div className="rounded-2xl border border-amber-500/30 bg-[#0F172A] p-4 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 font-black">
                <Globe className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-xs font-black uppercase text-amber-300">Filtro Anti-Phishing</h4>
                <span className="text-[10px] text-slate-400">Inspeção de Payload & URI</span>
              </div>
            </div>
            <span className="rounded bg-amber-950 border border-amber-800 px-2 py-0.5 text-[9px] font-black uppercase text-amber-300">
              ATIVO
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-3 leading-relaxed">
            Detecta injeções maliciosas (SQLi, XSS, scripts externos não autorizados, clonagem de cabeçalhos e links falsificados).
          </p>
          <div className="mt-3 pt-2 border-t border-[#1E293B] flex items-center justify-between text-[11px] text-slate-400">
            <span>Inspeção profunda:</span>
            <span className="font-mono font-bold text-white">Headers + Body</span>
          </div>
        </div>

        {/* Anti Brute-Force */}
        <div className="rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] p-4 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#22D3EE]/20 text-[#22D3EE] font-black">
                <Lock className="h-4 w-4" />
              </div>
              <div>
                <h4 className="text-xs font-black uppercase text-[#22D3EE]">Anti Brute-Force</h4>
                <span className="text-[10px] text-slate-400">Controle de Tentativas</span>
              </div>
            </div>
            <span className="rounded bg-cyan-950 border border-cyan-800 px-2 py-0.5 text-[9px] font-black uppercase text-[#22D3EE]">
              ATIVO
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-3 leading-relaxed">
            Impede ataques de dicionário ou força bruta no login e 2FA. Bloqueia o IP automaticamente após <strong>5 falhas</strong> consecutivas.
          </p>
          <div className="mt-3 pt-2 border-t border-[#1E293B] flex items-center justify-between text-[11px] text-slate-400">
            <span>Tolerância de erros:</span>
            <span className="font-mono font-bold text-white">Máx 5 falhas</span>
          </div>
        </div>
      </div>

      {/* Contadores Gerais */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400">IPs Bloqueados Ativos</span>
          <p className="text-2xl font-black font-mono text-rose-400 mt-1">
            {status?.activeBlockedIpsCount ?? 0}
          </p>
        </div>

        <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400">Ataques Detectados</span>
          <p className="text-2xl font-black font-mono text-amber-400 mt-1">
            {status?.suspiciousEventsCount ?? 0}
          </p>
        </div>

        <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Bloqueados (Histórico)</span>
          <p className="text-2xl font-black font-mono text-slate-200 mt-1">
            {status?.totalBlockedHistorical ?? 0}
          </p>
        </div>

        <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-center">
          <span className="text-[10px] uppercase font-bold text-slate-400">Requisições Analisadas</span>
          <p className="text-2xl font-black font-mono text-[#22D3EE] mt-1">
            {status?.totalRequestsTracked ?? 0}
          </p>
        </div>
      </div>

      {/* Grid: Lista de IPs Bloqueados + Monitoramento Online de Ataques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* BLOCO 1: LISTA DE IPS BLOQUEADOS COM OPÇÃO DE DESBLOQUEAR */}
        <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Ban className="h-4 w-4 text-rose-400" />
              Lista de IPs Bloqueados ({filteredBlockedIps.length})
            </h3>
            <span className="text-[10px] text-slate-400">Acesso negado (HTTP 403 Forbidden)</span>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              placeholder="Filtrar por IP ou motivo..."
              value={searchIp}
              onChange={(e) => setSearchIp(e.target.value)}
              className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
            />
          </div>

          <div className="overflow-y-auto max-h-80 space-y-2">
            {filteredBlockedIps.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">
                Nenhum IP bloqueado no momento. Todos os nós operando em conformidade.
              </div>
            ) : (
              filteredBlockedIps.map((b) => (
                <div
                  key={b.ip}
                  className="flex items-center justify-between rounded-xl border border-rose-500/20 bg-rose-950/20 p-3 hover:bg-rose-950/30 transition"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-rose-300 text-xs">{b.ip}</span>
                      <span className="rounded bg-rose-950 border border-rose-800 px-1.5 py-0.2 text-[9px] font-mono text-rose-300">
                        BLOQUEADO
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-0.5">{b.reason}</p>
                    <p className="text-[9px] font-mono text-slate-500 mt-1">
                      Bloqueado em: {new Date(b.blockedAt).toLocaleString('pt-BR')} • Expira: {new Date(b.expiresAt).toLocaleTimeString('pt-BR')}
                    </p>
                  </div>

                  <button
                    onClick={() => handleUnblockIp(b.ip)}
                    className="flex items-center gap-1 rounded-lg border border-emerald-500/40 bg-emerald-950/60 px-3 py-1.5 text-xs font-bold text-emerald-300 hover:bg-emerald-900 transition shadow-sm shrink-0"
                    title="Desbloquear IP imediatamente"
                  >
                    <Unlock className="h-3.5 w-3.5" />
                    <span>Desbloquear</span>
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Bloqueio Manual de IP */}
          <form onSubmit={handleManualBlock} className="pt-3 border-t border-[#1E293B] space-y-2">
            <span className="text-[11px] font-bold text-slate-300 block">Bloquear IP Manualmente:</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                required
                placeholder="IP (ex: 185.220.101.5)"
                value={manualIp}
                onChange={(e) => setManualIp(e.target.value)}
                className="rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-1.5 text-xs font-mono text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
              />
              <input
                type="text"
                placeholder="Motivo do bloqueio"
                value={manualReason}
                onChange={(e) => setManualReason(e.target.value)}
                className="rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
              />
              <button
                type="submit"
                className="rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500 transition shadow-md"
              >
                Bloquear IP
              </button>
            </div>
          </form>
        </div>

        {/* BLOCO 2: MONITORAMENTO ONLINE DE POSSÍVEIS ATAQUES */}
        <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="h-4 w-4 text-[#22D3EE]" />
              Monitoramento Online de Possíveis Ataques
            </h3>
            <span className="flex items-center gap-1 text-[10px] font-bold text-amber-400">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping" />
              LIVE FEED
            </span>
          </div>

          <div className="overflow-y-auto max-h-[380px] space-y-2 font-mono text-xs">
            {(!status?.recentEvents || status.recentEvents.length === 0) ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                Nenhuma tentativa de ataque detectada recentemente. Todos os filtros operando sem anomalias.
              </div>
            ) : (
              status.recentEvents.map((ev) => {
                const isCrit = ev.severity === 'critical' || ev.severity === 'high';
                return (
                  <div
                    key={ev.id}
                    className={`rounded-xl p-2.5 border transition ${
                      isCrit
                        ? 'border-rose-500/30 bg-rose-950/20'
                        : 'border-amber-500/30 bg-amber-950/20'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="font-bold text-white flex items-center gap-1">
                        <AlertTriangle className={`h-3 w-3 ${isCrit ? 'text-rose-400' : 'text-amber-400'}`} />
                        {ev.type}
                      </span>
                      <span className="text-slate-400">
                        {new Date(ev.timestamp).toLocaleTimeString('pt-BR')}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-1 text-[11px]">
                      <span className="text-slate-300">{ev.details}</span>
                      <span className="font-bold text-[#22D3EE] ml-2 shrink-0">IP: {ev.ip}</span>
                    </div>

                    <div className="flex items-center justify-between mt-1.5 pt-1.5 border-t border-slate-800 text-[9px]">
                      <span className={`font-bold uppercase ${isCrit ? 'text-rose-400' : 'text-amber-400'}`}>
                        Severidade: {ev.severity}
                      </span>
                      {ev.blocked && (
                        <span className="text-emerald-400 font-bold">
                          ✓ Bloqueado pelo Firewall
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
