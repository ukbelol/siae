import fetch from 'node-fetch';
import Database from 'better-sqlite3';

const db = new Database('./siae.db');
try {
  db.prepare("INSERT INTO houses (name, street, city, state, location, representative_id) VALUES ('Casa Modelo', 'Rua A', 'Cidade', 'Estado', '123,123', 999)").run();
} catch(e){}
const house = db.prepare("SELECT id FROM houses LIMIT 1").get() as any;
const houseId = house ? house.id : 1;

try {
  db.prepare('INSERT INTO assistance_types (house_id, name, description, status) VALUES (?, ?, ?, ?)').run(houseId, 'Test', 'Test', 'active');
  console.log("INSERT DIRECT SUCCESS!");
} catch(e) {
  console.error("INSERT DIRECT ERROR:", e);
}

async function test() {
  try {
    const res = await fetch(`http://localhost:3000/api/houses/${houseId}/assistance-types`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Test2', description: 'Test', status: 'active' })
    });
    console.log(res.status, res.statusText);
    const text = await res.text();
    console.log("RESPONSE:", text);
  } catch (e) {
    console.error(e);
  }
}
test();
