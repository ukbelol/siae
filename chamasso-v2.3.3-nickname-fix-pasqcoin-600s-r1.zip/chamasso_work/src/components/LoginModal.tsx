import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  ShieldAlert,
  CheckCircle2,
  ArrowRight,
  KeyRound,
  AlertTriangle,
  Mail,
  Eye,
  EyeOff,
  Smartphone,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { formatCPF, cleanCPF } from '../utils/cpf.ts';
import type { User } from '../types.ts';
import { POPULAR_2FA_APPS } from './TwoFactorAppList.tsx';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User, usedDisposable: boolean, matchedCode?: string) => void;
  onSwitchToRegister: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onSwitchToRegister,
}) => {
  const [identifier, setIdentifier] = useState(''); // Email or CPF
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [step, setStep] = useState<1 | 2>(1);
  const [verifiedName, setVerifiedName] = useState('');
  const [verifiedEmail, setVerifiedEmail] = useState('');
  const [maskedEmail, setMaskedEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(30);

  // Calcula os segundos restantes do ciclo TOTP de 30 segundos
  useEffect(() => {
    const updateCountdown = () => {
      const nowSeconds = Math.floor(Date.now() / 1000);
      const remaining = 30 - (nowSeconds % 30);
      setSecondsRemaining(remaining);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!isOpen) return null;

  const handleIdentifierChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    // Auto format if typing CPF numbers
    if (/^\d{0,11}$/.test(val.replace(/\D/g, '')) && !val.includes('@') && val.replace(/\D/g, '').length > 3) {
      setIdentifier(formatCPF(val));
    } else {
      setIdentifier(val);
    }
    setError('');
  };

  const handleVerifyUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmed = identifier.trim();
    if (!trimmed) {
      setError('Informe seu e-mail de usuário ou CPF.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/check-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: trimmed,
          password: password.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Credenciais não localizadas.');
      }

      setVerifiedName(data.userName);
      setVerifiedEmail(data.email || trimmed);
      setMaskedEmail(data.emailMasked);
      setStep(2);
    } catch (err: any) {
      setError(err.message || 'Falha ao verificar credenciais.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!twoFactorCode.trim()) {
      setError('Por favor, informe o código 2FA do seu aplicativo autenticador ou um código descartável.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: identifier.trim(),
          password: password.trim() || undefined,
          twoFactorCode: twoFactorCode.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Autenticação 2FA falhou.');
      }

      onSuccess(data.user, data.usedDisposable, data.matchedDisposableCode);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Erro ao realizar login.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 sm:p-7 shadow-2xl text-[#E2E8F0]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="text-center mb-6">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onClose();
            }}
            title="Ir para a página inicial"
            className="mx-auto block relative w-14 h-14 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/60 shadow-[0_0_20px_rgba(34,211,238,0.45)] mb-3 bg-[#0A0C10] cursor-pointer hover:scale-105 active:scale-95 transition-transform"
          >
            <img
              src="/fenix_chamas.gif"
              alt="chamasso live chat"
              className="w-full h-full object-cover"
            />
          </a>
          <h2 className="text-xl font-black uppercase italic tracking-tight text-white">
            Acessar <span className="text-[#22D3EE]">chamasso live chat</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Rede Social & Live Chat com Autenticação 2FA (Padrão TOTP)
          </p>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {step === 1 ? (
          <form onSubmit={handleVerifyUser} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Usuário (E-mail ou CPF cadastrado):
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  autoFocus
                  value={identifier}
                  onChange={handleIdentifierChange}
                  placeholder="seuemail@gmail.com ou 000.000.000-00"
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-10 pr-3.5 py-2.5 text-sm font-sans text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
                <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Você pode utilizar o seu e-mail configurado no cadastro como usuário.
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Senha de Acesso:
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Digite sua senha cadastrada"
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-10 pr-10 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
                <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || !identifier.trim() || !password.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-sm font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition disabled:opacity-50"
            >
              {loading ? (
                'Validando Credenciais...'
              ) : (
                <>
                  <span>Prosseguir para Validação 2FA</span>
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>

            <div className="pt-2 text-center text-xs text-slate-400">
              Ainda não tem conta cadastrada?{' '}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onSwitchToRegister();
                }}
                className="font-bold text-[#22D3EE] hover:underline"
              >
                Cadastrar-se com 2FA
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="rounded-xl border border-[#22D3EE]/30 bg-[#22D3EE]/10 p-3 text-xs text-slate-300">
              <div className="flex items-center gap-1.5 text-[#22D3EE] font-semibold mb-1">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>Credenciais Autenticadas: {verifiedEmail}</span>
              </div>
              <p className="text-slate-400">
                Titular: <strong className="text-slate-200">{verifiedName}</strong>
              </p>
            </div>

            {/* Showcase de Apps Suportados no Login */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10]/90 p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                  <Smartphone className="h-3.5 w-3.5 text-[#22D3EE]" />
                  <span>Abra seu App Autenticador (TOTP)</span>
                </span>
                <div className="flex items-center gap-1.5 font-mono text-[10px] text-[#22D3EE]">
                  <Clock className="h-3 w-3 animate-pulse" />
                  <span>Ciclo: {secondsRemaining}s</span>
                </div>
              </div>

              {/* Badges de apps suportados */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                {POPULAR_2FA_APPS.slice(0, 6).map((app) => (
                  <div
                    key={app.id}
                    className="flex items-center gap-1.5 rounded-lg border border-[#1E293B] bg-[#0F172A] px-2 py-1 text-[10px] text-slate-300"
                  >
                    <div className={`h-3.5 w-3.5 rounded ${app.iconBg} flex items-center justify-center font-bold text-[8px] text-white shrink-0`}>
                      {app.iconText.slice(0, 1)}
                    </div>
                    <span className="truncate">{app.name.split(' ')[0]}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-200 mb-1.5 text-center">
                Digite o Código de 6 Dígitos ou Código Descartável:
              </label>
              <div className="flex justify-center">
                <input
                  type="text"
                  required
                  autoFocus
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value.toUpperCase())}
                  placeholder="123456 ou CHAM-XXXX-YYYY"
                  className="w-full text-center font-mono text-lg font-bold rounded-xl border border-[#22D3EE]/50 bg-[#0A0C10] py-2.5 text-[#22D3EE] focus:border-[#22D3EE] focus:outline-none focus:ring-2 focus:ring-[#22D3EE]/40 tracking-widest placeholder:text-sm placeholder:tracking-normal placeholder:text-slate-600"
                />
              </div>
              <p className="text-[11px] text-slate-400 text-center mt-2 leading-relaxed">
                Insira o código de <strong>6 dígitos</strong> de qualquer app autenticador cadastrado{' '}
                <span className="text-slate-500">ou</span> um dos seus <strong>11 códigos descartáveis</strong>.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
              >
                Voltar
              </button>
              <button
                type="submit"
                disabled={loading || !twoFactorCode.trim()}
                className="w-2/3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition disabled:opacity-50"
              >
                {loading ? 'Autenticando 2FA...' : 'Entrar no Sistema'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
