const fs = require('fs');
const glob = require('fs').readdirSync;

function rewriteToAsyncDb(file) {
  let content = fs.readFileSync(file, 'utf8');

  // Convert sync route handlers to async
  content = content.replace(/router\.(get|post|put|delete)\(([^,]+),\s*\(\s*req,\s*res\s*\)\s*=>/g, "router.$1($2, async (req, res) =>");

  // Await db.prepare chaining
  // db.prepare(...).get(...) -> await (await db.prepare(...)).get(...)
  // So:
  content = content.replace(/db\.prepare\((.*?)\)\.get\((.*?)\)/gs, "await (await db.prepare($1)).get($2)");
  content = content.replace(/db\.prepare\((.*?)\)\.all\((.*?)\)/gs, "await (await db.prepare($1)).all($2)");
  content = content.replace(/db\.prepare\((.*?)\)\.run\((.*?)\)/gs, "await (await db.prepare($1)).run($2)");

  // Parameterless variants
  content = content.replace(/db\.prepare\((.*?)\)\.get\(\)/gs, "await (await db.prepare($1)).get()");
  content = content.replace(/db\.prepare\((.*?)\)\.all\(\)/gs, "await (await db.prepare($1)).all()");
  content = content.replace(/db\.prepare\((.*?)\)\.run\(\)/gs, "await (await db.prepare($1)).run()");

  // Unchained db.prepare
  // const stmt = db.prepare(...)
  content = content.replace(/db\.prepare\(/g, "await db.prepare(");

  // Unchained execution
  // stmt.run(...) -> await stmt.run(...)
  content = content.replace(/stmt\.run\(/g, "await stmt.run(");
  content = content.replace(/stmt\.get\(/g, "await stmt.get(");
  content = content.replace(/stmt\.all\(/g, "await stmt.all(");

  // Fix up those double awaits we might have caused:
  content = content.replace(/await await/g, "await");

  // Fix missing imports or type errors? 
  // Let's just fix info assignments.
  // const info = stmt.run(...) -> const info = await stmt.run(...)
  // already handled!

  // Fix dates
  // MySQL date syntax vs SQLite date syntax
  // date(created_at) -> DATE(created_at)
  content = content.replace(/date\(created_at\)/g, "DATE(created_at)");

  fs.writeFileSync(file, content);
}

['src/api/index.ts', 'src/api/admin.ts', 'src/lib/backup.ts'].forEach(f => fs.existsSync(f) && rewriteToAsyncDb(f));
console.log('Done!');
