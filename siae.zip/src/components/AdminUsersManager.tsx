import React, { useState } from 'react';
import { Trash2, Key, Plus, Edit, X, Search, CheckCircle, Power } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminUsersManager({ usersList, loadData }: { usersList: any[], loadData: () => void }) {
  const [showAdd, setShowAdd] = useState(false);
  const [newUser, setNewUser] = useState({
    role: 'assisted', email: '', password: '', first_name: '', last_name: '', cpf: '', dob: ''
  });
  
  const [editUser, setEditUser] = useState<any>(null);
  const [resettingUser, setResettingUser] = useState<any>(null);
  const [newPasswordVal, setNewPasswordVal] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('');

  const handleAddUser = async (e: any) => {
    e.preventDefault();
    try {
      await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser)
      });
      setNewUser({ role: 'assisted', email: '', password: '', first_name: '', last_name: '', cpf: '', dob: '' });
      setShowAdd(false);
      loadData();
      toast.success('Usuário adicionado com sucesso!');
    } catch (err) {
      toast.error('Erro ao adicionar usuário');
    }
  };

  const handleUpdateUser = async (e: any) => {
    e.preventDefault();
    try {
      await fetch(`/api/admin/users/${editUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editUser)
      });
      setEditUser(null);
      loadData();
      toast.success('Usuário atualizado com sucesso!');
    } catch (err) {
      toast.error('Erro ao atualizar usuário');
    }
  };

  const handleToggleUserStatus = async (id: number, currentStatus: string, role: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    try {
      await fetch(`/api/admin/users/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, role })
      });
      loadData();
      toast.success(newStatus === 'active' ? 'Usuário ativado com sucesso!' : 'Usuário desativado com sucesso!');
    } catch (e) {
      toast.error('Erro ao alterar status do usuário');
    }
  };

  const executeResetPassword = async () => {
    if (!resettingUser || !newPasswordVal) {
      toast.error('A senha não pode estar em branco');
      return;
    }
    try {
      await fetch(`/api/admin/users/${resettingUser.id}/password`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: newPasswordVal })
      });
      toast.success('Senha atualizada e gravada automaticamente!');
      setResettingUser(null);
      setNewPasswordVal('');
      loadData();
    } catch(err) {
      toast.error('Erro ao alterar senha');
    }
  };

  const handleGenerateRandomPassword = () => {
    const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#';
    let generatedPass = 'SIAE-';
    for (let i = 0; i < 6; i++) {
      generatedPass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPasswordVal(generatedPass);
    toast.success('Senha gerada automaticamente!');
  };
  
  const filteredUsers = usersList.filter(u => {
     if (roleFilter && u.role !== roleFilter) return false;
     if (!searchTerm) return true;
     const s = searchTerm.toLowerCase();
     const name = `${u.first_name} ${u.last_name}`.toLowerCase();
     return name.includes(s) || (u.email && u.email.toLowerCase().includes(s)) || (u.cpf && u.cpf.includes(s));
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h3 className="text-xl font-bold text-gray-800">Gerenciamento de Usuários</h3>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Buscar usuário..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)} className="border rounded-lg px-2 py-2 text-sm focus:ring-1 focus:ring-indigo-500 cursor-pointer">
             <option value="">Todos os Papéis</option>
             <option value="assisted">Assistido</option>
             <option value="worker">Trabalhador</option>
             <option value="representative">Representante</option>
             <option value="super_admin">Super Admin</option>
          </select>
          <button onClick={() => setShowAdd(!showAdd)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700 whitespace-nowrap">
            <Plus className="w-4 h-4" /> Novo
          </button>
        </div>
      </div>

      {showAdd && (
        <form onSubmit={handleAddUser} className="bg-gray-50 p-6 rounded-xl border border-gray-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div><label className="block text-xs font-bold text-gray-700">Nome</label><input required type="text" className="w-full border rounded px-3 py-2" value={newUser.first_name} onChange={e => setNewUser({...newUser, first_name: e.target.value})} /></div>
          <div><label className="block text-xs font-bold text-gray-700">Sobrenome</label><input required type="text" className="w-full border rounded px-3 py-2" value={newUser.last_name} onChange={e => setNewUser({...newUser, last_name: e.target.value})} /></div>
          <div><label className="block text-xs font-bold text-gray-700">CPF</label><input required type="text" className="w-full border rounded px-3 py-2" value={newUser.cpf} onChange={e => setNewUser({...newUser, cpf: e.target.value})} /></div>
          <div><label className="block text-xs font-bold text-gray-700">Nascimento</label><input required type="date" className="w-full border rounded px-3 py-2" value={newUser.dob} onChange={e => setNewUser({...newUser, dob: e.target.value})} /></div>
          <div><label className="block text-xs font-bold text-gray-700">E-mail</label><input required type="email" className="w-full border rounded px-3 py-2" value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} /></div>
          <div><label className="block text-xs font-bold text-gray-700">Senha</label><input required type="text" className="w-full border rounded px-3 py-2" value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} /></div>
          <div>
             <label className="block text-xs font-bold text-gray-700">Papel</label>
             <select className="w-full border rounded px-3 py-2" value={newUser.role} onChange={e => setNewUser({...newUser, role: e.target.value})}>
               <option value="assisted">Assistido</option>
               <option value="worker">Trabalhador</option>
               <option value="representative">Representante</option>
               <option value="super_admin">Super Admin</option>
             </select>
          </div>
          <div className="col-span-1 md:col-span-2 lg:col-span-3 flex justify-end">
             <button type="submit" className="bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700 font-bold">Salvar Novo Usuário</button>
          </div>
        </form>
      )}

      {editUser && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
             <div className="flex justify-between items-center p-6 border-b sticky top-0 bg-white">
               <h3 className="text-xl font-bold flex items-center gap-2"><Edit className="w-5 h-5"/> Editar Cadastro: {editUser.first_name}</h3>
               <button onClick={() => setEditUser(null)} className="text-gray-500 hover:text-black"><X className="w-6 h-6"/></button>
             </div>
             <form onSubmit={handleUpdateUser} className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                   <div className="md:col-span-3 flex items-center gap-4 border-b pb-4">
                     <img src={editUser.photo_url || 'https://via.placeholder.com/150'} alt="Profile" className="w-20 h-20 rounded-full object-cover border-2 shadow-sm" />
                     <div className="flex-1">
                        <label className="block text-xs font-bold text-gray-700 mb-1">URL da Foto de Perfil</label>
                        <input type="text" className="w-full border rounded px-3 py-2 text-sm" value={editUser.photo_url || ''} onChange={e => setEditUser({...editUser, photo_url: e.target.value})} />
                     </div>
                   </div>
                   
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Status (Ativo/Inativo)</label>
                   <select className={`w-full border rounded px-3 py-2 font-bold ${editUser.status === 'active' ? 'text-green-700' : 'text-red-700'}`} value={editUser.status || 'active'} onChange={e => setEditUser({...editUser, status: e.target.value})}>
                      <option value="active">🟢 Ativo</option>
                      <option value="inactive">🔴 Inativo</option>
                   </select></div>
                   
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Papel (Role)</label>
                   <select className="w-full border rounded px-3 py-2" value={editUser.role} onChange={e => setEditUser({...editUser, role: e.target.value})}>
                     <option value="assisted">Assistido</option>
                     <option value="worker">Trabalhador</option>
                     <option value="representative">Representante</option>
                     <option value="super_admin">Super Admin</option>
                   </select></div>
                   
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Nome</label><input required type="text" className="w-full border rounded px-3 py-2" value={editUser.first_name} onChange={e => setEditUser({...editUser, first_name: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Sobrenome</label><input required type="text" className="w-full border rounded px-3 py-2" value={editUser.last_name} onChange={e => setEditUser({...editUser, last_name: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">CPF</label><input required type="text" className="w-full border rounded px-3 py-2" value={editUser.cpf} onChange={e => setEditUser({...editUser, cpf: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Data Nascimento</label><input required type="date" className="w-full border rounded px-3 py-2" value={editUser.dob} onChange={e => setEditUser({...editUser, dob: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Telefone/WhatsApp</label><input type="text" className="w-full border rounded px-3 py-2" value={editUser.phone || ''} onChange={e => setEditUser({...editUser, phone: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">E-mail</label><input required type="email" className="w-full border rounded px-3 py-2" value={editUser.email} onChange={e => setEditUser({...editUser, email: e.target.value})} /></div>
                   
                   <div className="md:col-span-3 mt-4 border-t pt-4">
                     <h4 className="font-bold text-gray-800 mb-4">Endereço Completo</h4>
                   </div>
                   <div className="md:col-span-2"><label className="block text-xs font-bold text-gray-700 mb-1">Rua / Logradouro</label><input type="text" className="w-full border rounded px-3 py-2" value={editUser.street || ''} onChange={e => setEditUser({...editUser, street: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Número</label><input type="text" className="w-full border rounded px-3 py-2" value={editUser.number || ''} onChange={e => setEditUser({...editUser, number: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Bairro</label><input type="text" className="w-full border rounded px-3 py-2" value={editUser.neighborhood || ''} onChange={e => setEditUser({...editUser, neighborhood: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Cidade</label><input type="text" className="w-full border rounded px-3 py-2" value={editUser.city || ''} onChange={e => setEditUser({...editUser, city: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Estado (UF)</label><input type="text" maxLength={2} className="w-full border rounded px-3 py-2" value={editUser.state || ''} onChange={e => setEditUser({...editUser, state: e.target.value})} /></div>
                </div>
                
                <div className="flex justify-end gap-3 border-t pt-6">
                  <button type="button" onClick={() => setEditUser(null)} className="px-6 py-2 border rounded-lg font-bold text-gray-700 hover:bg-gray-50">Cancelar</button>
                  <button type="submit" className="bg-indigo-600 text-white px-8 py-2 rounded-lg hover:bg-indigo-700 font-bold flex items-center gap-2"><CheckCircle className="w-5 h-5"/> Gravar e Atualizar</button>
                </div>
             </form>
          </div>
        </div>
      )}

      {resettingUser && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden border">
             <div className="flex justify-between items-center p-5 border-b bg-indigo-600 text-white">
               <h3 className="text-lg font-bold flex items-center gap-2"><Key className="w-5 h-5 text-indigo-200"/> Resetar Senha Ativa</h3>
               <button type="button" onClick={() => setResettingUser(null)} className="text-white/80 hover:text-white p-1 rounded-md text-lg">✕</button>
             </div>
             <div className="p-6 space-y-4">
                <div>
                  <span className="text-xs uppercase tracking-wide font-bold text-gray-400">Usuário Selecionado</span>
                  <div className="font-bold text-gray-800 text-sm">{resettingUser.first_name} {resettingUser.last_name}</div>
                  <div className="text-xs text-gray-500">{resettingUser.email}</div>
                </div>
                
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Nova Senha</label>
                  <div className="flex gap-2">
                    <input 
                      required 
                      type="text" 
                      className="flex-1 border rounded px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-1 focus:ring-indigo-500" 
                      value={newPasswordVal} 
                      onChange={e => setNewPasswordVal(e.target.value)} 
                      placeholder="Mínimo 6 caracteres"
                    />
                    <button 
                      type="button" 
                      onClick={handleGenerateRandomPassword} 
                      className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-xs font-semibold rounded border text-gray-700 whitespace-nowrap cursor-pointer transition-colors"
                    >
                      Gerar Senha
                    </button>
                  </div>
                </div>

                <div className="flex justify-end gap-3 border-t pt-5 mt-4">
                  <button type="button" onClick={() => setResettingUser(null)} className="px-4 py-2 border rounded-lg text-sm text-gray-700 hover:bg-gray-50 font-semibold cursor-pointer">Cancelar</button>
                  <button 
                    type="button" 
                    onClick={executeResetPassword} 
                    className="bg-indigo-600 text-white px-5 py-2 rounded-lg hover:bg-indigo-700 text-sm font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    Gravar e Atualizar
                  </button>
                </div>
             </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
        <table className="w-full text-left min-w-max">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-4 font-bold text-gray-700 text-sm">Perfil</th>
              <th className="p-4 font-bold text-gray-700 text-sm">Nome & Contato</th>
              <th className="p-4 font-bold text-gray-700 text-sm">Função</th>
              <th className="p-4 font-bold text-gray-700 text-sm">Status</th>
              <th className="p-4 font-bold text-gray-700 text-sm text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map((u: any) => (
              <tr key={u.id} className="border-t hover:bg-gray-50 transition">
                 <td className="p-4">
                  <img src={u.photo_url || 'https://via.placeholder.com/50'} alt="User Profile" className="w-12 h-12 rounded-full object-cover border border-gray-200 shadow-sm" />
                </td>
                <td className="p-4">
                  <div className="font-bold text-gray-900">{u.first_name} {u.last_name}</div>
                  <div className="text-sm text-gray-500 mt-1 flex flex-col gap-0.5">
                    <span>{u.email}</span>
                    <span>{u.phone || 'Sem telefone'}</span>
                    <span>CPF: {u.cpf}</span>
                  </div>
                </td>
                <td className="p-4">
                    <span className={`inline-flex px-3 py-1 rounded-full text-xs font-bold border ${u.role === 'super_admin' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : u.role === 'representative' ? 'bg-purple-50 text-purple-700 border-purple-200' : u.role === 'worker' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-gray-100 text-gray-700 border-gray-200'}`}>
                      {u.role === 'super_admin' ? 'Super Admin' : u.role === 'representative' ? 'Representante' : u.role === 'worker' ? 'Trabalhador' : 'Assistido'}
                    </span>
                    {u.house_relations?.length > 0 && (
                       <div className="text-xs text-gray-500 mt-2">Vínculos: {u.house_relations.length} casas</div>
                    )}
                </td>
                <td className="p-4">
                   <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${u.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
                     <span className={`w-2 h-2 rounded-full ${u.status === 'active' ? 'bg-green-500' : 'bg-red-500'}`}></span>
                     {u.status === 'active' ? 'Ativo' : 'Inativo'}
                   </div>
                </td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-1">
                    <button 
                      onClick={() => handleToggleUserStatus(u.id, u.status, u.role)} 
                      className={`p-2 rounded-md transition-colors ${u.status === 'active' ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-emerald-600 bg-emerald-50 hover:bg-emerald-100'}`} 
                      title={u.status === 'active' ? 'Desativar Usuário' : 'Ativar Usuário'}
                    >
                      <Power className="w-5 h-5"/>
                    </button>
                    <button onClick={() => setEditUser(u)} className="text-indigo-600 bg-indigo-50 hover:bg-indigo-100 p-2 rounded-md transition-colors" title="Editar Cadastro e Dados Completos"><Edit className="w-5 h-5"/></button>
                    <button onClick={() => { setResettingUser(u); setNewPasswordVal(''); }} className="text-blue-600 bg-blue-50 hover:bg-blue-100 p-2 rounded-md transition-colors cursor-pointer" title="Resetar Senha Automação"><Key className="w-5 h-5"/></button>
                    <button onClick={() => {
                      if(window.confirm('Atenção: A exclusão é irreversível e pode quebrar logs do sistema. Deseja excluir este usuário?')) {
                        fetch(`/api/admin/users/${u.id}`, { method: 'DELETE' }).then(() => loadData());
                      }
                    }} className="text-red-600 bg-red-50 hover:bg-red-100 p-2 rounded-md transition-colors" title="Excluir Definitivamente"><Trash2 className="w-5 h-5"/></button>
                  </div>
                </td>
              </tr>
            ))}
            {filteredUsers.length === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-gray-500">Nenhum usuário encontrado com os filtros atuais.</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

