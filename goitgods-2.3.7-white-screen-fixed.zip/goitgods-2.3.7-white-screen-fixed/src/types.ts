/**
 * GOITGODS 2.1 + PASQUARED-OS
 * Core TypeScript Type Definitions
 */

export type EpistemicType = 'FACT' | 'INFERENCE' | 'FICTION' | 'HYPOTHESIS' | 'COUNTERFACTUAL';

export type GodId =
  | 'ZEUS'
  | 'ATHENA'
  | 'APOLLO'
  | 'HERMES'
  | 'HEPHAESTUS'
  | 'HADES'
  | 'ARES'
  | 'POSEIDON'
  | 'DEMETER'
  | 'APHRODITE'
  | 'DIONYSUS'
  | 'CHRONOS';

export interface GodMetadata {
  id: GodId;
  name: string;
  role: string;
  domain: string;
  description: string;
  color: string;
  iconName: string;
  defaultWeight: number;
}

export type FormulationMode = 'EXPRESS' | 'PERSONALIZED' | 'EXPERT';

export interface CognitiveVector {
  depth: number;           // D
  technicality: number;    // T
  academicLevel: number;   // A
  narrativeLevel: number;  // N
  criticalDepth: number;   // C
  historicalDepth: number; // H
  referenceRigor: number;  // R
  fictionFreedom: number;  // F
  visualDensity: number;   // V
  simplicity: number;      // S
}

export interface EbookDNA {
  topic: string;
  intent: string;
  audience: string;
  objective: string;
  language: string;
  depth: 'superficial' | 'intermediario' | 'profundo' | 'exaustivo';
  style: 'academico' | 'narrativo' | 'tecnico' | 'divulgacao' | 'ensaio';
  tone: 'analitico' | 'didatico' | 'critico' | 'imparcial' | 'dramatico';
  length: 'curto' | 'medio' | 'longo' | 'monumental';
  chapterCount: number;
  technicality: number;
  historicalDepth: number;
  criticalDepth: number;
  narrativeLevel: number;
  creativityLevel: number;
  fictionLevel: number;
  evidenceLevel: number;
  citationLevel: number;
  visualDensity: number;
  sourcePolicy: 'strict_peer_reviewed' | 'verified_only' | 'broad_historical' | 'exploratory';
  riskTolerance: 'zero_tolerance' | 'low' | 'moderate' | 'high';
  outputFormat: 'EPUB' | 'PDF' | 'DOCX' | 'HTML';
}


export type AcademicLevel =
  | 'FUNDAMENTAL_I' | 'FUNDAMENTAL_II' | 'MEDIO' | 'TECNICO'
  | 'GRADUACAO' | 'POS_GRADUACAO' | 'MESTRADO' | 'DOUTORADO' | 'OUTRO';

export interface ResearchAnamnesisInput {
  subjectArea: string; academicLevel: AcademicLevel; schoolYear?: string; topic: string; problem: string; scope?: string;
  generalObjective: string; specificObjectives?: string; premises?: string; knownFacts?: string; sourceRequirements?: string;
  methodPreference?: string; constraints?: string; outputType: string;
}

export interface ResearchAnamnesisQuestion {
  id: keyof ResearchAnamnesisInput | string; stage: string; question: string; required: boolean;
  kind: 'text' | 'textarea' | 'select' | 'level'; help?: string; options?: string[];
}

export interface ResearchAnamnesisProtocol {
  protocolId: string; subjectArea: string; academicLevel: AcademicLevel; schoolYear: string; topic: string; problem: string; scope: string;
  generalObjective: string; specificObjectives: string[]; premises: string[]; method: string; sourceRequirements: string; constraints: string; outputType: string;
  pedagogicalProfile: { rigor: number; language: string; expectedMinimumSources: number; requiresOriginalContribution: boolean; requiresExplicitMethodology: boolean; };
  researchStages: string[]; searchStrategy: string[];
}

export interface PremiseEvaluation {
  premiseId: string; premise: string; verdict: 'SUPPORTED' | 'REFUTED' | 'DISPUTED' | 'PROVISIONAL' | 'INSUFFICIENT_EVIDENCE'; confidence: number;
  supportingClaimIds: string[]; counterarguments: string[]; uncertainties: string[]; specialistNotes: string[];
}


export type KnowledgeDomainId =
  | 'MEDICINE' | 'LAW' | 'PSYCHOLOGY' | 'PSYCHOANALYSIS' | 'RADIOLOGY'
  | 'EXACT_SCIENCES' | 'BIOLOGICAL_SCIENCES' | 'ENGINEERING_TECHNOLOGY'
  | 'HUMANITIES' | 'EDUCATION' | 'ECONOMICS' | 'GENERAL';

export interface AcademicProviderDiagnostic {
  provider: string;
  enabled: boolean;
  success: boolean;
  resultCount: number;
  message: string;
}

export interface DynamicAnamnesisAnswer {
  questionId: string;
  answer: string;
}

export interface DynamicAnamnesisQuestion {
  id: string;
  stage: string;
  question: string;
  help?: string;
  required: boolean;
  kind: 'text' | 'textarea' | 'select';
  options?: string[];
}

export interface DynamicAnamnesisSession {
  sessionId: string;
  subjectArea: string;
  academicLevel: AcademicLevel;
  schoolYear?: string;
  detectedDomain: KnowledgeDomainId;
  answers: Record<string, string>;
  answeredQuestions: string[];
  currentQuestion: DynamicAnamnesisQuestion | null;
  complete: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DynamicAnamnesisStepResponse {
  session: DynamicAnamnesisSession;
  nextQuestion: DynamicAnamnesisQuestion | null;
  completed: boolean;
  synthesizedInput?: ResearchAnamnesisInput;
}

export interface ResearchAnamnesisResult {
  protocol: ResearchAnamnesisProtocol; research: any; premiseEvaluations: PremiseEvaluation[];
  readiness: { score: number; status: 'READY' | 'NEEDS_REFINEMENT' | 'INCOMPLETE' }; nextActions: string[];
}

export interface FormulationState {
  id: string;
  mode: FormulationMode;
  completenessScore: number; // FCS: 0 to 1
  ebookDNA: EbookDNA;
  cognitiveVector: CognitiveVector;
  questionsAsked: string[];
  userAnswers: Record<string, string>;
  isComplete: boolean;
}

export interface ResearchProfile {
  origin: boolean;        // A. Como começou
  causes: boolean;        // B. Fatores que causaram
  strengths: boolean;     // C. Pontos fortes
  weaknesses: boolean;    // D. Pontos fracos
  duration: boolean;      // E. Tempo em evidência
  beginning: boolean;     // F. Início
  development: boolean;   // G. Desenvolvimento
  middle: boolean;        // H. Meio
  ending: boolean;        // I. Fim
  consequences: boolean;  // J. Consequências
  actors: boolean;        // K. Atores
  sources: boolean;       // L. Fontes
  uncertainties: boolean; // M. Incertezas
  controversies: boolean; // N. Controvérsias
}

export interface KnowledgeObject {
  knowledge_id: string;
  source_id: string;
  entity_id: string;
  domain: string;
  claim: string;
  epistemic_type: EpistemicType;
  confidence: number;
  timestamp: string;
  author: string;
  publisher: string;
  source_url: string;
  source_hash: string;
  evidence_score: number;
  verification_status: 'VERIFIED' | 'PROVISIONAL' | 'UNVERIFIED' | 'DISPUTED';
  created_at: string;
  updated_at: string;
  version: number;
  pks: number; // PASQUARED Knowledge Score
}

export interface GodOutput {
  god_id: GodId;
  god_version: string;
  model_version: string;
  claim: string;
  reasoning_summary: string;
  evidence: string[];
  confidence: number;
  uncertainties: string[];
  counterarguments: string[];
  dependencies: string[];
  recommendation: string;
  epistemic_type: EpistemicType;
  source_ids: string[];
  knowledge_ids: string[];
}

export interface GodWeightInfo {
  god_id: GodId;
  affinity: number;
  raw_weight: number;
  normalized_weight: number; // Wg
  gps: number; // God Performance Score
}

export interface ContradictionNode {
  id: string;
  claimA: string;
  godA: GodId;
  claimB: string;
  godB: GodId;
  conflictScore: number;
  description: string;
}

export interface ARESAttack {
  god_id: GodId;
  target_claim: string;
  attack_score: number;
  attack: string;
  counterexample: string;
  missing_evidence: string;
  risk: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface HADESRisk {
  missing_data: string[];
  hidden_relations: string[];
  inconsistencies: string[];
  biases: string[];
  source_risks: string[];
  risk_score: number;
}

export interface MVEDScores {
  evidenceScore: number;   // M1
  logicScore: number;      // M2
  relevanceScore: number;  // M3
  riskScore: number;       // M4
  consensusScore: number;  // M5
  compositeMVED: number;   // Weighted total
}

export type DecisionState =
  | 'ACCEPTED'
  | 'HIGH_CONFIDENCE'
  | 'PROVISIONAL'
  | 'PARTIAL_CONSENSUS'
  | 'LOW_CONFIDENCE'
  | 'CONFLICT'
  | 'NO_CONSENSUS'
  | 'INSUFFICIENT_DATA';

export interface DissentRecord {
  dissent_id: string;
  god_id: GodId;
  decision_id: string;
  claim: string;
  reason: string;
  evidence: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  created_at: string;
}

export interface ZeusDecision {
  decision_id: string;
  primary_decision: string;
  confidence: number;
  consensus_level: number;
  uncertainty_level: number;
  decision_state: DecisionState;
  reasoning: string;
  evidence_ids: string[];
  epistemic_breakdown: Record<EpistemicType, number>;
  dissents: DissentRecord[];
  timestamp: string;
}

export interface HistoricalTimelineItem {
  phase: 'INÍCIO' | 'DESENVOLVIMENTO' | 'MEIO' | 'FIM' | 'CONSEQUÊNCIAS';
  period: string;
  event: string;
  description: string;
  actors: string[];
  evidenceDuration: string;
  causalityScore: number;
}

export interface ClaimWithEpistemology {
  id: string;
  text: string;
  epistemicType: EpistemicType;
  evidenceScore: number;
  confidence: number;
  source: string;
  sourceUrl?: string;
  explanation?: string;
}

export interface EbookChapter {
  chapter_id: string;
  chapter_number: number;
  title: string;
  objective: string;
  claims: ClaimWithEpistemology[];
  content: string;
  mved_summary: string;
  confidence: number;
  uncertainties: string[];
  timeline_items?: HistoricalTimelineItem[];
  epistemic_labels: Record<EpistemicType, number>;
}

export interface EbookBlueprint {
  blueprint_id: string;
  title: string;
  subtitle: string;
  metadata: {
    author: string;
    version: string;
    createdAt: string;
  };
  ebookDNA: EbookDNA;
  researchProfile: ResearchProfile;
  knowledgeScope: string[];
  sourcePolicy: string;
  epistemicPolicy: string;
  chapterPlan: { chapter_number: number; title: string; objective: string }[];
  godWeightMatrix: Partial<Record<GodId, number>>;
  evidenceRequirements: string;
  mvedPolicy: string;
  status: 'DRAFT' | 'READY_FOR_GENERATION' | 'GENERATING' | 'VALIDATING' | 'PUBLISHED' | 'REVISION_REQUIRED';
}

export interface EbookManuscript {
  ebook_id: string;
  blueprint_id: string;
  title: string;
  subtitle: string;
  coverImage?: string;
  foreword: string;
  chapters: EbookChapter[];
  conclusion: string;
  references: { id: string; author: string; title: string; year: string; url?: string; trustScore: number }[];
  methodologicalNotes: string;
  qualityScore: number; // EQS
  mvedScore: number;
  generatedAt: string;
}

export interface ReaderSettings {
  fontSize: number; // 12-32
  fontFamily: 'serif' | 'sans' | 'mono';
  theme: 'light' | 'dark' | 'sepia';
  lineSpacing: number; // 1.2 - 2.0
  maxWidth: number; // 600 - 1000
  showEpistemicLabels: boolean;
  showEvidenceDetails: boolean;
}

export interface UserAnnotation {
  id: string;
  ebookId: string;
  chapterId: string;
  cfiOrPosition: string;
  type: 'bookmark' | 'highlight' | 'note';
  text?: string;
  noteText?: string;
  color?: string;
  createdAt: string;
}

export interface ReaderProgress {
  ebookId: string;
  currentChapterIndex: number;
  percent: number; // 0 - 100
  lastReadAt: string;
}

export interface SystemExecutionResult {
  query: string;
  formulation: FormulationState;
  discoveredDomains: string[];
  selectedGods: GodWeightInfo[];
  godOutputs: GodOutput[];
  contradictions: ContradictionNode[];
  aresAttacks: ARESAttack[];
  hadesRisk: HADESRisk;
  mvedScores: MVEDScores;
  zeusDecision: ZeusDecision;
  historicalTimeline?: HistoricalTimelineItem[];
  knowledgeObjects: KnowledgeObject[];
  generatedBlueprint?: EbookBlueprint;
  generatedEbook?: EbookManuscript;
}

export interface OlympusGodSpec {
  id: GodId | string;
  name: string;
  domain: string;
  specialties: string[];
  gps: number; // God Performance Score
  status: 'ACTIVE' | 'SANDBOX' | 'RETIRED' | 'CANDIDATE';
  version: string;
  failureHistoryCount: number;
}

// ==========================================
// ADMIN PANEL TYPE DEFINITIONS
// ==========================================

export type UserRole = 'SUPER_ADMIN' | 'GOD_OPERATOR' | 'EVIDENCE_AUDITOR' | 'STANDARD_USER';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'PENDING_REVIEW';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  apiQuotaUsed: number;
  apiQuotaLimit: number;
  lastActive: string;
  apiKey: string;
  createdAt: string;
}

export interface MVEDWeightConfig {
  evidence: number;  // M1
  logic: number;     // M2
  relevance: number; // M3
  risk: number;      // M4
  consensus: number; // M5
}

export interface SystemSettings {
  kgsThreshold: number;
  epistemicStrictness: number;
  aresAttackRigor: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  hadesAutoQuarantine: boolean;
  maxConcurrentGods: number;
  geminiModel: string;
  maintenanceMode: boolean;
  mvedWeights: MVEDWeightConfig;
  blockedDomains: string[];
  rateLimitPerMin: number;
  microsoftFoundryApiKey: string;
  microsoftFoundryEndpoint: string;
  microsoftFoundryDeployment: string;
  microsoftFoundryModel: string;
  pasquaredAgentModel: string;
  goitgodsAgentModel: string;
}

export type ModerationType = 'CLAIM' | 'MANUSCRIPT' | 'SOURCE_DOMAIN';
export type ModerationStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'QUARANTINED';

export interface ModerationItem {
  id: string;
  type: ModerationType;
  title: string;
  description: string;
  epistemicType?: EpistemicType;
  confidenceScore: number;
  flagReason: string;
  status: ModerationStatus;
  submittedBy: string;
  createdAt: string;
  metadata?: Record<string, any>;
}

export interface LatencyHistoryPoint {
  time: string;
  latencyMs: number;
  arbitrations: number;
}

export interface AdminSystemStats {
  uptimeSeconds: number;
  cpuLoadPercent: number;
  memoryUsedMB: number;
  totalMemoryMB: number;
  totalArbitrations: number;
  avgHcsScore: number;
  avgLatencyMs: number;
  activeGodAgents: number;
  totalKnowledgeObjects: number;
  generatedEbooksCount: number;
  apiCallsTotal: number;
  geminiTokensUsed: number;
  latencyHistory: LatencyHistoryPoint[];
  roleDistribution: Record<UserRole, number>;
}

export interface SuperAdminProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  role: 'SUPER_ADMIN';
  status: 'ACTIVE';
  apiKey: string;
  createdAt: string;
  isConfigured: boolean;
}

export interface SetupStatusResponse {
  success: boolean;
  isSetup: boolean;
  superAdmin: {
    id: string;
    name: string;
    username: string;
    email: string;
    createdAt: string;
  } | null;
}

export interface AuthSession {
  token: string;
  user: AdminUser;
}

export type AuditSeverity = 'INFO' | 'WARN' | 'SECURITY' | 'ERROR';

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  severity: AuditSeverity;
  details: string;
}

// ==========================================
// PASQUARED-GOITGODS v3 TRIANGULATION & LEDGER TYPES
// ==========================================

export type SourceType =
  | 'crossref'
  | 'openalex'
  | 'opencitations'
  | 'doaj'
  | 'scielo'
  | 'pubmed'
  | 'wikidata'
  | 'governmental'
  | 'university'
  | 'digital_library'
  | 'primary'
  | 'historical_archive'
  | 'europepmc';

export interface SourceProvider {
  source_id: string;
  title: string;
  authors: string[];
  publisher: string;
  publication_date: string;
  url: string; // NEVER invent URL. Mark UNVERIFIED if unconfirmed.
  source_type: SourceType;
  authority_score: number; // 0 to 1
  independence_score: number; // 0 to 1
  recency_score: number; // 0 to 1
  relevance_score: number; // 0 to 1
  citation_metadata: Record<string, any>;
  retrieved_at: string;
  content_hash: string;
  verification_status: 'VERIFIED' | 'UNVERIFIED' | 'DISPUTED';
}

export interface PksBreakdown {
  pks: number;
  components: {
    kq: { value: number; reason: string; evidence: string };
    relevance: { value: number; reason: string; evidence: string };
    verification: { value: number; reason: string; evidence: string };
    freshness: { value: number; reason: string; evidence: string };
    independence: { value: number; reason: string; evidence: string };
  };
}

export type ContradictionType =
  | 'DIRECT_CONTRADICTION'
  | 'PARTIAL_CONFLICT'
  | 'SCOPE_CONFLICT'
  | 'TEMPORAL_CONFLICT'
  | 'DEFINITION_CONFLICT'
  | 'NO_CONFLICT';

export interface TriangulationDimensions {
  documentary: {
    agreementScore: number;
    corroboratingSourcesCount: number;
    notes: string;
  };
  independentSources: {
    independenceScore: number;
    distinctPublishersCount: number;
    circularCitationRisk: boolean;
    notes: string;
  };
  epistemological: {
    epistemicType: EpistemicType;
    evidenceStrength: number;
    notes: string;
  };
}

export type ZeusEpistemicStatus =
  | 'VERIFIED'
  | 'SUPPORTED'
  | 'PROVISIONAL'
  | 'DISPUTED'
  | 'INSUFFICIENT_EVIDENCE'
  | 'REJECTED';

export interface VerifiedClaim {
  claim_id: string;
  claim: string;
  epistemic_type: EpistemicType;
  status: ZeusEpistemicStatus;
  confidence: number;
  pks: number;
  pks_breakdown: PksBreakdown;
  mved: number;
  source_ids: string[];
  god_analysis_ids: string[];
  ares_status: {
    attacked: boolean;
    severity: string;
    risk: string;
  };
  hades_status: {
    audited: boolean;
    riskScore: number;
    inconsistencies: string[];
  };
  zeus_decision: string;
  triangulation: TriangulationDimensions;
  uncertainties: string[];
}

export interface VerifiedKnowledgeLedger {
  ledger_id: string;
  topic: string;
  totalClaims: number;
  verifiedCount: number;
  supportedCount: number;
  provisionalCount: number;
  disputedCount: number;
  rejectedCount: number;
  insufficientEvidenceCount: number;
  claims: VerifiedClaim[];
  generatedAt: string;
}

export interface ChapterResearchPacket {
  chapter_number: number;
  title: string;
  objective: string;
  researchQuestions: string[];
  verifiedClaims: VerifiedClaim[];
  disputedClaims: VerifiedClaim[];
  timeline: HistoricalTimelineItem[];
  sources: SourceProvider[];
  specialistAnalyses: GodOutput[];
  counterarguments: string[];
  uncertainties: string[];
  evidenceMatrix: {
    claimId: string;
    sourceIds: string[];
    epistemicType: EpistemicType;
    status: ZeusEpistemicStatus;
  }[];
}

export interface BookIntegrityReport {
  book_id: string;
  qualityScore: number; // EQS 0 to 1
  components: {
    evidenceQuality: number;
    researchCoverage: number;
    sourceDiversity: number;
    sourceIndependence: number;
    logicalConsistency: number;
    epistemicAccuracy: number;
    citationIntegrity: number;
    narrativeCoherence: number;
    completeness: number;
    readability: number;
  };
  explanation: string;
  unsupportedClaimsCount: number;
  hallucinatedSourcesCount: number;
  auditTimestamp: string;
}


