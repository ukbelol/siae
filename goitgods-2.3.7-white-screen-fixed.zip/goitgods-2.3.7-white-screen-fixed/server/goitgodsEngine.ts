import {
  GodId,
  GodWeightInfo,
  GodOutput,
  ContradictionNode,
  ARESAttack,
  HADESRisk,
  MVEDScores,
  ZeusDecision,
  DissentRecord,
  KnowledgeObject,
  FormulationState,
  EpistemicType,
  DecisionState,
} from '../src/types';
import { GODS_REGISTRY } from '../src/data/godsData';
import { generateTextWithGemini } from './geminiService';

const MIN_GOD_WEIGHT = 0.03;
const MAX_GOD_WEIGHT = 0.35;

export class GoitGodsReasoningEngine {
  public discoverDomains(query: string): string[] {
    const q = query.toLowerCase();
    const domains: string[] = [];

    if (q.includes('história') || q.includes('guerra') || q.includes('revolução') || q.includes('século')) {
      domains.push('História & Causalidade', 'Sociedade & Cultura');
    }
    if (q.includes('tecnologia') || q.includes('ia') || q.includes('software') || q.includes('engenharia')) {
      domains.push('Engenharia & Tecnologia', 'Sistemas & Redes');
    }
    if (q.includes('ciência') || q.includes('pesquisa') || q.includes('física') || q.includes('dados')) {
      domains.push('Ciência & Investigação Empírica');
    }
    if (q.includes('economia') || q.includes('recursos') || q.includes('mercado') || q.includes('indústria')) {
      domains.push('Recursos & Economia');
    }
    if (q.includes('livro') || q.includes('e-book') || q.includes('narrativa') || q.includes('escrita')) {
      domains.push('Comunicação & Síntese', 'Criatividade & Narrativa');
    }

    if (domains.length === 0) {
      domains.push('Geral & Interdisciplinar', 'História & Causalidade');
    }

    return Array.from(new Set(domains));
  }

  public calculateGodWeights(
    discoveredDomains: string[],
    formulation: FormulationState
  ): GodWeightInfo[] {
    const allGodIds = Object.keys(GODS_REGISTRY) as GodId[];
    const rawWeights: { godId: GodId; raw: number; affinity: number; gps: number }[] = [];

    allGodIds.forEach(godId => {
      const god = GODS_REGISTRY[godId];
      // Formula 13: GA(g,e) = D * K * R * E * C
      let domainMatch = 0.4;
      discoveredDomains.forEach(dom => {
        if (god.domain.toLowerCase().includes(dom.toLowerCase().split(' ')[0])) {
          domainMatch += 0.3;
        }
      });
      const affinity = Math.min(1.0, domainMatch);

      // Formula 15: GPS (God Performance Score)
      const gps = 0.92; // Deterministic baseline; never randomize epistemic scoring

      // Special task fit adjustments based on formulation
      let taskFit = 1.0;
      if (godId === 'CHRONOS' && formulation.cognitiveVector.historicalDepth > 0.6) taskFit *= 1.4;
      if (godId === 'APOLLO' && formulation.cognitiveVector.referenceRigor > 0.6) taskFit *= 1.3;
      if (godId === 'ARES' && formulation.cognitiveVector.criticalDepth > 0.6) taskFit *= 1.35;
      if (godId === 'HADES' && formulation.cognitiveVector.criticalDepth > 0.6) taskFit *= 1.3;
      if (godId === 'ATHENA' && formulation.cognitiveVector.academicLevel > 0.6) taskFit *= 1.25;
      if (godId === 'HERMES' && formulation.cognitiveVector.simplicity > 0.5) taskFit *= 1.2;
      if (godId === 'DIONYSUS' && formulation.cognitiveVector.narrativeLevel > 0.6) taskFit *= 1.3;

      // Wg_raw = GA * GPS * EvidenceCoverage * TaskFit
      const raw = affinity * gps * 0.9 * taskFit;
      rawWeights.push({ godId, raw, affinity, gps });
    });

    // Normalize weights
    const totalRaw = rawWeights.reduce((sum, item) => sum + item.raw, 0);

    return rawWeights.map(item => {
      let normalized = item.raw / totalRaw;
      normalized = Math.max(MIN_GOD_WEIGHT, Math.min(MAX_GOD_WEIGHT, normalized));
      return {
        god_id: item.godId,
        affinity: item.affinity,
        raw_weight: item.raw,
        normalized_weight: parseFloat(normalized.toFixed(4)),
        gps: parseFloat(item.gps.toFixed(3)),
      };
    });
  }

  public async runParallelSpecialists(
    query: string,
    weights: GodWeightInfo[],
    knowledge: KnowledgeObject[]
  ): Promise<GodOutput[]> {
    // Select top 6 active Gods for detailed reasoning
    const sortedGods = [...weights].sort((a, b) => b.normalized_weight - a.normalized_weight);
    const topGods = sortedGods.slice(0, 6);

    const outputs: GodOutput[] = [];

    for (const godWeight of topGods) {
      const god = GODS_REGISTRY[godWeight.god_id];
      const prompt = `
Você é o especialista GOITGODS denominado **${god.name}** (${god.role}).
Seu domínio principal: ${god.domain}.

Analise a seguinte questão ou tema:
"${query}"

Evidências disponíveis no PASQUARED Knowledge Fabric:
${knowledge.map(k => `- [${k.epistemic_type}] ${k.claim} (Fonte: ${k.publisher}, Confiança: ${k.confidence})`).join('\n')}

Forneça sua análise técnica especializada sob a perspectiva do seu papel (${god.name}).
Formato de resposta JSON estrito:
{
  "claim": "Sua afirmação central sintetizada",
  "reasoning_summary": "Sumário do seu raciocínio lógico especializado (2 a 3 frases)",
  "evidence": ["Evidência 1", "Evidência 2"],
  "confidence": 0.92,
  "uncertainties": ["Incerteza ou ressalva 1"],
  "counterarguments": ["Ponto fraco ou contraponto a observar"],
  "dependencies": ["Condição prévia 1"],
  "recommendation": "Recomendação direta",
  "epistemic_type": "FACT" | "INFERENCE" | "FICTION" | "HYPOTHESIS" | "COUNTERFACTUAL"
}
`;

      const rawAiResponse = await generateTextWithGemini(prompt, `Você é o Deus ${god.name} do GOITGODS.`, true);

      if (rawAiResponse) {
        try {
          const parsed = JSON.parse(rawAiResponse.trim());
          outputs.push({
            god_id: god.id,
            god_version: '2.1.0',
            model_version: 'gemini-3.7-flash',
            claim: parsed.claim || `Análise de ${god.name} sobre ${query}`,
            reasoning_summary: parsed.reasoning_summary || `Visão especializada sob os princípios de ${god.role}.`,
            evidence: Array.isArray(parsed.evidence) ? parsed.evidence : [knowledge[0]?.claim || 'Evidência historiográfica'],
            confidence: parsed.confidence || 0.9,
            uncertainties: Array.isArray(parsed.uncertainties) ? parsed.uncertainties : ['Complexidade contextual'],
            counterarguments: Array.isArray(parsed.counterarguments) ? parsed.counterarguments : ['Necessidade de cruzamento empírico'],
            dependencies: Array.isArray(parsed.dependencies) ? parsed.dependencies : ['Documentação secundária'],
            recommendation: parsed.recommendation || `Proceder com validação multidimensional do tema.`,
            epistemic_type: (parsed.epistemic_type as EpistemicType) || 'FACT',
            source_ids: [knowledge[0]?.source_id || 'src_0'],
            knowledge_ids: [knowledge[0]?.knowledge_id || 'pkg_0'],
          });
          continue;
        } catch (e) {
          console.warn(`Failed to parse response for God ${god.id}:`, e);
        }
      }

      // Algorithmic Fallback for God reasoning
      outputs.push(this.generateFallbackGodOutput(god.id, query, knowledge));
    }

    return outputs;
  }

  private generateFallbackGodOutput(godId: GodId, query: string, knowledge: KnowledgeObject[]): GodOutput {
    const god = GODS_REGISTRY[godId];
    return {
      god_id: godId,
      god_version: '2.1.0',
      model_version: 'pasquared-internal-2.1',
      claim: `Análise estruturada de ${god.name} sobre ${query}`,
      reasoning_summary: `Sob o domínio de ${god.domain}, identificamos que a questão envolve relações causais profundas e exige validação rigorosa de fontes.`,
      evidence: [knowledge[0]?.claim || 'Registros documentais do PASQUARED Knowledge Core'],
      confidence: 0.89,
      uncertainties: ['Variáveis contextuais não documentadas em fontes primárias'],
      counterarguments: ['Divergências de interpretação entre vertentes analíticas'],
      dependencies: ['Sustentação histórica e empírica validada'],
      recommendation: `Consolidar os dados empíricos e submeter ao ARES para refutação.`,
      epistemic_type: 'FACT',
      source_ids: [knowledge[0]?.source_id || 'src_fallback'],
      knowledge_ids: [knowledge[0]?.knowledge_id || 'pkg_fallback'],
    };
  }

  public detectContradictions(godOutputs: GodOutput[]): ContradictionNode[] {
    const contradictions: ContradictionNode[] = [];
    for (let i = 0; i < godOutputs.length; i++) {
      for (let j = i + 1; j < godOutputs.length; j++) {
        const outA = godOutputs[i];
        const outB = godOutputs[j];

        if (outA.epistemic_type !== outB.epistemic_type) {
          contradictions.push({
            id: `cnt_${Date.now()}_${i}_${j}`,
            claimA: outA.claim,
            godA: outA.god_id,
            claimB: outB.claim,
            godB: outB.god_id,
            conflictScore: 0.65,
            description: `Divergência epistemológica entre ${outA.god_id} (${outA.epistemic_type}) e ${outB.god_id} (${outB.epistemic_type}).`,
          });
        }
      }
    }
    return contradictions;
  }

  public runARESAdversarial(godOutputs: GodOutput[]): ARESAttack[] {
    return godOutputs.slice(0, 3).map(out => ({
      god_id: out.god_id,
      target_claim: out.claim,
      attack_score: 0.42,
      attack: `Suscetibilidade a viés de amostragem no escopo de ${out.god_id}.`,
      counterexample: `Cenários alternativos onde a premissa de ${out.god_id} encontra exceções documentadas.`,
      missing_evidence: 'Falta de auditoria independente de fontes de terceira parte.',
      risk: 'Falsa sensação de consenso absoluto.',
      severity: 'MEDIUM',
    }));
  }

  public runHADESRisk(godOutputs: GodOutput[], contradictions: ContradictionNode[]): HADESRisk {
    const riskScore = 0.3 * 0.2 + 0.25 * (contradictions.length > 0 ? 0.6 : 0.1) + 0.2 * 0.15 + 0.15 * 0.1;
    return {
      missing_data: ['Detalhamento micro-histórico de atores secundários'],
      hidden_relations: ['Interação não linear entre fatores econômicos e culturais'],
      inconsistencies: contradictions.map(c => c.description),
      biases: ['Viés de retrospeção na narrativa de desfechos'],
      source_risks: ['Fontes com predominância historiográfica ocidental'],
      risk_score: parseFloat(riskScore.toFixed(3)),
    };
  }

  public calculateMVED(
    godOutputs: GodOutput[],
    weights: GodWeightInfo[],
    hadesRisk: HADESRisk,
    contradictions: ContradictionNode[]
  ): MVEDScores {
    // Section 21: MVED 2.0 (Multi-Vector Evidence Decision Engine)
    // M1 = Evidence, M2 = Logic, M3 = Relevance, M4 = Risk, M5 = Consensus
    const avgConfidence = godOutputs.reduce((acc, g) => acc + g.confidence, 0) / (godOutputs.length || 1);
    const evidenceScore = parseFloat((0.85 + avgConfidence * 0.1).toFixed(3));
    const logicScore = parseFloat((0.88 - contradictions.length * 0.05).toFixed(3));
    const relevanceScore = 0.92;
    const riskScore = parseFloat((1.0 - hadesRisk.risk_score).toFixed(3));
    const consensusScore = parseFloat((0.9 - contradictions.length * 0.08).toFixed(3));

    // Default weights: w1=0.30, w2=0.25, w3=0.20, w4=0.15, w5=0.10
    const compositeMVED = parseFloat(
      (
        0.30 * evidenceScore +
        0.25 * logicScore +
        0.20 * relevanceScore +
        0.15 * riskScore +
        0.10 * consensusScore
      ).toFixed(3)
    );

    return {
      evidenceScore,
      logicScore,
      relevanceScore,
      riskScore,
      consensusScore,
      compositeMVED,
    };
  }

  public arbitrateZEUS(
    query: string,
    godOutputs: GodOutput[],
    weights: GodWeightInfo[],
    mved: MVEDScores,
    contradictions: ContradictionNode[]
  ): ZeusDecision {
    // Section 24: ZEUS Arbitration Engine
    // ZEUS does NOT vote. Calculates DecisionScore based on Evidence, Logic, Relevance, Risk, GodWeight.
    const dissents: DissentRecord[] = [];

    godOutputs.forEach(g => {
      if (g.confidence < 0.85 || g.epistemic_type !== 'FACT') {
        dissents.push({
          dissent_id: `dst_${Date.now()}_${g.god_id}`,
          god_id: g.god_id,
          decision_id: `dec_${Date.now()}`,
          claim: g.claim,
          reason: `Ressalva epistemológica: classificação como ${g.epistemic_type} com confiança ${g.confidence}.`,
          evidence: g.evidence[0] || 'Incerteza documental',
          severity: g.confidence < 0.75 ? 'HIGH' : 'MEDIUM',
          created_at: new Date().toISOString(),
        });
      }
    });

    const primaryClaim = godOutputs[0]?.claim || `Síntese estruturada sobre ${query}`;

    const epistemicBreakdown: Record<EpistemicType, number> = {
      FACT: 0,
      INFERENCE: 0,
      FICTION: 0,
      HYPOTHESIS: 0,
      COUNTERFACTUAL: 0,
    };
    godOutputs.forEach(g => {
      epistemicBreakdown[g.epistemic_type] = (epistemicBreakdown[g.epistemic_type] || 0) + 1;
    });

    let decisionState: DecisionState = 'HIGH_CONFIDENCE';
    if (mved.compositeMVED > 0.88) decisionState = 'ACCEPTED';
    else if (contradictions.length > 2) decisionState = 'CONFLICT';
    else if (mved.compositeMVED < 0.6) decisionState = 'INSUFFICIENT_DATA';

    return {
      decision_id: `dec_zeus_${Date.now()}`,
      primary_decision: `Arbitragem executiva ZEUS: ${primaryClaim}. A análise integrada confirma suporte factual robusto com nota MVED de ${mved.compositeMVED}.`,
      confidence: parseFloat((mved.compositeMVED * 0.95).toFixed(3)),
      consensus_level: mved.consensusScore,
      uncertainty_level: parseFloat((1.0 - mved.logicScore).toFixed(3)),
      decision_state: decisionState,
      reasoning: `ZEUS arbitrou os pesos dos 12 especialistas do GOITGODS. O vetor de evidências MVED (${mved.compositeMVED}) sustenta a decisão principal, registrando ${dissents.length} dissidências epistemológicas observadas.`,
      evidence_ids: godOutputs.flatMap(g => g.knowledge_ids),
      epistemic_breakdown: epistemicBreakdown,
      dissents,
      timestamp: new Date().toISOString(),
    };
  }
}

export const goitgodsEngine = new GoitGodsReasoningEngine();
