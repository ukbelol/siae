
import { Language } from './types';

export const translations: Record<Language, any> = {
  'en': {
    appName: 'FREEFLOW 577',
    sections: {
      dashboard: 'Dashboard',
      investigation: 'Investigation',
      analytics: 'Analytics',
      community: 'Community',
      nodes: 'Node Infrastructure',
      users: 'User Demographics',
      uptime: 'System Stability',
      commits: 'Code Architecture'
    },
    status: {
      label: 'System Status',
      operational: 'Operational'
    },
    common: {
      back: 'Back',
      deploy: 'Deploy V2.1',
      cdn: 'Global CDN',
      overview: 'Project Overview',
      loading: 'Loading data...',
      nodes: 'Total Nodes',
      activeUsers: 'Active Users',
      uptime: 'Uptime',
      commits: 'Commits',
      stable: 'Stable'
    },
    investigation: {
      terminal: 'AI Inquiry Terminal',
      placeholder: 'Ask why your project was featured...',
      processing: 'Processing vector analysis...',
      evidence: 'Event Evidence',
      impact: 'Global Impact Scale',
      impactDesc: 'Ranked in top 1% of emerging OS kernels.',
      welcome: "Welcome to the FreeFlow OS 577 Analysis Hub. I am the system agent. How can I assist you in investigating why Google featured your project in their recent showcase?",
      promptsTitle: 'Suggested Inquiries',
      prompt1: 'Why did Google feature FreeFlow OS 577 in their developer showcase?',
      prompt2: 'What architectural innovations make our OS kernel unique?',
      prompt3: 'How does our benchmark performance compare with modern microkernels?'
    },
    nodes: {
      regions: 'Primary Regions',
      distribution: 'Node Distribution Over Time',
      registry: 'Active Node Registry',
      id: 'Node ID',
      provider: 'Provider',
      region: 'Region',
      latency: 'Latency',
      status: 'Status'
    },
    users: {
      monthly: 'Monthly Active',
      signups: 'New Signups',
      churn: 'Churn Rate',
      nps: 'NPS Score',
      breakdown: 'User Type Breakdown',
      growth: 'User Growth Analysis',
      growthDesc: 'Detailed demographics and retention heatmaps are being calculated.'
    }
  },
  'fr': {
    appName: 'FREEFLOW 577',
    sections: {
      dashboard: 'Tableau de bord',
      investigation: 'Investigation',
      analytics: 'Analytique',
      community: 'Communauté',
      nodes: 'Infrastructure des Nœuds',
      users: 'Démographie des Utilisateurs',
      uptime: 'Stabilité du Système',
      commits: 'Architecture du Code'
    },
    status: {
      label: 'État du Système',
      operational: 'Opérationnel'
    },
    common: {
      back: 'Retour',
      deploy: 'Déployer V2.1',
      cdn: 'CDN Global',
      overview: 'Aperçu du Projet',
      loading: 'Chargement des données...',
      nodes: 'Nœuds Totaux',
      activeUsers: 'Utilisateurs Actifs',
      uptime: 'Temps de fonctionnement',
      commits: 'Commits',
      stable: 'Stable'
    },
    investigation: {
      terminal: 'Terminal d\'enquête IA',
      placeholder: 'Demandez pourquoi votre projet a été présenté...',
      processing: 'Traitement de l\'analyse vectorielle...',
      evidence: 'Preuves de l\'événement',
      impact: 'Échelle d\'impact mondial',
      impactDesc: 'Classé dans le top 1% des noyaux OS émergents.',
      welcome: "Bienvenue sur le FreeFlow OS 577 Analysis Hub. Je suis l'agent du système. Comment puis-je vous aider à comprendre pourquoi Google a présenté votre projet ?",
      promptsTitle: 'Questions suggérées',
      prompt1: 'Pourquoi Google a-t-il mis en avant FreeFlow OS 577 dans son showcase développeurs ?',
      prompt2: 'Quelles innovations architecturales rendent notre noyau unique ?',
      prompt3: 'Comment nos performances se comparent-elles aux micro-noyaux modernes ?'
    },
    nodes: {
      regions: 'Régions Principales',
      distribution: 'Distribution des nœuds dans le temps',
      registry: 'Registre des Nœuds Actifs',
      id: 'ID du Nœud',
      provider: 'Fournisseur',
      region: 'Région',
      latency: 'Latence',
      status: 'Statut'
    },
    users: {
      monthly: 'Actifs Mensuels',
      signups: 'Inscriptions',
      churn: 'Taux de désabonnement',
      nps: 'Score NPS',
      breakdown: 'Répartition par type d\'utilisateur',
      growth: 'Analyse de la croissance',
      growthDesc: 'Les données démographiques détaillées sont en cours de calcul.'
    }
  },
  'es': {
    appName: 'FREEFLOW 577',
    sections: {
      dashboard: 'Tablero',
      investigation: 'Investigación',
      analytics: 'Analítica',
      community: 'Comunidad',
      nodes: 'Infraestructura de Nodos',
      users: 'Demografía de Usuarios',
      uptime: 'Estabilidad del Sistema',
      commits: 'Arquitectura de Código'
    },
    status: {
      label: 'Estado del Sistema',
      operational: 'Operativo'
    },
    common: {
      back: 'Volver',
      deploy: 'Desplegar V2.1',
      cdn: 'CDN Global',
      overview: 'Resumen del Proyecto',
      loading: 'Cargando datos...',
      nodes: 'Nodos Totales',
      activeUsers: 'Usuarios Activos',
      uptime: 'Tiempo de Actividad',
      commits: 'Commits',
      stable: 'Estable'
    },
    investigation: {
      terminal: 'Terminal de Consulta IA',
      placeholder: 'Pregunta por qué tu proyecto fue destacado...',
      processing: 'Procesando análisis vectorial...',
      evidence: 'Evidencia del Evento',
      impact: 'Escala de Impacto Global',
      impactDesc: 'Clasificado en el top 1% de núcleos de SO emergentes.',
      welcome: "Bienvenido al Centro de Análisis de FreeFlow OS 577. Soy el agente del sistema. ¿Cómo puedo ayudarte a investigar por qué Google destacó tu proyecto?",
      promptsTitle: 'Consultas sugeridas',
      prompt1: '¿Por qué Google destacó FreeFlow OS 577 en su showcase de desarrolladores?',
      prompt2: '¿Qué innovaciones arquitectónicas hacen único a nuestro núcleo?',
      prompt3: '¿Cómo se compara nuestro rendimiento con microkernels modernos?'
    },
    nodes: {
      regions: 'Regiones Principales',
      distribution: 'Distribución de Nodos en el Tiempo',
      registry: 'Registro de Nodos Activos',
      id: 'ID de Nodo',
      provider: 'Proveedor',
      region: 'Región',
      latency: 'Latencia',
      status: 'Estado'
    },
    users: {
      monthly: 'Activos Mensuales',
      signups: 'Nuevos Registros',
      churn: 'Tasa de Abandono',
      nps: 'Puntuación NPS',
      breakdown: 'Desglose de Tipo de Usuario',
      growth: 'Análisis de Crecimiento de Usuarios',
      growthDesc: 'Se están calculando mapas de calor de retención detallados.'
    }
  },
  'pt-br': {
    appName: 'FREEFLOW 577',
    sections: {
      dashboard: 'Painel',
      investigation: 'Investigação',
      analytics: 'Análise',
      community: 'Comunidade',
      nodes: 'Infraestrutura de Nós',
      users: 'Demografia de Usuários',
      uptime: 'Estabilidade do Sistema',
      commits: 'Arquitetura de Código'
    },
    status: {
      label: 'Status do Sistema',
      operational: 'Operacional'
    },
    common: {
      back: 'Voltar',
      deploy: 'Implantar V2.1',
      cdn: 'CDN Global',
      overview: 'Visão Geral do Projeto',
      loading: 'Carregando dados...',
      nodes: 'Total de Nós',
      activeUsers: 'Usuários Ativos',
      uptime: 'Tempo Online',
      commits: 'Commits',
      stable: 'Estável'
    },
    investigation: {
      terminal: 'Terminal de Consulta IA',
      placeholder: 'Pergunte por que seu projeto foi destaque...',
      processing: 'Processando análise vetorial...',
      evidence: 'Evidência do Evento',
      impact: 'Escala de Impacto Global',
      impactDesc: 'Classificado no top 1% dos kernels de SO emergentes.',
      welcome: "Bem-vindo ao Hub de Análise do FreeFlow OS 577. Eu sou o agente do sistema. Como posso ajudar você a investigar por que o Google apresentou seu projeto?",
      promptsTitle: 'Perguntas sugeridas',
      prompt1: 'Por que o Google destacou o FreeFlow OS 577 no seu showcase de desenvolvedores?',
      prompt2: 'Quais inovações arquiteturais tornam o nosso kernel de SO único?',
      prompt3: 'Como o nosso benchmark de desempenho se compara com microkernels modernos?'
    },
    nodes: {
      regions: 'Principais Regiões',
      distribution: 'Distribuição de Nós ao Longo do Tempo',
      registry: 'Registro de Nós Ativos',
      id: 'ID do Nó',
      provider: 'Provedor',
      region: 'Região',
      latency: 'Latência',
      status: 'Status'
    },
    users: {
      monthly: 'Ativos Mensais',
      signups: 'Novos Cadastros',
      churn: 'Taxa de Churn',
      nps: 'Pontuação NPS',
      breakdown: 'Divisão por Tipo de Usuário',
      growth: 'Análise de Crescimento',
      growthDesc: 'Dados demográficos detalhados estão sendo calculados.'
    }
  }
};
