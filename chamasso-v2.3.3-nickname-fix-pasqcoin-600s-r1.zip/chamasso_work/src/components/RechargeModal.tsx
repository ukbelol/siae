import React, { useState, useEffect } from 'react';
import {
  X,
  CreditCard,
  QrCode,
  Copy,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldCheck,
  AlertCircle,
  Zap,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import type { User, ChamassoTariffSettings } from '../types.ts';

interface RechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onRechargeSuccess: (newPasqcoins: number, statusMessage?: string) => void;
  initialAmount?: number;
}

export const RechargeModal: React.FC<RechargeModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onRechargeSuccess,
  initialAmount = 5,
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number>(initialAmount);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [isCustom, setIsCustom] = useState(false);
  const [tariffSettings, setTariffSettings] = useState<ChamassoTariffSettings>({
    billingEnabled: true,
    ratePerMinute: 0.01,
    minRechargeAmount: 5.0,
    rechargeValidityDays: 30,
  });

  const [pasqcoinSettings, setPasqcoinSettings] = useState({
    secondsPerCoin: 600,
    pricePerCoin: 1.00,
  });
  const [purchaseStatusMessage, setPurchaseStatusMessage] = useState<string>('');

  const [paymentStep, setPaymentStep] = useState<'select' | 'payment' | 'confirmed'>('select');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card'>('pix');
  const [isProcessing, setIsProcessing] = useState(false);
  const [pixData, setPixData] = useState<{
    txId: string;
    qrCodeText: string;
    qrCodeBase64?: string;
    amount: number;
    minutes: number;
    pasqcoins: number;
    secondsGranted: number;
    environment?: 'test' | 'production';
    sandbox?: boolean;
    ticketUrl?: string;
  } | null>(null);
  const [copiedPix, setCopiedPix] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Carrega configurações de tarifas do servidor
  useEffect(() => {
    if (!isOpen) return;
    fetch('/api/tariffs/settings')
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data.ratePerMinute === 'number') {
          setTariffSettings(data);
        }
      })
      .catch((err) => console.error('Erro ao buscar tarifas:', err));

    fetch('/api/pasqcoin/settings')
      .then((res) => res.json())
      .then((data) => {
        const settings = data?.settings || data;
        if (settings && Number(settings.secondsPerCoin) > 0 && Number(settings.pricePerCoin) > 0) {
          setPasqcoinSettings({
            secondsPerCoin: Number(settings.secondsPerCoin),
            pricePerCoin: Number(settings.pricePerCoin),
          });
        }
      })
      .catch((err) => console.error('Erro ao buscar parâmetros PASQcoin:', err));
  }, [isOpen]);

  if (!isOpen) return null;

  const currentRate = tariffSettings.ratePerMinute > 0 ? tariffSettings.ratePerMinute : 0.01;
  const finalAmount = isCustom ? Math.max(tariffSettings.minRechargeAmount, parseFloat(customAmount) || tariffSettings.minRechargeAmount) : selectedAmount;
  const estimatedPasqcoins = Number((finalAmount / Math.max(0.000001, pasqcoinSettings.pricePerCoin)).toFixed(6));
  const estimatedSeconds = Math.floor(estimatedPasqcoins * pasqcoinSettings.secondsPerCoin);
  const estimatedMinutes = Math.floor(estimatedSeconds / 60);

  const formatDuration = (totalSeconds: number) => {
    const safe = Math.max(0, Math.floor(totalSeconds));
    const days = Math.floor(safe / 86400);
    const hours = Math.floor((safe % 86400) / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const seconds = safe % 60;
    if (days > 0) return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
    return `${minutes}m ${seconds}s`;
  };

  const predefinedPackages = [
    { amount: 5, label: 'Pacote Básico', tag: 'Mínimo', popular: false },
    { amount: 10, label: 'Pacote Conversa', tag: 'Recomendado', popular: true },
    { amount: 20, label: 'Pacote Paquera & Amizade', tag: 'Econômico', popular: false },
    { amount: 50, label: 'Pacote VIP Mensal', tag: 'Super Duração', popular: false },
  ];

  const handleGeneratePix = async () => {
    if (!currentUser) {
      setErrorMessage('É necessário estar autenticado para recarregar.');
      return;
    }

    if (finalAmount < tariffSettings.minRechargeAmount) {
      setErrorMessage(`O valor mínimo de recarga é de R$ ${tariffSettings.minRechargeAmount.toFixed(2)}.`);
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const res = await fetch(`/api/users/${currentUser.id}/create-recharge-pix`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: finalAmount,
          method: paymentMethod,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao gerar cobrança Mercado Pago.');
      }

      const data = await res.json();
      setPixData({
        txId: data.transactionId,
        qrCodeText: data.pixCopyPaste,
        qrCodeBase64: data.pixQrCodeUrl,
        amount: finalAmount,
        minutes: Math.floor(Number(data.secondsGranted ?? estimatedSeconds) / 60),
        pasqcoins: Number(data.pasqcoinsToCredit ?? estimatedPasqcoins),
        secondsGranted: Number(data.secondsGranted ?? estimatedSeconds),
        environment: data.environment,
        sandbox: data.sandbox,
        ticketUrl: data.ticketUrl,
      });
      setPaymentStep('payment');
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro de conexão com o gateway Mercado Pago.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmPayment = async () => {
    if (!currentUser || !pixData) return;
    setIsProcessing(true);
    try {
      const res = await fetch(`/api/users/${currentUser.id}/recharge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionId: pixData.txId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const newPasqcoins = Number(data.pasqcoins ?? 0);
        const statusMessage = data.message || `Pagamento aprovado. ${Number(data.pasqcoinsPurchased || 0).toFixed(6)} PASQcoin creditados.`;
        setPurchaseStatusMessage(statusMessage);
        onRechargeSuccess(newPasqcoins, statusMessage);
        setPaymentStep('confirmed');
      } else {
        const err = await res.json();
        setErrorMessage(err.error || 'Pagamento ainda não liquidado.');
      }
    } catch (err) {
      setErrorMessage('Falha ao confirmar pagamento.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopyPix = () => {
    if (!pixData?.qrCodeText) return;
    navigator.clipboard.writeText(pixData.qrCodeText);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] text-slate-200 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0A0C10] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="rounded-xl border border-emerald-400/40 bg-emerald-500/10 p-2.5 text-emerald-400">
              <Zap className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                Compra de PASQcoin • Chamasso
              </h2>
              <p className="text-xs text-[#22D3EE] font-mono">
                Gateway Mercado Pago • 1 PASQ = {pasqcoinSettings.secondsPerCoin}s • R$ {pasqcoinSettings.pricePerCoin.toFixed(4).replace('.', ',')} / PASQ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Mensagem de Erro se houver */}
          {errorMessage && (
            <div className="rounded-xl border border-rose-500/40 bg-rose-500/10 p-3 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Regras Importantes do Sistema */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3.5 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-[#22D3EE]" />
                Regras de Desbloqueio e Expiração:
              </span>
              <span className="text-[10px] font-mono bg-[#22D3EE]/20 text-[#22D3EE] px-2 py-0.5 rounded-full">
                Mínimo R$ {tariffSettings.minRechargeAmount.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <p className="text-slate-300">
              • O saldo positivo em <strong className="text-emerald-400">PASQcoin desbloqueia todas as funções</strong> da sala. O consumo é proporcional ao tempo efetivamente utilizado e pode gerar saldo fracionado.
            </p>
            <p className="text-slate-300">
              • Os créditos <strong className="text-amber-400">expiram em {tariffSettings.rechargeValidityDays} dias</strong> a contar da primeira entrada em sala de bate-papo ou do primeiro contato direto realizado.
            </p>
          </div>

          {/* STEP 1: Seleção de Pacote */}
          {paymentStep === 'select' && (
            <div className="space-y-4">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                Escolha o Valor do Pacote de Recarga:
              </label>

              <div className="grid grid-cols-2 gap-3">
                {predefinedPackages.map((pkg) => {
                  const isSelected = !isCustom && selectedAmount === pkg.amount;
                  const pkgPasq = pkg.amount / Math.max(0.000001, pasqcoinSettings.pricePerCoin);
                  const mins = Math.floor((pkgPasq * pasqcoinSettings.secondsPerCoin) / 60);
                  return (
                    <button
                      key={pkg.amount}
                      type="button"
                      onClick={() => {
                        setIsCustom(false);
                        setSelectedAmount(pkg.amount);
                      }}
                      className={`relative flex flex-col p-3.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'border-[#22D3EE] bg-[#22D3EE]/10 shadow-[0_0_15px_rgba(34,211,238,0.2)]'
                          : 'border-[#1E293B] bg-[#0A0C10] hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-1">
                        <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-[#1E293B] text-slate-300">
                          {pkg.tag}
                        </span>
                        {isSelected && <span className="text-xs text-[#22D3EE] font-bold">✓</span>}
                      </div>
                      <div className="text-xl font-black text-white">
                        R$ {pkg.amount.toFixed(2).replace('.', ',')}
                      </div>
                      <div className="text-xs text-emerald-400 font-mono mt-1 font-semibold">
                        ~{pkgPasq.toFixed(2)} PASQ • {mins.toLocaleString()} min
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {pkg.label}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Opção de Valor Personalizado */}
              <div className="pt-1">
                <div
                  onClick={() => setIsCustom(true)}
                  className={`p-3 rounded-xl border transition ${
                    isCustom
                      ? 'border-[#22D3EE] bg-[#22D3EE]/10'
                      : 'border-[#1E293B] bg-[#0A0C10] hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-white">
                      Ou digite um valor personalizado (a partir de R$ 5,00):
                    </span>
                    {isCustom && <span className="text-xs text-[#22D3EE] font-bold">✓ Selecionado</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-400">R$</span>
                    <input
                      type="number"
                      step="1"
                      min={tariffSettings.minRechargeAmount}
                      placeholder="Ex: 35.00"
                      value={customAmount}
                      onFocus={() => setIsCustom(true)}
                      onChange={(e) => {
                        setIsCustom(true);
                        setCustomAmount(e.target.value);
                      }}
                      className="flex-1 bg-[#1E293B] border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[#22D3EE]"
                    />
                  </div>
                </div>
              </div>

              {/* Resumo Selecionado */}
              <div className="rounded-xl bg-[#0A0C10] border border-[#1E293B] p-4 flex items-center justify-between">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block">
                    Resumo da Recarga
                  </span>
                  <span className="text-2xl font-black text-white">
                    R$ {finalAmount.toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block">
                    PASQcoin + Tempo Equivalente
                  </span>
                  <span className="text-lg font-black text-emerald-400 font-mono">
                    {estimatedPasqcoins.toFixed(6)} PASQ
                  </span>
                  <span className="block text-[11px] text-slate-400 font-mono mt-0.5">
                    {formatDuration(estimatedSeconds)}
                  </span>
                </div>
              </div>

              {/* Botão de Prosseguir */}
              <button
                type="button"
                disabled={isProcessing}
                onClick={handleGeneratePix}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-emerald-400 px-5 py-3 text-sm font-black text-black shadow-lg shadow-[#22D3EE]/20 hover:brightness-110 active:scale-98 transition disabled:opacity-50 cursor-pointer"
              >
                {isProcessing ? (
                  <RefreshCw className="h-4 w-4 animate-spin text-black" />
                ) : (
                  <>
                    <span>Gerar Pagamento PIX Mercado Pago</span>
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </div>
          )}

          {/* STEP 2: Pagamento PIX e QR Code */}
          {paymentStep === 'payment' && pixData && (
            <div className="space-y-4 text-center">
              <div className="rounded-xl border border-[#22D3EE]/40 bg-[#0A0C10] p-4 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#22D3EE]">
                  Pague com PIX pelo Mercado Pago
                </span>
                <div className="text-2xl font-black text-white">
                  R$ {pixData.amount.toFixed(2).replace('.', ',')}
                </div>
                <p className="text-xs text-slate-400">
                  Após a aprovação serão creditados <strong className="text-emerald-400 font-bold">{pixData.pasqcoins.toFixed(6)} PASQ</strong>, equivalentes a <strong className="text-[#22D3EE]">{formatDuration(pixData.secondsGranted)}</strong> de uso tarifado.
                </p>
                <div className={`rounded-lg px-3 py-2 text-[11px] font-bold ${pixData.sandbox ? 'border border-amber-500/40 bg-amber-500/10 text-amber-300' : 'border border-emerald-500/40 bg-emerald-500/10 text-emerald-300'}`}>
                  {pixData.sandbox
                    ? 'AMBIENTE DE TESTE: este PIX é sandbox e não deve ser pago por um aplicativo bancário real.'
                    : 'AMBIENTE DE PRODUÇÃO: QR Code e Copia e Cola emitidos diretamente pelo Mercado Pago.'}
                </div>

                {/* QR Code */}
                <div className="flex justify-center my-3">
                  <div className="p-3 bg-white rounded-xl shadow-lg inline-block border-2 border-[#22D3EE]">
                    {pixData.qrCodeBase64 ? (
                      <img
                        src={pixData.qrCodeBase64}
                        alt="QR Code PIX Mercado Pago"
                        className="w-48 h-48 object-contain"
                      />
                    ) : (
                      <div className="w-48 h-48 flex flex-col items-center justify-center text-slate-800 p-2">
                        <QrCode className="h-28 w-28 text-slate-900 mb-2" />
                        <span className="text-[11px] font-mono font-bold">PIX MERCADO PAGO</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Código Pix Copia e Cola */}
                <div className="space-y-1.5 text-left">
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Código Pix Copia e Cola:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      readOnly
                      value={pixData.qrCodeText}
                      className="flex-1 bg-[#1E293B] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-300 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleCopyPix}
                      className="flex items-center gap-1.5 rounded-lg bg-[#22D3EE] px-3 py-2 text-xs font-bold text-black hover:bg-[#22D3EE]/90 transition"
                    >
                      {copiedPix ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      <span>{copiedPix ? 'Copiado!' : 'Copiar'}</span>
                    </button>
                  </div>
                </div>
                {pixData.ticketUrl && (
                  <a
                    href={pixData.ticketUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center rounded-lg border border-[#22D3EE]/40 px-3 py-2 text-xs font-bold text-[#22D3EE] hover:bg-[#22D3EE]/10"
                  >
                    Abrir instruções do PIX no Mercado Pago
                  </a>
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentStep('select')}
                  className="flex-1 rounded-xl border border-[#1E293B] bg-[#0A0C10] px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#1E293B] transition"
                >
                  Voltar e Escolher Outro Valor
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmPayment}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-2.5 text-xs font-black text-black shadow-lg shadow-emerald-400/20 hover:bg-emerald-300 transition"
                >
                  {isProcessing ? (
                    <RefreshCw className="h-4 w-4 animate-spin text-black" />
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Verificar Pagamento no Mercado Pago</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Confirmação de Sucesso */}
          {paymentStep === 'confirmed' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto text-emerald-400 animate-bounce">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-black text-white">
                Compra de PASQcoin Confirmada!
              </h3>
              <p className="text-sm text-slate-300 max-w-md mx-auto">
                {purchaseStatusMessage || `Pagamento aprovado. ${pixData?.pasqcoins.toFixed(6)} PASQcoin foram adicionados à sua carteira Chamasso.`}
              </p>
              <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 p-3 text-xs text-amber-300 flex items-center justify-center gap-2">
                <Clock className="h-4 w-4 shrink-0" />
                <span>Saldo PASQcoin disponível para consumo por tempo. O contador desconta frações de PASQ conforme os segundos utilizados.</span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-8 py-2.5 text-xs font-black text-black hover:brightness-110 transition"
              >
                Continuar para o Bate-Papo
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
