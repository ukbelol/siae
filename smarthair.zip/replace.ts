import fs from 'fs';
import path from 'path';

function replaceInFile(filePath: string) {
  let content = fs.readFileSync(filePath, 'utf-8');
  
  // replace stone with slate
  content = content.replace(/stone/g, 'slate');
  
  // replace emerald with cyan
  content = content.replace(/emerald/g, 'cyan');

  // Let's also sprinkle teal for the "verde água" feel
  // for instance, background colors or text
  // Let's replace cyan-800 and 900 with teal
  content = content.replace(/cyan-900/g, 'teal-900');
  content = content.replace(/cyan-800/g, 'teal-800');
  content = content.replace(/cyan-950/g, 'teal-950');

  // and some hover states to give a dynamic cyan/teal interaction
  content = content.replace(/hover:bg-cyan-700/g, 'hover:bg-teal-600');
  content = content.replace(/hover:bg-cyan-800/g, 'hover:bg-teal-700');
  
  fs.writeFileSync(filePath, content, 'utf-8');
}

function walkDir(dir: string) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walkDir(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      replaceInFile(fullPath);
    }
  }
}

walkDir('./src');
console.log('Palette substitution completed!');
