const fs = require('fs');

let t = fs.readFileSync('src/api/index.ts', 'utf8');

// Fix info.insertId
t = t.replace(/info\.insertId/g, "(info as any).insertId");

// Fix stmtCommand vs stmt
t = t.replace(/stmtCommand/g, "stmt");

// TS2554: src/api/index.ts(239,154) Expected 1 arguments, but got 2.
// Wait, db.query in 239. Let's see later.

// TS1308 src/api/index.ts(1143,28) 
t = t.replace(/\} catch\(e\) \{ await conn\.rollback\(\); throw e; \} finally \{ conn\.release\(\); \} \};/g, "});");
// The transaction block is fine, but maybe there is `await` outside async function?
t = t.replace(/router\.post\('\/system-settings\/backup\/run', \(req, res\) => \{/g, "router.post('/system-settings/backup/run', async (req, res) => {"); // if not async

fs.writeFileSync('src/api/index.ts', t);

let b = fs.readFileSync('src/lib/backup.ts', 'utf8');
b = b.replace(/export function runManualBackup/g, "export async function runManualBackup");
fs.writeFileSync('src/lib/backup.ts', b);
