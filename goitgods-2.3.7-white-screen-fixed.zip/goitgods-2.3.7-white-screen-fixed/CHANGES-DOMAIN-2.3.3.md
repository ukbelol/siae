# GOITGODS 2.3.3 — alteração de domínio

Domínio oficial alterado de `goitgods.ukbelol.space` para `goitgods.pasquared.space` em todo o pacote.

Arquivos atualizados automaticamente: README.md, repair-white-screen.sh, CHANGES-SSL-2.3.1.md, install-gods.sh.

Foi incluído `migrate-domain-to-pasquared.sh` para migrar uma instalação existente, atualizar o VirtualHost Apache e emitir um novo certificado Let's Encrypt para `goitgods.pasquared.space`.
