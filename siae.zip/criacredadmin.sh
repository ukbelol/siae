#!/bin/bash
echo "Apagando as credenciais do super admin e criando novas..."

node -e "
import('node:fs').then(fs => {
  const file = 'src/lib/db.ts';
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/'21490905@Siae-roger-577'/g, \"'21490905@Siae-577'\");
  fs.writeFileSync(file, content);
  console.log('Credenciais atualizadas para admin@siae.space e a nova senha 21490905@Siae-577 no código de inicialização!');
});
"

echo "As novas credenciais (21490905@Siae-577) foram injetadas no banco de dados na inicialização do servidor."
echo "Irei reiniciar o servidor de desenvolvimento para aplicar as alterações."
