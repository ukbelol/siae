import './index.css';

declare global {
  interface Window {
    __GOITGODS_BOOTSTRAPPED__?: boolean;
    GOITGODS_BOOT_STAGE?: (stage: string) => void;
    GOITGODS_BOOT_OK?: () => void;
    GOITGODS_BOOT_FAIL?: (error: unknown) => void;
  }
}

async function boot() {
  const rootElement = document.getElementById('root');
  if (!rootElement) throw new Error('Elemento #root não encontrado.');

  // Importações dinâmicas são intencionais: se App ou uma dependência falhar durante
  // avaliação, o bootstrap já está ativo e mostra o erro real em vez de tela preta.
  window.GOITGODS_BOOT_STAGE?.('Carregando React…');
  const [{ createElement }, { createRoot }, appModule, boundaryModule] = await Promise.all([
    import('react'),
    import('react-dom/client'),
    import('./App.tsx'),
    import('./components/AppErrorBoundary'),
  ]);

  window.GOITGODS_BOOT_STAGE?.('Montando GOITGODS…');
  const App = appModule.default;
  const AppErrorBoundary = boundaryModule.AppErrorBoundary;
  const root = createRoot(rootElement);
  root.render(createElement(AppErrorBoundary, null, createElement(App)));

  // Dá ao React dois frames para efetivar o primeiro commit.
  requestAnimationFrame(() => requestAnimationFrame(() => {
    if (rootElement.childElementCount === 0) {
      window.GOITGODS_BOOT_FAIL?.(new Error('React foi carregado, mas #root permaneceu vazio após o primeiro commit.'));
      return;
    }
    window.GOITGODS_BOOT_OK?.();
  }));
}

boot().catch((error) => {
  console.error('[GOITGODS] Falha de bootstrap:', error);
  window.GOITGODS_BOOT_FAIL?.(error);
});
