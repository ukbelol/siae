import React from 'react';
import { EbookBlueprint } from '../types';
import { BookOpen, CheckCircle, X, Sparkles, Layers, ShieldCheck } from 'lucide-react';

interface EbookBlueprintModalProps {
  blueprint: EbookBlueprint;
  isOpen: boolean;
  onClose: () => void;
  onConfirmGenerate: () => void;
  isGenerating: boolean;
}

export const EbookBlueprintModal: React.FC<EbookBlueprintModalProps> = ({
  blueprint,
  isOpen,
  onClose,
  onConfirmGenerate,
  isGenerating,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#0F0F0F] border-2 border-[#FF3E00] max-w-3xl w-full p-6 text-[#E0E0E0] shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#222222] pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-[#111111] text-[#FF3E00] border border-[#FF3E00]">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white tracking-tight uppercase">
                Blueprint do E-Book Personalizado
              </h3>
              <p className="text-xs text-[#888888] font-mono">
                Aprovação da estrutura, metadados e plano de capítulos antes da geração integral
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#888888] hover:text-white hover:bg-[#111111] transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Blueprint Summary Info */}
        <div className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-3 text-xs font-mono">
          <div>
            <h4 className="text-sm font-bold text-[#FF3E00] uppercase tracking-wider">{blueprint.title}</h4>
            <p className="text-[#CCCCCC]">{blueprint.subtitle}</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#222222] text-[10px]">
            <div>
              <span className="text-[#888888] block">Estilo:</span>
              <span className="font-bold text-white capitalize">{blueprint.ebookDNA.style}</span>
            </div>
            <div>
              <span className="text-[#888888] block">Profundidade:</span>
              <span className="font-bold text-white capitalize">{blueprint.ebookDNA.depth}</span>
            </div>
            <div>
              <span className="text-[#888888] block">Capítulos:</span>
              <span className="font-bold text-white">{blueprint.chapterPlan.length}</span>
            </div>
            <div>
              <span className="text-[#888888] block">Formato:</span>
              <span className="font-bold text-[#00FF41]">{blueprint.ebookDNA.outputFormat}</span>
            </div>
          </div>
        </div>

        {/* Chapter Plan List */}
        <div className="space-y-2">
          <h4 className="text-[10px] font-mono font-bold uppercase text-[#888888] tracking-widest flex items-center space-x-2">
            <Layers className="w-4 h-4 text-[#FF3E00]" />
            <span>Plano de Capítulos Proposto ({blueprint.chapterPlan.length})</span>
          </h4>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1 text-xs font-mono">
            {blueprint.chapterPlan.map(ch => (
              <div key={ch.chapter_number} className="bg-[#0A0A0A] p-3 border border-[#222222] space-y-1">
                <span className="font-bold text-white">{ch.title}</span>
                <p className="text-[10px] text-[#888888] font-sans">{ch.objective}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-3 border-t border-[#222222] font-mono">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-[#888888] hover:text-white uppercase transition-all"
          >
            Ajustar Parâmetros
          </button>

          <button
            id="btn-confirm-blueprint-generate"
            onClick={onConfirmGenerate}
            disabled={isGenerating}
            className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black uppercase px-5 py-2.5 transition-all text-xs sm:text-sm flex items-center space-x-2 tracking-wider disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Compilando E-Book...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Aprovar & Gerar E-Book Integral</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
