# Hair Smart Mall - Sistema de Gestão de Salões

Sistema completo para gestão de agendamentos, profissionais e serviços para salões de beleza e barbearias.

## 🚀 Instalação Automatizada (Debian 12)

Para instalar o sistema em um servidor Debian 12 com Apache e SSL, utilize o script de deploy:

```bash
chmod +x deploy.sh
sudo ./deploy.sh
```

O script irá configurar:
- Node.js 20
- Apache2 como Proxy Reverso
- SSL/TLS via Certbot (Let's Encrypt)
- PM2 para gerenciamento do processo Node.js

## 🔐 Acesso Super Admin

Após a instalação, você pode acessar o painel administrativo com as seguintes credenciais:

- **URL:** `https://hair.smartmall577.space/login/superadmin`
- **Usuário:** `roger577@smartmall577.space`
- **Senha:** `21490905@Hair-RGS`

## 🛠️ Tecnologias Utilizadas

- **Frontend:** React, Vite, Tailwind CSS
- **Backend:** Node.js, Express
- **Banco de Dados:** SQLite
- **Pagamentos:** Mercado Pago (Split de Pagamentos)

## 📧 Suporte e Segurança

Email de Segurança: `rogeriogomes11@gmail.com`
Domínio: `hair.smartmall577.space`

## 💼 Regras de Negócio

O modelo de negócio do **Hair Smart Mall** foi desenhado para ser um Hub completo e sistema colaborativo para o mercado de beleza e estética (SaaS + Marketplace). As principais regras operacionais são:

1. **Perfis de Acesso:**
   - **Super Admin:** Dono ou gestores da plataforma (Hair Smart Mall). Responsáveis pela gestão de todos os salões cadastrados, controle de planos de assinatura e fluxo financeiro geral (taxas de plataforma).
   - **Dono do Salão (Admin):** Proprietário do estabelecimento parceiro. Gerencia sua equipe, serviços, agenda, define a % de comissão de cada profissional e acompanha os relatórios de faturamento do seu estabelecimento.
   - **Profissional (Barbeiro/Cabeleireiro/Esteticista):** Especialista que atende os clientes. Possui agenda atrelada ao seu nome e recebe comissões automáticas diretamente em sua conta de recebimento para cada serviço que executar.
   - **Cliente Externo:** Consumidor final e usuário. Realiza acessos através das páginas dos salões, faz agendamentos, escolhe o profissional e realiza pagamentos integrados.

2. **Fluxo Principal (Automação de Agendamentos):**
   - Os clientes reservam horários 24/7 com base na disponibilidade real e combinada das agendas exclusivas de cada profissional de um salão específico.

## 📅 Regras e Lógica de Agendamentos

A lógica de agendamento foi desenvolvida para otimizar o tempo dos profissionais e reduzir ausências (no-shows), baseada nas seguintes diretrizes:

### 1. Disponibilidade Inteligente e Prevenção de Conflitos
- O sistema calcula a disponibilidade cruzando a **agenda de funcionamento do salão** com a **escala individual de cada profissional**.
- A grade de horários apresentada ao cliente leva em conta o tempo de duração exato do(s) serviço(s) selecionado(s).
- O sistema bloqueia automaticamente janelas de horário sobrepostas, garantindo que um profissional nunca seja agendado para dois clientes simultaneamente.

### 2. Confirmação mediante Antecipação (Sinal de Reserva)
- Para confirmar a reserva do horário, o cliente deve realizar o pagamento de um **sinal/taxa de agendamento** (ex: 15% do valor do serviço) por meio da integração de pagamentos.
- Assim que o pagamento do sinal é aprovado, o agendamento avança do status *Pendente* para *Confirmado*, bloqueando definitivamente a agenda do profissional para aquele horário.
- O valor restante é acertado posteriormente pelo cliente.

### 3. Associação Cliente x Profissional
- Durante o agendamento, o cliente tem a liberdade de selecionar o seu profissional de preferência (barbeiro, cabeleireiro, manicure, etc).
- As faixas de horário são exibidas **exclusivamente com base na disponibilidade do profissional selecionado**.

### 4. Ciclo de Vida do Agendamento (Status)
Os agendamentos seguem um fluxo transparente de transição de status:
- **Pendente:** O horário foi pré-reservado, mas o cliente ainda não concluiu o pagamento do sinal no check-out.
- **Confirmado:** O pagamento foi compensado pelo gateway e o horário está 100% garantido para o cliente.
- **Concluído:** O cliente compareceu, o serviço foi executado pelo salão e finalizado no sistema.
- **Cancelado/No-show:** O agendamento foi revogado antes de acontecer ou o cliente faltou ser comparecer.

### 5. Política de Cancelamento e Reembolso
- Dependendo do acordo e SLA configurado, caso o cliente desista do serviço com uma antecedência mínima combinada, as regras de split efetuam o reembolso. 
- Em caso de cancelamento tardio ou ausência sem justificativa, o valor do sinal de reserva pago atua como compensação financeira pelas horas ociosas geradas para o profissional e para a cadeira do salão.

## 💰 Regras de Repasse de Verbas e Split de Pagamentos (Mercado Pago)

O sistema utiliza a arquitetura de Marketplace e o recurso de **Split de Pagamentos (Divisão automática de pagamentos)** do **Mercado Pago** para automatizar toda a cadeia logística financeira, mitigando a necessidade de repasses manuais e evitando bitributação para as empresas de beleza.

### 1. Dinâmica do Split Integrado
Assim que o cliente paga um agendamento pela plataforma (ex: via Pix ou Cartão de Crédito), o montante principal da transação sofre "Split". O dinheiro é imediatamente dividido e enviado às contas do Mercado Pago cadastradas previamente para cada envolvido na cadeia. 

### 2. Divisão de Valores (Fluxo e Ordem de Retenções)
A divisão sobre o valor total do serviço pago segue esta arquitetura padrão:
1. **Custos Adquirente (Mercado Pago):** São descontadas primeiro as taxas transacionais do meio de pagamento (Pix, parcelamentos no cartão, etc), conforme acordo com o Mercado Pago.
2. **Taxa da Plataforma (Hair Smart Mall):** Percentual predefinido + tarifa fixa que a plataforma retém sobre a transação (conhecida como *Application Fee*) a título de manutenção do sistema e fornecimento de infraestrutura.
3. **Comissão do Profissional:** Percentual definido pelo Dono do Salão (ex: 40%, 50%, etc). O cálculo da comissão do profissional é aplicado sobre o montante da transação e este valor cai direto na subconta individual do Mercado Pago associada ao profissional. O Salão pode definir se sua comissão deduz previamente as taxas do cartão ou não.
4. **Receita Líquida do Salão:** Após deduzidas as taxas do Gateway, o *Platform Fee* e a comissão do prestador de serviço (Profissional), o montante restante resultante é liquidado e depositado diretamente na conta Mercado Pago titular do Dono do Salão.

### 3. Vantagens Fiscais e Compliance
- **Fim da Bitributação:** Cada ente recebedor da cadeia (Plataforma, Salão e Profissional associado) emite nota fiscal e declara tributos **apenas** sobre a parte que de fato teve entrada legal na sua carteira digital, evitando que o CNPJ do Salão seja tributado pelo valor integral de transações onde metade foi da comissão de seu funcionário.
- **Trânsito Financeiro Centralizado:** O fluxo "Marketplace", perante as regras do Banco Central, isenta o Hair Smart Mall de atuar como instituição de pagamentos de terceiros ou acumulo de saldo - o ecossistema Mercado Pago faz a compensação.
- **Cancelamentos ou Estornos:** No evento de chargebacks ou reembolsos de reservas canceladas, os valores são subtraídos simultânea e proporcionalmente de todos os recebedores automáticos no ato.