import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Scissors, Calendar, LogOut, Trash2, Settings, DollarSign, Save, ExternalLink, CheckCircle, Database } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import Logo from '../components/Logo';

export default function SuperAdminDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({ users: 0, salons: 0, appointments: 0, revenue: 0 });
  const [users, setUsers] = useState<any[]>([]);
  const [salons, setSalons] = useState<any[]>([]);
  
  // Platform Fee state
  const [feeData, setFeeData] = useState<any[]>([]);
  const [filterBrazilRegion, setFilterBrazilRegion] = useState('all');
  const [filterState, setFilterState] = useState('all');
  const [filterStateRegion, setFilterStateRegion] = useState('all');
  const [filterCity, setFilterCity] = useState('all');
  
  // Settings state
  const [mpSettings, setMpSettings] = useState({
    mp_env: 'test',
    mp_test_public_key: '',
    mp_test_access_token: '',
    mp_test_client_id: '',
    mp_test_client_secret: '',
    mp_prod_public_key: '',
    mp_prod_access_token: '',
    mp_prod_client_id: '',
    mp_prod_client_secret: ''
  });
  
  const [backupSettings, setBackupSettings] = useState({
    backup_smb_server: '',
    backup_smb_user: '',
    backup_smb_password: '',
    backup_frequency: 'daily',
    backup_time: '02:00'
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isConnectingHub, setIsConnectingHub] = useState(false);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/login/superadmin');
      return;
    }
    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== 'superadmin') {
      navigate('/login/superadmin');
      return;
    }
    setUser(parsedUser);
    fetchData();

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'MP_AUTH_SUCCESS') {
        showToast('Conta Marketplace conectada com sucesso!');
        fetchData();
      } else if (event.data?.type === 'MP_AUTH_ERROR') {
        showToast(event.data.message || 'Erro ao conectar conta Marketplace.', 'error');
      }
    };
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  const fetchData = async () => {
    const [statsRes, usersRes, salonsRes, settingsRes, feeRes] = await Promise.all([
      fetch('/api/admin/stats'),
      fetch('/api/admin/users'),
      fetch('/api/admin/salons'),
      fetch('/api/admin/settings'),
      fetch('/api/admin/fee-stats')
    ]);
    
    if (statsRes.ok) setStats(await statsRes.json());
    if (usersRes.ok) setUsers(await usersRes.json());
    if (salonsRes.ok) setSalons(await salonsRes.json());
    if (settingsRes.ok) {
      const settingsData = await settingsRes.json();
      setMpSettings(prev => ({ ...prev, ...settingsData }));
      setBackupSettings(prev => ({ ...prev, ...settingsData }));
    }
    if (feeRes.ok) {
      setFeeData(await feeRes.json());
    }
  };

  const saveSettings = async () => {
    setIsSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...mpSettings, ...backupSettings })
      });
      const data = await res.json();
      if (res.ok) {
        showToast('Configurações salvas com sucesso!');
      } else {
        showToast(data.message || 'Erro ao salvar configurações.', 'error');
      }
    } catch (error) {
      showToast('Erro de conexão ao salvar configurações.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const deleteUser = async (id: number) => {
    const res = await fetch(`/api/admin/users/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Usuário excluído com sucesso');
      fetchData();
    } else {
      showToast('Erro ao excluir usuário', 'error');
    }
  };

  const deleteSalon = async (id: number) => {
    const res = await fetch(`/api/admin/salons/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Salão excluído com sucesso');
      fetchData();
    } else {
      showToast('Erro ao excluir salão', 'error');
    }
  };

  const logout = () => {
    localStorage.removeItem('user');
    navigate('/login/superadmin');
  };

  const handleConnectHub = async () => {
    setIsConnectingHub(true);
    try {
      const res = await fetch('/api/auth/mercadopago/platform/url');
      const data = await res.json();
      if (res.ok && data.url) {
        window.open(data.url, 'mp_auth', 'width=600,height=700');
      } else {
        showToast(data.message || 'Erro ao iniciar conexão do hub.', 'error');
      }
    } catch (error) {
      showToast('Erro de conexão ao iniciar hub.', 'error');
    } finally {
      setIsConnectingHub(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {toast && (
        <div className={`fixed top-4 right-4 px-6 py-3 rounded-xl shadow-lg font-medium z-50 transition-all ${
          toast.type === 'success' ? 'bg-cyan-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.message}
        </div>
      )}
      <aside className="w-64 bg-slate-900 text-white flex flex-col">
        <div className="p-6 text-2xl font-bold border-b border-slate-800 flex items-center gap-2">
          <Logo className="w-8 h-8" />
          Hair Smart Mall Admin
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'overview' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}
          >
            <Calendar className="w-5 h-5" /> Visão Geral
          </button>
          <button 
            onClick={() => setActiveTab('users')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'users' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}
          >
            <Users className="w-5 h-5" /> Gerenciar Clientes
          </button>
          <button 
            onClick={() => setActiveTab('salons')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'salons' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}
          >
            <Scissors className="w-5 h-5" /> Gerenciar Salões
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'settings' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}
          >
            <Settings className="w-5 h-5" /> Config API MP
          </button>
          <button 
            onClick={() => setActiveTab('backup')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'backup' ? 'bg-slate-800' : 'hover:bg-slate-800'}`}
          >
            <Database className="w-5 h-5" /> Backup do Sistema
          </button>
          <button 
            onClick={() => setActiveTab('fee_monitoring')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'fee_monitoring' ? 'bg-slate-800 text-white' : 'hover:bg-slate-800 text-slate-300'}`}
          >
            <DollarSign className="w-5 h-5 text-orange-400" /> Fee da Plataforma (5%)
          </button>
        </nav>
        <div className="p-4 border-t border-slate-800">
          <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-slate-800 transition-colors text-slate-300">
            <LogOut className="w-5 h-5" /> Sair
          </button>
        </div>
      </aside>

      <main className="flex-1 p-8 overflow-y-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Painel do Super Administrador</h1>
          <p className="text-slate-500">Bem-vindo, {user.name}</p>
        </header>

        {activeTab === 'overview' && (
          <>
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
                <div className="w-12 h-12 bg-cyan-100 text-cyan-700 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Total de Usuários</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.users}</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center">
                  <Scissors className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Salões Cadastrados</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.salons}</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Agendamentos</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.appointments}</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Arrecadação (5%)</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.revenue)}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-xl font-bold mb-4">Ações Rápidas</h2>
              <p className="text-slate-600 mb-4">
                O painel completo de administração permite gerenciar todos os salões, clientes e agendamentos da plataforma.
                Para acessar os dados detalhados, utilize as ferramentas de exportação ou os relatórios avançados.
              </p>
              <div className="flex gap-4">
                <button className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800">
                  Exportar Relatório Geral
                </button>
                <button className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50">
                  Gerenciar Taxas da Plataforma
                </button>
              </div>
            </div>
          </>
        )}

        {activeTab === 'users' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold mb-4">Gerenciar Usuários</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-sm">
                    <th className="pb-3 font-medium">ID</th>
                    <th className="pb-3 font-medium">Nome</th>
                    <th className="pb-3 font-medium">Email</th>
                    <th className="pb-3 font-medium">Tipo</th>
                    <th className="pb-3 font-medium">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u.id} className="border-b border-slate-100 last:border-0">
                      <td className="py-3 text-slate-500">#{u.id}</td>
                      <td className="py-3 font-medium">{u.name}</td>
                      <td className="py-3 text-slate-500">{u.email}</td>
                      <td className="py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          u.role === 'superadmin' ? 'bg-purple-100 text-purple-700' :
                          u.role === 'salon_admin' ? 'bg-blue-100 text-blue-700' :
                          'bg-cyan-100 text-cyan-700'
                        }`}>
                          {u.role === 'superadmin' ? 'Admin' : u.role === 'salon_admin' ? 'Salão' : 'Cliente'}
                        </span>
                      </td>
                      <td className="py-3">
                        {u.role !== 'superadmin' && (
                          <button onClick={() => deleteUser(u.id)} className="text-red-500 hover:text-red-700 p-1">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {users.length === 0 && (
                    <tr><td colSpan={5} className="py-4 text-center text-slate-500">Nenhum usuário encontrado.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'salons' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold mb-4">Gerenciar Salões</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-sm">
                    <th className="pb-3 font-medium">ID</th>
                    <th className="pb-3 font-medium">Nome do Salão</th>
                    <th className="pb-3 font-medium">CNPJ</th>
                    <th className="pb-3 font-medium">Administrador</th>
                    <th className="pb-3 font-medium">Email Admin</th>
                    <th className="pb-3 font-medium">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {salons.map(s => (
                    <tr key={s.id} className="border-b border-slate-100 last:border-0">
                      <td className="py-3 text-slate-500">#{s.id}</td>
                      <td className="py-3 font-medium">{s.name}</td>
                      <td className="py-3 text-slate-500">{s.cnpj || '-'}</td>
                      <td className="py-3">{s.admin_name}</td>
                      <td className="py-3 text-slate-500">{s.admin_email}</td>
                      <td className="py-3">
                        <button onClick={() => deleteSalon(s.id)} className="text-red-500 hover:text-red-700 p-1">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {salons.length === 0 && (
                    <tr><td colSpan={6} className="py-4 text-center text-slate-500">Nenhum salão encontrado.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 max-w-3xl">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Settings className="w-6 h-6 text-slate-500" />
              Configurações do Mercado Pago
            </h2>
            
            <div className="space-y-6">
              <div className="bg-cyan-50 border border-cyan-200 p-6 rounded-2xl mb-8">
                <h3 className="text-lg font-bold text-teal-900 mb-2 flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Ativação do Hub de Pagamentos (Marketplace)
                </h3>
                <div className="text-teal-800 text-sm mb-6 space-y-4">
                  <p>
                    Para que o sistema de split funcione, você precisa configurar e conectar a conta master da plataforma. 
                    Esta conta receberá as taxas de serviço (5%) e gerenciará as transações dos salões.
                  </p>
                  
                  <div className="bg-white p-4 rounded-xl border border-cyan-100 shadow-sm">
                    <h4 className="font-bold mb-2">Passo a Passo para Configuração:</h4>
                    <ol className="list-decimal list-inside space-y-2">
                      <li>Acesse o <a href="https://www.mercadopago.com.br/developers/panel/applications" target="_blank" rel="noopener noreferrer" className="text-cyan-600 font-bold hover:underline">Painel de Desenvolvedor do Mercado Pago</a> e faça login com a conta Master.</li>
                      <li>Crie uma nova aplicação e preencha os dados solicitados.</li>
                      <li>Na seção de <strong>Credenciais</strong>, copie a <strong>Public Key</strong> e o <strong>Access Token</strong> (tanto de Teste quanto de Produção) e preencha nos campos abaixo.</li>
                      <li>Na seção de <strong>Credenciais &gt; Credenciais de Produção</strong>, copie também o <strong>Client ID</strong> e o <strong>Client Secret</strong> e preencha abaixo.</li>
                      <li>Vá em <strong>Configurações &gt; Autenticação (OAuth)</strong> e adicione a seguinte URL de Redirecionamento (Callback):
                        <div className="bg-slate-100 p-2 rounded mt-1 font-mono text-xs text-slate-700 break-all select-all">
                          {window.location.origin}/api/auth/mercadopago/callback
                        </div>
                      </li>
                      <li>Salve as configurações nesta tela clicando no botão <strong>Salvar Configurações</strong> no final da página.</li>
                      <li>Por fim, clique no botão <strong>Conectar Conta Marketplace</strong> abaixo para autorizar a aplicação.</li>
                    </ol>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <button
                    onClick={handleConnectHub}
                    disabled={isConnectingHub}
                    className="flex items-center gap-2 px-6 py-3 bg-cyan-600 text-white rounded-xl font-bold hover:bg-teal-600 transition-colors disabled:opacity-50 shadow-md"
                  >
                    <ExternalLink className="w-5 h-5" />
                    {isConnectingHub ? 'Iniciando...' : 'Conectar Conta Marketplace'}
                  </button>
                  {mpSettings.mp_test_user_id || mpSettings.mp_prod_user_id ? (
                    <span className="text-cyan-600 text-sm font-medium flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" /> Hub Ativo ({mpSettings.mp_env === 'prod' ? 'Produção' : 'Teste'})
                    </span>
                  ) : (
                    <span className="text-amber-600 text-sm font-medium">Hub não configurado</span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Ambiente</label>
                <select
                  value={mpSettings.mp_env}
                  onChange={e => setMpSettings({...mpSettings, mp_env: e.target.value})}
                  className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                >
                  <option value="test">Teste (Sandbox)</option>
                  <option value="prod">Produção</option>
                </select>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                <h3 className="font-medium text-slate-900">Credenciais de Teste</h3>
                <p className="text-xs text-slate-500 mb-4">Utilize estas credenciais para realizar testes sem movimentar dinheiro real.</p>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Public Key (Teste)</label>
                  <p className="text-xs text-slate-500 mb-1">Chave pública usada no frontend para gerar tokens de cartão.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_test_public_key}
                    onChange={e => setMpSettings({...mpSettings, mp_test_public_key: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="TEST-..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Access Token (Teste)</label>
                  <p className="text-xs text-slate-500 mb-1">Token de acesso privado usado no backend para criar pagamentos.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_test_access_token}
                    onChange={e => setMpSettings({...mpSettings, mp_test_access_token: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="TEST-..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">App ID / Client ID (Teste)</label>
                  <p className="text-xs text-slate-500 mb-1">Credencial OAuth: Identificador da sua aplicação no Mercado Pago, necessário para autenticar a conta do salão no Split.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_test_client_id}
                    onChange={e => setMpSettings({...mpSettings, mp_test_client_id: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="App ID / Client ID..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Client Secret (Teste)</label>
                  <p className="text-xs text-slate-500 mb-1">Credencial OAuth: Chave secreta da sua aplicação para autorização do salão.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_test_client_secret}
                    onChange={e => setMpSettings({...mpSettings, mp_test_client_secret: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Client Secret..."
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                <h3 className="font-medium text-slate-900">Credenciais de Produção</h3>
                <p className="text-xs text-slate-500 mb-4">Utilize estas credenciais quando o sistema estiver pronto para receber pagamentos reais.</p>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Public Key (Produção)</label>
                  <p className="text-xs text-slate-500 mb-1">Chave pública usada no frontend para gerar tokens de cartão.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_prod_public_key}
                    onChange={e => setMpSettings({...mpSettings, mp_prod_public_key: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="APP_USR-..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Access Token (Produção)</label>
                  <p className="text-xs text-slate-500 mb-1">Token de acesso privado usado no backend para criar pagamentos.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_prod_access_token}
                    onChange={e => setMpSettings({...mpSettings, mp_prod_access_token: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="APP_USR-..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">App ID / Client ID (Produção)</label>
                  <p className="text-xs text-slate-500 mb-1">Credencial OAuth: Identificador da sua aplicação no Mercado Pago, necessário para autenticar a conta do salão no Split.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_prod_client_id}
                    onChange={e => setMpSettings({...mpSettings, mp_prod_client_id: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="App ID / Client ID..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Client Secret (Produção)</label>
                  <p className="text-xs text-slate-500 mb-1">Credencial OAuth: Chave secreta da sua aplicação para autorização do salão.</p>
                  <input
                    type="text"
                    value={mpSettings.mp_prod_client_secret}
                    onChange={e => setMpSettings({...mpSettings, mp_prod_client_secret: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Client Secret..."
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200">
                <button
                  onClick={saveSettings}
                  disabled={isSaving}
                  className="flex items-center gap-2 px-6 py-3 bg-cyan-600 text-white rounded-xl font-medium hover:bg-teal-600 transition-colors disabled:opacity-50"
                >
                  <Save className="w-5 h-5" />
                  {isSaving ? 'Salvando...' : 'Salvar Configurações'}
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'backup' && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 max-w-3xl">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Database className="w-6 h-6 text-slate-500" />
              Backup do Sistema
            </h2>
            
            <div className="space-y-6">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <h3 className="text-lg font-medium text-slate-800 mb-4">Servidor de Armazenamento (SMB)</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Servidor SMB (IP ou Domínio)</label>
                    <input 
                      type="text" 
                      placeholder="Ex: 192.168.1.100 ou backup.empresa.com"
                      value={backupSettings.backup_smb_server} 
                      onChange={e => setBackupSettings({...backupSettings, backup_smb_server: e.target.value})}
                      className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Usuário do Compartilhamento</label>
                    <input 
                      type="text" 
                      value={backupSettings.backup_smb_user} 
                      onChange={e => setBackupSettings({...backupSettings, backup_smb_user: e.target.value})}
                      className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Senha do Compartilhamento</label>
                    <input 
                      type="password" 
                      value={backupSettings.backup_smb_password} 
                      onChange={e => setBackupSettings({...backupSettings, backup_smb_password: e.target.value})}
                      className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <h3 className="text-lg font-medium text-slate-800 mb-4">Configuração de Backup Incremental</h3>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Frequência Automática</label>
                    <select
                      value={backupSettings.backup_frequency}
                      onChange={e => setBackupSettings({...backupSettings, backup_frequency: e.target.value})}
                      className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                    >
                      <option value="daily">Diário</option>
                      <option value="weekly">Semanal</option>
                      <option value="monthly">Mensal</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Horário de Início</label>
                    <input 
                      type="time" 
                      value={backupSettings.backup_time} 
                      onChange={e => setBackupSettings({...backupSettings, backup_time: e.target.value})}
                      className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                    />
                  </div>
                </div>
                <div className="mt-4 p-4 bg-cyan-50 border border-cyan-100 rounded-xl text-sm text-cyan-800">
                  <p className="font-medium mb-1">Sobre a Estrutura de Backup Incremental:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Cópias criadas automaticamente na pasta <strong>/geral</strong> com todos os dados.</li>
                    <li>Cópias separadas por salão nas pastas <strong>/salão_[código]</strong>.</li>
                    <li>Os backups ocorrerão no horário definido, apenas para os dados alterados desde o último backup.</li>
                  </ul>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200">
                <button
                  onClick={saveSettings}
                  disabled={isSaving}
                  className="flex items-center gap-2 px-6 py-3 bg-cyan-600 text-white rounded-xl font-medium hover:bg-teal-600 transition-colors disabled:opacity-50"
                >
                  <Save className="w-5 h-5" />
                  {isSaving ? 'Salvando Configurações...' : 'Salvar Configurações de Backup'}
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'fee_monitoring' && (() => {
          const uniqueRegionsList = Array.from(new Set(feeData.map(d => d.brazil_region))).filter(Boolean);
          const uniqueStatesList = Array.from(new Set(feeData.map(d => d.state))).filter(Boolean);
          const uniqueStateRegionsList = Array.from(new Set(feeData.map(d => d.state_region))).filter(Boolean);
          const uniqueCitiesList = Array.from(new Set(feeData.map(d => d.city))).filter(Boolean);

          const filteredFees = feeData.filter(d => {
            if (filterBrazilRegion !== 'all' && d.brazil_region !== filterBrazilRegion) return false;
            if (filterState !== 'all' && d.state !== filterState) return false;
            if (filterStateRegion !== 'all' && d.state_region !== filterStateRegion) return false;
            if (filterCity !== 'all' && d.city !== filterCity) return false;
            return true;
          });

          const totalFinancialAmount = filteredFees.reduce((acc, d) => acc + d.total_amount, 0);
          const totalPlatformFeesCollected = filteredFees.reduce((acc, d) => acc + d.platform_fee, 0);
          const totalAppointmentsCount = filteredFees.length;

          const pendingAppointments = filteredFees.filter(d => ['confirmed', 'pending_payment', 'pending'].includes(d.status)).length;
          const cancelledAppointments = filteredFees.filter(d => ['cancelled', 'cancelled_expired'].includes(d.status)).length;
          const completedAppointments = filteredFees.filter(d => d.status === 'completed').length;

          const cityStats: { [city: string]: { count: number; total: number; fee: number; pending: number; cancelled: number } } = {};
          filteredFees.forEach(d => {
            if (!cityStats[d.city]) {
              cityStats[d.city] = { count: 0, total: 0, fee: 0, pending: 0, cancelled: 0 };
            }
            cityStats[d.city].count += 1;
            cityStats[d.city].total += d.total_amount;
            cityStats[d.city].fee += d.platform_fee;
            if (['confirmed', 'pending_payment', 'pending'].includes(d.status)) {
              cityStats[d.city].pending += 1;
            } else if (['cancelled', 'cancelled_expired'].includes(d.status)) {
              cityStats[d.city].cancelled += 1;
            }
          });

          let geoLabel = "Regiões do Brasil";
          let geoChartData: any[] = [];
          if (filterBrazilRegion === 'all') {
            geoLabel = "Regiões do Brasil";
            const agg: { [key: string]: number } = {};
            filteredFees.forEach(d => { agg[d.brazil_region] = (agg[d.brazil_region] || 0) + d.platform_fee; });
            geoChartData = Object.entries(agg).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) }));
          } else if (filterState === 'all') {
            geoLabel = "Estados";
            const agg: { [key: string]: number } = {};
            filteredFees.forEach(d => { agg[d.state] = (agg[d.state] || 0) + d.platform_fee; });
            geoChartData = Object.entries(agg).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) }));
          } else if (filterStateRegion === 'all') {
            geoLabel = "Regiões do Estado";
            const agg: { [key: string]: number } = {};
            filteredFees.forEach(d => { agg[d.state_region] = (agg[d.state_region] || 0) + d.platform_fee; });
            geoChartData = Object.entries(agg).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) }));
          } else {
            geoLabel = "Cidades";
            const agg: { [key: string]: number } = {};
            filteredFees.forEach(d => { agg[d.city] = (agg[d.city] || 0) + d.platform_fee; });
            geoChartData = Object.entries(agg).map(([name, value]) => ({ name, value: parseFloat(value.toFixed(2)) }));
          }

          if (geoChartData.length === 0) {
            geoChartData = [{ name: "Sem transações", value: 0 }];
          }

          const statusChartData = [
            { name: "Comparec. Pens.", value: pendingAppointments, color: "#00d2ff" },
            { name: "Cancelados", value: cancelledAppointments, color: "#ff6b00" },
            { name: "Concluídos", value: completedAppointments, color: "#0df5c4" }
          ].filter(item => item.value > 0);

          const COLORS = ['#00d2ff', '#0df5c4', '#ff6b00', '#c084fc', '#2dd4bf', '#fb923c', '#38bdf8'];

          const resetFilters = () => {
            setFilterBrazilRegion('all');
            setFilterState('all');
            setFilterStateRegion('all');
            setFilterCity('all');
          };

          return (
            <div className="space-y-8 animate-fade-in text-slate-800">
              <div className="bg-gradient-to-r from-slate-900 to-slate-950 p-6 rounded-2xl border border-cyan-500/20 shadow-[0_0_30px_rgba(0,210,255,0.05)] relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>
                <div className="absolute bottom-0 left-12 w-64 h-64 bg-teal-500/5 rounded-full blur-3xl pointer-events-none"></div>
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div>
                    <h2 className="text-2xl font-extrabold tracking-tight text-white flex items-center gap-2">
                      <DollarSign className="w-7 h-7 text-cyan-400 quantum-animate-pulse" />
                      Monitoramento de Taxas da Plataforma (5% Fee)
                    </h2>
                    <p className="text-slate-400 text-sm mt-1">
                      Analise fluxos de caixa de split em tempo real mapeados geograficamente em todo o território nacional.
                    </p>
                  </div>
                  <button 
                    onClick={resetFilters}
                    className="px-5 py-2.5 text-xs font-bold uppercase tracking-wider bg-slate-900 text-cyan-300 hover:text-white border border-cyan-500/30 hover:border-cyan-400 rounded-xl transition-all duration-300 pointer-events-auto cursor-pointer"
                  >
                    Resetar Filtros (Todo o Brasil)
                  </button>
                </div>
              </div>

              <div className="grid md:grid-cols-4 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-teal-500"></div>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Arrecadação Fee (5%)</p>
                  <p className="text-3xl font-extrabold text-cyan-600 mt-2">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalPlatformFeesCollected)}
                  </p>
                  <p className="text-slate-400 text-[11px] mt-1">Efetuados via split Mercado Pago</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-orange-500"></div>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Total Transacionado</p>
                  <p className="text-3xl font-extrabold text-slate-900 mt-2">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalFinancialAmount)}
                  </p>
                  <p className="text-slate-400 text-[11px] mt-1">Volume financeiro total (100%)</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-cyan-400"></div>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Pendentes Comparecimento</p>
                  <p className="text-3xl font-extrabold text-cyan-500 mt-2">{pendingAppointments}</p>
                  <p className="text-slate-400 text-[11px] mt-1">Agendamentos ativos em andamento</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-orange-600"></div>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Agendamentos Cancelados</p>
                  <p className="text-3xl font-extrabold text-orange-600 mt-2">{cancelledAppointments}</p>
                  <p className="text-slate-400 text-[11px] mt-1">Cancelados ou expirados no checkout</p>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-800 mb-4 text-sm uppercase tracking-wider">Filtros de Escopo Geográfico</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Região do Brasil</label>
                    <select
                      value={filterBrazilRegion}
                      onChange={e => {
                        setFilterBrazilRegion(e.target.value);
                        setFilterState('all');
                        setFilterStateRegion('all');
                        setFilterCity('all');
                      }}
                      className="w-full p-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-cyan-500 outline-none cursor-pointer"
                    >
                      <option value="all">Todo o Brasil</option>
                      {uniqueRegionsList.map(r => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Estado</label>
                    <select
                      value={filterState}
                      onChange={e => {
                        setFilterState(e.target.value);
                        setFilterStateRegion('all');
                        setFilterCity('all');
                      }}
                      className="w-full p-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-cyan-500 outline-none cursor-pointer"
                    >
                      <option value="all">Todos os Estados</option>
                      {uniqueStatesList.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Região do Estado</label>
                    <select
                      value={filterStateRegion}
                      onChange={e => {
                        setFilterStateRegion(e.target.value);
                        setFilterCity('all');
                      }}
                      className="w-full p-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-cyan-500 outline-none cursor-pointer"
                    >
                      <option value="all">Todas as Regiões</option>
                      {uniqueStateRegionsList.map(sr => (
                        <option key={sr} value={sr}>{sr}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Cidade</label>
                    <select
                      value={filterCity}
                      onChange={e => setFilterCity(e.target.value)}
                      className="w-full p-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-cyan-500 outline-none cursor-pointer"
                    >
                      <option value="all">Todas as Cidades</option>
                      {uniqueCitiesList.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between h-[420px]">
                  <div>
                    <h3 className="font-bold text-slate-800 text-base leading-tight">Desempenho Geográfico (Arrecadação 5%)</h3>
                    <p className="text-slate-400 text-xs mt-1">Divisão de faturamento baseado no agrupamento por: <strong>{geoLabel}</strong></p>
                  </div>
                  <div className="flex-1 min-h-[220px] relative flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={geoChartData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {geoChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value: any) => [`R$ ${parseFloat(value).toFixed(2)}`, "Arrecadação Fee"]}
                        />
                        <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '11px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between h-[420px]">
                  <div>
                    <h3 className="font-bold text-slate-800 text-base leading-tight">Composição dos Agendamentos</h3>
                    <p className="text-slate-400 text-xs mt-1">Percentual correspondente a comparecimentos, pendentes e taxas</p>
                  </div>
                  <div className="flex-1 min-h-[220px] relative flex items-center justify-center">
                    {statusChartData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={statusChartData}
                            cx="50%"
                            cy="50%"
                            innerRadius={0}
                            outerRadius={95}
                            dataKey="value"
                            label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                          >
                            {statusChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => [value, "Quantidade"]} />
                          <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '11px' }} />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="text-center text-slate-400 text-sm">Nenhum agendamento com os filtros atuais</div>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="font-bold text-slate-900 text-lg mb-4 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-cyan-400 rounded-full inline-block"></span>
                  Estatísticas Detalhadas por Cidade
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider">
                        <th className="pb-3 font-bold">Cidade</th>
                        <th className="pb-3 font-bold text-center">Quantidade de Agendamentos</th>
                        <th className="pb-3 font-bold text-center">Pendentes</th>
                        <th className="pb-3 font-bold text-center">Cancelados</th>
                        <th className="pb-3 font-bold text-right">Volume Total (100%)</th>
                        <th className="pb-3 font-bold text-right text-cyan-600">Fee Plataforma (5%)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {Object.entries(cityStats).map(([cityName, data]) => (
                        <tr key={cityName} className="hover:bg-slate-50 transition-colors text-sm">
                          <td className="py-3.5 font-semibold text-slate-900">{cityName || "São Paulo"}</td>
                          <td className="py-3.5 text-center font-bold text-slate-700">{data.count}</td>
                          <td className="py-3.5 text-center font-medium text-cyan-500">{data.pending}</td>
                          <td className="py-3.5 text-center font-medium text-orange-500">{data.cancelled}</td>
                          <td className="py-3.5 text-right font-medium">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.total)}
                          </td>
                          <td className="py-3.5 text-right font-bold text-cyan-600">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.fee)}
                          </td>
                        </tr>
                      ))}
                      {Object.keys(cityStats).length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-400 text-sm">
                            Nenhum dado geográfico de arrecadação encontrado para os filtros atuais.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          );
        })()}
      </main>
    </div>
  );
}
