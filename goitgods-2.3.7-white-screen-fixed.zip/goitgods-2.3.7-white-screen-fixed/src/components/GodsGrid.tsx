import React from 'react';
import { GodWeightInfo } from '../types';
import { GODS_REGISTRY } from '../data/godsData';
import {
  Crown,
  Shield,
  Sun,
  Feather,
  Hammer,
  Skull,
  Swords,
  Waves,
  Sprout,
  Heart,
  Sparkles,
  Hourglass,
  Activity,
  Award,
} from 'lucide-react';

interface GodsGridProps {
  weights?: GodWeightInfo[];
}

const ICON_MAP: Record<string, any> = {
  Crown,
  Shield,
  Sun,
  Feather,
  Hammer,
  Skull,
  Swords,
  Waves,
  Sprout,
  Heart,
  Sparkles,
  Hourglass,
};

export const GodsGrid: React.FC<GodsGridProps> = ({ weights }) => {
  const allGodIds = Object.keys(GODS_REGISTRY) as (keyof typeof GODS_REGISTRY)[];

  const getWeightInfo = (id: string): GodWeightInfo | undefined => {
    return weights?.find(w => w.god_id === id);
  };

  return (
    <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#FF3E00] p-5 sm:p-6 text-[#E0E0E0] space-y-4">
      <div className="flex items-center justify-between border-b border-[#222222] pb-3">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-[#FF3E00]" />
          <h3 className="text-sm sm:text-base font-black text-white tracking-tight uppercase">
            Rede Dinâmica de Especialistas GOITGODS (Rede Olympus)
          </h3>
        </div>
        <span className="text-[10px] px-2.5 py-1 font-mono uppercase bg-[#1A1A1A] text-[#00FF41] font-bold border border-[#333333]">
          12 Agentes Ativos
        </span>
      </div>

      <p className="text-xs text-[#888888] font-mono">
        Cada especialista atua em raciocínio paralelo. O GOITGODS arbitra pesos dinâmicos ($W_g$) e pontuação de desempenho ($GPS$) com limites de segurança (3% min, 35% max).
      </p>

      {/* Gods Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {allGodIds.map(godId => {
          const god = GODS_REGISTRY[godId];
          const info = getWeightInfo(godId);
          const IconComponent = ICON_MAP[god.iconName] || Crown;
          const weightPercent = info ? (info.normalized_weight * 100).toFixed(1) : (god.defaultWeight * 100).toFixed(1);

          return (
            <div
              key={godId}
              id={`god-card-${godId}`}
              className="bg-[#0A0A0A] border border-[#222222] border-l-2 border-l-[#333333] hover:border-l-[#FF3E00] p-3 transition-all flex flex-col justify-between space-y-2 group hover:bg-[#111111]"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-[#151515] border border-[#333333] text-[#FF3E00] group-hover:border-[#FF3E00] transition-all">
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-white uppercase tracking-wider group-hover:text-[#FF3E00] transition-colors">
                      {god.name}
                    </h4>
                    <span className="text-[10px] text-[#666666] font-mono block line-clamp-1">{god.role}</span>
                  </div>
                </div>
              </div>

              {/* Weight & GPS bar */}
              <div className="space-y-1 font-mono">
                <div className="flex justify-between text-[10px] font-bold">
                  <span className="text-[#666666]">Peso ($W_g$)</span>
                  <span className="text-[#FF3E00]">{weightPercent}%</span>
                </div>
                <div className="w-full bg-[#1A1A1A] h-1 overflow-hidden">
                  <div
                    className="bg-[#FF3E00] h-full transition-all duration-500"
                    style={{ width: `${Math.min(100, parseFloat(weightPercent) * 2.8)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[9px] text-[#555555] pt-0.5">
                  <span>Afinidade: {info ? (info.affinity * 100).toFixed(0) : '85'}%</span>
                  <span>GPS: {info ? info.gps.toFixed(2) : '0.92'}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
