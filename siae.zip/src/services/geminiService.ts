import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini API client
// Ensure GEMINI_API_KEY is set in your environment variables
const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  console.warn("GEMINI_API_KEY is not set. Gemini features will be disabled.");
}

const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export async function generateContent(prompt: string) {
  if (!ai) {
    throw new Error("Gemini API is not configured.");
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating content with Gemini:", error);
    throw error;
  }
}
