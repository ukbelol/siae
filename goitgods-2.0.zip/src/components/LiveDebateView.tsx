import React, { useState } from 'react';
import { 
  Crown, 
  Swords, 
  EyeOff, 
  ShieldCheck, 
  AlertTriangle, 
  Scale, 
  Sparkles, 
  Layers, 
  BarChart3, 
  CheckCircle2, 
  XCircle,
  HelpCircle,
  RefreshCw
} from 'lucide-react';
import { GODS_LIST } from '../data/godsData';
import { SearchParametersResult, DecisionState, GodId } from '../types';

interface LiveDebateViewProps {
  searchResult: SearchParametersResult | null;
}

export const LiveDebateView: React.FC<LiveDebateViewProps> = ({ searchResult }) => {
  const [selectedGodId, setSelectedGodId] = useState<GodId>('zeus');

  const topicName = searchResult?.topic || 'Revolução Industrial';
  const godDebateList = searchResult?.godDebate || [];
  const mved = searchResult?.mvedResult || {
    m1_evidence: 0.90,
    m2_logic: 0.94,
    m3_relevance: 0.92,
    m4_risk: 0.86,
    m5_consensus: 0.88,
    totalMvedScore: 0.908,
  };
  const zeusArbitration = searchResult?.zeusArbitration || {
    decision: `Tese sobre "${topicName}" aprovada com alto suporte empírico e lógico.`,
    confidence: 0.92,
    decisionState: 'HIGH_CONFIDENCE' as DecisionState,
    reason: 'Forte corroboração de fontes públicas com zero contradições insolúveis.',
  };

  const activeGod = GODS_LIST.find((g) => g.id === selectedGodId) || GODS_LIST[0];

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-mono">
              <Crown className="w-3.5 h-3.5" />
              <span>GOITGODS 2.0 • Orquestrador do Olimpo</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-serif font-black text-white">
              Debate Multiagente em Tempo Real
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Os 12 Deuses do Olimpo executam raciocínio paralelo sobre <span className="text-amber-300 font-semibold">"{topicName}"</span>, confrontando teses, executando testes de estresse com ARES e analisando riscos com HADES.
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-center min-w-[200px]">
            <span className="text-xs text-slate-400 font-mono uppercase block">Score MVED 2.0 Global</span>
            <span className="text-3xl font-serif font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-amber-200">
              {(mved.totalMvedScore * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-emerald-400 font-mono block mt-1">
              • Estado: {zeusArbitration.decisionState}
            </span>
          </div>
        </div>
      </div>

      {/* 12 Gods Selection Carousel Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-mono uppercase text-slate-400 tracking-wider flex items-center space-x-2">
          <Crown className="w-4 h-4 text-amber-400" />
          <span>Conselho dos 12 Deuses do Olimpo (Clusters Especializados):</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          {GODS_LIST.map((god) => {
            const isSelected = god.id === selectedGodId;
            return (
              <button
                key={god.id}
                onClick={() => setSelectedGodId(god.id)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-500/50 shadow-lg shadow-amber-500/10 scale-[1.02]'
                    : 'bg-slate-900/80 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-serif font-black text-sm text-white">{god.name}</span>
                  <span 
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: god.color }}
                  />
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-1">{god.title}</p>
                <div className="mt-2 text-[10px] font-mono text-amber-300/80">
                  GPS: {(god.gpsScore * 100).toFixed(0)}%
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Selected God Reasoning Detail Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-4">
            <div 
              className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black font-serif text-xl shadow-lg"
              style={{ backgroundColor: activeGod.color }}
            >
              {activeGod.name[0]}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-serif font-bold text-white">{activeGod.name}</h2>
                <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                  ns/{activeGod.namespace}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">{activeGod.title}</p>
            </div>
          </div>

          <div className="bg-slate-950 px-4 py-2 rounded-xl border border-slate-800 text-right">
            <span className="text-[10px] text-slate-500 font-mono block uppercase">Estratégia de Raciocínio</span>
            <span className="text-xs text-amber-300 font-mono">{activeGod.reasoningStrategy}</span>
          </div>
        </div>

        {/* Dynamic Claim and reasoning breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-2">
              <Sparkles className="w-4 h-4" />
              <span>Afirmação Central (Claim):</span>
            </h4>
            <p className="text-sm text-slate-200 leading-relaxed font-serif">
              "{godDebateList.find(g => g.godId === activeGod.id)?.claim || `Análise especializada sobre ${topicName} conduzida por ${activeGod.name}.`}"
            </p>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-2">
              <Layers className="w-4 h-4" />
              <span>Resumo do Raciocínio (Reasoning Summary):</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {godDebateList.find(g => g.godId === activeGod.id)?.reasoning_summary || `O agente ${activeGod.name} processou as UCIs relacionadas a ${topicName} aplicando validação em seu domínio especialista.`}
            </p>
          </div>
        </div>

        {/* Specialties Chips */}
        <div>
          <span className="text-[11px] font-mono text-slate-400 uppercase block mb-2">Especialidades do Cluster:</span>
          <div className="flex flex-wrap gap-2">
            {activeGod.specialties.map((spec, i) => (
              <span key={i} className="text-xs bg-slate-800 text-slate-300 px-3 py-1 rounded-lg border border-slate-700">
                {spec}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Adversarial Engines (ARES & HADES) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* ARES Adversarial Engine Card */}
        <div className="bg-red-950/20 border border-red-800/50 rounded-3xl p-6 space-y-4 shadow-xl">
          <div className="flex items-center space-x-3 text-red-400 border-b border-red-900/40 pb-3">
            <Swords className="w-5 h-5" />
            <div>
              <h3 className="font-serif font-bold text-base text-white">ARES • Raciocínio Adversarial</h3>
              <p className="text-[11px] text-red-300/80 font-mono">ATTACK_SCORE = Weakness × EvidenceGap × LogicalRisk</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            ARES submeteu as hipóteses a testes de estresse rigorosos. Buscou ativamente lacunas de evidência, contra-exemplos históricos e contradições lógicas latentes.
          </p>
          <div className="bg-slate-950 p-4 rounded-xl border border-red-900/30 text-xs space-y-2">
            <div className="flex justify-between text-red-400 font-mono">
              <span>Nível de Ataque Lógico:</span>
              <span className="font-bold">RESISTIDO (0.24 Attack Risk)</span>
            </div>
            <p className="text-slate-400 text-[11px]">
              "A hipótese resistiu ao teste de refutação direta. Nenhuma evidência primária foi invalidada."
            </p>
          </div>
        </div>

        {/* HADES Hidden Risk Engine Card */}
        <div className="bg-purple-950/20 border border-purple-800/50 rounded-3xl p-6 space-y-4 shadow-xl">
          <div className="flex items-center space-x-3 text-purple-400 border-b border-purple-900/40 pb-3">
            <EyeOff className="w-5 h-5" />
            <div>
              <h3 className="font-serif font-bold text-base text-white">HADES • Riscos Ocultos & Anomalias</h3>
              <p className="text-[11px] text-purple-300/80 font-mono">RiskScore = 0.30U + 0.25C + 0.20D + 0.15B + 0.10S</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            HADES inspecionou a base em busca de pontos cegos, suposições implícitas e vieses de fontes.
          </p>
          <div className="bg-slate-950 p-4 rounded-xl border border-purple-900/30 text-xs space-y-2">
            <div className="flex justify-between text-purple-400 font-mono">
              <span>Pontos Cegos Mapeados:</span>
              <span className="font-bold">02 Menores (Incerteza U=0.12)</span>
            </div>
            <p className="text-slate-400 text-[11px]">
              "Risco sob controle. Recomenda-se registrar variantes contextuais na memória evolutiva SMEE."
            </p>
          </div>
        </div>

      </div>

      {/* MVED 2.0 Vector Breakdown & Zeus Arbitration */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex items-center space-x-3 border-b border-slate-800 pb-4">
          <Scale className="w-6 h-6 text-amber-400" />
          <div>
            <h3 className="font-serif font-bold text-xl text-white">
              MVED 2.0 (Multi-Vector Evidence Decision) & Arbitragem de ZEUS
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              MVED = 0.30M1 (Evidence) + 0.25M2 (Logic) + 0.20M3 (Relevance) + 0.15M4 (Risk) + 0.10M5 (Consensus)
            </p>
          </div>
        </div>

        {/* Vector Sliders Display */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">M1: Evidência (30%)</span>
            <span className="text-xl font-bold text-amber-400">{(mved.m1_evidence * 100).toFixed(0)}%</span>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-amber-400 h-full" style={{ width: `${mved.m1_evidence * 100}%` }} />
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">M2: Lógica (25%)</span>
            <span className="text-xl font-bold text-blue-400">{(mved.m2_logic * 100).toFixed(0)}%</span>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-blue-400 h-full" style={{ width: `${mved.m2_logic * 100}%` }} />
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">M3: Relevância (20%)</span>
            <span className="text-xl font-bold text-cyan-400">{(mved.m3_relevance * 100).toFixed(0)}%</span>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-cyan-400 h-full" style={{ width: `${mved.m3_relevance * 100}%` }} />
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">M4: Risco (15%)</span>
            <span className="text-xl font-bold text-purple-400">{(mved.m4_risk * 100).toFixed(0)}%</span>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-purple-400 h-full" style={{ width: `${mved.m4_risk * 100}%` }} />
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">M5: Consenso (10%)</span>
            <span className="text-xl font-bold text-emerald-400">{(mved.m5_consensus * 100).toFixed(0)}%</span>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-400 h-full" style={{ width: `${mved.m5_consensus * 100}%` }} />
            </div>
          </div>
        </div>

        {/* Zeus Verdict Box */}
        <div className="bg-gradient-to-r from-amber-950/40 via-slate-950 to-slate-950 border border-amber-500/40 rounded-2xl p-6 space-y-3">
          <div className="flex items-center space-x-2 text-amber-400 font-serif font-bold text-lg">
            <Crown className="w-5 h-5 text-amber-400" />
            <span>Veredito de Arbitragem de ZEUS:</span>
          </div>
          <p className="text-sm text-slate-200 leading-relaxed font-serif">
            "{zeusArbitration.decision}"
          </p>
          <div className="text-xs text-slate-400 font-mono">
            Justificativa: {zeusArbitration.reason}
          </div>
        </div>

      </div>
    </div>
  );
};
