# Chamasso 2.1.0 — PASQUARED Find Match

## Implementado
- Nova aba privada **Lista find Match** no perfil social.
- Formulário de afinidades com intenção (amizade, paquera ou ambos), 11 escalas comportamentais, qualidades, pontos a melhorar e interesses.
- Persistência do perfil de afinidades no cadastro do usuário via `dbManager`, preservando compatibilidade com o backup existente/Supabase do store.
- Motor PASQUARED explicável: **UCI → EKO → MVED → ICI**.
- Triangulação em três eixos: valores/comunicação (45%), convivência/estilo (30%) e interesses/qualidades (25%).
- Corte inicial de ICI em 55%, ranking decrescente e explicação resumida por candidato.
- Separação por finalidade: Amizade e/ou Paquera conforme intenção mútua.
- Proteção de paquera: somente aparece quando os dois perfis possuem data de nascimento válida e idade >= 18 anos.
- Privacidade: questionário e lista são acessíveis somente pelo próprio usuário autenticado; participação pode ser desativada.
- O algoritmo não usa CPF, e-mail, localização precisa nem atributos sensíveis para pontuar afinidade.

## Endpoints
- `GET /api/pasquared/match/profile/:id`
- `PUT /api/pasquared/match/profile/:id`
- `GET /api/pasquared/match/list/:id`

## Observação
O ICI é uma estimativa de compatibilidade baseada nas respostas declaradas e não deve ser apresentado como garantia de amizade, atração ou relacionamento.
