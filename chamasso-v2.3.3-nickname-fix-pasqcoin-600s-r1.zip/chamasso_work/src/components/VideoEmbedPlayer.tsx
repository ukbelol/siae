import React, { useState } from 'react';
import { Play, ExternalLink, Maximize2, Minimize2, Video } from 'lucide-react';
import type { VideoEmbed } from '../types.ts';

interface VideoEmbedPlayerProps {
  embed: VideoEmbed;
}

export const VideoEmbedPlayer: React.FC<VideoEmbedPlayerProps> = ({ embed }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const getPlatformBadge = () => {
    switch (embed.platform) {
      case 'youtube':
        return { label: 'YouTube', color: 'bg-red-600 text-white' };
      case 'twitch':
        return { label: 'Twitch', color: 'bg-purple-600 text-white' };
      case 'vimeo':
        return { label: 'Vimeo', color: 'bg-blue-500 text-white' };
      case 'dailymotion':
        return { label: 'DailyMotion', color: 'bg-indigo-600 text-white' };
      default:
        return { label: 'Vídeo MP4', color: 'bg-cyan-500 text-black' };
    }
  };

  const badge = getPlatformBadge();

  return (
    <div
      className={`my-2 overflow-hidden rounded-2xl border border-[#22D3EE]/30 bg-[#0A0C10] shadow-lg transition-all ${
        isExpanded ? 'col-span-full ring-2 ring-[#22D3EE]' : ''
      }`}
    >
      {/* Barra de título do player */}
      <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0F172A] px-3 py-1.5 text-xs">
        <div className="flex items-center gap-2">
          <span className={`rounded px-1.5 py-0.5 text-[10px] font-black uppercase ${badge.color}`}>
            {badge.label}
          </span>
          <span className="font-medium text-slate-300 truncate max-w-[200px] sm:max-w-xs">
            {embed.title || 'Mídia Incorporada'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="rounded p-1 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
            title={isExpanded ? 'Modo Normal' : 'Modo Teatro'}
          >
            {isExpanded ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
          </button>
          <a
            href={embed.url}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded p-1 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
            title="Abrir no site original"
          >
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>

      {/* Frame / Player */}
      <div className="relative aspect-video w-full bg-black">
        {embed.platform === 'direct' ? (
          <video
            src={embed.url}
            controls
            playsInline
            className="h-full w-full object-contain"
            preload="metadata"
          />
        ) : !isPlaying ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-t from-black via-black/80 to-transparent p-4 text-center">
            <button
              onClick={() => setIsPlaying(true)}
              className="group flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black shadow-xl shadow-[#22D3EE]/30 transition-all transform hover:scale-110 active:scale-95"
            >
              <Play className="h-6 w-6 fill-current ml-0.5" />
            </button>
            <p className="mt-3 text-xs font-semibold text-slate-300">
              Clique para reproduzir {badge.label} na sala
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5 truncate max-w-sm">{embed.url}</p>
          </div>
        ) : (
          <iframe
            src={embed.embedUrl}
            title={embed.title || 'Stream Incorporado'}
            className="h-full w-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        )}
      </div>
    </div>
  );
};
