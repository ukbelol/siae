import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, MapPin, Scissors, LogOut, Phone } from 'lucide-react';
import Logo from '../components/Logo';
import { SERVICE_CATEGORIES } from '../constants/services';

export default function ClientDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [salons, setSalons] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [filters, setFilters] = useState({ city: '', neighborhood: '', state: '', service: '' });

  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/login/client');
      return;
    }
    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);
    fetchSalons();
    fetchAppointments(parsedUser.id);

    // Check for Mercado Pago return
    const urlParams = new URLSearchParams(window.location.search);
    const paymentStatus = urlParams.get('payment');
    const appointmentId = urlParams.get('appointment_id');
    const paymentId = urlParams.get('payment_id');

    if (paymentStatus === 'success' && appointmentId) {
      confirmPayment(appointmentId, paymentId);
    } else if (paymentStatus === 'failure') {
      showToast('Pagamento falhou. Tente novamente.', 'error');
    }
  }, []);

  const confirmPayment = async (appointmentId: string, paymentId: string | null) => {
    try {
      const res = await fetch(`/api/appointments/${appointmentId}/confirm-payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_id: paymentId })
      });
      if (res.ok) {
        showToast('Pagamento confirmado com sucesso!');
        if (user) fetchAppointments(user.id);
      }
    } catch (error) {
      console.error('Error confirming payment:', error);
    }
  };

  const handleCancel = async (appointmentId: number) => {
    if (!confirm('Tem certeza que deseja cancelar este agendamento? Se estiver dentro de 24h, o estorno será processado.')) return;

    try {
      const res = await fetch(`/api/appointments/${appointmentId}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ client_id: user.id })
      });
      const data = await res.json();
      
      if (res.ok) {
        showToast(data.message || 'Agendamento cancelado com sucesso.');
        fetchAppointments(user.id);
      } else {
        showToast(data.message || 'Erro ao cancelar.', 'error');
      }
    } catch (error) {
      showToast('Erro ao cancelar.', 'error');
    }
  };

  const handlePay = async (app: any) => {
    try {
      const res = await fetch('/api/checkout/preference', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `Sinal: ${app.service_name} - ${app.salon_name}`,
          price: app.paid_amount,
          appointmentId: app.id,
          salonId: app.salon_id,
          totalServicePrice: app.paid_amount + app.pending_amount
        })
      });
      const data = await res.json();
      if (data.success && data.init_point) {
        window.location.href = data.init_point;
      } else {
        showToast(data.message || 'Erro ao gerar pagamento.', 'error');
      }
    } catch (error) {
      showToast('Erro ao processar pagamento.', 'error');
    }
  };

  const fetchAppointments = async (userId: number) => {
    const res = await fetch(`/api/users/${userId}/appointments`);
    const data = await res.json();
    setAppointments(data);
  };

  const fetchSalons = async () => {
    const query = new URLSearchParams(filters).toString();
    const res = await fetch(`/api/salons?${query}`);
    const data = await res.json();
    setSalons(data);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchSalons();
  };

  const logout = () => {
    localStorage.removeItem('user');
    navigate('/');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xl font-bold text-teal-900">
            <Logo className="w-8 h-8" variant="dark" />
            Hair Smart Mall
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm font-medium text-slate-900">Olá, {user.name?.split(' ')[0]}</div>
              <div className="text-[10px] text-slate-500 font-mono">{user.identifier}</div>
            </div>
            <button onClick={logout} className="text-slate-500 hover:text-slate-700 flex items-center gap-1 text-sm">
              <LogOut className="w-4 h-4" /> Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Meus Agendamentos</h2>
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-sm bg-slate-50">
                    <th className="py-4 px-6 font-medium">Data/Hora</th>
                    <th className="py-4 px-6 font-medium">Salão</th>
                    <th className="py-4 px-6 font-medium">Serviço</th>
                    <th className="py-4 px-6 font-medium">Profissional</th>
                    <th className="py-4 px-6 font-medium">Status</th>
                    <th className="py-4 px-6 font-medium">Sinal Pago</th>
                    <th className="py-4 px-6 font-medium">Pendente</th>
                    <th className="py-4 px-6 font-medium text-right">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {appointments.map(app => {
                    const isCancelable = (app.status === 'scheduled' || app.status === 'pending_payment') && (new Date(app.start_time).getTime() - new Date().getTime()) / (1000 * 60 * 60) >= 24;
                    const canPay = app.status === 'pending_payment';

                    return (
                      <tr key={app.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
                        <td className="py-4 px-6 text-slate-900 font-medium">{new Date(app.start_time).toLocaleString('pt-BR')}</td>
                        <td className="py-4 px-6 text-slate-600">{app.salon_name}</td>
                        <td className="py-4 px-6 text-slate-600">{app.service_name}</td>
                        <td className="py-4 px-6 text-slate-600">{app.employee_name || 'N/A'}</td>
                        <td className="py-4 px-6">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            app.status === 'completed' ? 'bg-cyan-100 text-cyan-700' : 
                            app.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                            app.status === 'pending_payment' ? 'bg-amber-100 text-amber-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {app.status === 'scheduled' ? 'Agendado' : 
                             app.status === 'completed' ? 'Concluído' : 
                             app.status === 'cancelled' ? 'Cancelado' :
                             app.status === 'pending_payment' ? 'Aguardando Pagamento' : app.status}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-cyan-600 font-medium">R$ {app.paid_amount?.toFixed(2) || '0.00'}</td>
                        <td className="py-4 px-6 text-amber-600 font-medium">R$ {app.pending_amount?.toFixed(2) || '0.00'}</td>
                        <td className="py-4 px-6 text-right">
                          <div className="flex items-center justify-end gap-3">
                            {canPay && (
                              <button 
                                onClick={() => handlePay(app)}
                                className="bg-cyan-600 text-white px-3 py-1 rounded-lg text-xs font-medium hover:bg-teal-600 transition-colors"
                              >
                                Pagar Sinal
                              </button>
                            )}
                            {isCancelable && (
                              <button 
                                onClick={() => handleCancel(app.id)}
                                className="text-red-500 hover:text-red-700 text-sm font-medium transition-colors"
                              >
                                Cancelar
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {appointments.length === 0 && (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        Você ainda não possui agendamentos.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Search className="w-5 h-5 text-cyan-700" />
            Encontrar Salões
          </h2>
          <form onSubmit={handleSearch} className="grid md:grid-cols-5 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Serviço</label>
              <select 
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                value={filters.service} 
                onChange={e => setFilters({...filters, service: e.target.value})}
              >
                <option value="">Todos os serviços</option>
                {SERVICE_CATEGORIES.map(category => (
                  <optgroup key={category.category} label={category.category}>
                    {category.services.map(service => (
                      <option key={service} value={service}>{service}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Cidade</label>
              <input type="text" className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                value={filters.city} onChange={e => setFilters({...filters, city: e.target.value})} placeholder="Ex: São Paulo" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Bairro</label>
              <input type="text" className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                value={filters.neighborhood} onChange={e => setFilters({...filters, neighborhood: e.target.value})} placeholder="Ex: Centro" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Estado</label>
              <input type="text" className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                value={filters.state} onChange={e => setFilters({...filters, state: e.target.value})} placeholder="Ex: SP" />
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-teal-900 text-white rounded-lg px-4 py-2 text-sm font-medium hover:bg-teal-800 transition-colors">
                Pesquisar
              </button>
            </div>
          </form>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {salons.map(salon => (
            <Link key={salon.id} to={`/salon/${salon.id}`} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow group">
              <div className="h-32 bg-slate-200 relative">
                {salon.bg_url ? (
                  <img src={salon.bg_url} alt="Capa" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-teal-900/10 flex items-center justify-center">
                    <Scissors className="w-8 h-8 text-teal-900/30" />
                  </div>
                )}
                {salon.logo_url && (
                  <div className="absolute -bottom-6 left-5 border-4 border-white rounded-full bg-white overflow-hidden shadow-sm h-14 w-14">
                     <img src={salon.logo_url} alt="Logo" className="w-full h-full object-contain" />
                  </div>
                )}
              </div>
              <div className="p-5 pt-8">
                <h3 className="font-bold text-lg text-slate-900 group-hover:text-cyan-700 transition-colors">{salon.name}</h3>
                {salon.slogan && <p className="text-sm font-medium text-cyan-600 mt-1 line-clamp-1">{salon.slogan}</p>}
                
                <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-slate-100">
                  <div className="flex items-start gap-2 text-xs text-slate-500">
                    <MapPin className="w-4 h-4 shrink-0 text-slate-400 mt-0.5" />
                    <span>
                      {salon.street}, {salon.number}<br/>
                      {salon.neighborhood}, {salon.city} - {salon.state}
                    </span>
                  </div>
                  {salon.phone && (
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Phone className="w-4 h-4 shrink-0 text-slate-400" />
                      <span>{salon.phone}</span>
                    </div>
                  )}
                </div>
              </div>
            </Link>
          ))}
          {salons.length === 0 && (
            <div className="col-span-3 text-center py-12 text-slate-500">
              Nenhum salão encontrado com os filtros atuais.
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
