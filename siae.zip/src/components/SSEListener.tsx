import React, { useEffect } from 'react';
import toast from 'react-hot-toast';

export default function SSEListener() {
  useEffect(() => {
    const token = localStorage.getItem('siae_token');
    // For terminal accounts, we might not want global toast, but let's connect anyway if they possess a valid token.
    if (!token) return;

    const eventSource = new EventSource(`/api/notifications/stream?token=${token}`);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'ping') return;
        
        switch(data.type) {
            case 'queue_called':
            case 'worker_called':
                toast.success(data.message, { duration: 8000, icon: '🛎️' });
                // We could play a sound here
                const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
                audio.play().catch(e => console.log('Audio denied:', e));
                break;
            case 'worker_started':
            case 'assisted_started':
                 toast(data.message, { duration: 5000, icon: '🚪' });
                 break;
            case 'queue_requeued':
                 toast(data.message, { duration: 6000, icon: '🔄' });
                 break;
            case 'queue_joined':
                 toast.success(data.message, { duration: 5000, icon: '🎫' });
                 break;
            case 'attendance_completed':
                 toast.success(data.message, { duration: 7000, icon: '🎉' });
                 break;
            default:
                toast(data.message);
        }
      } catch (err) {
        console.error('SSE Error processing message', err);
      }
    };

    eventSource.onerror = (error) => {
      console.error('EventSource failed:', error);
      eventSource.close();
      // Simple reconnection logic could go here, or depend on React lifecycle
    };

    return () => {
      eventSource.close();
    };
  }, []);

  return null;
}
