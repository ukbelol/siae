import React, { useEffect, useState } from 'react';
import { Shield, ShieldAlert, ShieldCheck, RefreshCw, Unlock, Trash2, AlertTriangle, Activity } from 'lucide-react';

export default function AdminFirewallManager() {
  const [data, setData] = useState<any>({
    active: true,
    maxAttempts: 2,
    blockedCount: 0,
    blockedIps: [],
    logs: []
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/firewall/status');
      const json = await res.json();
      setData(json);
    } catch (err) {
      console.error('Error fetching firewall status:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleUnblock = async (ip: string) => {
    if (!confirm(`Deseja realmente desbloquear o IP ${ip}?`)) return;
    try {
      const res = await fetch('/api/admin/firewall/unblock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip })
      });
      const json = await res.json();
      if (json.success) {
        setMessage(json.message);
        loadData();
      } else {
        alert(json.error || 'Erro ao desbloquear IP.');
      }
    } catch (err: any) {
      alert('Falha ao comunicar com o servidor.');
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Tem certeza que deseja desbloquear TODOS os endereços IP bloqueados?')) return;
    try {
      const res = await fetch('/api/admin/firewall/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const json = await res.json();
      if (json.success) {
        setMessage(json.message);
        loadData();
      } else {
        alert(json.error || 'Erro ao limpar IPs.');
      }
    } catch (err: any) {
      alert('Falha ao comunicar com o servidor.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 shadow-xl border border-indigo-500/20">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-2xl text-red-400">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-2xl font-black flex items-center gap-2">
                Firewall de Segurança & Proteção Brute Force
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-3 py-1 rounded-full font-bold uppercase tracking-wider">
                  Ativo & Protegendo
                </span>
              </h3>
              <p className="text-gray-300 text-sm mt-1">
                Bloqueia automaticamente endereços IP após <strong className="text-white">2 tentativas seguidas</strong> com erro de senha em qualquer rota do SIAE.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadData}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-sm font-bold transition-all border border-white/10"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Atualizar
            </button>
            {data.blockedCount > 0 && (
              <button
                onClick={handleClearAll}
                className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-red-600/30"
              >
                <Trash2 className="w-4 h-4" /> Desbloquear Todos
              </button>
            )}
          </div>
        </div>
      </div>

      {message && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex justify-between items-center text-sm font-semibold">
          <span>{message}</span>
          <button onClick={() => setMessage(null)} className="text-emerald-600 font-bold hover:underline">Fechar</button>
        </div>
      )}

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-emerald-100 text-emerald-600 rounded-xl">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">Status do Firewall</p>
            <p className="text-xl font-black text-gray-800">Proteção Ativa (2 Erros)</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-red-100 text-red-600 rounded-xl">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">IPs Atualmentes Bloqueados</p>
            <p className="text-2xl font-black text-red-600">{data.blockedCount}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-indigo-100 text-indigo-600 rounded-xl">
            <Activity className="w-8 h-8" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">Registros de Eventos</p>
            <p className="text-2xl font-black text-indigo-600">{data.logs?.length || 0}</p>
          </div>
        </div>
      </div>

      {/* Blocked IPs Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
          <h4 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-500" />
            Endereços IP Bloqueados por Tentativas Falhas
          </h4>
          <span className="text-xs font-semibold text-gray-500">
            {data.blockedIps?.length} IP(s) registrado(s)
          </span>
        </div>

        {data.blockedIps?.length === 0 ? (
          <div className="p-12 text-center text-gray-500 space-y-2">
            <ShieldCheck className="w-12 h-12 text-emerald-500 mx-auto" />
            <p className="font-bold text-gray-700 text-lg">Nenhum IP bloqueado no momento.</p>
            <p className="text-sm">O sistema está monitorando ativamente contra ataques de força bruta.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b border-gray-200">
                  <th className="p-4 font-bold">Endereço IP</th>
                  <th className="p-4 font-bold">Usuário/Alvo</th>
                  <th className="p-4 font-bold">Erros</th>
                  <th className="p-4 font-bold">Data/Hora do Bloqueio</th>
                  <th className="p-4 font-bold">Motivo</th>
                  <th className="p-4 font-bold text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-sm">
                {data.blockedIps?.map((entry: any, index: number) => (
                  <tr key={index} className="hover:bg-red-50/30 transition-colors">
                    <td className="p-4 font-mono font-bold text-red-600">{entry.ip}</td>
                    <td className="p-4 text-gray-700">{entry.targetUser || 'Desconhecido'}</td>
                    <td className="p-4">
                      <span className="px-2.5 py-1 bg-red-100 text-red-700 font-bold text-xs rounded-full">
                        {entry.attempts} tentativas
                      </span>
                    </td>
                    <td className="p-4 text-gray-500 text-xs">
                      {new Date(entry.blockedAt).toLocaleString('pt-BR')}
                    </td>
                    <td className="p-4 text-gray-600 text-xs">{entry.reason}</td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => handleUnblock(entry.ip)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-all shadow-md shadow-emerald-600/20"
                      >
                        <Unlock className="w-3.5 h-3.5" /> Desbloquear
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Firewall Logs */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4">
        <h4 className="text-lg font-bold text-gray-800 flex items-center gap-2">
          <Activity className="w-5 h-5 text-indigo-600" />
          Histórico Recente de Alertas e Tentativas de Invasão
        </h4>

        <div className="max-h-80 overflow-y-auto space-y-2 pr-2">
          {data.logs?.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-4">Nenhum evento registrado ainda.</p>
          ) : (
            data.logs?.map((log: any, idx: number) => (
              <div
                key={idx}
                className={`p-3 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center text-xs gap-2 ${
                  log.event_type === 'IP_BLOCKED'
                    ? 'bg-red-50 border-red-200 text-red-900 font-semibold'
                    : 'bg-gray-50 border-gray-200 text-gray-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-0.5 rounded font-bold uppercase text-[10px] ${
                    log.event_type === 'IP_BLOCKED' ? 'bg-red-600 text-white' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {log.event_type}
                  </span>
                  <span className="font-mono font-bold">{log.ip}</span>
                  <span>— {log.details}</span>
                </div>
                <span className="text-gray-400 text-[11px]">
                  {new Date(log.created_at).toLocaleString('pt-BR')}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
