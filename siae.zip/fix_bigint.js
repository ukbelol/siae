import fs from 'fs';
let content = fs.readFileSync('src/api/index.ts', 'utf8');
content = content.replace(/info\.lastInsertRowid/g, 'Number(info.lastInsertRowid)');
fs.writeFileSync('src/api/index.ts', content);
console.log('Done!');
