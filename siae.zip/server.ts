import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { initDb } from './src/lib/db.js';
import { scheduleBackup } from './src/lib/backup.js';
import apiRoutes from './src/api/index.js';

process.on('uncaughtException', (err: any) => {
  if (err?.code !== 'ECONNREFUSED' && err?.message?.indexOf('ECONNREFUSED') === -1) {
    console.error('Uncaught Exception:', err);
  }
});
process.on('unhandledRejection', (reason: any, promise) => {
  if (reason?.code !== 'ECONNREFUSED' && reason?.message?.indexOf('ECONNREFUSED') === -1) {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Database
  initDb().catch(() => {});
  scheduleBackup();

  // API Routes
  app.use('/api', apiRoutes);

  // Rota de redirecionamento para o checkout de compra do Chaveiro NFC SIAE (Propaganda de Venda)
  app.get('/comprar-chaveiro', (req, res) => {
    res.redirect('/checkout?ref=propaganda');
  });

  // Serve uploads
  const uploadsPath = path.join(process.cwd(), 'uploads');
  app.use('/uploads', express.static(uploadsPath));

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
