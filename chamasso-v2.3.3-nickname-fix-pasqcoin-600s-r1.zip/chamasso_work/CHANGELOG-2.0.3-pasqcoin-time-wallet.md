# Chamasso 2.0.3 — Carteira PASQcoin por tempo

## Alterações
- Carteira do usuário passa a exibir PASQcoin em vez de saldo em R$ para uso do chat.
- Saldo PASQcoin usa 6 casas decimais, permitindo partes inteiras e fracionadas.
- O consumo é proporcional ao tempo: `PASQ consumido = segundos usados / segundosPorPasqcoin`.
- A interface atualiza a contagem a cada segundo e persiste o consumo no backend em pequenos lotes para reduzir carga.
- Exibição simultânea de saldo PASQcoin e tempo restante equivalente.
- PIX continua sendo pago em R$, mas após confirmação o valor é convertido e creditado em PASQcoin.
- Preço do PASQcoin e segundos por PASQ são registrados no momento da geração da cobrança para preservar a condição da compra.
- Após confirmação no Mercado Pago, a tela mostra mensagem explícita de compra aprovada e quantidade de PASQcoin creditada.
- Webhook e confirmação manual creditam PASQcoin, não saldo em reais.
- Schema PostgreSQL atualizado para `pasqcoins NUMERIC(20,6)`.
- Removida a cobrança concorrente por minuto em R$ no cliente para evitar débito duplicado.

## Exemplo
Com `1 PASQ = 60 segundos`, 30 segundos de uso consomem `0,500000 PASQ`.
Um saldo de `10,250000 PASQ` equivale a 615 segundos (10m15s).
