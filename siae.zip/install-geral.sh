#!/bin/bash
# ==============================================================================
# Script de Instalação Geral Unificado - SIAE (SIAE Meet Autônomo e Integrado)
# ==============================================================================
# Sistema Autônomo de Videoconferência e Atendimento Espírita baseados em WebRTC.
# Recursos Integrados:
# - Painel Super Admin Unificado com edição e alteração de NFCs integradas à segurança do banco.
# - Monitor de Senhas em Tela Única 16:9 via Tabela Matricial de agrupamento dinâmico com
#   salas de atendimento individuais, exibindo senha chamada, nome e sala na coluna
#   da assistência, seguido pelas próximas 7 senhas em fila.
# - Sala de Videoconferência com efeito espelho e cartões integrados (foto, cidade, telefone).
# - Módulo NFC Inteligente no terminal com de-duplicação de cache (5s) impedindo disparos
#   múltiplos na aproximação, e validação rígida de apenas uma tag ativa por CPF/usuário.
#
# DOMÍNIOS QUE DEVEM SER APONTADOS NO SEU DNS (Tipo A / AAAA):
# 1. appa.siae.space          -> IP da sua VPS (Principal: SIAE)
# ==============================================================================

set -e

# Cores para Saída Elegante
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

echo -e "${CYAN}=====================================================================${NC}"
echo -e "${CYAN}        SIAE MEET AUTÔNOMO: INSTALADOR E CONFIGURADOR COESO V3       ${NC}"
echo -e "${CYAN}=====================================================================${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}ERRO: Por favor, execute este script como root (sudo).${NC}"
  exit 1
fi

DOMAIN="appa.siae.space"
EMAIL="rogermei577@gmail.com"
APP_DIR="/var/www/siae"

# Parâmetros customizáveis do Banco de Dados e API do Google Gemini para VPS
DB_HOST="localhost"
DB_USER="siae_user"
DB_PASSWORD="siae_password"
DB_NAME="siae_db"
GEMINI_API_KEY="" # Chave opcional do Google Gemini para inteligência artificial se desejar habilitar resumos/sugestões

# ==============================================================================
# ETAPA 1: COMPLETAR DESINSTALAÇÃO DOS SISTEMAS ANTERIORES E CONFIGURAÇÃO FIREWALL
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 1 - LIMPEZA & FIREWALL] Removendo sistemas legados (Openfire/Jitsi/OpenMeetings)...${NC}"

# Pausando e expurgando serviços antigos
systemctl stop openfire 2>/dev/null || true
systemctl disable openfire 2>/dev/null || true
systemctl stop jitsi-videobridge2 2>/dev/null || true
systemctl stop jicofo 2>/dev/null || true
systemctl stop prosody 2>/dev/null || true
systemctl stop openmeetings 2>/dev/null || true
docker stop kms 2>/dev/null || true
docker rm kms 2>/dev/null || true

# Expurgando totalmente pacotes antigos ddo sistema
DEBIAN_FRONTEND=noninteractive apt-get purge -y openfire jitsi-meet jitsi-meet-web jitsi-meet-web-config jitsi-meet-prosody jicofo prosody || true
apt-get autoremove -y || true

# Limpando diretórios residuais dos antigos sistemas de videoconferência para assegurar a coesão do sistema
rm -rf /etc/openfire /var/lib/openfire /var/log/openfire /usr/share/openfire || true
rm -rf /etc/jitsi /var/log/jitsi /etc/prosody /var/lib/prosody || true
rm -rf /opt/openmeetings /opt/mirotalk-sfu || true

# Configura regras estritas de firewall: abre somente portas Web Seguras 80/443 e TURN/STUN para WebRTC
if command -v ufw >/dev/null; then
    echo -e "${YELLOW}-> Ativando portas seguras no firewall UFW...${NC}"
    ufw allow 80/tcp || true
    ufw allow 443/tcp || true
    # Limpando portas legadas do Jitsi/Openfire para evitar frestas de segurança na VPS
    ufw delete allow 7070/tcp 2>/dev/null || true
    ufw delete allow 7443/tcp 2>/dev/null || true
    ufw delete allow 9090/tcp 2>/dev/null || true
    ufw delete allow 9091/tcp 2>/dev/null || true
    ufw delete allow 5222/tcp 2>/dev/null || true
    ufw delete allow 5223/tcp 2>/dev/null || true
    ufw delete allow 5080/tcp 2>/dev/null || true
    ufw reload || true
fi

# Removendo conflitos de porta do Nginx
systemctl stop nginx 2>/dev/null || true
systemctl disable nginx 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get purge -y nginx nginx-common || true

# ==============================================================================
# ETAPA 2: INSTALAÇÃO DO APACHE, NODE.JS E DEPENDÊNCIAS
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 2 - DEPENDÊNCIAS] Instalando Apache Web Server e utilitários...${NC}"

apt-get update
apt-get install -y mariadb-server apache2 certbot python3-certbot-apache build-essential git psmisc net-tools curl wget unzip

# Habilitando os módulos necessários do Apache para Proxy reverso WebRTC e WebSocket
a2enmod proxy || true
a2enmod proxy_http || true
a2enmod proxy_wstunnel || true
a2enmod rewrite || true
a2enmod ssl || true
a2enmod headers || true

systemctl unmask apache2 || true
systemctl enable apache2 || true
systemctl start apache2 || true

# ==============================================================================
# ETAPA 3: SOLICITAÇÃO DOS CERTIFICADOS SSL VÁLIDOS (LET'S ENCRYPT)
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 3 - CERTIFICADOS SSL] Gerando Certificado SSL Let's Encrypt Válido...${NC}"

systemctl stop apache2 || true
if command -v fuser >/dev/null; then
    fuser -k 80/tcp || true
    fuser -k 443/tcp || true
fi

echo -e "${YELLOW}-> Solicitando certificado standalone Let's Encrypt para o domínio principal...${NC}"
SSL_DIR_MAIN=""

if certbot certonly --standalone -d ${DOMAIN} --non-interactive --agree-tos -m ${EMAIL} --keep-until-expiring; then
    echo -e "${GREEN}Sucesso! Certificado Let's Encrypt obtido com sucesso.${NC}"
    SSL_DIR_MAIN="${DOMAIN}"
else
    echo -e "${RED}Erro ao obter certificado. O instalador usará chaves locais autoassinadas para contingência.${NC}"
fi

systemctl start apache2 || true

# ==============================================================================
# ETAPA 4: INICIALIZAÇÃO DA APLICAÇÃO SIAE COM O NOVO SISTEMA AUTÔNOMO MEET
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 4 - BACKEND & FRONTEND] Preparando o Servidor de Sinalização e Frontend...${NC}"

# 4.1 Iniciar MariaDB
systemctl start mariadb || true
systemctl enable mariadb || true

# Criação das Tabelas do banco SIAE com parâmetros customizáveis
echo -e "${YELLOW}-> Configurando o Banco de Dados MariaDB (${DB_NAME})...${NC}"
mysql -uroot -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8 COLLATE utf8_general_ci;"
mysql -uroot -e "GRANT ALL ON ${DB_NAME}.* TO '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';"
mysql -uroot -e "FLUSH PRIVILEGES;"

# 4.2 Configurando Node.js v22
if ! command -v node >/dev/null; then
    echo -e "${YELLOW}-> Configurando Node.js v22...${NC}"
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg --yes
    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
    apt-get update
    apt-get install -y nodejs
fi

# 4.3 Movendo arquivos e compilando frontend
mkdir -p ${APP_DIR}
cp -r ./* ${APP_DIR}/ 2>/dev/null || true
cp -r ./.[!.]* ${APP_DIR}/ 2>/dev/null || true
cd ${APP_DIR}

# Criação do arquivo .env configurado automaticamente para o ambiente de produção da VPS
echo -e "${YELLOW}-> Criando o arquivo de variáveis de ambiente (.env) na VPS...${NC}"
cat <<EOF > .env
PORT=3000
NODE_ENV=production
DB_HOST=${DB_HOST}
DB_USER=${DB_USER}
DB_PASSWORD=${DB_PASSWORD}
DB_NAME=${DB_NAME}
APP_URL=https://${DOMAIN}
GEMINI_API_KEY=${GEMINI_API_KEY}
EOF

echo -e "${YELLOW}-> Instalando dependências npm...${NC}"
rm -rf node_modules dist
npm install

echo -e "${YELLOW}-> Compilando Frontend e empacotando servidor...${NC}"
npm run build

# 4.4 Inicialização de Processos com o PM2
echo -e "${YELLOW}-> Ativando o processo Node em background via PM2...${NC}"
npm install -g pm2 tsx || true
pm2 delete siae 2>/dev/null || true

# Inicializa usando o bundle compilado em dist/server.cjs
pm2 start dist/server.cjs --name "siae" --max-memory-restart 1G
pm2 startup systemd -u root --hp /root || true
pm2 save

# Pasta de Uploads de arquivos das salas de conferência
mkdir -p ${APP_DIR}/uploads
chown -R www-data:www-data ${APP_DIR} || true
chmod -R 775 ${APP_DIR}/uploads || true

# ==============================================================================
# ETAPA 5: CONFIGURAÇÃO DO VIRTUAL HOST PROXY NO APACHE
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 5 - PROXY APACHE] Aplicando Configuração do Host do Apache...${NC}"

if [ -n "$SSL_DIR_MAIN" ] && [ -f "/etc/letsencrypt/live/${SSL_DIR_MAIN}/fullchain.pem" ]; then
    APACHE_SSL_CERT="/etc/letsencrypt/live/${SSL_DIR_MAIN}/fullchain.pem"
    APACHE_SSL_KEY="/etc/letsencrypt/live/${SSL_DIR_MAIN}/privkey.pem"
else
    # Autoassinado local se Let's Encrypt falhar
    mkdir -p /etc/apache2/ssl
    openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
      -keyout /etc/apache2/ssl/apache.key \
      -out /etc/apache2/ssl/apache.crt \
      -subj "/CN=localhost" || true
    APACHE_SSL_CERT="/etc/apache2/ssl/apache.crt"
    APACHE_SSL_KEY="/etc/apache2/ssl/apache.key"
fi

cat <<EOF > /etc/apache2/sites-available/siae.conf
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    Redirect permanent / https://${DOMAIN}/
</VirtualHost>

<VirtualHost *:443>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}

    SSLEngine on
    SSLCertificateFile ${APACHE_SSL_CERT}
    SSLCertificateKeyFile ${APACHE_SSL_KEY}

    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/
    
    # Suporte a WebSockets para tráfego WebRTC veloz no sinalizador autônomo
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule ^/(.*) ws://127.0.0.1:3000/\$1 [P,L]
</VirtualHost>
EOF

# Desativa default e ativa virtual hosts no Apache
a2dissite 000-default.conf || true
a2dissite default-ssl.conf || true
a2dissite siae.conf || true
a2ensite siae.conf || true

echo -e "${YELLOW}-> Testando sintaxe das alterações do Apache e reiniciando...${NC}"
apache2ctl configtest
systemctl restart apache2 || true

echo -e "\n${GREEN}=====================================================================${NC}"
echo -e "${GREEN}           PARABÉNS! SISTEMA DE VIDEOCONFERÊNCIA CRIPTOGRAFADO ATIVO  ${NC}"
echo -e "${GREEN}=====================================================================${NC}"
echo -e "${CYAN}Acesso ao SIAE Geral & Meet:   https://${DOMAIN}${NC}"
echo -e "${CYAN}Status do Processo Node (SIAE):${NC}"
pm2 status siae || true
echo -e "====================================================================="
