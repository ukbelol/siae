import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { FormulationPanel } from './components/FormulationPanel';
import { HistoricalProfileSelector } from './components/HistoricalProfileSelector';
import { GodsGrid } from './components/GodsGrid';
import { ReasoningDashboard } from './components/ReasoningDashboard';
import { TimelineView } from './components/TimelineView';
import { EbookBlueprintModal } from './components/EbookBlueprintModal';
import { EbookReader } from './components/EbookReader';
import { OlympusEvolutionModal } from './components/OlympusEvolutionModal';
import { AdminPanel } from './components/AdminPanel';
import { MethodologySlideshow } from './components/MethodologySlideshow';
import { ResearchAnamnesisPanel } from './components/ResearchAnamnesisPanel';
import {
  FormulationState,
  ResearchProfile,
  SystemExecutionResult,
  EbookBlueprint,
  EbookManuscript,
} from './types';
import { Search, Sparkles, BookOpen, Hourglass, Sliders, ChevronDown, ChevronUp, Cpu, History, ArrowRight } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'search' | 'ebooks' | 'reader' | 'olympus' | 'admin'>('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<SystemExecutionResult | null>(null);

  // PFA & CHRONOS State
  const [formulation, setFormulation] = useState<FormulationState>({
    id: 'pfa_initial',
    mode: 'EXPRESS',
    completenessScore: 0.95,
    ebookDNA: {
      topic: 'Revolução Industrial',
      intent: 'Pesquisa e E-Book',
      audience: 'Geral',
      objective: 'Análise profunda e cronologia',
      language: 'Português',
      depth: 'profundo',
      style: 'narrativo',
      tone: 'analitico',
      length: 'medio',
      chapterCount: 8,
      technicality: 0.7,
      historicalDepth: 0.85,
      criticalDepth: 0.75,
      narrativeLevel: 0.8,
      creativityLevel: 0.6,
      fictionLevel: 0.0,
      evidenceLevel: 0.9,
      citationLevel: 0.85,
      visualDensity: 0.5,
      sourcePolicy: 'verified_only',
      riskTolerance: 'low',
      outputFormat: 'EPUB',
    },
    cognitiveVector: {
      depth: 0.8,
      technicality: 0.7,
      academicLevel: 0.85,
      narrativeLevel: 0.8,
      criticalDepth: 0.75,
      historicalDepth: 0.85,
      referenceRigor: 0.9,
      fictionFreedom: 0.0,
      visualDensity: 0.5,
      simplicity: 0.3,
    },
    questionsAsked: [],
    userAnswers: {},
    isComplete: true,
  });

  const [researchProfile, setResearchProfile] = useState<ResearchProfile>({
    origin: true,
    causes: true,
    strengths: true,
    weaknesses: true,
    duration: true,
    beginning: true,
    development: true,
    middle: true,
    ending: true,
    consequences: true,
    actors: true,
    sources: true,
    uncertainties: true,
    controversies: true,
  });

  // UI Toggles
  const [showPfaPanel, setShowPfaPanel] = useState(false);
  const [showChronosPanel, setShowChronosPanel] = useState(false);

  // E-Book & Reader state
  const [ebooks, setEbooks] = useState<EbookManuscript[]>([]);
  const [currentBlueprint, setCurrentBlueprint] = useState<EbookBlueprint | null>(null);
  const [isBlueprintOpen, setIsBlueprintOpen] = useState(false);
  const [isGeneratingEbook, setIsGeneratingEbook] = useState(false);
  const [activeManuscript, setActiveManuscript] = useState<EbookManuscript | null>(null);

  // Super Admin setup and authentication states
  const [isSystemSetup, setIsSystemSetup] = useState<boolean | null>(null);
  const [setupFullName, setSetupFullName] = useState('');
  const [setupUsername, setSetupUsername] = useState('');
  const [setupEmail, setSetupEmail] = useState('');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupError, setSetupError] = useState<string | null>(null);

  // Check Super Admin setup status on initialization
  useEffect(() => {
    fetch('/api/v2/admin/setup-status')
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setIsSystemSetup(data.isSetup);
        }
      })
      .catch(err => {
        console.error('Error checking setup status:', err);
        // Fallback to true if server fails to avoid blocking
        setIsSystemSetup(true);
      });
  }, []);

  const handleRegisterSuperAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!setupFullName || !setupUsername || !setupEmail || !setupPassword) {
      setSetupError('Todos os campos são obrigatórios.');
      return;
    }
    setSetupError(null);
    try {
      const response = await fetch('/api/v2/admin/setup-super-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: setupFullName,
          username: setupUsername,
          email: setupEmail,
          password: setupPassword,
        }),
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem('goitgods_admin_token', data.token);
        localStorage.setItem('goitgods_admin_user', JSON.stringify(data.user));
        setIsSystemSetup(true);
        setActiveTab('admin');
      } else {
        setSetupError(data.error || 'Erro ao realizar cadastro.');
      }
    } catch (err) {
      console.error(err);
      setSetupError('Erro de conexão ao salvar dados.');
    }
  };

  // Load existing ebooks on start
  useEffect(() => {
    fetch('/api/v2/ebooks')
      .then(r => r.json())
      .then(data => {
        if (data.success && Array.isArray(data.ebooks)) {
          setEbooks(data.ebooks);
        }
      })
      .catch(err => console.log('Fetch ebooks err:', err));
  }, []);

  // Main pipeline execution trigger
  const handleExecuteQuery = async (queryOverride?: string) => {
    const q = (queryOverride || searchQuery).trim() || 'Revolução Industrial';
    setSearchQuery(q);
    setIsExecuting(true);

    try {
      const response = await fetch('/api/v2/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: q,
          mode: formulation.mode,
          customAnswers: formulation.userAnswers,
          researchProfile,
        }),
      });

      const data = await response.json();
      if (data.success && data.result) {
        setExecutionResult(data.result);
        setFormulation(data.result.formulation);
      }
    } catch (e) {
      console.error('Execution error:', e);
    } finally {
      setIsExecuting(false);
    }
  };

  // Open Blueprint Modal for E-Book Creation
  const handleOpenBlueprint = async () => {
    const topic = searchQuery || 'Revolução Industrial';
    try {
      const res = await fetch('/api/v2/ebooks/blueprint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: topic,
          formulation,
          researchProfile,
          godWeights: executionResult?.selectedGods.reduce((acc, g) => ({ ...acc, [g.god_id]: g.normalized_weight }), {}),
        }),
      });
      const data = await res.json();
      if (data.success && data.blueprint) {
        setCurrentBlueprint(data.blueprint);
        setIsBlueprintOpen(true);
      }
    } catch (e) {
      console.error('Error fetching blueprint:', e);
    }
  };

  // Confirm Generation of complete E-Book
  const handleConfirmGenerateEbook = async () => {
    if (!currentBlueprint) return;
    setIsGeneratingEbook(true);

    try {
      const res = await fetch('/api/v2/ebooks/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          blueprint: currentBlueprint,
          executionResult,
        }),
      });
      const data = await res.json();
      if (data.success && data.manuscript) {
        setEbooks(prev => [data.manuscript, ...prev]);
        setActiveManuscript(data.manuscript);
        setIsBlueprintOpen(false);
        setActiveTab('reader');
      }
    } catch (e) {
      console.error('Error generating manuscript:', e);
    } finally {
      setIsGeneratingEbook(false);
    }
  };

  if (isSystemSetup === null) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-[#E0E0E0] flex flex-col justify-center items-center font-mono">
        <div className="space-y-3 text-center">
          <div className="w-12 h-12 border-2 border-t-2 border-t-[#FF3E00] border-[#222222] rounded-full animate-spin mx-auto" />
          <p className="text-xs uppercase text-[#888888] tracking-widest animate-pulse">
            Iniciando GOITGODS 2.1 Core...
          </p>
        </div>
      </div>
    );
  }

  if (isSystemSetup === false) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-[#E0E0E0] flex flex-col justify-center items-center font-mono p-4 selection:bg-[#FF3E00] selection:text-black">
        <div className="w-full max-w-lg bg-[#0F0F0F] border border-[#222222] border-t-4 border-t-[#FF3E00] p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#1A1A1A] border border-[#333333] text-amber-400 text-[10px] font-bold uppercase tracking-wider">
              <span>CONFIGURAÇÃO DE SEGURANÇA</span>
            </div>
            <h1 className="text-xl font-black text-white uppercase tracking-tight">
              Cadastro Inicial do Super Admin
            </h1>
            <p className="text-xs text-[#888888] font-sans">
              Detectamos que este sistema ainda não possui um operador principal registrado. Crie as credenciais mestre abaixo.
            </p>
          </div>

          {setupError && (
            <div className="bg-red-500/15 border border-red-500/50 text-red-400 text-xs p-3 font-semibold">
              [ERRO]: {setupError}
            </div>
          )}

          <form onSubmit={handleRegisterSuperAdmin} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] text-[#888888] uppercase font-bold">Nome Completo</label>
              <input
                type="text"
                placeholder="Ex: Gabriel Pasqual"
                value={setupFullName}
                onChange={e => setSetupFullName(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] px-3 py-2 text-xs text-white placeholder-[#444444] outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-[#888888] uppercase font-bold">Nome de Usuário / Login</label>
              <input
                type="text"
                placeholder="Ex: super_admin"
                value={setupUsername}
                onChange={e => setSetupUsername(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] px-3 py-2 text-xs text-white placeholder-[#444444] outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-[#888888] uppercase font-bold">E-mail de Segurança</label>
              <input
                type="email"
                placeholder="Ex: admin@pasquared.os"
                value={setupEmail}
                onChange={e => setSetupEmail(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] px-3 py-2 text-xs text-white placeholder-[#444444] outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-[#888888] uppercase font-bold">Senha do Super Admin (Chave Mestra)</label>
              <input
                type="password"
                placeholder="••••••••••••"
                value={setupPassword}
                onChange={e => setSetupPassword(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] px-3 py-2 text-xs text-white placeholder-[#444444] outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#FF3E00] hover:bg-white text-black font-black text-xs uppercase tracking-wider transition-all border border-[#FF3E00] hover:border-white mt-2"
            >
              Registrar Super Admin & Ativar Sistema
            </button>
          </form>

          <div className="border-t border-[#222222] pt-4 text-center">
            <span className="text-[10px] text-[#555555]">
              GOITGODS 2.0.1 + PASQUARED-OS — BANCO DE DADOS PERSISTENTE ATIVO
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#E0E0E0] flex flex-col font-sans selection:bg-[#FF3E00] selection:text-black">
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        ebookCount={ebooks.length}
        openEbookCount={() => setActiveTab('ebooks')}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {activeTab === 'search' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Apresentação Metodológica do Sistema */}
            <MethodologySlideshow />

            <ResearchAnamnesisPanel onTopicReady={(topic) => setSearchQuery(topic)} />

            {/* Hero Search Section */}
            <div className="bg-[#0F0F0F] border border-[#222222] border-t-4 border-t-[#FF3E00] p-6 sm:p-10 shadow-2xl relative overflow-hidden">
              <div className="max-w-3xl mx-auto space-y-6 text-center">
                <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#1A1A1A] border border-[#333333] text-[#00FF41] text-xs font-mono font-bold uppercase">
                  <Sparkles className="w-3.5 h-3.5 text-[#00FF41]" />
                  <span>VERSÃO 2.1 — PASQUARED-OS KNOWLEDGE INTELLIGENCE</span>
                </div>

                <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight uppercase">
                  O que você deseja pesquisar ou transformar em e-book sob medida?
                </h1>

                {/* Search Bar Input */}
                <div className="relative max-w-2xl mx-auto font-mono">
                  <div className="relative flex items-center bg-[#0A0A0A] border-2 border-[#222222] focus-within:border-[#FF3E00] p-1.5 transition-all">
                    <Search className="w-5 h-5 text-[#888888] ml-3 shrink-0" />
                    <input
                      id="input-main-search"
                      type="text"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleExecuteQuery()}
                      placeholder="Ex: Revolução Industrial, Primeira Guerra Mundial, IA Generativa..."
                      className="w-full bg-transparent px-3 py-3 text-sm text-white placeholder-[#555555] focus:outline-none"
                    />
                    <button
                      id="btn-main-search-execute"
                      onClick={() => handleExecuteQuery()}
                      disabled={isExecuting}
                      className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black uppercase px-5 py-3 transition-all text-xs sm:text-sm flex items-center space-x-2 shrink-0 disabled:opacity-50"
                    >
                      {isExecuting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                          <span>Arbitrando...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>Pesquisar</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Preset Themes */}
                <div className="flex flex-wrap items-center justify-center gap-2 text-xs pt-1 font-mono">
                  <span className="text-[#888888] font-bold flex items-center space-x-1 uppercase">
                    <History className="w-3.5 h-3.5" />
                    <span>Sugestões:</span>
                  </span>
                  {[
                    'Revolução Industrial',
                    'Primeira Guerra Mundial',
                    'Imprensa de Gutenberg',
                    'Inteligência Artificial Generativa',
                  ].map(preset => (
                    <button
                      key={preset}
                      onClick={() => handleExecuteQuery(preset)}
                      className="px-3 py-1 bg-[#0A0A0A] border border-[#222222] text-[#888888] hover:text-white hover:border-[#FF3E00] transition-all font-mono text-[11px] uppercase"
                    >
                      {preset}
                    </button>
                  ))}
                </div>

                {/* Quick Toggle Buttons for PFA & CHRONOS */}
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2 font-mono">
                  <button
                    id="btn-toggle-pfa-panel"
                    onClick={() => setShowPfaPanel(!showPfaPanel)}
                    className={`px-3.5 py-2 text-xs font-bold uppercase transition-all border flex items-center space-x-2 ${
                      showPfaPanel ? 'bg-[#FF3E00] text-black border-[#FF3E00]' : 'bg-[#0A0A0A] text-[#888888] border-[#222222] hover:text-white'
                    }`}
                  >
                    <Sliders className="w-4 h-4" />
                    <span>Configurar PFA ({formulation.mode})</span>
                    {showPfaPanel ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    id="btn-toggle-chronos-panel"
                    onClick={() => setShowChronosPanel(!showChronosPanel)}
                    className={`px-3.5 py-2 text-xs font-bold uppercase transition-all border flex items-center space-x-2 ${
                      showChronosPanel ? 'bg-[#00FF41] text-black border-[#00FF41]' : 'bg-[#0A0A0A] text-[#888888] border-[#222222] hover:text-white'
                    }`}
                  >
                    <Hourglass className="w-4 h-4" />
                    <span>Parâmetros CHRONOS</span>
                    {showChronosPanel ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    id="btn-quick-create-ebook-blueprint"
                    onClick={handleOpenBlueprint}
                    className="px-4 py-2 text-xs font-black uppercase bg-[#FF3E00] text-black hover:bg-white transition-all flex items-center space-x-2"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>Criar E-Book Sob Medida</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Collapsible PFA Formulation Panel */}
            {showPfaPanel && (
              <FormulationPanel
                formulation={formulation}
                onChange={setFormulation}
                onConfirm={() => setShowPfaPanel(false)}
              />
            )}

            {/* Collapsible CHRONOS Historical Profile Panel */}
            {showChronosPanel && (
              <HistoricalProfileSelector
                profile={researchProfile}
                onChange={setResearchProfile}
              />
            )}

            {/* Active Execution Results */}
            {executionResult && (
              <div className="space-y-6">
                {/* 1. Reasoning & ZEUS Arbitration Dashboard */}
                <ReasoningDashboard
                  result={executionResult}
                  onGenerateEbook={handleOpenBlueprint}
                />

                {/* 2. CHRONOS Historical Timeline */}
                {executionResult.historicalTimeline && (
                  <TimelineView timeline={executionResult.historicalTimeline} />
                )}

                {/* 3. Olympus Specialist Network Grid */}
                <GodsGrid weights={executionResult.selectedGods} />
              </div>
            )}
          </div>
        )}

        {/* E-Books Tab */}
        {activeTab === 'ebooks' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[#222222] pb-4">
              <div>
                <h2 className="text-xl font-black text-white uppercase tracking-tight">Acervo de E-Books Formulados</h2>
                <p className="text-xs text-[#888888] font-mono">
                  Obras personalizadas criadas com a matriz de evidências PASQUARED-OS
                </p>
              </div>

              <button
                onClick={handleOpenBlueprint}
                className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black uppercase px-4 py-2.5 text-xs flex items-center space-x-2 transition-all font-mono"
              >
                <BookOpen className="w-4 h-4" />
                <span>Novo E-Book</span>
              </button>
            </div>

            {ebooks.length === 0 ? (
              <div className="bg-[#0F0F0F] border border-[#222222] p-10 text-center space-y-4 font-mono">
                <BookOpen className="w-12 h-12 text-[#444444] mx-auto" />
                <h3 className="text-base font-bold text-white uppercase">Nenhum e-book gerado ainda</h3>
                <p className="text-xs text-[#888888] max-w-md mx-auto font-sans">
                  Execute uma pesquisa ou clique em &quot;Criar E-Book Sob Medida&quot; para compilar um livro com capítulos, matriz de evidências e leitor interativo.
                </p>
                <button
                  onClick={handleOpenBlueprint}
                  className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black uppercase px-5 py-2.5 text-xs transition-all"
                >
                  Formular Primeiro E-Book
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono">
                {ebooks.map(eb => (
                  <div
                    key={eb.ebook_id}
                    className="bg-[#0F0F0F] border border-[#222222] p-5 hover:border-[#FF3E00] transition-all space-y-3 flex flex-col justify-between group"
                  >
                    <div className="space-y-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-[#111111] text-[#00FF41] border border-[#00FF41]">
                        EQS Quality: {eb.qualityScore}
                      </span>
                      <h3 className="font-bold text-base text-white group-hover:text-[#FF3E00] transition-colors uppercase">
                        {eb.title}
                      </h3>
                      <p className="text-xs text-[#888888] line-clamp-2 font-sans">{eb.subtitle}</p>
                    </div>

                    <div className="pt-3 border-t border-[#222222] flex items-center justify-between text-xs">
                      <span className="text-[#888888] font-mono text-[11px]">
                        {eb.chapters.length} Capítulos
                      </span>
                      <button
                        onClick={() => {
                          setActiveManuscript(eb);
                          setActiveTab('reader');
                        }}
                        className="bg-[#0A0A0A] hover:bg-[#FF3E00] hover:text-black border border-[#333333] text-white px-3 py-1.5 font-bold transition-all flex items-center space-x-1 uppercase text-[11px]"
                      >
                        <span>Abrir Leitor</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* E-Book Reader Screen */}
        {activeTab === 'reader' && activeManuscript && (
          <EbookReader
            manuscript={activeManuscript}
            onClose={() => setActiveTab('ebooks')}
          />
        )}

        {/* Olympus Network Tab */}
        {activeTab === 'olympus' && (
          <div className="space-y-6 animate-fadeIn">
            <GodsGrid weights={executionResult?.selectedGods} />
            <OlympusEvolutionModal />
          </div>
        )}

        {/* Administration Panel Tab */}
        {activeTab === 'admin' && <AdminPanel />}
      </main>

      {/* Blueprint Modal */}
      {currentBlueprint && (
        <EbookBlueprintModal
          blueprint={currentBlueprint}
          isOpen={isBlueprintOpen}
          onClose={() => setIsBlueprintOpen(false)}
          onConfirmGenerate={handleConfirmGenerateEbook}
          isGenerating={isGeneratingEbook}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-[#222222] bg-[#0A0A0A] py-4 text-center text-xs text-[#666666] font-mono uppercase">
        <p>GOITGODS 2.0.1 + PASQUARED-OS — Especificação Integrada de Arquitetura & Motor de E-Books (2026)</p>
      </footer>
    </div>
  );
}
