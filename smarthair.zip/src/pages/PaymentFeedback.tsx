import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { CheckCircle, XCircle, Clock, ArrowLeft } from 'lucide-react';

export default function PaymentFeedback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const status = searchParams.get('status');
  const paymentId = searchParams.get('payment_id');
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate('/client/dashboard');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  const renderContent = () => {
    switch (status) {
      case 'success':
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-cyan-100 text-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Pagamento Confirmado!</h1>
            <p className="text-slate-600 mb-8">
              Seu sinal foi processado com sucesso. O agendamento agora está confirmado em nosso sistema.
            </p>
            {paymentId && (
              <p className="text-xs text-slate-400 mb-4">ID do Pagamento: {paymentId}</p>
            )}
          </div>
        );
      case 'failure':
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <XCircle className="w-12 h-12" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Ops! Algo deu errado.</h1>
            <p className="text-slate-600 mb-8">
              Não conseguimos processar seu pagamento. Por favor, tente novamente ou entre em contato com o salão.
            </p>
          </div>
        );
      case 'pending':
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Clock className="w-12 h-12" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Pagamento em Processamento</h1>
            <p className="text-slate-600 mb-8">
              Seu pagamento está sendo analisado pelo Mercado Pago. Assim que for aprovado, seu agendamento será confirmado automaticamente.
            </p>
          </div>
        );
      default:
        return (
          <div className="text-center">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">Status Indefinido</h1>
            <p className="text-slate-600 mb-8">Redirecionando você de volta ao painel...</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 md:p-12">
        {renderContent()}
        
        <div className="space-y-4">
          <button
            onClick={() => navigate('/client/dashboard')}
            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" /> Voltar ao Painel
          </button>
          <p className="text-center text-sm text-slate-400">
            Redirecionando automaticamente em {countdown} segundos...
          </p>
        </div>
      </div>
    </div>
  );
}
