import { db } from './src/lib/db.js';
import bcrypt from 'bcryptjs';

async function updateSuperAdmin() {
  const adminEmail = 'admin@siae.space';
  const adminPassword = '21490905@Siae-roger-577';
  
  try {
    const hashedPassword = await bcrypt.hash(adminPassword, 10);
    
    // Check if any super admin exists
    const [rows] = await db.query("SELECT * FROM users WHERE role = 'super_admin'");
    const existingAdmins = rows as Record<string, any>[];
    
    if (existingAdmins.length > 0) {
      console.log('Found existing super_admin. Updating email and password...');
      await db.query(`
        UPDATE users 
        SET email = ?, password = ? 
        WHERE id = ?
      `, [adminEmail, hashedPassword, existingAdmins[0].id]);
      console.log('Super admin credentials updated.');
    } else {
      console.log('No super_admin exists. Creating one...');
      // check if email already exists
      const [emailRows] = await db.query("SELECT * FROM users WHERE email = ?", [adminEmail]);
      if ((emailRows as any[]).length > 0) {
         console.log('User with this email exists but is not super_admin. Updating role and password.');
          await db.query(`
            UPDATE users 
            SET role = 'super_admin', password = ?
            WHERE id = ?
           `, [hashedPassword, (emailRows as any[])[0].id]);
      } else {
         await db.query(`
            INSERT INTO users (first_name, last_name, email, password, role) 
            VALUES ('Super', 'Admin', ?, ?, 'super_admin')
        `, [adminEmail, hashedPassword]);
      }
      console.log('Super admin created.');
    }
  } catch (err) {
    console.error('Error updating super admin:', err);
  } finally {
    process.exit(0);
  }
}

updateSuperAdmin();
