import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft, ArrowRight, BadgeCheck, Camera, Coins, HeartHandshake,
  Images, MessageCircle, Play, Radio, ShieldCheck, SkipForward,
  Sparkles, Users, Video, Volume2, VolumeX, Zap
} from 'lucide-react';

interface IntroScreenProps {
  onEnterApp: () => void;
  targetRoute?: string;
}

const marketingSlides = [
  {
    eyebrow: 'PROMOÇÃO DE BOAS-VINDAS',
    title: '60 MINUTOS FREE PARA COMEÇAR',
    text: 'Novo cadastro recebe PASQcoin equivalentes a 60 minutos de uso no chat com texto, áudio e vídeo. Benefício único por CPF, exclusivo para novos usuários.',
    icon: Coins,
    badge: 'CADASTRE-SE • RECEBA • CONVERSE',
  },
  {
    eyebrow: 'CONVERSAS DO SEU JEITO',
    title: 'TEXTO, ÁUDIO E VÍDEO EM UM SÓ LUGAR',
    text: 'Converse em tempo real, alterne entre formatos e escolha como quer se conectar. Uma experiência criada para aproximar pessoas sem complicação.',
    icon: MessageCircle,
    badge: 'CHAT MULTIMÍDIA',
  },
  {
    eyebrow: 'ENCONTROS AO VIVO',
    title: 'SALAS DE VÍDEO PARA CONHECER E INTERAGIR',
    text: 'Entre em salas, participe de conversas ao vivo e encontre novas pessoas em ambientes de interação com vídeo, áudio e chat.',
    icon: Video,
    badge: 'SALAS • VÍDEO • PRESENÇA',
  },
  {
    eyebrow: 'SEU ESPAÇO SOCIAL',
    title: 'PERFIL, CAPA E GALERIA DE FOTOS E VÍDEOS',
    text: 'Personalize seu perfil, publique sua identidade visual e mantenha sua própria galeria de mídia. Defina fotos de perfil e capa direto da galeria.',
    icon: Images,
    badge: 'PERFIL SOCIAL',
  },
  {
    eyebrow: 'CONEXÕES QUE CONTINUAM',
    title: 'AMIZADES E CHAT 1×1',
    text: 'Envie solicitações de amizade, mantenha seus contatos por perto e abra conversas individuais para continuar aquela conexão que começou no Chamasso.',
    icon: HeartHandshake,
    badge: 'CONTATOS • AMIZADES • 1×1',
  },
  {
    eyebrow: 'AO VIVO AGORA',
    title: 'TRANSMISSÕES PARA COMPARTILHAR O MOMENTO',
    text: 'Use os recursos de transmissão ao vivo para criar presença, compartilhar momentos e ampliar a interação com outros membros da comunidade.',
    icon: Radio,
    badge: 'LIVE',
  },
  {
    eyebrow: 'DESCUBRA NOVAS CONEXÕES',
    title: 'FIND MATCH COM PASQUARED',
    text: 'Explore o recurso de descoberta e compatibilidade do Chamasso para encontrar perfis e novas possibilidades de conexão dentro da plataforma.',
    icon: Users,
    badge: 'PASQUARED • FIND MATCH',
  },
  {
    eyebrow: 'TEMPO SOB SEU CONTROLE',
    title: 'PASQCOIN: USE, ACOMPANHE E RECARREGUE',
    text: 'A carteira PASQcoin transforma créditos em tempo de utilização. Acompanhe seu saldo e recarregue quando quiser continuar suas conversas.',
    icon: Zap,
    badge: 'CARTEIRA PASQCOIN',
  },
  {
    eyebrow: 'MAIS CONTROLE PARA SUA CONTA',
    title: 'SEGURANÇA E PRIVACIDADE',
    text: 'Recursos de autenticação, controles de conta e opções de privacidade ajudam você a administrar sua experiência e suas conexões no site.',
    icon: ShieldCheck,
    badge: 'CONTA PROTEGIDA',
  },
  {
    eyebrow: 'CHAMASSO LIVE CHAT',
    title: 'NÃO É SÓ CHAT. É O SEU NOVO POINT.',
    text: 'Conheça pessoas, converse, apareça, compartilhe e crie conexões. Faça seu cadastro e aproveite a promoção de boas-vindas para experimentar o Chamasso.',
    icon: Sparkles,
    badge: 'SEU POINT DE ENCONTROS',
  },
];

export const IntroScreen: React.FC<IntroScreenProps> = ({ onEnterApp, targetRoute = '/app' }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoEnded, setVideoEnded] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [slide, setSlide] = useState(0);
  const [transitioning, setTransitioning] = useState(false);

  const goToSlide = (next: number) => {
    setTransitioning(true);
    window.setTimeout(() => {
      setSlide((next + marketingSlides.length) % marketingSlides.length);
      setTransitioning(false);
    }, 260);
  };

  useEffect(() => {
    if (!videoEnded) return;
    const timer = window.setInterval(() => goToSlide(slide + 1), 6500);
    return () => window.clearInterval(timer);
  }, [videoEnded, slide]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
  }, []);

  const replay = () => {
    setVideoEnded(false); setSlide(0); setProgress(0);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    }
  };

  const enter = () => {
    window.history.pushState({}, '', targetRoute);
    onEnterApp();
  };

  const current = marketingSlides[slide];
  const Icon = current.icon;

  return (
    <div className="relative w-full h-screen bg-[#05070b] overflow-hidden select-none">
      <div className="absolute -top-32 -left-20 w-[34rem] h-[34rem] bg-cyan-400/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-40 -right-20 w-[38rem] h-[38rem] bg-blue-600/15 rounded-full blur-3xl" />

      <video
        ref={videoRef} src="/chamasso_in.mp4" playsInline autoPlay muted={isMuted}
        onEnded={() => setVideoEnded(true)}
        onTimeUpdate={() => {
          const v = videoRef.current;
          if (!v?.duration) return;
          setProgress((v.currentTime / v.duration) * 100);
          if (v.duration - v.currentTime <= .35) setVideoEnded(true);
        }}
        className={`absolute inset-0 w-full h-full object-contain transition-all duration-1000 ${videoEnded ? 'opacity-10 scale-110 blur-xl' : 'opacity-100'}`}
      />

      {!videoEnded && <>
        <div className="absolute top-5 right-5 z-30 flex gap-2">
          <button onClick={() => { if (videoRef.current) videoRef.current.muted = !isMuted; setIsMuted(!isMuted); }} className="p-3 rounded-full bg-black/60 border border-cyan-400/30 text-cyan-300 backdrop-blur-xl">
            {isMuted ? <VolumeX size={18}/> : <Volume2 size={18}/>} 
          </button>
          <button onClick={() => { videoRef.current?.pause(); setVideoEnded(true); }} className="px-4 py-2 rounded-full bg-black/60 border border-white/15 text-sm text-white backdrop-blur-xl flex items-center gap-2">Pular <SkipForward size={16}/></button>
        </div>
        {!isPlaying && <button onClick={() => videoRef.current?.play().then(() => setIsPlaying(true))} className="absolute z-30 inset-0 m-auto w-fit h-fit px-7 py-4 rounded-full bg-cyan-400 text-black font-black flex items-center gap-2"><Play size={20}/> Reproduzir</button>}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/70"><div className="h-full bg-cyan-400 transition-all" style={{width:`${progress}%`}} /></div>
      </>}

      {videoEnded && (
        <div className="absolute inset-0 z-40 flex items-center justify-center px-4 sm:px-8 bg-gradient-to-b from-[#05070b]/75 via-[#07111a]/80 to-[#05070b] backdrop-blur-sm">
          <div className={`w-full max-w-5xl transition-all duration-500 ${transitioning ? 'opacity-0 blur-xl scale-[.97]' : 'opacity-100 blur-0 scale-100'}`}>
            <div className="mx-auto w-fit mb-5 px-4 py-2 rounded-full border border-cyan-300/30 bg-cyan-400/10 text-cyan-200 text-[10px] sm:text-xs font-black tracking-[.25em] uppercase flex items-center gap-2">
              <BadgeCheck size={15}/> {current.eyebrow}
            </div>

            <div className="text-center">
              <div className="mx-auto mb-5 w-20 h-20 rounded-3xl border border-cyan-300/40 bg-cyan-400/10 flex items-center justify-center shadow-[0_0_45px_rgba(34,211,238,.2)]">
                <Icon size={38} className="text-cyan-300"/>
              </div>
              <h1 className="text-3xl sm:text-5xl md:text-6xl font-black italic uppercase tracking-tight text-white leading-[1.02] drop-shadow-[0_0_25px_rgba(34,211,238,.25)]">{current.title}</h1>
              <p className="mt-5 max-w-3xl mx-auto text-sm sm:text-lg text-slate-300 leading-relaxed">{current.text}</p>
              <p className="mt-5 text-cyan-300 text-xs sm:text-sm font-black tracking-[.22em] uppercase">{current.badge}</p>
            </div>

            <div className="mt-8 flex items-center justify-center gap-3">
              <button onClick={() => goToSlide(slide - 1)} aria-label="Slide anterior" className="p-3 rounded-full border border-white/15 bg-white/5 text-white hover:border-cyan-300/60 hover:text-cyan-300 transition"><ArrowLeft size={20}/></button>
              <div className="flex gap-1.5">{marketingSlides.map((_, i) => <button key={i} onClick={() => goToSlide(i)} aria-label={`Ir para slide ${i+1}`} className={`h-2 rounded-full transition-all ${i === slide ? 'w-8 bg-cyan-300' : 'w-2 bg-white/25 hover:bg-white/50'}`} />)}</div>
              <button onClick={() => goToSlide(slide + 1)} aria-label="Próximo slide" className="p-3 rounded-full border border-white/15 bg-white/5 text-white hover:border-cyan-300/60 hover:text-cyan-300 transition"><ArrowRight size={20}/></button>
            </div>

            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button onClick={enter} className="group px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-300 to-sky-500 text-[#031018] font-black uppercase tracking-wider shadow-[0_0_35px_rgba(34,211,238,.3)] hover:scale-105 active:scale-95 transition flex items-center gap-2">
                <Sparkles size={19}/> Entrar no Chamasso <ArrowRight size={19} className="group-hover:translate-x-1 transition"/>
              </button>
              <button onClick={replay} className="px-5 py-3 text-xs text-slate-400 hover:text-cyan-300 transition">Rever vinheta</button>
            </div>

            <p className="mt-4 text-center text-[10px] sm:text-xs text-slate-500">* Promoção: crédito equivalente a 60 minutos para novos cadastros elegíveis, uma única vez por CPF. O consumo segue as regras vigentes da plataforma.</p>
          </div>
        </div>
      )}
    </div>
  );
};
