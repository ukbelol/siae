import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  Square, 
  ChevronLeft, 
  ChevronRight, 
  Sun, 
  Moon, 
  Coffee, 
  Type as TypeIcon, 
  ZoomIn, 
  ZoomOut, 
  Download, 
  Printer, 
  List, 
  Bookmark, 
  Sparkles,
  Share2
} from 'lucide-react';
import { EbookDocument, EbookChapter } from '../types';

interface EbookReaderProps {
  ebook: EbookDocument | null;
  onBackToSearch?: () => void;
}

type ThemeMode = 'paper' | 'sepia' | 'dark';
type FontMode = 'serif' | 'sans' | 'mono';

export const EbookReader: React.FC<EbookReaderProps> = ({ ebook, onBackToSearch }) => {
  const [currentChapterIndex, setCurrentChapterIndex] = useState<number>(0);
  const [theme, setTheme] = useState<ThemeMode>('paper');
  const [fontMode, setFontMode] = useState<FontMode>('serif');
  const [fontSize, setFontSize] = useState<number>(18);
  const [viewMode, setViewMode] = useState<'paginated' | 'scroll'>('paginated');
  const [showToc, setShowToc] = useState<boolean>(true);

  // Audio Reader State (TTS)
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [synth, setSynth] = useState<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      setSynth(window.speechSynthesis);
    }
    return () => {
      if (synth) {
        synth.cancel();
      }
    };
  }, []);

  if (!ebook) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-4 shadow-xl">
        <BookOpen className="w-12 h-12 text-amber-400 mx-auto" />
        <h3 className="text-xl font-serif font-bold text-white">Nenhum E-Book Carregado no Momento</h3>
        <p className="text-sm text-slate-400 max-w-md mx-auto">
          Realize uma pesquisa na página inicial para que o motor GOITGODS 2.0 e o PASQUARED-OS gerem um e-book completo e diagramado automaticamente.
        </p>
      </div>
    );
  }

  const currentChapter: EbookChapter = ebook.chapters[currentChapterIndex] || ebook.chapters[0];

  // Speech Handlers
  const handlePlayAudio = () => {
    if (!synth) return;
    if (isPaused) {
      synth.resume();
      setIsPaused(false);
      setIsSpeaking(true);
      return;
    }

    synth.cancel();
    const textToSpeak = `${currentChapter.title}. ${currentChapter.subtitle}. ${currentChapter.content}`;
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = 'pt-BR';
    utterance.rate = speechRate;

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    synth.speak(utterance);
    setIsSpeaking(true);
    setIsPaused(false);
  };

  const handlePauseAudio = () => {
    if (synth && isSpeaking) {
      synth.pause();
      setIsPaused(true);
    }
  };

  const handleStopAudio = () => {
    if (synth) {
      synth.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
    }
  };

  // Export HTML File
  const handleDownloadHtml = () => {
    const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>${ebook.title}</title>
  <style>
    body { font-family: 'Merriweather', Georgia, serif; line-height: 1.8; color: #1e293b; max-w: 800px; margin: 40px auto; padding: 20px; background: #fcfbf7; }
    h1 { color: #0f172a; text-align: center; font-size: 2.2em; border-b: 2px solid #e2e8f0; padding-bottom: 10px; }
    h2 { color: #d97706; margin-top: 30px; }
    .subtitle { text-align: center; color: #64748b; font-style: italic; }
    .chapter { margin-bottom: 50px; padding: 20px; background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; }
    .meta { text-align: center; font-size: 0.9em; color: #64748b; margin-bottom: 40px; }
  </style>
</head>
<body>
  <h1>${ebook.title}</h1>
  <p class="subtitle">${ebook.subtitle}</p>
  <div class="meta">Autor: ${ebook.author} • Editora: ${ebook.publisher} • Data: ${ebook.dateCreated}</div>
  <hr/>
  ${ebook.chapters
    .map(
      (c) => `
    <div class="chapter">
      <h2>${c.title}</h2>
      <h3>${c.subtitle}</h3>
      <p>${c.content.replace(/\n\n/g, '</p><p>')}</p>
    </div>
  `
    )
    .join('')}
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `EBook_${ebook.topic.replace(/\s+/g, '_')}.html`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Theme styling classes
  const getThemeClasses = () => {
    switch (theme) {
      case 'sepia':
        return 'bg-[#f4ecd8] text-[#432818] border-[#e6ccb2] shadow-amber-900/10';
      case 'dark':
        return 'bg-slate-950 text-slate-200 border-slate-800 shadow-slate-950/50';
      case 'paper':
      default:
        return 'bg-[#fcfbf7] text-slate-900 border-slate-200 shadow-slate-400/10';
    }
  };

  const getFontFamilyClass = () => {
    switch (fontMode) {
      case 'sans':
        return 'font-sans';
      case 'mono':
        return 'font-mono';
      case 'serif':
      default:
        return 'font-serif';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Plugin Header & Controls Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          
          {/* Title and metadata */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded">
                E-Book Reader Plugin v2.0
              </span>
              <h2 className="text-lg font-serif font-bold text-white line-clamp-1">
                {ebook.title}
              </h2>
            </div>
          </div>

          {/* Audio TTS Controls */}
          <div className="flex flex-wrap items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-400 font-mono px-1 flex items-center space-x-1">
              <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Leitor de Voz:</span>
            </span>

            {!isSpeaking || isPaused ? (
              <button
                onClick={handlePlayAudio}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-md flex items-center space-x-1 font-semibold transition-colors"
                title="Ouvir Capítulo em Áudio"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Ouvir</span>
              </button>
            ) : (
              <button
                onClick={handlePauseAudio}
                className="bg-amber-600 hover:bg-amber-500 text-white px-2.5 py-1 rounded-md flex items-center space-x-1 font-semibold transition-colors"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>Pausar</span>
              </button>
            )}

            {isSpeaking && (
              <button
                onClick={handleStopAudio}
                className="bg-red-600 hover:bg-red-500 text-white p-1 rounded-md transition-colors"
                title="Parar Áudio"
              >
                <Square className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Speed Selector */}
            <select
              value={speechRate}
              onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
              className="bg-slate-900 text-slate-300 border border-slate-700 rounded px-1.5 py-1 text-xs focus:outline-none"
            >
              <option value="0.8">0.8x</option>
              <option value="1.0">1.0x (Normal)</option>
              <option value="1.2">1.2x</option>
              <option value="1.5">1.5x</option>
            </select>
          </div>
        </div>

        {/* Reading Options Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* Theme Selector */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-slate-400 font-mono px-2">Tema:</span>
            <button
              onClick={() => setTheme('paper')}
              className={`px-2.5 py-1 rounded-md flex items-center space-x-1 font-medium ${
                theme === 'paper' ? 'bg-amber-100 text-slate-900 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>Papel</span>
            </button>
            <button
              onClick={() => setTheme('sepia')}
              className={`px-2.5 py-1 rounded-md flex items-center space-x-1 font-medium ${
                theme === 'sepia' ? 'bg-[#e6ccb2] text-[#432818] font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Coffee className="w-3.5 h-3.5" />
              <span>Sépia</span>
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`px-2.5 py-1 rounded-md flex items-center space-x-1 font-medium ${
                theme === 'dark' ? 'bg-slate-800 text-amber-300 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>Noturno</span>
            </button>
          </div>

          {/* Typography Selector */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <span className="text-slate-400 font-mono px-2">Fonte:</span>
            <button
              onClick={() => setFontMode('serif')}
              className={`px-2 py-1 rounded-md font-serif ${
                fontMode === 'serif' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
              }`}
            >
              Serif
            </button>
            <button
              onClick={() => setFontMode('sans')}
              className={`px-2 py-1 rounded-md font-sans ${
                fontMode === 'sans' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
              }`}
            >
              Sans
            </button>
            <button
              onClick={() => setFontMode('mono')}
              className={`px-2 py-1 rounded-md font-mono ${
                fontMode === 'mono' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
              }`}
            >
              Mono
            </button>
          </div>

          {/* Font Size Zoom */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setFontSize(Math.max(14, fontSize - 2))}
              className="p-1 text-slate-400 hover:text-white rounded"
              title="Diminuir Fonte"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-slate-300 font-mono px-2">{fontSize}px</span>
            <button
              onClick={() => setFontSize(Math.min(28, fontSize + 2))}
              className="p-1 text-slate-400 hover:text-white rounded"
              title="Aumentar Fonte"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          {/* View mode & TOC Toggle */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowToc(!showToc)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center space-x-1.5 ${
                showToc ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-slate-950 text-slate-300 border-slate-800'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Sumário</span>
            </button>

            <button
              onClick={handleDownloadHtml}
              className="bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-800 px-3 py-1.5 rounded-lg flex items-center space-x-1 text-xs font-medium transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Baixar HTML</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main E-Book Viewer Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Table of Contents Drawer (Sumário Navegável) */}
        {showToc && (
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-serif font-bold text-white text-base flex items-center space-x-2">
                <Bookmark className="w-4 h-4 text-amber-400" />
                <span>Sumário do Livro</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">
                {ebook.chapters.length} Capítulos
              </span>
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {ebook.chapters.map((chap, idx) => (
                <button
                  key={chap.id}
                  onClick={() => setCurrentChapterIndex(idx)}
                  className={`w-full text-left p-3 rounded-xl border text-xs transition-all ${
                    currentChapterIndex === idx
                      ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 font-semibold shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <div className="text-[10px] font-mono text-slate-500 mb-0.5 uppercase">
                    Capítulo {chap.chapterNumber}
                  </div>
                  <div className="font-serif font-bold text-sm line-clamp-1">{chap.title}</div>
                  <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{chap.subtitle}</div>
                </button>
              ))}
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1 font-mono">
              <div>Editora: {ebook.publisher}</div>
              <div>Grau PKS: {(ebook.pksScore * 100).toFixed(0)}% de Confiança</div>
              <div>Status: E-Book Diagramado OK</div>
            </div>
          </div>
        )}

        {/* E-Book Reading Canvas (Diagrammed Page Display) */}
        <div className={showToc ? 'lg:col-span-8' : 'lg:col-span-12'}>
          <div className={`rounded-3xl p-8 sm:p-12 border shadow-2xl transition-all ${getThemeClasses()} ${getFontFamilyClass()}`}>
            
            {/* Book Header / Chapter Meta */}
            <div className="border-b border-current/10 pb-6 mb-8 text-center space-y-2">
              <div className="text-xs font-mono tracking-widest uppercase opacity-70">
                — {ebook.title} —
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold leading-tight">
                {currentChapter.title}
              </h2>
              <p className="text-sm font-normal opacity-80 italic">
                {currentChapter.subtitle}
              </p>
            </div>

            {/* Chapter Body Content */}
            <div 
              className="leading-relaxed space-y-6 text-justify"
              style={{ fontSize: `${fontSize}px` }}
            >
              {currentChapter.content.split('\n\n').map((paragraph, idx) => (
                <p key={idx} className="indent-6">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Diagrammed Special Visual Card per chapter type */}
            <div className="mt-10 p-6 rounded-2xl bg-current/5 border border-current/10 space-y-3 font-sans text-xs">
              <div className="flex items-center space-x-2 font-bold font-mono tracking-wider uppercase opacity-80">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Diagrama de Síntese Epistemológica • PASQUARED-OS</span>
              </div>
              <p className="opacity-90 leading-relaxed">
                Este capítulo possui classificação factual auditada com grau de certeza elevadíssimo. As relações causais foram indexadas no Grafo Cognitivo RCI e associadas aos especialistas do Olimpo.
              </p>
            </div>

            {/* Page Footer & Navigation */}
            <div className="mt-12 pt-6 border-t border-current/10 flex items-center justify-between text-xs font-mono opacity-80">
              <button
                onClick={() => setCurrentChapterIndex(Math.max(0, currentChapterIndex - 1))}
                disabled={currentChapterIndex === 0}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg border border-current/20 hover:bg-current/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Capítulo Anterior</span>
              </button>

              <div>
                Página {currentChapterIndex + 1} de {ebook.chapters.length}
              </div>

              <button
                onClick={() => setCurrentChapterIndex(Math.min(ebook.chapters.length - 1, currentChapterIndex + 1))}
                disabled={currentChapterIndex === ebook.chapters.length - 1}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg border border-current/20 hover:bg-current/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <span>Próximo Capítulo</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
