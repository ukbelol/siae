import React, { useState, useEffect } from 'react';
import { Trash2, Edit, X, CheckCircle, Search, Users, Power } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminHousesManager({ houses, usersList, loadData }: { houses: any[], usersList: any[], loadData: () => void }) {
  const [editHouse, setEditHouse] = useState<any>(null);
  const [expandedHouse, setExpandedHouse] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleUpdateHouse = async (e: any) => {
    e.preventDefault();
    try {
      await fetch(`/api/admin/houses/${editHouse.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editHouse)
      });
      setEditHouse(null);
      loadData();
      toast.success('Casa Espírita atualizada com sucesso!');
    } catch(err) {
      toast.error('Erro ao atualizar casa espírita');
    }
  };

  const handleToggleHouseStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    try {
      await fetch(`/api/admin/houses/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      loadData();
      toast.success(newStatus === 'active' ? 'Casa Espírita ativada com sucesso!' : 'Casa Espírita desativada com sucesso!');
    } catch (e) {
      toast.error('Erro ao alterar status da casa espírita');
    }
  };

  const filteredHouses = houses.filter(h => {
     if (!searchTerm) return true;
     const s = searchTerm.toLowerCase();
     return (h.name && h.name.toLowerCase().includes(s)) || (h.cnpj && h.cnpj.includes(s)) || (h.city && h.city.toLowerCase().includes(s));
  });

  const getHouseUsers = (houseId: number) => {
     return usersList.filter(u => u.house_relations?.some((hr: any) => hr.house_id === houseId));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h3 className="text-xl font-bold text-gray-800">Gerenciamento de Casas Espíritas</h3>
        <div className="relative w-full md:w-64">
           <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
           <input 
             type="text" 
             placeholder="Buscar Casa..."
             value={searchTerm}
             onChange={e => setSearchTerm(e.target.value)}
             className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm focus:ring-1 focus:ring-indigo-500"
           />
        </div>
      </div>

      {editHouse && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
             <div className="flex justify-between items-center p-6 border-b sticky top-0 bg-white">
               <h3 className="text-xl font-bold flex items-center gap-2"><Edit className="w-5 h-5"/> Editar Casa: {editHouse.name}</h3>
               <button onClick={() => setEditHouse(null)} className="text-gray-500 hover:text-black"><X className="w-6 h-6"/></button>
             </div>
             <form onSubmit={handleUpdateHouse} className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                   <div className="md:col-span-3 flex items-center gap-4 border-b pb-4">
                     <img src={editHouse.photo_url || 'https://via.placeholder.com/150'} alt="House Cover" className="w-20 h-20 rounded-lg object-cover border-2 shadow-sm" />
                     <div className="flex-1">
                        <label className="block text-xs font-bold text-gray-700 mb-1">URL da Foto / Logotipo</label>
                        <input type="text" className="w-full border rounded px-3 py-2 text-sm" value={editHouse.photo_url || ''} onChange={e => setEditHouse({...editHouse, photo_url: e.target.value})} />
                     </div>
                   </div>
                   
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Status (Ativo/Inativo)</label>
                   <select className={`w-full border rounded px-3 py-2 font-bold ${editHouse.status === 'active' ? 'text-green-700' : 'text-red-700'}`} value={editHouse.status || 'active'} onChange={e => setEditHouse({...editHouse, status: e.target.value})}>
                      <option value="active">🟢 Ativa</option>
                      <option value="inactive">🔴 Inativa</option>
                   </select></div>
                   
                   <div className="md:col-span-2"><label className="block text-xs font-bold text-gray-700 mb-1">Nome da Casa Espírita</label><input required type="text" className="w-full border rounded px-3 py-2" value={editHouse.name} onChange={e => setEditHouse({...editHouse, name: e.target.value})} /></div>
                   
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">CNPJ</label><input required type="text" className="w-full border rounded px-3 py-2" value={editHouse.cnpj} onChange={e => setEditHouse({...editHouse, cnpj: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Telefone/WhatsApp</label><input type="text" className="w-full border rounded px-3 py-2" value={editHouse.phone || ''} onChange={e => setEditHouse({...editHouse, phone: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">E-mail de Contato</label><input required type="email" className="w-full border rounded px-3 py-2" value={editHouse.email || ''} onChange={e => setEditHouse({...editHouse, email: e.target.value})} /></div>
                   
                   <div className="md:col-span-3 mt-4 border-t pt-4">
                     <h4 className="font-bold text-gray-800 mb-4">Endereço Completo</h4>
                   </div>
                   <div className="md:col-span-2"><label className="block text-xs font-bold text-gray-700 mb-1">Rua / Logradouro</label><input type="text" className="w-full border rounded px-3 py-2" value={editHouse.street || ''} onChange={e => setEditHouse({...editHouse, street: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">CEP</label><input type="text" placeholder="00000-000" className="w-full border rounded px-3 py-2" value={editHouse.cep || ''} onChange={e => setEditHouse({...editHouse, cep: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Número</label><input type="text" className="w-full border rounded px-3 py-2" value={editHouse.number || ''} onChange={e => setEditHouse({...editHouse, number: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Bairro</label><input type="text" className="w-full border rounded px-3 py-2" value={editHouse.neighborhood || ''} onChange={e => setEditHouse({...editHouse, neighborhood: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Cidade</label><input type="text" className="w-full border rounded px-3 py-2" value={editHouse.city || ''} onChange={e => setEditHouse({...editHouse, city: e.target.value})} /></div>
                   <div><label className="block text-xs font-bold text-gray-700 mb-1">Estado (UF)</label><input type="text" maxLength={2} className="w-full border rounded px-3 py-2" value={editHouse.state || ''} onChange={e => setEditHouse({...editHouse, state: e.target.value})} /></div>
                </div>
                
                <div className="flex justify-end gap-3 border-t pt-6">
                  <button type="button" onClick={() => setEditHouse(null)} className="px-6 py-2 border rounded-lg font-bold text-gray-700 hover:bg-gray-50">Cancelar</button>
                  <button type="submit" className="bg-indigo-600 text-white px-8 py-2 rounded-lg hover:bg-indigo-700 font-bold flex items-center gap-2"><CheckCircle className="w-5 h-5"/> Gravar e Atualizar</button>
                </div>
             </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
        <table className="w-full text-left min-w-max">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-4 font-bold text-gray-700 text-sm">Foto</th>
              <th className="p-4 font-bold text-gray-700 text-sm">Identidade & Endereço</th>
              <th className="p-4 font-bold text-gray-700 text-sm">Contato</th>
              <th className="p-4 font-bold text-gray-700 text-sm text-center">Membros</th>
              <th className="p-4 font-bold text-gray-700 text-sm text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filteredHouses.map((h: any) => {
              const hUsers = getHouseUsers(h.id);
              const isExpanded = expandedHouse === h.id;
              
              return (
                <React.Fragment key={h.id}>
                  <tr className="border-t hover:bg-indigo-50/50 transition">
                     <td className="p-4">
                      <img src={h.photo_url || 'https://via.placeholder.com/60'} alt="House" className="w-16 h-16 rounded-xl object-cover border border-gray-200 shadow-sm" />
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-gray-900 text-lg flex items-center gap-2">
                        {h.name}
                        {h.status !== 'active' && <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full uppercase">Inativa</span>}
                      </div>
                      <div className="text-sm text-gray-500 mt-1">CNPJ: {h.cnpj}</div>
                      <div className="text-xs text-gray-500 mt-2 flex gap-1 items-center">
                         <span>📍 {h.street}, {h.number} - {h.city}/{h.state}</span>
                      </div>
                    </td>
                    <td className="p-4 text-sm text-gray-600">
                      <div className="flex flex-col gap-1">
                        <span>📧 {h.email || 'N/I'}</span>
                        <span>📱 {h.phone || 'N/I'}</span>
                      </div>
                    </td>
                    <td className="p-4 text-center">
                       <button onClick={() => setExpandedHouse(isExpanded ? null : h.id)} className="inline-flex items-center gap-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 px-3 py-1.5 rounded-lg text-sm font-bold transition">
                          <Users className="w-4 h-4"/> 
                          {hUsers.length} Membros
                       </button>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-1">
                        <button 
                          onClick={() => handleToggleHouseStatus(h.id, h.status)} 
                          className={`p-2 rounded-md transition-colors ${h.status === 'active' ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-emerald-600 bg-emerald-50 hover:bg-emerald-100'}`} 
                          title={h.status === 'active' ? 'Desativar Casa' : 'Ativar Casa'}
                        >
                          <Power className="w-5 h-5"/>
                        </button>
                        <button onClick={() => setEditHouse(h)} className="text-indigo-600 bg-indigo-50 hover:bg-indigo-100 p-2 rounded-md transition-colors" title="Editar Casa"><Edit className="w-5 h-5"/></button>
                        <button onClick={() => {
                          if(window.confirm('Excluir esta casa espírita?')) {
                            fetch(`/api/admin/houses/${h.id}`, { method: 'DELETE' }).then(() => loadData());
                          }
                        }} className="text-red-500 bg-red-50 hover:bg-red-100 p-2 rounded-md transition-colors" title="Excluir"><Trash2 className="w-5 h-5"/></button>
                      </div>
                    </td>
                  </tr>
                  
                  {isExpanded && (
                    <tr>
                      <td colSpan={5} className="p-0 border-t bg-gray-50/50">
                        <div className="p-4 md:p-6 bg-gradient-to-br from-indigo-50/50 to-white inset-shadow-sm border-b overflow-x-auto">
                           <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                             <Users className="w-5 h-5 text-indigo-600" /> Membros da Casa: {h.name}
                           </h4>
                           {hUsers.length > 0 ? (
                             <table className="w-full text-sm text-left bg-white rounded-lg shadow-sm overflow-hidden border">
                               <thead className="bg-gray-100/80">
                                 <tr>
                                   <th className="p-3 text-gray-600 font-bold">Foto</th>
                                   <th className="p-3 text-gray-600 font-bold">Nome</th>
                                   <th className="p-3 text-gray-600 font-bold">Contato</th>
                                   <th className="p-3 text-gray-600 font-bold">Função</th>
                                 </tr>
                               </thead>
                               <tbody>
                                 {hUsers.map(u => (
                                   <tr key={u.id} className="border-t">
                                     <td className="p-3"><img src={u.photo_url || 'https://via.placeholder.com/40'} alt="User" className="w-8 h-8 rounded-full object-cover border" /></td>
                                     <td className="p-3 font-semibold text-gray-800">{u.first_name} {u.last_name}<br/><span className="text-xs text-gray-400 font-normal">CPF: {u.cpf}</span></td>
                                     <td className="p-3 text-gray-600 text-xs">{u.email}<br/>{u.phone}</td>
                                     <td className="p-3">
                                       <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold border ${u.role === 'super_admin' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : u.role === 'representative' ? 'bg-purple-50 text-purple-700 border-purple-200' : u.role === 'worker' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-gray-100 text-gray-700 border-gray-200'}`}>
                                         {u.role === 'super_admin' ? 'Super Admin' : u.role === 'representative' ? 'Representante' : u.role === 'worker' ? 'Trabalhador' : 'Assistido'}
                                       </span>
                                     </td>
                                   </tr>
                                 ))}
                               </tbody>
                             </table>
                           ) : (
                             <div className="text-gray-500 text-sm">Nenhum membro vinculado a esta casa.</div>
                           )}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
            {filteredHouses.length === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-gray-500">Nenhuma casa encontrada.</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}
