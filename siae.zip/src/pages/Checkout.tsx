import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, ArrowLeft, Loader2, CheckCircle2, ShieldCheck, Truck, Sparkles, Copy, Check } from 'lucide-react';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';

export default function Checkout() {
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(window.location.search);
  const isFromPromo = queryParams.get('ref') === 'propaganda';
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [myHouses, setMyHouses] = useState<any[]>([]);
  const [selectedHouse, setSelectedHouse] = useState<any>(null);
  const [quantity, setQuantity] = useState(1);
  const [maxQtyLimit, setMaxQtyLimit] = useState(10);
  const [processing, setProcessing] = useState(false);
  const [orderCode, setOrderCode] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const userStr = localStorage.getItem('siae_user');
    if (!userStr) {
      toast.error("Por favor, faça login para continuar para o checkout.");
      navigate('/login?redirect=checkout');
      return;
    }
    const parsedUser = JSON.parse(userStr);
    setUser(parsedUser);

    // Fetch the Chaveiro product
    fetch('/api/products')
      .then(r => r.json())
      .then(data => {
        const chaveiro = data.find((p: any) => p.name.includes('Chaveiro') || p.id === 1) || data[0];
        setProduct(chaveiro);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
      
    // Fetch user's registered Spiritual Houses
    fetch(`/api/users/${parsedUser.id}/houses`)
      .then(r => r.json())
      .then((data: any[]) => {
        setMyHouses(data);
        if (data && data.length > 0) {
          setSelectedHouse(data[0].id);
        }
      })
      .catch(err => console.error(err));

    // Fetch Mercado Pago configuration for limits
    fetch('/api/config/mercadopago')
      .then(r => r.json())
      .then(config => {
        if (config && config.max_qty_per_order !== undefined) {
          setMaxQtyLimit(Number(config.max_qty_per_order));
        }
      })
      .catch(err => console.error(err));
  }, [navigate]);

  const handleBuy = async () => {
    if (!selectedHouse) {
      toast.error("Por favor, selecione sua Casa Espírita para a retirada.");
      return;
    }
    if (!product) {
      toast.error("Produto não disponível no momento.");
      return;
    }

    try {
      setProcessing(true);
      const res = await fetch('/api/store/buy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          houseId: selectedHouse,
          productId: product.id,
          quantity: quantity
        })
      });
      
      const data = await res.json();
      if (data.error) {
        toast.error(data.error);
        setProcessing(false);
      } else {
        setProcessing(false);
        setOrderCode(data);
        toast.success("Pedido gerado com sucesso! Aguardando pagamento via Pix.");
      }
    } catch(e) {
      console.error(e);
      toast.error('Erro ao processar pedido de compra');
      setProcessing(false);
    }
  };

  const copyPixCode = () => {
    if (orderCode && orderCode.qr_code) {
      navigator.clipboard.writeText(orderCode.qr_code);
      setCopied(true);
      toast.success("Código Pix Copiado!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
        <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mb-4" />
        <p className="text-indigo-200 font-medium">Carregando o checkout seguro...</p>
      </div>
    );
  }

  // Calculate total price based on product price
  const unitPrice = product ? Number(product.price) : 15.00;
  const totalPrice = unitPrice * quantity;

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between">
      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-md border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => navigate(-1)} 
              className="p-2 -ml-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              title="Voltar"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <span className="h-6 w-px bg-slate-800 hidden sm:inline" />
            <h1 className="text-lg sm:text-xl font-bold flex items-center gap-2 bg-gradient-to-r from-indigo-400 to-emerald-400 bg-clip-text text-transparent">
              <ShoppingCart className="w-5 h-5 text-indigo-400" />
              Checkout Único SIAE
            </h1>
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-xs sm:text-sm">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span className="font-mono">Ambiente Seguro</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 flex flex-col items-center justify-center">
        {isFromPromo && !orderCode && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-6xl bg-gradient-to-r from-emerald-500/15 via-indigo-500/15 to-blue-500/15 border border-indigo-500/30 rounded-2xl p-4 text-center text-sm font-medium text-emerald-300 shadow-[0_0_15px_rgba(99,102,241,0.25)] flex items-center justify-center gap-2 mb-6"
          >
            <Sparkles className="w-5 h-5 text-emerald-400 animate-pulse flex-shrink-0" />
            <span>Você está comprando através da <strong>Propaganda Oficial de Vendas do Chaveiro NFC SIAE</strong>! Retirada agilizada na Casa Espírita.</span>
          </motion.div>
        )}
        {orderCode ? (
          /* Payment Success Screen with Pix QR Code */
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl text-center space-y-6"
          >
            <div className="w-16 h-16 bg-emerald-500/15 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            
            <div className="space-y-2">
              <h2 className="text-2xl font-black text-white leading-tight">Pedido Realizado com Sucesso!</h2>
              <p className="text-slate-400 text-sm">
                Escaneie o QR Code abaixo com seu aplicativo de pagamentos ou use o Pix Copia e Cola para pagar.
              </p>
            </div>

            <div className="bg-slate-950/60 rounded-2xl p-6 border border-slate-800">
              <p className="text-xs text-slate-500 font-mono uppercase tracking-widest mb-1">Valor Total</p>
              <p className="text-3xl font-black text-emerald-400 mb-6 font-sans">R$ {Number(orderCode.totalAmount).toFixed(2)}</p>
              
              {orderCode.qr_code_base64 && (
                <div className="flex flex-col items-center justify-center gap-3 mb-6 bg-white p-4 rounded-xl max-w-[210px] mx-auto border border-indigo-500/10 shadow-[0_0_20px_rgba(99,102,241,0.1)]">
                  <img 
                    src={`data:image/png;base64,${orderCode.qr_code_base64}`} 
                    alt="QR Code Pix" 
                    className="w-40 h-40" 
                  />
                  <span className="text-[10px] text-slate-800 font-black tracking-widest uppercase">PIX SEGURO</span>
                </div>
              )}
              
              <div className="text-left space-y-2">
                <label className="block text-xs font-bold text-slate-500 font-mono uppercase tracking-wider">Pix Copia e Cola:</label>
                <div className="relative">
                  <textarea 
                    readOnly 
                    className="w-full text-xs font-mono text-slate-300 bg-slate-950 border border-slate-800 p-3 rounded-xl h-24 focus:outline-none resize-none pr-10" 
                    value={orderCode.qr_code || ''}
                  />
                  <button 
                    onClick={copyPixCode}
                    className="absolute top-2 right-2 p-2 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white rounded-lg transition-colors"
                    title="Copiar Pix"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="text-left bg-slate-950/30 hover:bg-slate-950/50 p-4 rounded-2xl border border-slate-800/60 flex gap-4 items-start transition-colors">
              <Truck className="w-6 h-6 text-indigo-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-bold text-slate-200">Como funciona a Retirada?</p>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  O chaveiro não é enviado via correios. Lembre-se de retirar o seu Chaveiro NFC na Casa Espírita selecionada após a confirmação do pagamento. Apresente seus dados na recepção para ativação imediata.
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button 
                onClick={() => navigate('/dashboard')} 
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 hover:shadow-indigo-500/20 text-white font-bold py-3.5 px-6 rounded-xl transition-all shadow-lg active:scale-95"
              >
                Ir para o Painel Geral
              </button>
            </div>
          </motion.div>
        ) : (
          /* Checkout View with Forms */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 w-full max-w-6xl">
            {/* Left Column: Product Showcase */}
            <div className="lg:col-span-5 flex flex-col justify-center space-y-6">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-slate-900/60 backdrop-blur-md rounded-3xl p-6 md:p-8 border border-indigo-500/20 shadow-2xl space-y-6 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl"></div>
                
                {/* Product Title / Image */}
                <div className="flex flex-col items-center text-center">
                  <div className="relative group/pic mb-4 bg-slate-950/60 p-6 rounded-2xl border border-slate-800">
                    <img 
                      src={product?.image_url || '/chaveiro-siae.png'} 
                      alt="Chaveiro NFC" 
                      className="w-40 h-40 object-contain drop-shadow-[0_10px_20px_rgba(99,102,241,0.4)]"
                    />
                    <span className="absolute bottom-2 right-2 bg-emerald-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded border border-emerald-400 shadow">
                      NFC 13.56MHz
                    </span>
                  </div>
                  
                  <span className="text-emerald-400 font-extrabold text-[10px] tracking-widest uppercase bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20 mb-2">
                    Dispositivo Oficial
                  </span>
                  <h3 className="text-2xl font-black text-white">{product?.name || 'Chaveiro NFC SIAE'}</h3>
                  <p className="text-sm text-slate-400 mt-2 font-light leading-relaxed max-w-sm">
                    {product?.description || 'Chaveiro plástico com tag ativo para check-in instantâneo, dispensando o uso de celulares e aplicativos.'}
                  </p>
                </div>

                {/* Technical specs or Benefits list */}
                <div className="border-t border-slate-800 pt-6 space-y-3">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">Destaques do Dispositivo</h4>
                  <ul className="space-y-2.5 text-xs text-slate-300">
                    <li className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <span>Material plástico ABS ultra-durável contra impactos e umidade.</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <span>Comunicação passiva (sem baterias ou carregador).</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <span>Autenticação de presença segura e privada nos totens.</span>
                    </li>
                  </ul>
                </div>
              </motion.div>
            </div>

            {/* Right Column: Checkout Options Form */}
            <div className="lg:col-span-7 flex flex-col justify-center">
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-black text-white">Finalize sua Compra</h2>
                  <p className="text-sm text-slate-400 mt-1">Insira suas configurações de retirada e quantidade abaixo.</p>
                </div>
                
                {/* Form fields */}
                <div className="space-y-5">
                  {/* Local de Retirada */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">
                      Selecione o Local de Retirada (Sua Casa Espírita)
                    </label>
                    {myHouses.length === 0 ? (
                      <div className="bg-slate-950 border border-dashed border-slate-800 p-4 rounded-xl text-center text-sm text-amber-400 font-bold">
                        Você precisa fazer parte ou registrar-se em uma Casa Espírita no painel antes de poder finalizar compras de chaveiro.
                      </div>
                    ) : (
                      <select 
                        value={selectedHouse || ''} 
                        onChange={(e) => setSelectedHouse(Number(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-slate-300 font-medium text-sm focus:outline-none focus:border-indigo-500 transition-colors"
                      >
                        {myHouses.map(h => (
                          <option key={h.id} value={h.id}>{h.name}</option>
                        ))}
                      </select>
                    )}
                    <span className="block text-[11px] text-slate-500">
                      O chaveiro é retirado e ativado pessoalmente no balcão de recepção da Casa Espírita selecionada.
                    </span>
                  </div>

                  {/* Quantidade & Preços */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end border-t border-slate-800/60 pt-5">
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">
                        Quantidade de Chaveiros
                      </label>
                      <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 py-1 text-slate-300">
                        <button 
                          onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                          className="w-10 h-10 flex items-center justify-center font-bold text-lg text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
                        >
                          -
                        </button>
                        <input 
                          type="number" 
                          min="1" 
                          max={maxQtyLimit}
                          value={quantity}
                          onChange={(e) => setQuantity(Math.min(Math.max(1, Number(e.target.value)), maxQtyLimit))}
                          className="flex-1 w-full bg-transparent border-none text-center font-bold focus:outline-none"
                        />
                        <button 
                          onClick={() => setQuantity(prev => Math.min(maxQtyLimit, prev + 1))}
                          className="w-10 h-10 flex items-center justify-center font-bold text-lg text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800 flex justify-between items-center">
                      <div>
                        <span className="block text-[10px] text-slate-500 uppercase tracking-wider font-mono">Preço Unitário:</span>
                        <span className="text-sm font-bold text-slate-300">R$ {unitPrice.toFixed(2)}</span>
                      </div>
                      <div className="text-right">
                        <span className="block text-[10px] text-slate-500 uppercase tracking-wider font-mono">Valor Final:</span>
                        <span className="text-lg font-black text-emerald-400">R$ {totalPrice.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Compra segura notice */}
                <div className="bg-slate-950/30 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
                  <ShieldCheck className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                  <span className="text-[11px] text-slate-400 leading-snug">
                     Seu pagamento por PIX é intermediado com criptografia SSL 256 bits via Mercado Pago Oficial.
                  </span>
                </div>

                {/* Submit button */}
                <button
                  type="button"
                  disabled={processing || myHouses.length === 0}
                  onClick={handleBuy}
                  className="w-full bg-gradient-to-r from-emerald-500 to-indigo-600 hover:from-emerald-600 hover:to-indigo-700 text-white font-black py-4 rounded-xl flex items-center justify-center space-x-3 transition-all transform hover:scale-[1.01] active:scale-95 shadow-xl shadow-indigo-950/40 disabled:opacity-50 disabled:pointer-events-none"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin text-white" />
                      <span>Gerando Código Pix Seguro...</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-5 h-5 text-white animate-pulse" />
                      <span>Gerar Pix &amp; Concluir Compra (R$ {totalPrice.toFixed(2)})</span>
                    </>
                  )}
                </button>
              </motion.div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500 font-mono">
          <p>© 2026 S.I.A.E - Sistema Integrado de Atendimento Espiritual. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
