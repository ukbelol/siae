import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Clock, Calendar, CheckSquare, Settings, ArrowRight, Trash2, Edit2, Save } from 'lucide-react';
import PhotoUpload from '../components/PhotoUpload';

export default function RegisterHouse() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [step, setStep] = useState(2);
  const [houseId, setHouseId] = useState<number | null>(null);

  // Step 2 state
  const [houseData, setHouseData] = useState({
    name: '', cnpj: '', email: '', phone: '', cep: '', street: '', number: '', neighborhood: '', city: '', state: '', country: 'Brasil', photo_url: ''
  });

  // Step 3 state
  const [timeBlocks, setTimeBlocks] = useState<any[]>([]);
  const [editingBlock, setEditingBlock] = useState<any>(null);

  // Step 4 state
  const [assistanceTypes, setAssistanceTypes] = useState<any[]>([]);
  const [editingAssistance, setEditingAssistance] = useState<any>(null);

  // Step 5 state
  const [dayLinks, setDayLinks] = useState<any[]>([]);

  const diasSemana = [
    { id: 0, label: 'Dom' },
    { id: 1, label: 'Seg' },
    { id: 2, label: 'Ter' },
    { id: 3, label: 'Qua' },
    { id: 4, label: 'Qui' },
    { id: 5, label: 'Sex' },
    { id: 6, label: 'Sáb' },
  ];

  useEffect(() => {
    const u = localStorage.getItem('siae_user');
    if (u) {
      const parsed = JSON.parse(u);
      if (parsed.role !== 'representative') {
        navigate('/dashboard');
      } else {
        setUser(parsed);
        checkExistingHouse(parsed.id);
      }
    } else {
      navigate('/login');
    }
  }, [navigate]);

  const checkExistingHouse = async (repId: number) => {
    try {
      const res = await fetch(`/api/houses/rep/${repId}`);
      if (res.ok) {
        const data = await res.json();
        if (data) {
          setHouseId(data.id);
          setHouseData(data);
          loadOperatingDays(data.id);
          loadAssistanceTypes(data.id);
          loadDayAssistances(data.id);
        }
      }
    } catch (e) {}
  };

  const loadOperatingDays = async (hId: number) => {
    const res = await fetch(`/api/houses/${hId}/operating-days`);
    if (res.ok) {
      const days = await res.json();
      const grouped: any = {};
      days.forEach((d: any) => {
        const key = `${d.open_time}-${d.close_time}`;
        if (!grouped[key]) {
          grouped[key] = { id: key, openTime: d.open_time, closeTime: d.close_time, days: [] };
        }
        grouped[key].days.push(d.day_of_week);
      });
      setTimeBlocks(Object.values(grouped));
    }
  };

  const loadAssistanceTypes = async (hId: number) => {
    const res = await fetch(`/api/houses/${hId}/assistance-types`);
    if (res.ok) {
      const types = await res.json();
      setAssistanceTypes(types);
    }
  };

  const loadDayAssistances = async (hId: number) => {
    const res = await fetch(`/api/houses/${hId}/day-assistances`);
    if (res.ok) {
      const links = await res.json();
      const grouped: any = {};
      links.forEach((l: any) => {
        if (!grouped[l.assistance_type_id]) {
          grouped[l.assistance_type_id] = { assistanceTypeId: l.assistance_type_id, days: [] };
        }
        grouped[l.assistance_type_id].days.push(l.day_of_week);
      });
      setDayLinks(Object.values(grouped));
    }
  };

  const handleHouseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      if (houseId) {
        await fetch(`/api/houses/${houseId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(houseData)
        });
      } else {
        const res = await fetch('/api/houses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...houseData, representativeId: user.id })
        });
        const data = await res.json();
        setHouseId(data.id);
      }
      setStep(3);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const saveTimeBlock = (block: any) => {
    if (!block.openTime || !block.closeTime) {
      alert("Preencha horário inicial e final.");
      return;
    }
    if (block.id) {
      setTimeBlocks(timeBlocks.map(b => (b.id === block.id ? block : b)));
    } else {
      setTimeBlocks([...timeBlocks, { ...block, id: Math.random().toString() }]);
    }
    setEditingBlock(null);
  };
  
  const deleteTimeBlock = (id: string) => {
    setTimeBlocks(timeBlocks.filter(b => b.id !== id));
  };

  const handleStep3Submit = async () => {
    if (!houseId) return;
    await fetch(`/api/houses/${houseId}/operating-days/bulk`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ timeBlocks })
    });
    setStep(4);
  };

  const saveAssistanceType = async (typeData: any) => {
    if (!houseId) return;
    if (!typeData.name) {
      alert("Preencha o nome da assistência.");
      return;
    }
    if (typeData.id) {
      await fetch(`/api/houses/${houseId}/assistance-types/${typeData.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(typeData)
      });
      setAssistanceTypes(assistanceTypes.map(t => (t.id === typeData.id ? typeData : t)));
    } else {
      const res = await fetch(`/api/houses/${houseId}/assistance-types`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(typeData)
      });
      const data = await res.json();
      setAssistanceTypes([...assistanceTypes, { ...typeData, id: data.id }]);
    }
    setEditingAssistance(null);
  };

  const deleteAssistanceType = async (id: number) => {
    alert('Para manter a integridade, apenas evite vincular na próxima etapa, caso não consiga excluir.');
  };

  const handleStep4Submit = async () => {
    setStep(5);
  };

  const handleToggleDayLink = (typeId: number, dayId: number) => {
    setDayLinks(prev => {
      const existing = prev.find(l => l.assistanceTypeId === typeId);
      if (existing) {
        if (existing.days.includes(dayId)) {
          return prev.map(l => l.assistanceTypeId === typeId ? { ...l, days: l.days.filter((d: number) => d !== dayId) } : l);
        } else {
          return prev.map(l => l.assistanceTypeId === typeId ? { ...l, days: [...l.days, dayId] } : l);
        }
      } else {
        return [...prev, { assistanceTypeId: typeId, days: [dayId] }];
      }
    });
  };

  const handleStep5Submit = async () => {
    if (!houseId) return;
    try {
      await fetch(`/api/houses/${houseId}/day-assistances/bulk`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ links: dayLinks })
      });
      alert('Configuração finalizada com sucesso!');
      navigate('/dashboard');
    } catch (err: any) {
      alert(err.message);
    }
  };

  if (!user) return <div className="p-8 text-center">Verificando acesso...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        
        {/* Progress Bar */}
        <div className="bg-indigo-600 px-8 py-6">
          <h2 className="text-2xl font-bold text-white mb-6">Configuração da Casa Espírita</h2>
          <div className="flex justify-between relative max-w-2xl mx-auto">
            <div className="absolute left-0 top-1/2 -mt-[2px] w-full h-[4px] bg-indigo-500 rounded z-0"></div>
            {[2, 3, 4, 5].map((s, idx) => (
              <div key={s} className="relative z-10 flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step >= s ? 'bg-white text-indigo-600 shadow-md' : 'bg-indigo-400 text-indigo-100'}`}>
                  {step > s ? <CheckCircle className="w-5 h-5 text-indigo-600" /> : idx + 2}
                </div>
                <span className={`text-xs mt-2 font-medium ${step >= s ? 'text-white' : 'text-indigo-200'}`}>
                  {s === 2 && 'Dados'}
                  {s === 3 && 'Horários'}
                  {s === 4 && 'Assistências'}
                  {s === 5 && 'Agenda'}
                </span>
              </div>
            ))}
          </div>
          <p className="text-center text-indigo-100 mt-4 text-sm font-medium opacity-80">(Etapa 1 concluída: Cadastro do Representante)</p>
        </div>

        <div className="p-8">
          
          {step === 2 && (
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2"><Settings className="w-6 h-6 text-indigo-600" /> Etapa 2: Dados da Casa Espírita</h3>
              <form onSubmit={handleHouseSubmit} className="space-y-6">
                <div className="mb-4 flex flex-col items-center">
                   <label className="block text-sm font-medium text-gray-700 mb-2 text-center">Logo ou Foto da Fachada</label>
                   <PhotoUpload 
                     currentPhoto={houseData.photo_url} 
                     onUploadComplete={(url) => setHouseData({...houseData, photo_url: url})} 
                   />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nome da Casa Espírita</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.name} onChange={e => setHouseData({...houseData, name: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">CNPJ</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.cnpj} onChange={e => setHouseData({...houseData, cnpj: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                    <input required type="email" className="w-full border rounded-lg p-2.5" value={houseData.email} onChange={e => setHouseData({...houseData, email: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
                    <input required type="tel" className="w-full border rounded-lg p-2.5" value={houseData.phone} onChange={e => setHouseData({...houseData, phone: e.target.value})} />
                  </div>
                   <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">CEP</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" placeholder="00000-000" value={houseData.cep || ''} onChange={e => setHouseData({...houseData, cep: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Rua / Avenida</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.street} onChange={e => setHouseData({...houseData, street: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Número</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.number} onChange={e => setHouseData({...houseData, number: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Bairro</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.neighborhood} onChange={e => setHouseData({...houseData, neighborhood: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Cidade</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.city} onChange={e => setHouseData({...houseData, city: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Estado</label>
                    <input required type="text" className="w-full border rounded-lg p-2.5" value={houseData.state} onChange={e => setHouseData({...houseData, state: e.target.value})} />
                  </div>
                </div>
                <div className="flex justify-end pt-4 border-t mt-6">
                  <button type="submit" className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700 transition flex items-center gap-2">
                    Salvar e Continuar <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </form>
            </div>
          )}

          {step === 3 && (
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2"><Clock className="w-6 h-6 text-indigo-600" /> Etapa 3: Horários de Funcionamento</h3>
              
              <div className="mb-6">
                <button 
                  onClick={() => setEditingBlock({ openTime: '', closeTime: '', days: [] })} 
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
                >
                  <Calendar className="w-4 h-4" /> Adicionar Horário
                </button>
              </div>

              {editingBlock && (
                <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 mb-6 shadow-sm">
                  <h4 className="font-bold text-gray-800 mb-4 text-lg">{editingBlock.id ? 'Editar Horário' : 'Novo Horário'}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Horário Inicial</label>
                      <input type="time" value={editingBlock.openTime} onChange={e => setEditingBlock({...editingBlock, openTime: e.target.value})} className="w-full border rounded-lg p-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Horário Final</label>
                      <input type="time" value={editingBlock.closeTime} onChange={e => setEditingBlock({...editingBlock, closeTime: e.target.value})} className="w-full border rounded-lg p-2" />
                    </div>
                  </div>
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-3">Dias da Semana</label>
                    <div className="flex flex-wrap gap-4">
                      {diasSemana.map(d => (
                        <label key={d.id} className="flex items-center gap-2 cursor-pointer bg-white border px-3 py-2 rounded-lg hover:border-indigo-400 transition-colors">
                          <input 
                            type="checkbox" 
                            checked={editingBlock.days.includes(d.id)}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              setEditingBlock((prev: any) => ({
                                ...prev, 
                                days: checked ? [...prev.days, d.id] : prev.days.filter((x: number) => x !== d.id)
                              }))
                            }}
                            className="w-5 h-5 text-indigo-600 accent-indigo-600"
                          />
                          <span className="text-sm font-medium select-none text-gray-700">{d.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => saveTimeBlock(editingBlock)} className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium shadow-sm hover:bg-indigo-700 flex items-center gap-2"><Save className="w-4 h-4"/> Salvar na Tabela</button>
                    <button onClick={() => setEditingBlock(null)} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-lg font-medium hover:bg-gray-300">Cancelar</button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto border rounded-xl mb-6 shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-100 border-b">
                      <th className="p-4 font-bold text-gray-700 border-r w-1/4">Horário</th>
                      <th className="p-4 font-bold text-gray-700 text-center" colSpan={7}>Dias da Semana</th>
                      <th className="p-4 font-bold text-gray-700 w-32 text-right">Ações</th>
                    </tr>
                    <tr className="bg-gray-50 border-b text-sm">
                      <th className="p-2 border-r text-center font-medium text-gray-500">Início - Fim</th>
                      {diasSemana.map(d => (
                        <th key={d.id} className="p-2 text-center text-xs text-gray-500 border-r">{d.label}</th>
                      ))}
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {timeBlocks.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="p-8 text-center text-gray-500">Nenhum horário parametrizado. Clique em "Adicionar Horário".</td>
                      </tr>
                    ) : timeBlocks.map((block) => (
                      <tr key={block.id} className="border-b hover:bg-gray-50 transition-colors">
                        <td className="p-4 font-bold text-indigo-900 border-r text-center whitespace-nowrap">{block.openTime || '--:--'} às {block.closeTime || '--:--'}</td>
                        {diasSemana.map(d => (
                          <td key={d.id} className="p-4 text-center border-r bg-white">
                            <input type="checkbox" readOnly checked={block.days.includes(d.id)} className="w-5 h-5 accent-indigo-600 cursor-default" />
                          </td>
                        ))}
                        <td className="p-4 text-right whitespace-nowrap">
                          <button onClick={() => setEditingBlock(block)} className="text-blue-600 hover:text-blue-800 p-2 mx-1 rounded-full hover:bg-blue-50 transition-colors"><Edit2 className="w-5 h-5" /></button>
                          <button onClick={() => deleteTimeBlock(block.id)} className="text-red-600 hover:text-red-800 p-2 mx-1 rounded-full hover:bg-red-50 transition-colors"><Trash2 className="w-5 h-5" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between pt-4 border-t">
                <button type="button" onClick={() => setStep(2)} className="bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-medium hover:bg-gray-300 transition">Voltar</button>
                <button onClick={handleStep3Submit} className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700 transition flex items-center gap-2">
                  Salvar e Continuar <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2"><CheckSquare className="w-6 h-6 text-indigo-600" /> Etapa 4: Cadastro de Tipos de Assistências</h3>
              
              <div className="mb-6">
                <button 
                  onClick={() => setEditingAssistance({ name: '', description: '', status: 'active' })} 
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
                >
                  <CheckSquare className="w-4 h-4" /> Adicionar Assistência
                </button>
              </div>

              {editingAssistance && (
                <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 mb-6 shadow-sm">
                  <h4 className="font-bold text-gray-800 mb-4 text-lg">{editingAssistance.id ? 'Editar Assistência' : 'Nova Assistência'}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                      <input type="text" value={editingAssistance.name} onChange={e => setEditingAssistance({...editingAssistance, name: e.target.value})} className="w-full border rounded-lg p-2.5" placeholder="Ex: Passe, Atendimento Fraterno" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                      <input type="text" value={editingAssistance.description} onChange={e => setEditingAssistance({...editingAssistance, description: e.target.value})} className="w-full border rounded-lg p-2.5" />
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => saveAssistanceType(editingAssistance)} className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 flex items-center gap-2"><Save className="w-4 h-4"/> Salvar na Tabela</button>
                    <button onClick={() => setEditingAssistance(null)} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-lg font-medium hover:bg-gray-300">Cancelar</button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto border rounded-xl mb-6 shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-100 border-b">
                      <th className="p-4 font-bold text-gray-700 w-1/3">Nome da Assistência</th>
                      <th className="p-4 font-bold text-gray-700">Descrição</th>
                      <th className="p-4 font-bold text-gray-700 w-32 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assistanceTypes.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="p-8 text-center text-gray-500">Nenhuma assistência cadastrada.</td>
                      </tr>
                    ) : assistanceTypes.map((t) => (
                      <tr key={t.id} className="border-b hover:bg-gray-50 transition-colors">
                        <td className="p-4 font-bold text-gray-900 border-r">{t.name}</td>
                        <td className="p-4 text-gray-600">{t.description}</td>
                        <td className="p-4 text-right whitespace-nowrap">
                          <button onClick={() => setEditingAssistance(t)} className="text-blue-600 hover:text-blue-800 p-2 mx-1 rounded-full hover:bg-blue-50 transition-colors"><Edit2 className="w-5 h-5" /></button>
                          <button onClick={() => deleteAssistanceType(t.id)} className="text-red-600 hover:text-red-800 p-2 mx-1 rounded-full hover:bg-red-50 transition-colors"><Trash2 className="w-5 h-5" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between pt-4 border-t">
                <button type="button" onClick={() => setStep(3)} className="bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-medium hover:bg-gray-300 transition">Voltar</button>
                <button onClick={handleStep4Submit} className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700 transition flex items-center gap-2">
                  Salvar e Continuar <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {step === 5 && (
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2"><Calendar className="w-6 h-6 text-indigo-600" /> Etapa 5: Vínculo Assistências aos Dias da Semana</h3>
              <p className="text-gray-600 mb-6">Selecione os dias em que cada assistência estará disponível em sua casa espírita.</p>
              
              <div className="overflow-x-auto border rounded-xl mb-6 shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-100 border-b">
                      <th className="p-4 font-bold text-gray-700 border-r w-1/3">Assistência (Ordem Alfabética)</th>
                      {diasSemana.map(d => (
                        <th key={d.id} className="p-4 font-bold text-gray-700 text-center border-r">{d.label}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {assistanceTypes.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-gray-500">Nenhuma assistência cadastrada, volte à etapa 4.</td>
                      </tr>
                    ) : [...assistanceTypes].sort((a,b) => a.name.localeCompare(b.name)).map((t) => {
                      const linkData = dayLinks.find(l => l.assistanceTypeId === t.id);
                      const selectedDays = linkData ? linkData.days : [];

                      return (
                        <tr key={t.id} className="border-b hover:bg-gray-50 transition-colors">
                          <td className="p-4 font-bold text-indigo-900 border-r">{t.name}</td>
                          {diasSemana.map(d => (
                            <td key={d.id} className="p-4 text-center border-r bg-white hover:bg-indigo-50 transition-colors" onClick={() => handleToggleDayLink(t.id, d.id)}>
                              <input 
                                type="checkbox" 
                                checked={selectedDays.includes(d.id)} 
                                onChange={() => {}} // handled by td onClick
                                className="w-6 h-6 accent-indigo-600 cursor-pointer pointer-events-none" 
                              />
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between pt-4 border-t">
                <button type="button" onClick={() => setStep(4)} className="bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-medium hover:bg-gray-300 transition">Voltar</button>
                <button onClick={handleStep5Submit} className="bg-green-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-green-700 transition flex items-center gap-2 shadow-md">
                  <CheckCircle className="w-5 h-5" /> Salvar Tudo e Concluir
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
