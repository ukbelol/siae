const fs = require('fs');

let t = fs.readFileSync('src/api/index.ts', 'utf8');

// Replace all remaining db.prepare(...).run/get/all 
// that might be left due to multiline or string replacements that failed

t = t.replace(/\(await db\.query\((['`][\s\S]+?['`])\)\.run\((.*?)\);/g, "await db.query($1, [$2]);");
t = t.replace(/db\.prepare\((['`][\s\S]+?['`])\)\.run\((.*?)\);/g, "await db.query($1, [$2]);");
t = t.replace(/db\.prepare\((['`][\s\S]+?['`])\)\.run\((.*?)\)/g, "await db.query($1, [$2])");

t = t.replace(/db\.prepare\('UPDATE attendances SET status = !!completed!!, end_time = CURRENT_TIMESTAMP WHERE id = \?'\.replace\(\/!!\/g, "'"\)\)\.run\(activeAttendance\.id\);/g, 
  "await db.query('UPDATE attendances SET status = \\'completed\\', end_time = CURRENT_TIMESTAMP WHERE id = ?', [activeAttendance.id]);");

t = t.replace(/db\.prepare\('UPDATE attendances SET status = !!in_progress!!, start_time = CURRENT_TIMESTAMP WHERE id = \?'\.replace\(\/!!\/g, "'"\)\)\.run\(active\.id\);/g, 
  "await db.query('UPDATE attendances SET status = \\'in_progress\\', start_time = CURRENT_TIMESTAMP WHERE id = ?', [active.id]);");

// SQLite INSERT OR IGNORE -> MySQL INSERT IGNORE
t = t.replace(/INSERT OR IGNORE/g, "INSERT IGNORE");

// Transaction blocks fixing
t = t.replace(/const (\w+) = db\.transaction\(\(([\s\S]*?)\) => \{/g, "const $1 = async ($2) => { const conn = await db.getConnection(); await conn.beginTransaction(); try {");
t = t.replace(/const (\w+) = db\.transaction\(async \(([\s\S]*?)\) => \{/g, "const $1 = async ($2) => { const conn = await db.getConnection(); await conn.beginTransaction(); try {");
t = t.replace(/\}\);\n\n/g, "} catch(e) { await conn.rollback(); throw e; } finally { conn.release(); } };\n\n");

t = t.replace(/insertParticipant\.run/g, "await conn.query(insertParticipantCmd, ");
t = t.replace(/insert\.run/g, "await conn.query(insertCmd, ");

fs.writeFileSync('src/api/index.ts', t);
