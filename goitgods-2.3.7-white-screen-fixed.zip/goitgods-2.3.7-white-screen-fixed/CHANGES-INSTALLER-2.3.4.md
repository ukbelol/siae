# GOITGODS 2.3.4 — instalador geral Debian 12

## Principais correções

- Domínio oficial: `goitgods.pasquared.space`.
- Node.js atualizado para linha 24 LTS; o instalador atualiza runtimes mais antigos.
- Corrigido `server.ts`: agora respeita `process.env.PORT`; a porta interna padrão de produção é 3100.
- Corrigido `/api/v2/health`: inclui `success: true`, `status: "ok"` e versão 2.3.4.
- `install-gods.sh` instala as dependências APT necessárias, Node/npm, PM2, Apache, MariaDB e Certbot.
- PM2 é configurado no systemd para reiniciar o GOITGODS após reboot.
- `.env`, `data/` e segredos existentes são preservados em reinstalações; backups adicionais ficam em `/var/backups/goitgods`.
- Build Vite/backend é obrigatório. Instalação aborta se `dist/index.html`, `dist/server.cjs` ou bundle JS estiverem ausentes.
- Validação TypeScript é gravada em `logs/typescript-check.log`; erros de tipos não são confundidos com falha de download, mas o build de produção precisa passar.
- Apache usa 80/443; backend fica apenas em `127.0.0.1:3100` via proxy `/api`.
- Certbot valida e-mail e DNS antes da emissão do certificado Let's Encrypt.
- `www.goitgods.pasquared.space` só entra automaticamente no certificado quando tem DNS.
- Testes pós-instalação verificam backend, frontend, proxy Apache e HTTPS.
- `repair-white-screen.sh` agora lê a porta correta do `.env` e usa o mesmo health check do instalador.
- Criado comando de diagnóstico `sudo goitgods-status`.
- UFW não é ativado automaticamente se estiver desligado, evitando bloquear SSH em porta personalizada.

## Instalação recomendada

```bash
chmod +x install-gods.sh
sudo ./install-gods.sh --certbot-email SEU_EMAIL_VALIDO
```

Ou sem `www`:

```bash
sudo ./install-gods.sh --certbot-email SEU_EMAIL_VALIDO --no-www
```

Antes de executar, o registro DNS A/AAAA de `goitgods.pasquared.space` deve apontar para o servidor e as portas 80/443 devem estar acessíveis pela Internet.
