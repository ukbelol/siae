import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { MercadoPagoConfig, Preference, PaymentRefund, Payment } from 'mercadopago';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Initialize SQLite Database
const db = new Database("database.sqlite");

// Create Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL, -- 'superadmin', 'salon_admin', 'employee', 'client'
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    surname TEXT,
    cpf TEXT,
    dob TEXT,
    phone TEXT,
    street TEXT,
    number TEXT,
    neighborhood TEXT,
    city TEXT,
    state TEXT,
    salon_id INTEGER,
    must_change_password INTEGER DEFAULT 0,
    identifier TEXT UNIQUE,
    active INTEGER DEFAULT 1,
    country TEXT,
    photo_url TEXT
  );

  CREATE TABLE IF NOT EXISTS salons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER,
    name TEXT NOT NULL,
    cnpj TEXT,
    slogan TEXT,
    logo_url TEXT,
    bg_url TEXT,
    salon_code TEXT UNIQUE,
    about_text TEXT,
    mission_text TEXT,
    street TEXT,
    number TEXT,
    neighborhood TEXT,
    city TEXT,
    state TEXT,
    country TEXT,
    mp_access_token TEXT,
    mp_refresh_token TEXT,
    mp_user_id TEXT,
    mp_public_key TEXT,
    FOREIGN KEY(admin_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    salon_id INTEGER,
    name TEXT NOT NULL,
    duration INTEGER NOT NULL,
    price REAL NOT NULL,
    description TEXT,
    photo_url TEXT,
    FOREIGN KEY(salon_id) REFERENCES salons(id)
  );

  CREATE TABLE IF NOT EXISTS working_hours (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    salon_id INTEGER,
    day_of_week INTEGER,
    open_time TEXT,
    close_time TEXT,
    FOREIGN KEY(salon_id) REFERENCES salons(id)
  );

  CREATE TABLE IF NOT EXISTS employee_services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER,
    service_id INTEGER,
    FOREIGN KEY(employee_id) REFERENCES users(id),
    FOREIGN KEY(service_id) REFERENCES services(id)
  );

  CREATE TABLE IF NOT EXISTS employee_working_hours (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER,
    day_of_week INTEGER,
    start_time TEXT,
    end_time TEXT,
    FOREIGN KEY(employee_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    salon_id INTEGER,
    service_id INTEGER,
    start_time TEXT,
    end_time TEXT,
    status TEXT,
    paid_amount REAL DEFAULT 0,
    pending_amount REAL DEFAULT 0,
    FOREIGN KEY(client_id) REFERENCES users(id),
    FOREIGN KEY(salon_id) REFERENCES salons(id),
    FOREIGN KEY(service_id) REFERENCES services(id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE NOT NULL,
    value TEXT NOT NULL
  );
`);

// Migrations for new columns
try { db.exec("ALTER TABLE services ADD COLUMN days_of_week TEXT DEFAULT '[0,1,2,3,4,5,6]'"); } catch (e) {}
try { db.exec("ALTER TABLE employee_services ADD COLUMN days_of_week TEXT DEFAULT '[0,1,2,3,4,5,6]'"); } catch (e) {}
try { db.exec("ALTER TABLE services ADD COLUMN active INTEGER DEFAULT 1"); } catch (e) {}
try { db.exec("ALTER TABLE services ADD COLUMN category TEXT DEFAULT 'Geral'"); } catch (e) {}
try { db.exec("ALTER TABLE appointments ADD COLUMN employee_id INTEGER REFERENCES users(id)"); } catch (e) {}
try { db.exec("ALTER TABLE appointments ADD COLUMN payment_id TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE appointments ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP"); } catch (e) {}
try { db.exec("ALTER TABLE users ADD COLUMN identifier TEXT UNIQUE"); } catch (e) {}
try { db.exec("ALTER TABLE salons ADD COLUMN salon_code TEXT UNIQUE"); } catch (e) {}
try { db.exec("ALTER TABLE users ADD COLUMN photo_url TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE salons ADD COLUMN mp_access_token TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE salons ADD COLUMN mp_refresh_token TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE salons ADD COLUMN mp_user_id TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE salons ADD COLUMN mp_public_key TEXT"); } catch (e) {}

// Helper to generate random code
function generateCode(length = 4) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Ensure unique identifier
function getUniqueCode(prefix, length = 4) {
  let code;
  let exists = true;
  while (exists) {
    code = generateCode(length);
    const check = db.prepare("SELECT id FROM users WHERE identifier = ?").get(prefix + code);
    if (!check) exists = false;
  }
  return code;
}

// Ensure unique personal ID (3 chars) for a salon
function getUniquePersonalId(salonCode, length = 3) {
  let code;
  let exists = true;
  while (exists) {
    code = generateCode(length);
    // Check if any user in this salon already has this 3-char ID part
    const check = db.prepare("SELECT id FROM users WHERE identifier LIKE ?").get(`%${salonCode}${code}%`);
    if (!check) exists = false;
  }
  return code;
}

// Ensure unique salon code (4 chars)
function getUniqueSalonCode() {
  let code;
  let exists = true;
  while (exists) {
    code = generateCode(4);
    const check = db.prepare("SELECT id FROM salons WHERE salon_code = ?").get(code);
    if (!check) exists = false;
  }
  return code;
}

// Insert Super Admin
db.prepare("DELETE FROM users WHERE email = ?").run("rgs577@smartmall577.space");

const checkAdmin = db.prepare("SELECT * FROM users WHERE email = ?").get("roger577@smartmall577.space");
if (!checkAdmin) {
  db.prepare(`
    INSERT INTO users (role, email, password, name, identifier)
    VALUES ('superadmin', 'roger577@smartmall577.space', '21490905@Hair-RGS', 'Super Admin', 'sa0000')
  `).run();
} else {
  // Update password if admin already exists to ensure it matches the request
  db.prepare("UPDATE users SET password = ? WHERE email = ?").run('21490905@Hair-RGS', 'roger577@smartmall577.space');
}

// Simple API Routes
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ? AND password = ?").get(email, password);
  if (user) {
    res.json({ success: true, user });
  } else {
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

app.post("/api/auth/register-client", (req, res) => {
  const { name, surname, dob, cpf, email, password, street, number, neighborhood, city, state, country } = req.body;
  try {
    const identifier = 'uc' + getUniqueCode('uc');
    const result = db.prepare(`
      INSERT INTO users (role, name, surname, dob, cpf, email, password, street, number, neighborhood, city, state, country, identifier)
      VALUES ('client', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(name, surname, dob, cpf, email, password, street, number, neighborhood, city, state, country, identifier);
    res.json({ success: true, userId: result.lastInsertRowid, identifier });
  } catch (error) {
    console.error(error);
    res.status(400).json({ success: false, message: "Email already exists or invalid data" });
  }
});

app.post("/api/auth/register-salon", (req, res) => {
  const { name, surname, dob, cpf, email, password, phone, street, number, neighborhood, city, state, country, salon_name, cnpj } = req.body;
  try {
    const salonCode = getUniqueSalonCode();
    const personalId = generateCode(3);
    const identifier = 'AS' + salonCode + personalId;

    const userResult = db.prepare(`
      INSERT INTO users (role, name, surname, dob, cpf, email, password, phone, street, number, neighborhood, city, state, country, identifier)
      VALUES ('salon_admin', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(name, surname, dob, cpf, email, password, phone, street, number, neighborhood, city, state, country, identifier);
    
    const adminId = userResult.lastInsertRowid;
    
    const salonResult = db.prepare(`
      INSERT INTO salons (admin_id, name, cnpj, salon_code)
      VALUES (?, ?, ?, ?)
    `).run(adminId, salon_name, cnpj, salonCode);

    const salonId = salonResult.lastInsertRowid;
    
    // Set salon_id for the admin user
    db.prepare("UPDATE users SET salon_id = ? WHERE id = ?").run(salonId, adminId);
    
    res.json({ success: true, userId: adminId, salonId, identifier });
  } catch (error) {
    console.error(error);
    res.status(400).json({ success: false, message: "Email already exists or invalid data" });
  }
});

app.get("/api/salons", (req, res) => {
  const { city, neighborhood, state, service } = req.query;
  let query = `
    SELECT s.*, 
           COALESCE(s.city, u.city) as city, 
           COALESCE(s.neighborhood, u.neighborhood) as neighborhood, 
           COALESCE(s.state, u.state) as state,
           COALESCE(s.street, u.street) as street,
           COALESCE(s.number, u.number) as number,
           COALESCE(s.country, u.country) as country,
           u.phone as phone
    FROM salons s 
    JOIN users u ON s.admin_id = u.id 
    WHERE 1=1
  `;
  const params = [];
  
  if (city) { query += " AND COALESCE(s.city, u.city) LIKE ?"; params.push(`%${city}%`); }
  if (neighborhood) { query += " AND COALESCE(s.neighborhood, u.neighborhood) LIKE ?"; params.push(`%${neighborhood}%`); }
  if (state) { query += " AND COALESCE(s.state, u.state) LIKE ?"; params.push(`%${state}%`); }
  if (service) {
    query += " AND s.id IN (SELECT salon_id FROM services WHERE name = ?)";
    params.push(service);
  }
  
  const salons = db.prepare(query).all(...params);
  res.json(salons);
});

app.get("/api/salons/:id", (req, res) => {
  const salon = db.prepare(`
    SELECT s.*, u.phone as phone, 
           COALESCE(s.city, u.city) as city,
           COALESCE(s.street, u.street) as street,
           COALESCE(s.number, u.number) as number,
           COALESCE(s.neighborhood, u.neighborhood) as neighborhood,
           COALESCE(s.state, u.state) as state
    FROM salons s 
    JOIN users u ON s.admin_id = u.id 
    WHERE s.id = ?
  `).get(req.params.id);
  if (salon) {
    res.json(salon);
  } else {
    res.status(404).json({ success: false, message: "Salon not found" });
  }
});

app.get("/api/admin/:adminId/salon", (req, res) => {
  const salon = db.prepare("SELECT * FROM salons WHERE admin_id = ?").get(req.params.adminId);
  if (salon) {
    // Don't send sensitive tokens to frontend unless necessary
    const { mp_access_token, mp_refresh_token, ...safeSalon } = salon as any;
    res.json({ ...safeSalon, has_mp: !!salon.mp_access_token });
  } else {
    res.status(404).json({ success: false, message: "Salon not found" });
  }
});

app.put("/api/salons/:id/mp-credentials", (req, res) => {
  const { id } = req.params;
  const { mp_public_key, mp_access_token } = req.body;

  try {
    // If access token is '********', it means it wasn't changed
    if (mp_access_token === '********') {
      db.prepare("UPDATE salons SET mp_public_key = ? WHERE id = ?").run(mp_public_key, id);
    } else {
      db.prepare("UPDATE salons SET mp_public_key = ?, mp_access_token = ? WHERE id = ?").run(mp_public_key, mp_access_token, id);
    }
    res.json({ success: true });
  } catch (error) {
    console.error("Error updating MP credentials:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// Mercado Pago OAuth Routes
app.get("/api/auth/mercadopago/url", (req, res) => {
  const { salonId } = req.query;
  const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
  const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
  const env = mpSettings.mp_env || 'test';
  const clientId = env === 'prod' ? mpSettings.mp_prod_client_id : mpSettings.mp_test_client_id;
  
  if (!clientId) {
    return res.status(400).json({ success: false, message: `Mercado Pago Client ID (${env}) não configurado no Super Admin.` });
  }

  const origin = req.get('origin') || req.protocol + '://' + req.get('host');
  const redirectUri = `${origin}/api/auth/mercadopago/callback`;
  
  const authUrl = `https://auth.mercadopago.com.br/authorization?client_id=${clientId}&response_type=code&platform_id=mp&state=${salonId}&redirect_uri=${encodeURIComponent(redirectUri)}`;
  
  res.json({ url: authUrl });
});

app.get("/api/auth/mercadopago/platform/url", (req, res) => {
  const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
  const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
  const env = mpSettings.mp_env || 'test';
  const clientId = env === 'prod' ? mpSettings.mp_prod_client_id : mpSettings.mp_test_client_id;
  
  if (!clientId) {
    return res.status(400).json({ success: false, message: `Mercado Pago Client ID (${env}) não configurado no Super Admin.` });
  }

  const origin = req.get('origin') || req.protocol + '://' + req.get('host');
  const redirectUri = `${origin}/api/auth/mercadopago/callback`;
  
  const authUrl = `https://auth.mercadopago.com.br/authorization?client_id=${clientId}&response_type=code&platform_id=mp&state=platform&redirect_uri=${encodeURIComponent(redirectUri)}`;
  
  res.json({ url: authUrl });
});

app.get("/api/auth/mercadopago/callback", async (req, res) => {
  const { code, state: salonId, error, error_description } = req.query;
  
  if (error) {
    return res.send(`
      <html>
        <body>
          <script>
            window.opener.postMessage({ type: 'MP_AUTH_ERROR', message: "${error_description || error}" }, '*');
            window.close();
          </script>
        </body>
      </html>
    `);
  }

  try {
    const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
    const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
    
    const env = mpSettings.mp_env || 'test';
    const clientId = env === 'prod' ? mpSettings.mp_prod_client_id : mpSettings.mp_test_client_id;
    const clientSecret = env === 'prod' ? mpSettings.mp_prod_client_secret : mpSettings.mp_test_client_secret;
    const origin = req.get('origin') || req.protocol + '://' + req.get('host');
    const redirectUri = `${origin}/api/auth/mercadopago/callback`;

    const response = await fetch('https://api.mercadopago.com/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: 'authorization_code',
        code: code as string,
        redirect_uri: redirectUri,
      })
    });

    const data = await response.json();

    if (data.access_token) {
      if (salonId === 'platform') {
        const prefix = env === 'prod' ? 'mp_prod_' : 'mp_test_';
        const stmt = db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
        stmt.run(`${prefix}access_token`, data.access_token);
        stmt.run(`${prefix}refresh_token`, data.refresh_token);
        stmt.run(`${prefix}user_id`, data.user_id.toString());
        stmt.run(`${prefix}public_key`, data.public_key);
      } else {
        db.prepare(`
          UPDATE salons 
          SET mp_access_token = ?, mp_refresh_token = ?, mp_user_id = ?, mp_public_key = ?
          WHERE id = ?
        `).run(data.access_token, data.refresh_token, data.user_id, data.public_key, salonId);
      }

      res.send(`
        <html>
          <body>
            <script>
              window.opener.postMessage({ type: 'MP_AUTH_SUCCESS' }, '*');
              window.close();
            </script>
            <p>Conexão com Mercado Pago realizada com sucesso! Você pode fechar esta janela.</p>
          </body>
        </html>
      `);
    } else {
      res.send(`
        <html>
          <body>
            <script>
              window.opener.postMessage({ type: 'MP_AUTH_ERROR', message: ${JSON.stringify(data.message || "Erro ao obter token")} }, '*');
              window.close();
            </script>
          </body>
        </html>
      `);
    }
  } catch (error) {
    console.error("MP Callback Error:", error);
    res.status(500).send("Erro interno ao processar callback do Mercado Pago.");
  }
});

app.get("/api/salons/:id/services", (req, res) => {
  const services = db.prepare("SELECT * FROM services WHERE salon_id = ?").all(req.params.id);
  res.json(services);
});

app.post("/api/salons/:id/services", (req, res) => {
  const { name, duration, price, description, active, category, photo_url } = req.body;
  try {
    const result = db.prepare(`
      INSERT INTO services (salon_id, name, duration, price, description, active, category, photo_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(req.params.id, name, duration, price, description, active !== undefined ? active : 1, category || 'Geral', photo_url || null);
    res.json({ success: true, serviceId: result.lastInsertRowid });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error adding service" });
  }
});

app.put("/api/salons/:id/services/:serviceId", (req, res) => {
  const { name, duration, price, description, active, category, photo_url, days_of_week } = req.body;
  try {
    db.prepare(`
      UPDATE services 
      SET name = ?, duration = ?, price = ?, description = ?, active = ?, category = ?, photo_url = ?, days_of_week = ?
      WHERE id = ? AND salon_id = ?
    `).run(name, duration, price, description, active, category || 'Geral', photo_url || null, days_of_week || '[0,1,2,3,4,5,6]', req.params.serviceId, req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error updating service" });
  }
});

app.put("/api/salons/:id/services/:serviceId/days", (req, res) => {
  const { days_of_week } = req.body;
  try {
    db.prepare("UPDATE services SET days_of_week = ? WHERE id = ? AND salon_id = ?").run(JSON.stringify(days_of_week), req.params.serviceId, req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error updating days" });
  }
});

app.delete("/api/salons/:id/services/:serviceId", (req, res) => {
  try {
    db.prepare("DELETE FROM services WHERE id = ? AND salon_id = ?").run(req.params.serviceId, req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error deleting service" });
  }
});

app.get("/api/salons/:id/employees", (req, res) => {
  const employees = db.prepare(`
    SELECT id, name, surname, email, role, active, cpf, dob, phone, street, number, neighborhood, city, state, country, photo_url, identifier
    FROM users 
    WHERE salon_id = ? AND (role = 'employee' OR identifier LIKE '%FS%')
  `).all(req.params.id);
  
  const employeesWithDetails = employees.map(emp => {
    const services = db.prepare("SELECT service_id as id, days_of_week FROM employee_services WHERE employee_id = ?").all(emp.id).map(s => {
      let days = [];
      try { days = JSON.parse(s.days_of_week || '[0,1,2,3,4,5,6]'); } catch {}
      return { id: s.id, days_of_week: days };
    });
    const workingHours = db.prepare("SELECT day_of_week, start_time, end_time FROM employee_working_hours WHERE employee_id = ?").all(emp.id);
    return { ...emp, services, workingHours };
  });
  
  res.json(employeesWithDetails);
});

app.post("/api/salons/:id/employees", (req, res) => {
  const { name, surname, email, password, active, cpf, dob, phone, street, number, neighborhood, city, state, country, photo_url, services, workingHours } = req.body;
  try {
    const salon = db.prepare("SELECT salon_code FROM salons WHERE id = ?").get(req.params.id);
    if (!salon || !salon.salon_code) {
      return res.status(400).json({ success: false, message: "Salon code not found" });
    }

    // Check if user already exists
    const existingUser = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    
    let employeeId;
    let identifier;

    if (existingUser) {
      // If it's the salon admin, we add the FS code
      if (existingUser.role === 'salon_admin' && existingUser.salon_id == req.params.id) {
        // Extract the 3-char ID from the existing identifier (AS + SalonCode + ID)
        // AS (2) + SalonCode (4) = 6 chars offset
        const personalId = existingUser.identifier.substring(6, 9);
        const fsCode = 'FS' + salon.salon_code + personalId;
        
        // Check if they already have the FS code
        if (!existingUser.identifier.includes(fsCode)) {
          identifier = existingUser.identifier + ',' + fsCode;
          db.prepare("UPDATE users SET identifier = ? WHERE id = ?").run(identifier, existingUser.id);
        } else {
          identifier = existingUser.identifier;
        }
        employeeId = existingUser.id;
      } else {
        return res.status(400).json({ success: false, message: "Usuário já existe com outro papel ou em outro salão." });
      }
    } else {
      const personalId = getUniquePersonalId(salon.salon_code);
      identifier = 'FS' + salon.salon_code + personalId;

      const result = db.prepare(`
        INSERT INTO users (role, name, surname, email, password, salon_id, must_change_password, active, cpf, dob, phone, street, number, neighborhood, city, state, country, photo_url, identifier)
        VALUES ('employee', ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(name, surname || null, email, password || 'funcs@Hair123', req.params.id, active !== undefined ? active : 1, cpf || null, dob || null, phone || null, street || null, number || null, neighborhood || null, city || null, state || null, country || null, photo_url || null, identifier);
      
      employeeId = result.lastInsertRowid;
    }
    
    if (services && Array.isArray(services)) {
      const insertService = db.prepare("INSERT INTO employee_services (employee_id, service_id, days_of_week) VALUES (?, ?, ?)");
      services.forEach(item => {
        if (typeof item === 'object') {
          insertService.run(employeeId, item.id, item.days_of_week ? JSON.stringify(item.days_of_week) : '[0,1,2,3,4,5,6]');
        } else {
          insertService.run(employeeId, item, '[0,1,2,3,4,5,6]');
        }
      });
    }
    
    if (workingHours && Array.isArray(workingHours)) {
      const insertWorkingHour = db.prepare("INSERT INTO employee_working_hours (employee_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)");
      workingHours.forEach(wh => insertWorkingHour.run(employeeId, wh.day_of_week, wh.start_time, wh.end_time));
    }
    
    res.json({ success: true, employeeId, identifier });
  } catch (error) {
    console.error(error);
    res.status(400).json({ success: false, message: "Error adding employee" });
  }
});

app.put("/api/salons/:id/employees/:employeeId", (req, res) => {
  const { name, surname, email, active, cpf, dob, phone, street, number, neighborhood, city, state, country, photo_url, services, workingHours } = req.body;
  try {
    db.prepare(`
      UPDATE users 
      SET name = ?, surname = ?, email = ?, active = ?, cpf = ?, dob = ?, phone = ?, street = ?, number = ?, neighborhood = ?, city = ?, state = ?, country = ?, photo_url = ?
      WHERE id = ? AND salon_id = ? AND role = 'employee'
    `).run(name, surname || null, email, active, cpf || null, dob || null, phone || null, street || null, number || null, neighborhood || null, city || null, state || null, country || null, photo_url || null, req.params.employeeId, req.params.id);
    
    const employeeId = req.params.employeeId;
    
    if (services && Array.isArray(services)) {
      db.prepare("DELETE FROM employee_services WHERE employee_id = ?").run(employeeId);
      const insertService = db.prepare("INSERT INTO employee_services (employee_id, service_id, days_of_week) VALUES (?, ?, ?)");
      services.forEach(item => {
        if (typeof item === 'object') {
          insertService.run(employeeId, item.id, item.days_of_week ? JSON.stringify(item.days_of_week) : '[0,1,2,3,4,5,6]');
        } else {
          insertService.run(employeeId, item, '[0,1,2,3,4,5,6]');
        }
      });
    }

    if (workingHours && Array.isArray(workingHours)) {
      db.prepare("DELETE FROM employee_working_hours WHERE employee_id = ?").run(employeeId);
      const insertWorkingHour = db.prepare("INSERT INTO employee_working_hours (employee_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)");
      workingHours.forEach(wh => insertWorkingHour.run(employeeId, wh.day_of_week, wh.start_time, wh.end_time));
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(400).json({ success: false, message: "Error updating employee" });
  }
});

app.delete("/api/salons/:id/employees/:employeeId", (req, res) => {
  try {
    const employeeId = req.params.employeeId;
    db.prepare("DELETE FROM employee_services WHERE employee_id = ?").run(employeeId);
    db.prepare("DELETE FROM employee_working_hours WHERE employee_id = ?").run(employeeId);
    db.prepare("DELETE FROM users WHERE id = ? AND salon_id = ? AND role = 'employee'").run(employeeId, req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error deleting employee" });
  }
});

app.put("/api/salons/:id/landing", (req, res) => {
  const { slogan, about_text, mission_text, logo_url, bg_url, street, number, neighborhood, city, state, country } = req.body;
  try {
    db.prepare(`
      UPDATE salons 
      SET slogan = ?, about_text = ?, mission_text = ?, logo_url = ?, bg_url = ?, street = ?, number = ?, neighborhood = ?, city = ?, state = ?, country = ?
      WHERE id = ?
    `).run(slogan, about_text, mission_text, logo_url, bg_url, street, number, neighborhood, city, state, country, req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error updating landing page config" });
  }
});

app.get("/api/users/:id/appointments", (req, res) => {
  const appointments = db.prepare(`
    SELECT a.*, s.name as salon_name, srv.name as service_name, emp.name as employee_name
    FROM appointments a
    JOIN salons s ON a.salon_id = s.id
    JOIN services srv ON a.service_id = srv.id
    LEFT JOIN users emp ON a.employee_id = emp.id
    WHERE a.client_id = ?
    ORDER BY a.start_time DESC
  `).all(req.params.id);
  res.json(appointments);
});

app.get("/api/salons/:id/appointments", (req, res) => {
  const appointments = db.prepare(`
    SELECT a.*, u.name as client_name, u.dob as client_dob, s.name as service_name, s.price as service_price, emp.name as employee_name
    FROM appointments a
    JOIN users u ON a.client_id = u.id
    JOIN services s ON a.service_id = s.id
    LEFT JOIN users emp ON a.employee_id = emp.id
    WHERE a.salon_id = ?
  `).all(req.params.id);
  res.json(appointments);
});

app.post("/api/checkout/preference", async (req, res) => {
  const { title, price, appointmentId, salonId, totalServicePrice } = req.body;
  
  try {
    const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
    const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
    
    const env = mpSettings.mp_env || 'test';
    const accessToken = env === 'prod' ? mpSettings.mp_prod_access_token : mpSettings.mp_test_access_token;
    
    if (!accessToken) {
      return res.status(400).json({ success: false, message: "Mercado Pago não configurado pelo administrador." });
    }

    const salon = db.prepare("SELECT * FROM salons WHERE id = ?").get(salonId) as any;
    
    const client = new MercadoPagoConfig({ accessToken: accessToken });
    const preference = new Preference(client);

    const origin = req.get('origin') || req.protocol + '://' + req.get('host');

    // Split Logic:
    // Total: R$ 100
    // Sinal (price): R$ 20 (20%)
    // Platform Fee: R$ 5 (5% of total)
    // Salon Share: R$ 15 (15% of total)
    
    const platformFee = totalServicePrice * 0.05;
    
    const body: any = {
      items: [
        {
          id: appointmentId.toString(),
          title: title,
          quantity: 1,
          unit_price: Number(price)
        }
      ],
      back_urls: {
        success: `${origin}/dashboard/client?payment=success&appointment_id=${appointmentId}`,
        failure: `${origin}/dashboard/client?payment=failure&appointment_id=${appointmentId}`,
        pending: `${origin}/dashboard/client?payment=pending&appointment_id=${appointmentId}`
      },
      auto_return: 'approved',
      external_reference: appointmentId.toString(),
      notification_url: `${origin}/api/webhooks/mercadopago`
    };

    // If salon has MP connected, use split
    if (salon && salon.mp_user_id) {
      body.marketplace_fee = platformFee;
      body.collector_id = Number(salon.mp_user_id);
    }

    const result = await preference.create({ body });

    const publicKey = env === 'prod' ? mpSettings.mp_prod_public_key : mpSettings.mp_test_public_key;

    res.json({ 
      success: true, 
      init_point: env === 'prod' ? result.init_point : result.sandbox_init_point,
      preferenceId: result.id,
      publicKey: publicKey
    });
  } catch (error) {
    console.error("Mercado Pago Error:", error);
    res.status(500).json({ success: false, message: "Erro ao gerar pagamento." });
  }
});

app.get("/api/appointments/:id", (req, res) => {
  try {
    const appointment = db.prepare(`
      SELECT a.*, s.name as service_name, s.price as service_price, sa.name as salon_name
      FROM appointments a
      JOIN services s ON a.service_id = s.id
      JOIN salons sa ON a.salon_id = sa.id
      WHERE a.id = ?
    `).get(req.params.id);
    
    if (!appointment) {
      return res.status(404).json({ success: false, message: "Agendamento não encontrado" });
    }
    
    res.json(appointment);
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.post("/api/checkout/process_payment", async (req, res) => {
  const { transaction_amount, token, description, installments, payment_method_id, issuer_id, payer, external_reference } = req.body;
  
  try {
    const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
    const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
    const env = mpSettings.mp_env || 'test';
    const accessToken = env === 'prod' ? mpSettings.mp_prod_access_token : mpSettings.mp_test_access_token;
    
    if (!accessToken) {
      return res.status(400).json({ success: false, message: "Mercado Pago não configurado." });
    }

    const appointment = db.prepare("SELECT * FROM appointments WHERE id = ?").get(external_reference) as any;
    if (!appointment) {
      return res.status(404).json({ success: false, message: "Agendamento não encontrado." });
    }
    
    const salon = db.prepare("SELECT * FROM salons WHERE id = ?").get(appointment.salon_id) as any;
    const service = db.prepare("SELECT * FROM services WHERE id = ?").get(appointment.service_id) as any;

    const platformFee = service.price * 0.05;

    const client = new MercadoPagoConfig({ accessToken: accessToken });
    const payment = new Payment(client);

    const body: any = {
      transaction_amount: Number(transaction_amount),
      description: description,
      payment_method_id: payment_method_id,
      payer: payer,
      external_reference: external_reference,
    };

    if (token) body.token = token;
    if (installments) body.installments = Number(installments);
    if (issuer_id) body.issuer_id = issuer_id;

    // Apply split if salon has MP connected
    // Payment SDK v2 supports application_fee
    if (salon && salon.mp_user_id) {
       body.application_fee = platformFee;
    }

    const requestOptions = {
        idempotencyKey: `${external_reference}-${Date.now()}`
    };

    const data = await payment.create({
      body: body,
      requestOptions: requestOptions
    });
    
    if (data.status === "approved" || data.status === "in_process" || data.status === "pending") {
      // If it's a synchronous approval (like card), we update the db immediately
      // If it's PIX (pending), the webhook will update the DB when paid.
      if (data.status === "approved") {
        db.prepare(`
          UPDATE appointments 
          SET status = 'scheduled', payment_id = ? 
          WHERE id = ?
        `).run(data.id.toString(), external_reference);
      }
      res.json({ success: true, payment_id: data.id, status: data.status, data: data });
    } else {
      console.error("MP Payment Error Response:", data);
      res.status(400).json({ success: false, message: "Pagamento recusado.", data: data });
    }
  } catch (error) {
    console.error("Payment Processing Error:", error);
    res.status(500).json({ success: false, message: "Erro ao processar pagamento." });
  }
});

// Webhook for payment notifications
app.post("/api/webhooks/mercadopago", async (req, res) => {
  const { action, data } = req.body;
  
  if (action === "payment.created" || action === "payment.updated") {
    const paymentId = data.id;
    
    try {
      const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
      const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
      const env = mpSettings.mp_env || 'test';
      const accessToken = env === 'prod' ? mpSettings.mp_prod_access_token : mpSettings.mp_test_access_token;

      const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      const paymentData = await response.json();

      if (paymentData.status === "approved") {
        const appointmentId = paymentData.external_reference;
        db.prepare(`
          UPDATE appointments 
          SET status = 'scheduled', payment_id = ? 
          WHERE id = ? AND status = 'pending_payment'
        `).run(paymentId, appointmentId);
      }
    } catch (error) {
      console.error("Webhook Error:", error);
    }
  }
  
  res.sendStatus(200);
});

app.post("/api/appointments", (req, res) => {
  const { client_id, salon_id, service_id, employee_id, start_time, end_time, paid_amount, pending_amount } = req.body;
  try {
    const result = db.prepare(`
      INSERT INTO appointments (client_id, salon_id, service_id, employee_id, start_time, end_time, status, paid_amount, pending_amount)
      VALUES (?, ?, ?, ?, ?, ?, 'pending_payment', ?, ?)
    `).run(client_id, salon_id, service_id, employee_id, start_time, end_time, paid_amount, pending_amount);
    res.json({ success: true, appointmentId: result.lastInsertRowid });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error booking appointment" });
  }
});

app.post("/api/appointments/:id/confirm-payment", (req, res) => {
  const { payment_id } = req.body;
  try {
    const result = db.prepare(`
      UPDATE appointments 
      SET status = 'scheduled', payment_id = ? 
      WHERE id = ? AND status = 'pending_payment'
    `).run(payment_id || null, req.params.id);
    
    if (result.changes > 0) {
      res.json({ success: true });
    } else {
      res.status(400).json({ success: false, message: "Appointment not found or already confirmed" });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Error confirming payment" });
  }
});

app.post("/api/appointments/:id/cancel", async (req, res) => {
  const { client_id } = req.body;
  
  try {
    const appointment = db.prepare("SELECT * FROM appointments WHERE id = ? AND client_id = ?").get(req.params.id, client_id) as any;
    
    if (!appointment) {
      return res.status(404).json({ success: false, message: "Agendamento não encontrado." });
    }

    if (appointment.status === 'cancelled') {
      return res.status(400).json({ success: false, message: "Agendamento já cancelado." });
    }

    const startDateTime = new Date(appointment.start_time);
    const now = new Date();
    const diffHours = (startDateTime.getTime() - now.getTime()) / (1000 * 60 * 60);

    let refundMessage = "";

    // Refund policy: only if > 24h before
    if (diffHours >= 24 && appointment.payment_id) {
      const settingsRows = db.prepare("SELECT * FROM settings").all() as any[];
      const mpSettings = settingsRows.reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
      
      const env = mpSettings.mp_env || 'test';
      const accessToken = env === 'prod' ? mpSettings.mp_prod_access_token : mpSettings.mp_test_access_token;
      
      if (accessToken) {
        const client = new MercadoPagoConfig({ accessToken: accessToken });
        const refund = new PaymentRefund(client);
        
        try {
          await refund.create({ payment_id: appointment.payment_id });
          refundMessage = "O estorno foi solicitado automaticamente.";
        } catch (mpError) {
          console.error("Mercado Pago Refund Error:", mpError);
          refundMessage = "Erro ao processar estorno automático. Entre em contato com o suporte.";
        }
      }
    } else if (diffHours < 24 && appointment.payment_id) {
      refundMessage = "O sinal de 20% não é reembolsável para cancelamentos com menos de 24h de antecedência.";
    }

    db.prepare("UPDATE appointments SET status = 'cancelled' WHERE id = ?").run(req.params.id);
    res.json({ success: true, message: `Agendamento cancelado com sucesso. ${refundMessage}` });

  } catch (error) {
    console.error("Cancel Error:", error);
    res.status(500).json({ success: false, message: "Erro ao cancelar agendamento." });
  }
});

app.get("/api/salons/:id/services/:serviceId/employees", (req, res) => {
  const { id, serviceId } = req.params;
  try {
    const employees = db.prepare(`
      SELECT u.id, u.name, u.surname, u.photo_url
      FROM users u
      JOIN employee_services es ON u.id = es.employee_id
      WHERE u.salon_id = ? AND u.role = 'employee' AND u.active = 1 AND es.service_id = ?
    `).all(id, serviceId);

    const employeesWithDays = employees.map(emp => {
      const workingDays = db.prepare(`
        SELECT DISTINCT day_of_week 
        FROM employee_working_hours 
        WHERE employee_id = ?
      `).all(emp.id).map(d => d.day_of_week);
      return { ...emp, workingDays };
    });

    res.json(employeesWithDays);
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Error fetching service employees" });
  }
});

app.get("/api/salons/:id/available-days", (req, res) => {
  const { service_id, employee_id } = req.query;
  const salon_id = req.params.id;

  if (!service_id) {
    return res.status(400).json({ success: false, message: "Missing service_id" });
  }

  try {
    let query = `
      SELECT DISTINCT ewh.day_of_week
      FROM employee_working_hours ewh
      JOIN employee_services es ON ewh.employee_id = es.employee_id
      JOIN users u ON u.id = ewh.employee_id
      WHERE u.salon_id = ? AND u.role = 'employee' AND u.active = 1 AND es.service_id = ?
    `;
    let params = [salon_id, service_id];

    if (employee_id) {
      query += ` AND u.id = ?`;
      params.push(employee_id);
    }

    const availableDays = db.prepare(query).all(...params);

    res.json(availableDays.map((d: any) => d.day_of_week));
  } catch (error) {
    console.error("Available Days Error:", error);
    res.status(500).json({ success: false, message: "Erro ao buscar dias disponíveis." });
  }
});

app.get("/api/salons/:id/available-times", (req, res) => {
  const { date, service_id, employee_id } = req.query;
  const salon_id = req.params.id;

  if (!date || !service_id) {
    return res.status(400).json({ success: false, message: "Missing date or service_id" });
  }

  try {
    // Cleanup expired appointments (older than 7 minutes)
    db.prepare(`
      UPDATE appointments 
      SET status = 'cancelled_expired' 
      WHERE status = 'pending_payment' 
      AND datetime(created_at, '+7 minutes') < datetime('now')
    `).run();

    const service = db.prepare("SELECT duration FROM services WHERE id = ? AND salon_id = ?").get(service_id, salon_id);
    if (!service) return res.status(404).json({ success: false, message: "Service not found" });

    const duration = service.duration;

    // Get active employees who provide the service
    let employeeQuery = `
      SELECT u.id 
      FROM users u
      JOIN employee_services es ON u.id = es.employee_id
      WHERE u.salon_id = ? AND u.role = 'employee' AND u.active = 1 AND es.service_id = ?
    `;
    let employeeParams = [salon_id, service_id];

    if (employee_id) {
      employeeQuery += ` AND u.id = ?`;
      employeeParams.push(employee_id);
    }

    const employees = db.prepare(employeeQuery).all(...employeeParams);

    if (employees.length === 0) {
      return res.json([]); // No employees available for this service
    }

    const dayOfWeek = new Date(`${date}T00:00:00`).getDay(); // 0 = Sunday, 1 = Monday...
    
    // Get working hours for these employees on this day
    const employeeIds = employees.map(e => e.id);
    const workingHours = db.prepare(`
      SELECT employee_id, start_time, end_time 
      FROM employee_working_hours 
      WHERE employee_id IN (${employeeIds.join(',')}) AND day_of_week = ?
    `).all(dayOfWeek);

    if (workingHours.length === 0) {
      return res.json([]); // No employees working on this day
    }

    // Get all appointments for that day for these employees
    const appointments = db.prepare(`
      SELECT employee_id, start_time, end_time 
      FROM appointments 
      WHERE salon_id = ? AND date(start_time) = ? AND status NOT IN ('cancelled', 'cancelled_expired') AND employee_id IN (${employeeIds.join(',')})
    `).all(salon_id, date);

    const availableTimes = [];
    
    // Find earliest start and latest end
    let minStart = "23:59";
    let maxEnd = "00:00";
    workingHours.forEach(wh => {
      if (wh.start_time < minStart) minStart = wh.start_time;
      if (wh.end_time > maxEnd) maxEnd = wh.end_time;
    });

    let currentSlot = new Date(`${date}T${minStart}:00`);
    const closeTime = new Date(`${date}T${maxEnd}:00`);

    // Current time in Brasilia (UTC-3)
    const now = new Date();
    const brtTime = new Date(now.toLocaleString("en-US", {timeZone: "America/Sao_Paulo"}));
    const minBookingTime = new Date(brtTime.getTime() + 60 * 60 * 1000); // +60 minutes

    while (currentSlot < closeTime) {
      const slotEnd = new Date(currentSlot.getTime() + duration * 60000);
      
      if (currentSlot >= minBookingTime) {
        let availableEmployeeId = null;

        for (const wh of workingHours) {
          const empStart = new Date(`${date}T${wh.start_time}:00`);
          const empEnd = new Date(`${date}T${wh.end_time}:00`);
          
          if (currentSlot >= empStart && slotEnd <= empEnd) {
            // Check appointments
            const empAppointments = appointments.filter((a: any) => a.employee_id === wh.employee_id);
            let isFree = true;
            for (const appt of empAppointments) {
              const apptStart = new Date(appt.start_time);
              const apptEnd = new Date(appt.end_time);
              if (currentSlot < apptEnd && slotEnd > apptStart) {
                isFree = false;
                break;
              }
            }
            if (isFree) {
              availableEmployeeId = wh.employee_id;
              break;
            }
          }
        }

        if (availableEmployeeId) {
          availableTimes.push({
            time: currentSlot.toTimeString().substring(0, 5), // HH:MM
            employee_id: availableEmployeeId
          });
        }
      }

      // Increment by 30 minutes
      currentSlot = new Date(currentSlot.getTime() + 30 * 60000);
    }

    res.json(availableTimes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.get("/api/admin/stats", (req, res) => {
  const usersCount = db.prepare("SELECT COUNT(*) as count FROM users").get();
  const salonsCount = db.prepare("SELECT COUNT(*) as count FROM salons").get();
  const appointmentsCount = db.prepare("SELECT COUNT(*) as count FROM appointments").get();
  const revenue = db.prepare("SELECT SUM(paid_amount + pending_amount) as total FROM appointments").get();
  
  const totalRevenue = revenue.total || 0;
  const platformRevenue = totalRevenue * 0.05; // 5% fee

  res.json({ 
    users: usersCount.count, 
    salons: salonsCount.count, 
    appointments: appointmentsCount.count,
    revenue: platformRevenue
  });
});

app.get("/api/admin/settings", (req, res) => {
  try {
    const settings = db.prepare("SELECT key, value FROM settings").all();
    const settingsObj = settings.reduce((acc, curr) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {});
    res.json(settingsObj);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching settings" });
  }
});

app.post("/api/admin/settings", (req, res) => {
  const settings = req.body;
  try {
    const stmt = db.prepare("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value");
    const insertMany = db.transaction((settingsObj) => {
      for (const [key, value] of Object.entries(settingsObj)) {
        stmt.run(key, String(value));
      }
    });
    insertMany(settings);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error saving settings" });
  }
});

app.get("/api/admin/users", (req, res) => {
  try {
    const users = db.prepare("SELECT id, name, email, role FROM users ORDER BY id DESC").all();
    res.json(users);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching users" });
  }
});

app.get("/api/admin/salons", (req, res) => {
  try {
    const salons = db.prepare(`
      SELECT s.id, s.name, s.cnpj, u.name as admin_name, u.email as admin_email
      FROM salons s 
      JOIN users u ON s.admin_id = u.id 
      ORDER BY s.id DESC
    `).all();
    res.json(salons);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching salons" });
  }
});

app.get("/api/admin/appointments", (req, res) => {
  const appointments = db.prepare(`
    SELECT a.id, a.start_time, a.status, a.paid_amount, a.pending_amount,
           u.name as client_name, s.name as salon_name, srv.name as service_name
    FROM appointments a
    JOIN users u ON a.client_id = u.id
    JOIN salons s ON a.salon_id = s.id
    JOIN services srv ON a.service_id = srv.id
    ORDER BY a.start_time DESC
  `).all();
  res.json(appointments);
});

app.get("/api/admin/fee-stats", (req, res) => {
  try {
    const appointments = db.prepare(`
      SELECT 
        a.id as appointment_id,
        a.start_time,
        a.status,
        a.paid_amount,
        a.pending_amount,
        s.id as salon_id,
        s.name as salon_name,
        s.city as salon_city,
        s.state as salon_state
      FROM appointments a
      JOIN salons s ON a.salon_id = s.id
    `).all() as any[];

    const mockSalons = [
      { id: 101, name: "Nexus Hair São Paulo", city: "São Paulo", state: "SP" },
      { id: 102, name: "Quantum Style Campinas", city: "Campinas", state: "SP" },
      { id: 103, name: "Guarujá Beach Cut", city: "Guarujá", state: "SP" },
      { id: 104, name: "Rio Energy Salon", city: "Rio de Janeiro", state: "RJ" },
      { id: 105, name: "Búzios Glow", city: "Búzios", state: "RJ" },
      { id: 106, name: "Serra Imperial Petrópolis", city: "Petrópolis", state: "RJ" },
      { id: 107, name: "Horizonte Infinity BH", city: "Belo Horizonte", state: "MG" },
      { id: 108, name: "Ouro Preto Classic", city: "Ouro Preto", state: "MG" },
      { id: 109, name: "Regent Curitiba", city: "Curitiba", state: "PR" },
      { id: 110, name: "Catedral Gramado Spa", city: "Gramado", state: "RS" },
      { id: 111, name: "Bahia Solar Stylists", city: "Salvador", state: "BA" },
      { id: 112, name: "Pernambuco Wave Recife", city: "Recife", state: "PE" },
      { id: 113, name: "Esplanada Matrix", city: "Brasília", state: "DF" },
      { id: 114, name: "Amazonas Tech Cut", city: "Manaus", state: "AM" }
    ];

    const finalData: any[] = [];

    appointments.forEach((app: any) => {
      const city = app.salon_city || "São Paulo";
      const state = (app.salon_state || "SP").toUpperCase().trim();
      const status = app.status || "confirmed";
      const paid = app.paid_amount || 0;
      const pending = app.pending_amount || 0;
      const total_amount = paid + pending;
      const platform_fee = total_amount * 0.05;

      let brazil_region = "Sudeste";
      if (["PR", "SC", "RS"].includes(state)) brazil_region = "Sul";
      else if (["BA", "PE", "CE", "RN", "PB", "AL", "SE", "MA", "PI"].includes(state)) brazil_region = "Nordeste";
      else if (["MT", "MS", "GO", "DF"].includes(state)) brazil_region = "Centro-Oeste";
      else if (["AM", "PA", "AC", "RO", "RR", "AP", "TO"].includes(state)) brazil_region = "Norte";

      let state_region = "Interior";
      const metropolises = ["SÃO PAULO", "RIO DE JANEIRO", "BELO HORIZONTE", "CURITIBA", "PORTO ALEGRE", "SALVADOR", "RECIFE", "FORTALEZA", "BRASÍLIA", "MANAUS", "BELÉM"];
      if (metropolises.includes(city.toUpperCase())) {
        state_region = "Região Metropolitana";
      } else if (["GUARUJÁ", "SANTOS", "UBATUBA", "ANGRA", "NITERÓI", "BALNEÁRIO", "FLORIANÓPOLIS", "BÚZIOS"].includes(city.toUpperCase())) {
        state_region = "Litoral";
      } else if (["PETRÓPOLIS", "CAMPOS DO JORDÃO", "GRAMADO"].includes(city.toUpperCase())) {
        state_region = "Serrana";
      }

      finalData.push({
        id: app.appointment_id,
        salon_id: app.salon_id,
        salon_name: app.salon_name,
        city,
        state,
        state_region,
        brazil_region,
        status,
        total_amount,
        platform_fee,
        start_time: app.start_time
      });
    });

    if (finalData.length < 5) {
      const mockStatuses = ["completed", "confirmed", "pending_payment", "cancelled"];
      for (let i = 0; i < 40; i++) {
        const mockSalon = mockSalons[i % mockSalons.length];
        const city = mockSalon.city;
        const state = mockSalon.state;
        const status = mockStatuses[i % mockStatuses.length];
        
        let total_amount = 80 + (i * 7.5) % 150;
        let paid = 0;
        let pending = 0;
        if (status === "completed") {
          paid = total_amount;
        } else if (status === "confirmed") {
          paid = total_amount * 0.20;
          pending = total_amount * 0.80;
        } else {
          pending = total_amount;
        }
        
        const platform_fee = total_amount * 0.05;

        let brazil_region = "Sudeste";
        if (["PR", "SC", "RS"].includes(state)) brazil_region = "Sul";
        else if (["BA", "PE", "CE", "RN", "PB", "AL", "SE", "MA", "PI"].includes(state)) brazil_region = "Nordeste";
        else if (["MT", "MS", "GO", "DF"].includes(state)) brazil_region = "Centro-Oeste";
        else if (["AM", "PA", "AC", "RO", "RR", "AP", "TO"].includes(state)) brazil_region = "Norte";

        let state_region = "Interior";
        const metropolises = ["SÃO PAULO", "RIO DE JANEIRO", "BELO HORIZONTE", "CURITIBA", "PORTO ALEGRE", "SALVADOR", "RECIFE", "FORTALEZA", "BRASÍLIA", "MANAUS", "BELÉM"];
        if (metropolises.includes(city.toUpperCase())) {
          state_region = "Região Metropolitana";
        } else if (["GUARUJÁ", "SANTOS", "UBATUBA", "ANGRA", "NITERÓI", "BALNEÁRIO", "FLORIANÓPOLIS", "BÚZIOS"].includes(city.toUpperCase())) {
          state_region = "Litoral";
        } else if (["PETRÓPOLIS", "CAMPOS DO JORDÃO", "GRAMADO"].includes(city.toUpperCase())) {
          state_region = "Serrana";
        }

        finalData.push({
          id: 9000 + i,
          salon_id: mockSalon.id,
          salon_name: mockSalon.name,
          city,
          state,
          state_region,
          brazil_region,
          status,
          total_amount,
          platform_fee,
          start_time: new Date(Date.now() - (i * 24 * 60 * 60 * 1000)).toISOString()
        });
      }
    }

    res.json(finalData);
  } catch (error) {
    console.error("Fee Stats Error:", error);
    res.status(500).json({ success: false, message: "Error fetching fee stats" });
  }
});

app.delete("/api/admin/users/:id", (req, res) => {
  try {
    db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error deleting user" });
  }
});

app.delete("/api/admin/salons/:id", (req, res) => {
  try {
    db.prepare("DELETE FROM salons WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error deleting salon" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
