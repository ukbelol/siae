# GOITGODS 2.3.1 — Correção SSL/Certbot

- Corrige o erro `Invalid email address: .` validando o e-mail antes de executar o Certbot.
- Permite informar o e-mail por `--certbot-email` ou `CERTBOT_EMAIL`.
- Remove fallback interativo inseguro após falha do Certbot.
- Valida DNS do domínio obrigatório `goitgods.pasquared.space`.
- Inclui `www.goitgods.pasquared.space` apenas quando houver DNS no modo padrão `auto`.
- Adiciona `--with-www` e `--no-www`.
- Gera VirtualHost Apache coerente com os nomes realmente incluídos no certificado.
- Verifica `fullchain.pem` e `privkey.pem` após a emissão.
- Habilita `certbot.timer` e executa `certbot renew --dry-run`.
- Atualiza `.env.example` com parâmetros TLS/Let's Encrypt.
