const fs = require('fs');
const path = require('path');

function replaceAllSqliteWithMysql(file) {
  if (!fs.existsSync(file)) return;
  let content = fs.readFileSync(file, 'utf8');

  // Convert schema
  if (file.includes('schema.ts')) {
    content = content.replace(/AUTOINCREMENT/g, 'AUTO_INCREMENT');
  }

  // Convert db calls
  if (file.includes('api/')) {
    // Convert synchronous router definitions to async
    content = content.replace(/router\.(get|post|put|delete)\(([^,]+),\s*\(\s*req,\s*res\s*\)\s*=>/g, "router.$1($2, async (req, res) =>");

    // Replace db.prepare(Q).get(args) -> (await db.query(Q, [args]))[0][0]
    // .get(params)
    content = content.replace(/db\.prepare\(`([^`]+)`\)\.get\(([^)]+)\)/g, "(await db.query(`$1`, [$2]))[0][0]");
    content = content.replace(/db\.prepare\('([^']+)'\)\.get\(([^)]+)\)/g, "(await db.query('$1', [$2]))[0][0]");
    // .get()
    content = content.replace(/db\.prepare\(`([^`]+)`\)\.get\(\)/g, "(await db.query(`$1`))[0][0]");
    content = content.replace(/db\.prepare\('([^']+)'\)\.get\(\)/g, "(await db.query('$1'))[0][0]");

    // .all(params)
    content = content.replace(/db\.prepare\(`([^`]+)`\)\.all\(([^)]+)\)/g, "(await db.query(`$1`, [$2]))[0]");
    content = content.replace(/db\.prepare\('([^']+)'\)\.all\(([^)]+)\)/g, "(await db.query('$1', [$2]))[0]");
    // .all()
    content = content.replace(/db\.prepare\(`([^`]+)`\)\.all\(\)/g, "(await db.query(`$1`))[0]");
    content = content.replace(/db\.prepare\('([^']+)'\)\.all\(\)/g, "(await db.query('$1'))[0]");

    // .run(params)
    content = content.replace(/db\.prepare\(`([^`]+)`\)\.run\(([^)]+)\)/g, "(await db.query(`$1`, [$2]))[0]");
    content = content.replace(/db\.prepare\('([^']+)'\)\.run\(([^)]+)\)/g, "(await db.query('$1', [$2]))[0]");
    // .run()
    content = content.replace(/db\.prepare\(`([^`]+)`\)\.run\(\)/g, "(await db.query(`$1`))[0]");
    content = content.replace(/db\.prepare\('([^']+)'\)\.run\(\)/g, "(await db.query('$1'))[0]");

    // Fix info assignments (from .run)
    // const info = stmt.run(...) -> const [info] = await db.query(...)
    content = content.replace(/const info = stmt\.run\(([^)]*)\);/g, "const [info] = await db.query(stmt, [$1]) as any;");
    content = content.replace(/const stmt = db\.prepare\((['`][^'`]+['`])\);/g, "const stmt = $1;");

    // Replace info.lastInsertRowid with info.insertId
    content = content.replace(/info\.lastInsertRowid/g, "info.insertId");
    
    // SQLite date functions might fail if not compatible, e.g. date(created_at) -> DATE(created_at)
    content = content.replace(/date\(created_at\)/g, "DATE(created_at)");
  }
  
  fs.writeFileSync(file, content);
}

['src/lib/schema.ts', 'src/api/index.ts', 'src/api/admin.ts'].forEach(replaceAllSqliteWithMysql);
