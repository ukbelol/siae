# Arquitetura e Fluxo de Pagamento - Mercado Pago Split

## Contexto
Marketplace B2C de serviços (Barbearia, Estética).
- Sinal: 20% online via plataforma.
- Restante: 80% presencial.
- Split do Sinal (20% do total):
  - 15% do valor total para o Prestador.
  - 5% do valor total para a Plataforma (Taxa).

## Arquitetura
1. **Frontend (React)**: Interface de checkout onde o cliente insere os dados do cartão ou gera PIX.
2. **Backend (Node.js/Express)**: Hub de pagamentos que se comunica com a API do Mercado Pago.
3. **Mercado Pago API**: Processa o pagamento e realiza a divisão (split) automaticamente.

## Fluxo de Funcionamento

### 1. Onboarding do Prestador (OAuth)
Para que o split funcione, o prestador precisa vincular sua conta do Mercado Pago à plataforma.
- O prestador clica em "Vincular Mercado Pago" no Dashboard.
- É redirecionado para a URL de autorização do Mercado Pago.
- Após autorizar, o Mercado Pago redireciona de volta com um `code`.
- O Backend troca o `code` por um `access_token` e `refresh_token` e salva no banco de dados atrelado ao Salão.

### 2. Agendamento e Checkout
- Cliente escolhe o serviço de R$ 100,00.
- O sistema calcula o sinal: R$ 20,00 (20%).
- Cliente vai para o checkout pagar os R$ 20,00.

### 3. Processamento do Pagamento (Backend)
O Backend cria a preferência de pagamento ou processa o pagamento via API (Advanced Payments) com as regras de split.

**Cálculo:**
- Valor Total do Serviço: R$ 100,00
- Valor Cobrado no MP (Sinal): R$ 20,00
- Taxa da Plataforma (5% do total): R$ 5,00
- Repasse ao Prestador (15% do total): R$ 15,00

**Payload para a API do Mercado Pago (Exemplo de Payment):**
\`\`\`json
{
  "transaction_amount": 20.00,
  "description": "Sinal - Serviço de Corte",
  "payment_method_id": "pix",
  "payer": {
    "email": "cliente@email.com"
  },
  "application_fee": 5.00, 
  "sponsor_id": 123456789, 
  "merchant_account_id": "ID_CONTA_PRESTADOR" 
}
\`\`\`
*Nota: O `application_fee` é o valor que fica com a plataforma (R$ 5,00). O restante (R$ 15,00) vai para a conta do prestador.*

### 4. Confirmação e Pós-Venda
- O Mercado Pago aprova o pagamento de R$ 20,00.
- O Webhook do Mercado Pago notifica o Backend da plataforma.
- O Backend atualiza o status do agendamento para `Confirmado`.
- O saldo de R$ 15,00 é liberado na conta do Mercado Pago do Prestador.
- O saldo de R$ 5,00 é liberado na conta do Mercado Pago da Plataforma.
- O sistema registra que R$ 80,00 estão pendentes para pagamento presencial.
