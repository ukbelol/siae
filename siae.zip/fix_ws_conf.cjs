const fs = require('fs');
let s = fs.readFileSync('si.siae.space.conf', 'utf8');
const search = 'RewriteRule ^/http-bind/(.*) "ws://127.0.0.1:7070/http-bind/$1" [P,L]';
const replace = search + '\n    RewriteRule ^/ws/(.*) "ws://127.0.0.1:7070/ws/$1" [P,L]';
s = s.split(search).join(replace);
fs.writeFileSync('si.siae.space.conf', s);
