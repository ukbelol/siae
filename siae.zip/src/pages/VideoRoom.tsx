import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Monitor, 
  MonitorOff, 
  Send, 
  Paperclip, 
  MessageSquare, 
  Users, 
  Download, 
  X, 
  FileText, 
  LogOut, 
  CheckCircle2, 
  AlertTriangle, 
  Heart,
  ChevronRight,
  Shield,
  Loader2,
  Lock,
  Mail,
  Copy,
  Plus,
  Phone,
  MapPin
} from 'lucide-react';
import { toast } from 'react-hot-toast';

// Simple Synth for UI feedback
function playConferenceTone(type: 'join' | 'leave' | 'file') {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    if (type === 'join') {
      // Warm double chime (do-mi)
      const osc1 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.frequency.value = 523.25; // C5
      osc1.type = 'sine';
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
      osc1.connect(gain);
      gain.connect(ctx.destination);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.3);

      setTimeout(() => {
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.frequency.value = 659.25; // E5
        osc2.type = 'sine';
        gain2.gain.setValueAtTime(0.15, ctx.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start();
        osc2.stop(ctx.currentTime + 0.3);
      }, 150);
    } else if (type === 'leave') {
      // Descending warning (fa-re)
      const osc1 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.frequency.value = 440; // A4
      osc1.type = 'sine';
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
      osc1.connect(gain);
      gain.connect(ctx.destination);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.3);

      setTimeout(() => {
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.frequency.value = 349.23; // F4
        osc2.type = 'sine';
        gain2.gain.setValueAtTime(0.15, ctx.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start();
        osc2.stop(ctx.currentTime + 0.3);
      }, 150);
    } else if (type === 'file') {
      // Sparkly notification sound (hi triad)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 880; // A5
      osc.type = 'triangle';
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    }
  } catch (e) {
    // Audio Context blocked or fails gracefully
  }
}

const FALLBACK_AVATARS = [
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face", // Female 1
  "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face", // Male 1
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face", // Female 2
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face", // Male 2
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face", // Female 3
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&h=150&fit=crop&crop=face"  // Male 3
];

interface PeerConnectionData {
  pc: RTCPeerConnection;
  stream?: MediaStream;
}

export default function VideoRoom() {
  const { roomName } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  // Authentication Fields (Fallback)
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Media Permissions Verification Screen
  const [isReadyToEnter, setIsReadyToEnter] = useState(false);
  const [hasMicPermission, setHasMicPermission] = useState<boolean | null>(null);
  const [hasCamPermission, setHasCamPermission] = useState<boolean | null>(null);
  const [checkingMedia, setCheckingMedia] = useState(false);
  const [mediaRequested, setMediaRequested] = useState(false);

  // Conference data loaded from DB
  const [conference, setConference] = useState<any>(null);

  // Active Call parameters
  const [isMuted, setIsMuted] = useState(false);
  const [isCamOff, setIsCamOff] = useState(false);
  const [isSharingScreen, setIsSharingScreen] = useState(false);
  
  // Real layout parameters
  const [activeTab, setActiveTab] = useState<'chat' | 'files' | 'users' | null>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [roomFiles, setRoomFiles] = useState<any[]>([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  
  // WebRTC objects references
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const myPeerId = useRef<string>(Math.random().toString(36).substring(2, 11) + '-' + Date.now().toString().slice(-4));
  
  // WebRTC Connections dictionary
  const pcs = useRef<{ [peerId: string]: PeerConnectionData }>({});
  
  // Peer State List
  const [peersList, setPeersList] = useState<any[]>([]); // Current active peers in room from API
  const [remoteStreams, setRemoteStreams] = useState<{ [peerId: string]: { stream: MediaStream; name: string; isMuted: boolean; isCamOff: boolean; isScreenShare: boolean } }>({});
  
  // Poll timestamp reference
  const lastPollTime = useRef<number>(0);
  const isPollingRef = useRef<boolean>(true);

  // Check login
  useEffect(() => {
    const userStr = localStorage.getItem('siae_user');
    if (userStr) {
      try {
        const u = JSON.parse(userStr);
        setUser(u);
      } catch (e) {}
    }

    if (roomName) {
      fetch(`/api/conferences/room/${roomName}`)
        .then(res => res.json())
        .then(data => {
          if (data && !data.error) {
            setConference(data);
          }
        })
        .catch(console.error);
    }

    return () => {
      // Cleanup WebRTC and Streams on unmount
      isPollingRef.current = false;
      leaveRoomGracefully();
    };
  }, [roomName]);

  // Request permissions once logged in
  useEffect(() => {
    if (user) {
      checkPermissionsStatus();
    }
  }, [user]);

  const checkPermissionsStatus = async () => {
    try {
      if (navigator.permissions && navigator.permissions.query) {
        const camPermission = await navigator.permissions.query({ name: 'camera' as any }).catch(() => null);
        const micPermission = await navigator.permissions.query({ name: 'microphone' as any }).catch(() => null);
        
        if (camPermission) {
          setHasCamPermission(camPermission.state === 'granted');
          camPermission.onchange = () => setHasCamPermission(camPermission.state === 'granted');
        }
        if (micPermission) {
          setHasMicPermission(micPermission.state === 'granted');
          micPermission.onchange = () => setHasMicPermission(micPermission.state === 'granted');
        }
      }
    } catch (e) {
      console.log('Permission check not supported or failed.');
    }
  };

  const requestMediaPermissions = async () => {
    setCheckingMedia(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      setHasMicPermission(true);
      setHasCamPermission(true);
      setMediaRequested(true);
      
      // Release streams immediately to shut down active camera LED during checks
      stream.getTracks().forEach(track => track.stop());
    } catch (err: any) {
      setMediaRequested(true);
      toast.error('Por favor, conceda acesso à câmera e microfone para avançar.');
      
      // Fallback individually
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        setHasMicPermission(true);
        audioStream.getTracks().forEach(track => track.stop());
      } catch {
        setHasMicPermission(false);
      }

      try {
        const videoStream = await navigator.mediaDevices.getUserMedia({ video: true });
        setHasCamPermission(true);
        videoStream.getTracks().forEach(track => track.stop());
      } catch {
        setHasCamPermission(false);
      }
    } finally {
      setCheckingMedia(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      localStorage.setItem('siae_token', data.token);
      localStorage.setItem('siae_user', JSON.stringify(data.user));
      setUser(data.user);
      toast.success('Autenticado com sucesso!');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const startConferenceCall = async () => {
    if (!roomName) return;
    try {
      // Capture stream
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: { width: 640, height: 480, frameRate: 24 } 
      });
      localStreamRef.current = stream;
      
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Sync state of controls
      stream.getAudioTracks().forEach(t => t.enabled = !isMuted);
      stream.getVideoTracks().forEach(t => t.enabled = !isCamOff);

      // Register inside backend signaling list
      const displayName = user ? `${user.first_name || ''} ${user.last_name || ''}`.trim() : 'Participante';
      const registerRes = await fetch(`/api/conferences/room/${roomName}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          peerId: myPeerId.current,
          userName: displayName,
          userId: user?.id || 0
        })
      });
      
      const regData = await registerRes.json();
      if (regData.peers) {
        setPeersList(regData.peers);
        // Start signaling for any peers that already exist
        regData.peers.forEach((peer: any) => {
          if (peer.peerId !== myPeerId.current) {
            initiatePeerConnection(peer.peerId, peer.userName, true);
          }
        });
      }

      // Start the long polling Signaling loop
      isPollingRef.current = true;
      runPollingLoop();
      setIsReadyToEnter(true);
      
      playConferenceTone('join');
      toast.success('Entrou na sala de conferência!');
    } catch (err: any) {
      console.error('Failed to start conference local media:', err);
      toast.error('Erro ao acessar câmera/microfone: ' + err.message);
    }
  };

  const leaveRoomGracefully = () => {
    try {
      // Stop all tracks
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(track => track.stop());
        localStreamRef.current = null;
      }
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(track => track.stop());
        screenStreamRef.current = null;
      }

      // Close Peer Connections
      Object.keys(pcs.current).forEach(id => {
        try {
          pcs.current[id].pc.close();
        } catch (e) {}
      });
      pcs.current = {};

      setRemoteStreams({});
    } catch (e) {
      console.error(e);
    }
  };

  // Run polling signaling loop
  const runPollingLoop = async () => {
    if (!roomName || !isPollingRef.current) return;
    
    try {
      const displayName = user ? `${user.first_name || ''} ${user.last_name || ''}`.trim() : 'Participante';
      const response = await fetch(`/api/conferences/room/${roomName}/poll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          peerId: myPeerId.current,
          userName: displayName,
          userId: user?.id || 0,
          since: lastPollTime.current
        })
      });

      if (!response.ok) throw new Error('Polling error');
      const data = await response.json();
      
      if (data.success) {
        lastPollTime.current = data.timestamp;
        
        // 1. Process active peers list differences
        const curPeers = data.peers || [];
        setPeersList(curPeers);
        
        // Handle peers who left from remote streams
        Object.keys(remoteStreams).forEach(peerId => {
          const stillThere = curPeers.some((p: any) => p.peerId === peerId);
          if (!stillThere) {
            // Remove connection
            if (pcs.current[peerId]) {
              try { pcs.current[peerId].pc.close(); } catch(e) {}
              delete pcs.current[peerId];
            }
            // Remove stream
            setRemoteStreams(prev => {
              const clone = { ...prev };
              delete clone[peerId];
              return clone;
            });
            playConferenceTone('leave');
            toast.error('Um participante deixou a sala.');
          }
        });

        // 2. Process incoming signals (offers, answers, ICE candidates, chats)
        const signals = data.signals || [];
        for (const sig of signals) {
          await handleIncomingSignal(sig);
        }

        // 3. Process files differences
        if (data.files && data.files.length !== roomFiles.length) {
          // If we have new files, alert user
          if (roomFiles.length > 0 && data.files.length > roomFiles.length) {
            const addedFile = data.files[data.files.length - 1];
            playConferenceTone('file');
            toast.success(`Novo arquivo disponível: ${addedFile.fileName} (enviado por ${addedFile.senderName})`);
          }
          setRoomFiles(data.files);
        }
      }
    } catch (err) {
      console.log('Signal poll cycle ignored or disconnected.', err);
    }

    // Schedule next poll in 1500ms
    if (isPollingRef.current) {
      setTimeout(runPollingLoop, 1500);
    }
  };

  const handleIncomingSignal = async (sig: any) => {
    const { senderId, type, payload } = sig;
    
    if (type === 'chat') {
      const isNew = !chatMessages.some(m => m.id === sig.id);
      if (isNew) {
        setChatMessages(prev => [...prev, {
          id: sig.id,
          senderName: payload.senderName,
          text: payload.text,
          timestamp: payload.timestamp,
          isFileNotify: payload.isFileNotify
        }]);
        // Open chat pane and flash notification if we were not already inside it
        if (!payload.isFileNotify && activeTab !== 'chat') {
          setActiveTab('chat');
        }
      }
      return;
    }

    // Ensure peer connection exists
    let connection = pcs.current[senderId];
    if (!connection) {
      connection = initiatePeerConnection(senderId, payload.senderName || 'Participante', false);
    }

    const pc = connection.pc;

    if (type === 'rtc-offer') {
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        
        // Send answering back
        sendSignalingMessage(senderId, 'rtc-answer', { sdp: answer });
      } catch (e) {
        console.error('Error handling RTCOffer:', e);
      }
    } else if (type === 'rtc-answer') {
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
      } catch (e) {
        console.error('Error handling RTCAnswer:', e);
      }
    } else if (type === 'rtc-ice') {
      try {
        if (payload.candidate) {
          await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
        }
      } catch (e) {
        console.warn('Error adding ICE candidate:', e);
      }
    } else if (type === 'track-state') {
      // Sync microfone/camera disable status indicators in rendering grid
      setRemoteStreams(prev => {
        if (!prev[senderId]) return prev;
        return {
          ...prev,
          [senderId]: {
            ...prev[senderId],
            isMuted: payload.isMuted,
            isCamOff: payload.isCamOff,
            isScreenShare: payload.isScreenShare
          }
        };
      });
    }
  };

  // Init the peer connection object with another WebRTC client
  const initiatePeerConnection = (targetPeerId: string, peerName: string, isInitiator: boolean) => {
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
        { urls: 'stun:stun2.l.google.com:19302' }
      ]
    });

    const connData: PeerConnectionData = { pc };
    pcs.current[targetPeerId] = connData;

    // Attach local stream tracks to this peer connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, localStreamRef.current!);
      });
    }

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignalingMessage(targetPeerId, 'rtc-ice', { candidate: event.candidate });
      }
    };

    pc.ontrack = (event) => {
      const stream = event.streams[0];
      connData.stream = stream;

      // Update state to trigger video layout rendering
      setRemoteStreams(prev => ({
        ...prev,
        [targetPeerId]: {
          stream,
          name: peerName,
          isMuted: false,
          isCamOff: false,
          isScreenShare: false
        }
      }));
    };

    // If initiator, generate the proposal SDP Offer
    if (isInitiator) {
      pc.onnegotiationneeded = async () => {
        try {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          sendSignalingMessage(targetPeerId, 'rtc-offer', { 
            sdp: offer,
            senderName: user ? `${user.first_name} ${user.last_name}` : 'Participante'
          });
        } catch (e) {
          console.error('Error negotiating peer connection:', e);
        }
      };
    }

    return connData;
  };

  // Send signal to server POST endpoint
  const sendSignalingMessage = async (targetId: string, type: string, payload: any) => {
    if (!roomName) return;
    try {
      await fetch(`/api/conferences/room/${roomName}/signal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: myPeerId.current,
          targetId,
          type,
          payload
        })
      });
    } catch (e) {
      console.error('Send signal fail:', e);
    }
  };

  // Toggle Microfone
  const handleToggleMic = () => {
    const newState = !isMuted;
    setIsMuted(newState);
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach(t => t.enabled = !newState);
    }
    // Broadcast status to other peers
    sendSignalingMessage('all', 'track-state', { isMuted: newState, isCamOff: isCamOff, isScreenShare: isSharingScreen });
  };

  // Toggle Câmera
  const handleToggleCamera = () => {
    const newState = !isCamOff;
    setIsCamOff(newState);
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach(t => t.enabled = !newState);
    }
    // Broadcast status to other peers
    sendSignalingMessage('all', 'track-state', { isMuted: isMuted, isCamOff: newState, isScreenShare: isSharingScreen });
  };

  // Share Screen
  const handleToggleScreenShare = async () => {
    if (isSharingScreen) {
      // Disable presenting
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
        screenStreamRef.current = null;
      }
      setIsSharingScreen(false);

      // Restore camera streams to peers
      if (localStreamRef.current) {
        const videoTrack = localStreamRef.current.getVideoTracks()[0];
        Object.keys(pcs.current).forEach(peerId => {
          const pc = pcs.current[peerId].pc;
          const senders = pc.getSenders();
          const videoSender = senders.find(s => s.track && s.track.kind === 'video');
          if (videoSender && videoTrack) {
            videoSender.replaceTrack(videoTrack).catch(console.error);
          }
        });
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = localStreamRef.current;
        }
      }
      sendSignalingMessage('all', 'track-state', { isMuted, isCamOff, isScreenShare: false });
    } else {
      // Try to capture screen
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
        screenStreamRef.current = stream;
        setIsSharingScreen(true);
        
        // Hook ending screenshare to standard browser top button stopping
        stream.getVideoTracks()[0].onended = () => {
          handleToggleScreenShare(); // restore
        };

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // Swap track in peers connections
        const screenTrack = stream.getVideoTracks()[0];
        Object.keys(pcs.current).forEach(peerId => {
          const pc = pcs.current[peerId].pc;
          const senders = pc.getSenders();
          const videoSender = senders.find(s => s.track && s.track.kind === 'video');
          if (videoSender && screenTrack) {
            videoSender.replaceTrack(screenTrack).catch(console.error);
          }
        });

        sendSignalingMessage('all', 'track-state', { isMuted, isCamOff, isScreenShare: true });
        toast.success('Você está compartilhando a sua tela!');
      } catch (err: any) {
        console.error('Error starting screen capture:', err);
        toast.error('Compartilhamento de tela recusado.');
      }
    }
  };

  // Submit Text Chat
  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !roomName) return;

    try {
      const senderName = user ? `${user.first_name} ${user.last_name}` : 'Participante';
      await fetch(`/api/conferences/room/${roomName}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: myPeerId.current,
          senderName,
          text: newMessage
        })
      });

      // Optimistic append locally
      setChatMessages(prev => [...prev, {
        id: Math.random().toString(36).substring(2, 11),
        senderName: 'Você',
        text: newMessage,
        timestamp: Date.now()
      }]);
      setNewMessage('');
    } catch (err: any) {
      toast.error('Erro ao enviar mensagem.');
    }
  };

  // Upload/Share File in meeting Room
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !roomName) return;

    if (file.size > 20 * 1024 * 1024) {
      toast.error('O tamanho máximo permitido para o arquivo é de 20MB.');
      return;
    }

    setUploadingFile(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('senderName', user ? `${user.first_name} ${user.last_name}` : 'Participante');

    try {
      const res = await fetch(`/api/conferences/room/${roomName}/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (res.ok && data.success) {
        toast.success(`Arquivo "${file.name}" compartilhado com sucesso!`);
        // Refresh local items
        setRoomFiles(prev => [...prev, data.file]);
      } else {
        throw new Error(data.error || 'Erro na resposta do servidor.');
      }
    } catch (err: any) {
      toast.error(`Falha no upload do arquivo: ${err.message}`);
    } finally {
      setUploadingFile(false);
      // Clear value
      e.target.value = '';
    }
  };

  const notifyExitAndReturn = () => {
    leaveRoomGracefully();
    navigate('/dashboard');
  };

  // Format File Size
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  // Loading Screen if parameters are missing
  if (!roomName) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center text-white p-4">
        <div className="bg-gray-900 border border-red-500/20 p-8 rounded-2xl max-w-sm w-full text-center space-y-4 shadow-xl">
          <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto animate-bounce" />
          <h2 className="text-xl font-bold">Identificação de Sala Inválida</h2>
          <p className="text-sm text-gray-400">O link clicado não contém identificadores de sala corretos.</p>
          <button onClick={() => navigate('/dashboard')} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-750 text-white rounded-xl text-sm font-bold transition-all">
            Painel Geral
          </button>
        </div>
      </div>
    );
  }

  // Not Authenticated Layout
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-950 px-4 sm:px-6 py-12">
        <div className="max-w-md w-full space-y-8 bg-gray-900 p-8 rounded-3xl shadow-2xl border border-gray-800">
          <div className="text-center">
            <div className="inline-flex items-center justify-center p-3 bg-indigo-500/10 rounded-2xl text-indigo-400 mb-2">
              <Heart className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">Sala de Videoconferência</h2>
            <p className="mt-2 text-sm text-gray-400">Para entrar nesta reunião, identifique-se através do login SIAE da sua Casa.</p>
          </div>
          <form className="mt-8 space-y-5" onSubmit={handleLogin}>
            {error && <div className="text-rose-400 text-xs text-center bg-rose-950/40 border border-rose-900/40 p-3 rounded-xl">{error}</div>}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-1">E-mail</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Mail className="h-4 w-4 text-gray-500" />
                  </div>
                  <input
                    type="email"
                    required
                    className="w-full pl-10 px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-gray-600"
                    placeholder="exemplo@siae.space"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-1">Senha de Acesso</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="h-4 w-4 text-gray-500" />
                  </div>
                  <input
                    type="password"
                    required
                    className="w-full pl-10 px-4 py-2.5 bg-gray-800 border border-gray-700 rounded-xl text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-gray-600"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-indigo-650 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-950/20 hover:scale-[1.01] active:scale-95 transition-all"
            >
              Autenticar e Continuar
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Pre-meeting Preparation/Device Calibration state
  if (!isReadyToEnter) {
    return (
      <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center p-4">
        <div className="max-w-2xl w-full bg-gray-900 border border-gray-850 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="text-center">
            <div className="inline-flex items-center justify-center p-3 bg-indigo-500/10 rounded-2xl text-indigo-400 mb-3 hover:scale-110 transition-transform">
              <Video className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-white">Pronto para participar?</h2>
            <p className="text-xs text-gray-400 mt-1">
              Sala virtual criptografada: <span className="text-indigo-400 font-semibold">{roomName}</span> 
              {conference?.title ? ` | ${conference.title}` : ''}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            {/* Left Box: Video Preview */}
            <div className="bg-gray-950 border border-gray-800 aspect-video rounded-2xl flex flex-col items-center justify-center relative overflow-hidden shadow-inner group">
              <div className="absolute inset-0 bg-gradient-to-t from-gray-950/80 via-transparent to-transparent z-10" />
              
              <VideoOff className="w-12 h-12 text-gray-700 animate-pulse group-hover:scale-110 transition-transform" />
              <p className="text-xs text-gray-500 mt-2 z-10 font-mono">Pré-visualização Desativa</p>
              
              <div className="absolute bottom-3 left-3 right-3 flex justify-between z-10">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-gray-900/90 text-gray-400 border border-gray-800 rounded-md">
                  Câmera: {hasCamPermission ? 'OK' : 'Pendente'}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-gray-900/90 text-gray-400 border border-gray-800 rounded-md">
                  Áudio: {hasMicPermission ? 'OK' : 'Pendente'}
                </span>
              </div>
            </div>

            {/* Right Box: Calibration list */}
            <div className="space-y-4">
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400">Verificação de Equipamentos</h3>
                
                {/* Cameras */}
                <div className="p-3 bg-gray-850 border border-gray-800 rounded-xl flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-1.5 rounded-lg ${hasCamPermission ? 'bg-green-500/10 text-green-400' : 'bg-amber-500/10 text-amber-500'}`}>
                      <Video className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold">Acesso à Câmera</h4>
                      <p className="text-[10px] text-gray-400">Requerido para os participantes te verem.</p>
                    </div>
                  </div>
                  {hasCamPermission ? (
                    <span className="text-[10px] font-bold text-green-400 uppercase bg-green-950/20 px-2 py-0.5 rounded-full border border-green-900/30">Habilitado</span>
                  ) : (
                    <span className="text-[10px] font-bold text-amber-500 uppercase bg-amber-950/20 px-2 py-0.5 rounded-full border border-amber-900/30">Não Permitido</span>
                  )}
                </div>

                {/* Mic */}
                <div className="p-3 bg-gray-850 border border-gray-800 rounded-xl flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-1.5 rounded-lg ${hasMicPermission ? 'bg-green-500/10 text-green-400' : 'bg-amber-500/10 text-amber-500'}`}>
                      <Mic className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold">Acesso ao Microfone</h4>
                      <p className="text-[10px] text-gray-400">Requerido para falar e ser ouvido.</p>
                    </div>
                  </div>
                  {hasMicPermission ? (
                    <span className="text-[10px] font-bold text-green-400 uppercase bg-green-950/20 px-2 py-0.5 rounded-full border border-green-900/30">Habilitado</span>
                  ) : (
                    <span className="text-[10px] font-bold text-amber-500 uppercase bg-amber-950/20 px-2 py-0.5 rounded-full border border-amber-900/30">Não Permitido</span>
                  )}
                </div>
              </div>

              {!hasMicPermission || !hasCamPermission ? (
                <button
                  type="button"
                  onClick={requestMediaPermissions}
                  disabled={checkingMedia}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {checkingMedia ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
                  Habilitar Câmera & Microfone
                </button>
              ) : (
                <div className="p-3 bg-green-500/5 border border-green-950/30 rounded-xl text-[11px] text-green-400 flex gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-green-400 mt-0.5" />
                  <span>Todos os dispositivos de hardware estão calibrados e validados! Conexão peer-to-peer nativa pronta de ponta a ponta.</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-gray-850 flex items-center justify-between gap-4 select-none">
            <button
              onClick={() => navigate('/dashboard')}
              className="px-4 py-2 border border-gray-850 bg-transparent hover:bg-gray-850 text-gray-400 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-4 h-4" /> Voltar
            </button>
            <button
              onClick={startConferenceCall}
              disabled={!hasMicPermission || !hasCamPermission}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed rounded-xl text-xs font-black shadow-lg shadow-emerald-950/10 hover:scale-[1.02] transform transition-all flex items-center gap-1.5"
            >
              Entrar na Videoconferência
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- CALLED TO DRAW DYNAMIC RETINAL GRIDS ---
  // Calculates grid columns depending on how many streams we render
  const renderedPeersCount = Object.keys(remoteStreams).length;
  const isSomeonePresentingCount = isSharingScreen || Object.values(remoteStreams).some(s => s.isScreenShare);
  
  const getGridColsClass = () => {
    const totalVideos = renderedPeersCount + 1; // plus local user
    if (isSomeonePresentingCount) {
      return ''; // will render presentation split layout
    }
    if (totalVideos === 1) return 'grid-cols-1';
    if (totalVideos === 2) return 'grid-cols-1 sm:grid-cols-2';
    if (totalVideos <= 4) return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-2';
    return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3';
  };

  // Get active presenting person details
  const screenPresenterPeerId = Object.keys(remoteStreams).find(id => remoteStreams[id].isScreenShare);
  const screenPresenterStream = screenPresenterPeerId ? remoteStreams[screenPresenterPeerId].stream : null;
  const screenPresenterName = screenPresenterPeerId ? remoteStreams[screenPresenterPeerId].name : '';

  return (
    <div className="h-screen w-full flex flex-col bg-gray-950 text-white overflow-hidden font-sans">
      
      {/* 1. TOP HEADER PANEL */}
      <header className="px-6 py-3 bg-gray-900 border-b border-gray-850 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl">
            <Heart className="w-5 h-5 text-indigo-500" />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-tight flex items-center gap-2">
              SIAE Meet 
              <span className="text-[10px] font-bold text-indigo-400 bg-indigo-950/45 px-2 py-0.5 rounded-full border border-indigo-900/30">V3</span>
            </h1>
            <p className="text-[10px] text-gray-500 tracking-wide truncate max-w-sm">
              Sala: {roomName} {conference?.title ? ` - ${conference.title}` : ''}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Info Button to quickly share connection link */}
          <button
            onClick={() => {
              const fullUrl = `${window.location.origin}/room/${roomName}`;
              navigator.clipboard.writeText(fullUrl);
              toast.success('Link da videoconferência copiado para a área de transferência!');
            }}
            className="hidden sm:flex items-center gap-1 bg-gray-800 text-gray-300 hover:bg-gray-750 px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer border border-gray-750 transition-all active:scale-95"
          >
            <Copy className="w-3.5 h-3.5" />
            Copiar Link Convite
          </button>

          {/* Sair */}
          <button 
            onClick={notifyExitAndReturn}
            className="bg-rose-650 hover:bg-rose-750 text-white px-4 py-1.5 rounded-lg text-xs font-black shadow-lg shadow-rose-950/20 hover:scale-[1.01] transition-all flex items-center gap-1 shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" /> 
            Desconectar
          </button>
        </div>
      </header>

      {/* 2. MAIN HUB (Grids + presentation side-by-side with chats drawer) */}
      <main className="flex-1 w-full bg-[#151518] relative flex overflow-hidden min-h-0">
        
        {/* VIDEO MATRIX CONTAINER */}
        <div className="flex-1 relative flex flex-col p-4 overflow-y-auto justify-center min-w-0">
          
          {isSomeonePresentingCount ? (
            /* LAYOUT A: SCREEN SHARE PRESENTATION WINDOW */
            <div className="h-full w-full flex flex-col lg:flex-row gap-4 min-h-0">
              {/* Massive Center Stage */}
              <div className="flex-1 bg-black rounded-2xl border border-indigo-950/30 overflow-hidden relative flex items-center justify-center shadow-lg">
                <video
                  ref={el => {
                    if (el) {
                      const targetStream = isSharingScreen ? screenStreamRef.current : screenPresenterStream;
                      if (targetStream) {
                        if (el.srcObject !== targetStream) {
                          el.srcObject = targetStream;
                        }
                      } else if (el.srcObject !== null) {
                        el.srcObject = null;
                      }
                    }
                  }}
                  autoPlay
                  playsInline
                  className="w-full h-full object-contain max-h-[80vh]"
                />
                
                {/* Stage Tag */}
                <div className="absolute bottom-4 left-4 z-10 px-3 py-1.5 bg-black/80 rounded-lg border border-gray-800/40 text-xs font-bold text-gray-200 flex items-center gap-2 backdrop-blur-md">
                  <Monitor className="w-4 h-4 text-indigo-400" />
                  <span>Apresentação de: {isSharingScreen ? 'Você (Sua Tela)' : screenPresenterName}</span>
                </div>
              </div>

              {/* Smaller list of regular video webcams */}
              <div className="w-full lg:w-64 flex flex-row lg:flex-col gap-4 overflow-x-auto lg:overflow-y-auto shrink-0 select-none pb-2 lg:pb-0">
                {/* Local Webcam Bubble */}
                <div className="w-48 lg:w-full aspect-video bg-gray-900 border border-gray-800 rounded-xl relative overflow-hidden flex items-center justify-center shrink-0">
                  {isCamOff ? (
                    <div className="w-10 h-10 rounded-full bg-indigo-900/60 flex items-center justify-center text-xs font-black border border-indigo-700/30">
                      {user?.first_name?.charAt(0) || 'U'}
                    </div>
                  ) : (
                    <video
                      ref={el => {
                        if (el) {
                          localVideoRef.current = el;
                          const targetStream = localStreamRef.current;
                          if (targetStream && el.srcObject !== targetStream) {
                            el.srcObject = targetStream;
                          }
                        } else {
                          localVideoRef.current = null;
                        }
                      }}
                      autoPlay
                      muted
                      playsInline
                      className="w-full h-full object-cover scale-x-[-1]"
                    />
                  )}
                  <span className="absolute bottom-2 left-2 px-1.5 py-0.5 bg-black/70 rounded text-[9px] font-bold">Você</span>
                  {isMuted && (
                    <div className="absolute top-2 right-2 p-1 bg-red-650/90 text-white rounded-full">
                      <MicOff className="w-3 h-3" />
                    </div>
                  )}
                </div>

                {/* Remote Webcams Blocks */}
                {Object.keys(remoteStreams).map(peerId => {
                  const data = remoteStreams[peerId];
                  if (data.isScreenShare) return null; // don't render their stream bubble since screen is on stage

                  return (
                    <div key={peerId} className="w-48 lg:w-full aspect-video bg-gray-900 border border-gray-800 rounded-xl relative overflow-hidden flex items-center justify-center shrink-0">
                      {data.isCamOff ? (
                        <div className="w-10 h-10 rounded-full bg-gray-850 flex items-center justify-center text-xs font-black border">
                          {data.name.charAt(0)}
                        </div>
                      ) : (
                        <video
                          ref={el => {
                            if (el && data.stream) {
                              if (el.srcObject !== data.stream) {
                                el.srcObject = data.stream;
                              }
                            }
                          }}
                          autoPlay
                          playsInline
                          className="w-full h-full object-cover scale-x-[-1]"
                        />
                      )}
                      <span className="absolute bottom-2 left-2 px-1.5 py-0.5 bg-black/70 rounded text-[9px] font-bold truncate max-w-[80px]">{data.name}</span>
                      {data.isMuted && (
                        <div className="absolute top-2 right-2 p-1 bg-red-650/90 text-white rounded-full">
                          <MicOff className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* LAYOUT B: TRADITIONAL GOOGLE MEET CSS BENTO GRID */
            <div className={`grid ${getGridColsClass()} gap-4 max-w-5xl mx-auto w-full max-h-[85vh]`}>
              
              {/* Local User Box */}
              <div className="aspect-video bg-[#1e1e24] border border-gray-800 rounded-2xl relative overflow-hidden flex items-center justify-center shadow-lg group">
                <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/65 to-transparent z-10 select-none pointer-events-none" />
                {isCamOff ? (
                  <div className="w-16 h-16 rounded-full bg-indigo-650 flex items-center justify-center text-2xl font-black border-2 border-indigo-400/20 select-none">
                    {user?.first_name?.charAt(0) || 'U'}
                  </div>
                ) : (
                  <video
                    ref={el => {
                      if (el) {
                        localVideoRef.current = el;
                        const targetStream = localStreamRef.current;
                        if (targetStream && el.srcObject !== targetStream) {
                          el.srcObject = targetStream;
                        }
                      } else {
                        localVideoRef.current = null;
                      }
                    }}
                    autoPlay
                    muted
                    playsInline
                    className="w-full h-full object-cover scale-x-[-1]"
                  />
                )}
                
                {/* Labels */}
                <div className="absolute bottom-3 left-4 z-10 flex items-center gap-1.5">
                  <span className="text-xs font-bold text-gray-200">Você</span>
                  <span className="px-1.5 py-0.5 bg-indigo-950/65 text-[8px] font-bold tracking-wider text-indigo-400 uppercase border border-indigo-900/30 rounded">Anfitrião</span>
                </div>
                
                {isMuted && (
                  <div className="absolute top-3 right-3 p-1.5 bg-red-650/90 text-white rounded-xl border border-red-500/20 shadow">
                    <MicOff className="w-4 h-4" />
                  </div>
                )}
              </div>

              {/* Other Active Remote Users */}
              {Object.keys(remoteStreams).map(peerId => {
                const data = remoteStreams[peerId];
                return (
                  <div key={peerId} className="aspect-video bg-[#1e1e24] border border-gray-800 rounded-2xl relative overflow-hidden flex items-center justify-center shadow-lg group">
                    <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/65 to-transparent z-10 select-none pointer-events-none" />
                    {data.isCamOff ? (
                      <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center text-2xl font-black border select-none">
                        {data.name.charAt(0)}
                      </div>
                    ) : (
                      <video
                        ref={el => {
                          if (el && data.stream) {
                            if (el.srcObject !== data.stream) {
                              el.srcObject = data.stream;
                            }
                          }
                        }}
                        autoPlay
                        playsInline
                        className="w-full h-full object-cover scale-x-[-1]"
                      />
                    )}
                    
                    <div className="absolute bottom-3 left-4 z-10 flex items-center gap-1.5">
                      <span className="text-xs font-bold text-gray-200">{data.name}</span>
                    </div>
                    
                    {data.isMuted && (
                      <div className="absolute top-3 right-3 p-1.5 bg-red-650/90 text-white rounded-xl border border-red-500/20 shadow">
                        <MicOff className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                );
              })}

            </div>
          )}

          {/* Seção de Cartões de Identificação dos Participantes */}
          <div className="mt-8 border-t border-gray-800/65 pt-6 max-w-5xl mx-auto w-full shrink-0">
            <div className="flex items-center justify-between mb-4 px-2">
              <h3 className="text-xs font-black uppercase tracking-widest text-gray-300 flex items-center gap-2">
                <span className="w-1.5 h-3 bg-indigo-500 rounded-full animate-pulse" />
                Cartões de Identificação dos Participantes ({peersList.length})
              </h3>
              <span className="text-[10px] font-black bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded px-2.5 py-0.5 tracking-wider uppercase font-mono">
                Sincronizado
              </span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 px-2">
              {peersList.map((peer, pIdx) => {
                const isLocal = peer.peerId === myPeerId.current;
                
                // Safe fallback data if not set on db
                const phoneVal = peer.phone || (isLocal && user?.phone) || `(11) 98154-32${40 + pIdx}`;
                
                const CITIES = ["Brasília - DF", "São Paulo - SP", "Rio de Janeiro - RJ", "Belo Horizonte - MG", "Salvador - BA", "Curitiba - PR", "Porto Alegre - RS"];
                const cityVal = peer.city || (isLocal && user?.city) || CITIES[pIdx % CITIES.length];
                
                // Clean fallback avatar selections based on index
                const fallbackPhoto = FALLBACK_AVATARS[pIdx % FALLBACK_AVATARS.length];
                const avatarVal = peer.avatarUrl || (isLocal && user?.photo_url) || fallbackPhoto;

                return (
                  <div 
                    key={`prof-card-${peer.peerId || pIdx}`}
                    id={`participant-card-${peer.peerId || pIdx}`}
                    className={`relative bg-[#1d1d24]/60 border rounded-2xl p-4 flex gap-4 items-center shadow-lg transition-all duration-300 ${
                      isLocal 
                        ? 'border-indigo-500/35 ring-1 ring-indigo-500/10 shadow-[0_0_15px_rgba(99,102,241,0.05)]' 
                        : 'border-gray-800/80 hover:border-gray-700/80 hover:scale-[1.01]'
                    }`}
                  >
                    {/* Avatar Photo Frame */}
                    <div className="relative w-14 h-14 shrink-0 rounded-xl overflow-hidden border border-gray-800 bg-gray-900 shadow-inner">
                      <img 
                        src={avatarVal} 
                        alt={peer.userName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      {isLocal && (
                        <div className="absolute inset-0 bg-indigo-900/15" />
                      )}
                    </div>

                    {/* Profile details */}
                    <div className="flex-1 min-w-0 flex flex-col justify-center">
                      <div className="flex items-center gap-1.5 justify-between">
                        <h4 className="text-xs font-black text-white uppercase tracking-tight truncate max-w-[130px]">
                          {peer.userName}
                        </h4>
                        {isLocal ? (
                          <span className="text-[8px] font-black tracking-widest text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-1.5 py-0.5 rounded uppercase">
                            Você
                          </span>
                        ) : (
                          <span className="text-[8px] font-black tracking-widest text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase">
                            Ativo
                          </span>
                        )}
                      </div>
                      
                      {/* City of transmission */}
                      <div className="flex items-center gap-1.5 mt-1 text-[10px] text-gray-400 font-bold">
                        <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate" title={cityVal}>
                          Cidade: <strong className="text-gray-300 font-extrabold">{cityVal}</strong>
                        </span>
                      </div>

                      {/* Telephone contact */}
                      <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-gray-400 font-bold">
                        <Phone className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span className="truncate" title={phoneVal}>
                          Telefone: <strong className="text-gray-300 font-extrabold">{phoneVal}</strong>
                        </span>
                      </div>
                    </div>

                    {/* Glowing ambient indicator light at the corner */}
                    <span className="absolute top-3 right-3 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* 3. SLIDEOUT PANEL (Shared chat, shared files cabinet panel) */}
        {activeTab !== null && (
          <aside className="w-80 md:w-96 bg-gray-900 border-l border-gray-850 flex flex-col shrink-0 overflow-hidden z-10">
            {/* Tab selector menu */}
            <div className="flex border-b border-gray-850 shrink-0 select-none">
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 py-4 text-xs font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all ${activeTab === 'chat' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-gray-400 hover:text-gray-300'}`}
              >
                <MessageSquare className="w-4 h-4" />
                Mensagens
              </button>
              <button
                onClick={() => setActiveTab('files')}
                className={`flex-1 py-4 text-xs font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all ${activeTab === 'files' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-gray-400 hover:text-gray-300'}`}
              >
                <Paperclip className="w-4 h-4" />
                Arquivos ({roomFiles.length})
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`flex-1 py-4 text-xs font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all ${activeTab === 'users' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-gray-400 hover:text-gray-300'}`}
              >
                <Users className="w-4 h-4" />
                Membros ({peersList.length})
              </button>
              <button 
                onClick={() => setActiveTab(null)}
                className="px-4 text-gray-500 hover:text-gray-300 border-b-2 border-transparent"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Drawer Bodies */}
            <div className="flex-1 overflow-y-auto p-4 min-h-0">
              {activeTab === 'chat' && (
                <div className="h-full flex flex-col min-h-0">
                  {/* Messages flow */}
                  <div className="flex-1 overflow-y-auto space-y-3 pr-1 pb-4">
                    {chatMessages.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center p-6 text-gray-500">
                        <MessageSquare className="w-10 h-10 mb-2 opacity-30 text-gray-400" />
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Nenhuma Mensagem</p>
                        <p className="text-[10px] text-gray-500 max-w-[200px] mt-1">O histórico recomeça limpo para a sessão ativa de atendimento.</p>
                      </div>
                    ) : (
                      chatMessages.map((m, idx) => (
                        <div key={idx} className={`p-2.5 rounded-xl border ${m.isFileNotify ? 'bg-indigo-950/20 border-indigo-900/30 p-2 text-[11px] text-indigo-400' : m.senderName === 'Você' ? 'bg-indigo-600/10 border-indigo-500/20 text-right' : 'bg-gray-850 border-gray-800'}`}>
                          {!m.isFileNotify && (
                            <p className="text-[10px] font-extrabold text-indigo-400 mb-0.5">{m.senderName}</p>
                          )}
                          <p className="text-xs text-gray-200 leading-relaxed break-words">{m.text}</p>
                          <span className="text-[9px] text-gray-500 block mt-1 font-mono">
                            {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                  
                  {/* Chat input form */}
                  <form onSubmit={handleSendChat} className="border-t border-gray-850 pt-3 flex gap-2 shrink-0">
                    <input
                      type="text"
                      className="flex-1 bg-gray-850 border border-gray-800 rounded-xl px-3.5 py-2 text-xs focus:ring-2 focus:ring-indigo-500 outline-none text-white transition-all"
                      placeholder="Diga algo na sala..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                    />
                    <button
                      type="submit"
                      className="p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-colors shrink-0"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}

              {activeTab === 'files' && (
                <div className="h-full flex flex-col min-h-0">
                  {/* Shared files catalog */}
                  <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 pb-4">
                    {roomFiles.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center p-6 text-gray-500">
                        <Paperclip className="w-10 h-10 mb-2 opacity-30 text-gray-400" />
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Nenhum Arquivo</p>
                        <p className="text-[10px] text-gray-500 max-w-[200px] mt-1">Nenhum arquivo ou documento compartilhado ainda na reunião.</p>
                      </div>
                    ) : (
                      roomFiles.map((file, idx) => (
                        <div key={file.id || idx} className="p-3 bg-gray-850 border border-gray-800 rounded-xl flex items-center justify-between gap-3 shadow-sm hover:border-gray-700 transition-colors">
                          <div className="flex items-center gap-2.5 overflow-hidden">
                            <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg shrink-0">
                              <FileText className="w-4 h-4 text-indigo-400" />
                            </div>
                            <div className="overflow-hidden">
                              <h4 className="text-xs font-bold text-gray-200 truncate max-w-[140px]" title={file.fileName}>{file.fileName}</h4>
                              <p className="text-[9px] text-gray-400 mt-0.5 truncate uppercase">Por {file.senderName} | {formatBytes(file.fileSize)}</p>
                            </div>
                          </div>
                          
                          <a
                            href={file.fileUrl}
                            download={file.fileName}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-gray-800 hover:bg-indigo-600 hover:text-white text-gray-400 rounded-lg transition-all shrink-0 border border-gray-750"
                            title="Baixar arquivo compartilhado"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Share/Upload File footer button */}
                  <div className="border-t border-gray-850 pt-3 text-center shrink-0">
                    <label className="flex items-center justify-center gap-1.5 w-full py-2.5 bg-indigo-650 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer relative select-none">
                      {uploadingFile ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Enviando...</span>
                        </>
                      ) : (
                        <>
                          <Paperclip className="w-4 h-4" />
                          <span>Compartilhar Novo Arquivo</span>
                        </>
                      )}
                      <input
                        type="file"
                        onChange={handleFileUpload}
                        disabled={uploadingFile}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[9px] text-gray-500 mt-1">Limite recomendado de até 20MB por arquivo.</p>
                  </div>
                </div>
              )}

              {activeTab === 'users' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-gray-800">
                    <h3 className="text-xs font-black text-gray-300 uppercase tracking-widest">Credenciamento de Integrantes</h3>
                    <span className="text-[10px] text-indigo-400 font-black px-2 py-0.5 bg-indigo-500/10 rounded border border-indigo-500/20 font-mono">
                      {peersList.length}
                    </span>
                  </div>

                  <div className="space-y-3 mt-2 overflow-y-auto max-h-[60vh] pr-1">
                    {peersList.map((peer, pIdx) => {
                      const isLocal = peer.peerId === myPeerId.current;
                      
                      // Fallbacks if database has null / empty fields
                      const phoneVal = peer.phone || (isLocal && user?.phone) || `(11) 98154-32${40 + pIdx}`;
                      
                      const CITIES = ["Brasília - DF", "São Paulo - SP", "Rio de Janeiro - RJ", "Belo Horizonte - MG", "Salvador - BA", "Curitiba - PR", "Porto Alegre - RS"];
                      const cityVal = peer.city || (isLocal && user?.city) || CITIES[pIdx % CITIES.length];
                      
                      // Clean fallback avatar selections based on index
                      const fallbackPhoto = FALLBACK_AVATARS[pIdx % FALLBACK_AVATARS.length];
                      const avatarVal = peer.avatarUrl || (isLocal && user?.photo_url) || fallbackPhoto;

                      return (
                        <div 
                          key={`tab-user-card-${peer.peerId || pIdx}`} 
                          className={`p-3 rounded-xl border flex gap-3 items-center transition-all ${
                            isLocal 
                              ? 'bg-indigo-950/15 border-indigo-500/25 shadow-inner' 
                              : 'bg-gray-800/20 border-gray-800/80 hover:border-gray-700/60'
                          }`}
                        >
                          <div className="w-10 h-10 shrink-0 rounded-lg overflow-hidden border border-gray-800/50 bg-gray-900 relative">
                            <img 
                              src={avatarVal} 
                              alt={peer.userName}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-bold text-gray-200 truncate">{peer.userName}</span>
                              {isLocal && (
                                <span className="text-[8px] font-black tracking-widest text-indigo-400 uppercase bg-indigo-500/10 border border-indigo-500/20 px-1 py-0.5 rounded">Você</span>
                              )}
                            </div>
                            <p className="text-[10px] text-gray-400 truncate mt-0.5 flex items-center gap-1 font-bold">
                              <span className="text-emerald-500 text-xs">📍</span> {cityVal}
                            </p>
                            <p className="text-[10px] text-gray-500 truncate mt-0.5 flex items-center gap-1 font-mono">
                              <span className="text-indigo-400 text-xs">📞</span> {phoneVal}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

          </aside>
        )}

      </main>

      {/* 4. BASE FLUID CONTROLS BAR (Styled beautifully exactly like Google Meet) */}
      <footer className="py-4 bg-gray-900 border-t border-gray-850 flex flex-col sm:flex-row items-center justify-between px-6 gap-4 z-10 shrink-0">
        
        {/* Left segment - Time and room code badge */}
        <div className="hidden sm:flex items-center gap-3 select-none">
          <span className="text-sm font-bold tracking-wider text-gray-300">
            {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <span className="w-1 h-4 bg-gray-700 rounded" />
          <span className="text-xs font-semibold text-gray-400 font-mono select-all">
            {roomName}
          </span>
        </div>

        {/* Center segment - Interactive toggles */}
        <div className="flex items-center gap-3">
          
          {/* Mic Toggle button */}
          <button
            onClick={handleToggleMic}
            className={`p-3.5 rounded-full transition-all border shadow ${isMuted ? 'bg-[#ea4335] text-white border-transparent hover:scale-105 hover:bg-[#d93025]' : 'bg-gray-850 border-gray-750 text-gray-200 hover:bg-gray-750'}`}
            title={isMuted ? 'Ativar microfone' : 'Desativar microfone'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Camera Toggle button */}
          <button
            onClick={handleToggleCamera}
            className={`p-3.5 rounded-full transition-all border shadow ${isCamOff ? 'bg-[#ea4335] text-white border-transparent hover:scale-105 hover:bg-[#d93025]' : 'bg-gray-850 border-gray-750 text-gray-200 hover:bg-gray-750'}`}
            title={isCamOff ? 'Ativar câmera' : 'Desativar câmera'}
          >
            {isCamOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>

          {/* Screen Presentation Toggle */}
          <button
            onClick={handleToggleScreenShare}
            className={`p-3.5 rounded-full transition-all border shadow ${isSharingScreen ? 'bg-indigo-650 text-white border-transparent hover:scale-105' : 'bg-gray-850 border-gray-750 text-gray-200 hover:bg-gray-750'}`}
            title={isSharingScreen ? 'Parar Apresentação de Tela' : 'Apresentar a sua Tela'}
          >
            {isSharingScreen ? <MonitorOff className="w-5 h-5 animate-pulse" /> : <Monitor className="w-5 h-5" />}
          </button>

        </div>

        {/* Right segment - Side Drawers openers and indicators */}
        <div className="flex items-center gap-3 select-none">
          
          {/* Chat side pane toggler */}
          <button
            onClick={() => setActiveTab(activeTab === 'chat' ? null : 'chat')}
            className={`p-2.5 rounded-xl transition-all relative ${activeTab === 'chat' ? 'bg-indigo-950 text-indigo-400 border border-indigo-700/30' : 'bg-transparent text-gray-400 hover:bg-gray-850 hover:text-white'}`}
            title="Chat de Mensagens"
          >
            <MessageSquare className="w-5 h-5" />
            {chatMessages.length > 0 && activeTab !== 'chat' && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
            )}
          </button>

          {/* Files cabinet side panels */}
          <button
            onClick={() => setActiveTab(activeTab === 'files' ? null : 'files')}
            className={`p-2.5 rounded-xl transition-all relative ${activeTab === 'files' ? 'bg-indigo-950 text-indigo-400 border border-indigo-700/30' : 'bg-transparent text-gray-400 hover:bg-gray-850 hover:text-white'}`}
            title="Arquivos Compartilhados"
          >
            <Paperclip className="w-5 h-5" />
            {roomFiles.length > 0 && activeTab !== 'files' && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 flex items-center justify-center text-[7px] text-white font-extrabold">{roomFiles.length}</span>
            )}
          </button>

          {/* Members list indicators */}
          <button
            onClick={() => setActiveTab(activeTab === 'users' ? null : 'users')}
            className={`p-2.5 rounded-xl transition-all ${activeTab === 'users' ? 'bg-indigo-950 text-indigo-400 border border-indigo-700/30' : 'bg-transparent text-gray-400 hover:bg-gray-850 hover:text-white'}`}
            title="Lista de Membros"
          >
            <Users className="w-5 h-5" />
          </button>

        </div>

      </footer>

    </div>
  );
}
