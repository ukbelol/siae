import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { ManagedIdentityCredential } from '@azure/identity';
import { BlobServiceClient, ContainerClient } from '@azure/storage-blob';

const enabled = String(process.env.AZURE_STORAGE_ENABLED || 'false').toLowerCase() === 'true';
const account = process.env.AZURE_STORAGE_ACCOUNT_NAME || 'chamasso';
const containerName = process.env.AZURE_STORAGE_CONTAINER || 'container-chamasso';
const endpoint = process.env.AZURE_STORAGE_ENDPOINT || `https://${account}.blob.core.windows.net`;
const backupDir = process.env.CHAMASSO_PROFILE_BACKUP_DIR || path.join(process.cwd(), 'data', 'profile-backups');
const prefix = (process.env.AZURE_STORAGE_PREFIX || 'recovery/users').replace(/^\/+|\/+$/g, '');

class AzureBlobBackupService {
  private container: ContainerClient | null = null;
  private timer: NodeJS.Timeout | null = null;
  private syncing = false;
  private lastHashes = new Map<string, string>();

  isEnabled() { return enabled; }

  private client(): ContainerClient {
    if (!enabled) throw new Error('Azure Blob Storage desativado.');
    if (!this.container) {
      const credential = new ManagedIdentityCredential();
      this.container = new BlobServiceClient(endpoint, credential).getContainerClient(containerName);
    }
    return this.container;
  }

  private hashFile(file: string) {
    return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  }

  async testConnection() {
    const started = Date.now();
    const c = this.client();
    const exists = await c.exists();
    if (!exists) throw new Error(`Container ${containerName} não encontrado ou sem permissão.`);
    return { success: true, account, container: containerName, endpoint, latencyMs: Date.now() - started, auth: 'Managed Identity' };
  }

  scheduleSync(delayMs = 2500) {
    if (!enabled) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.syncAll().catch(e => console.error('[AzureBlob] sync automático FALHOU:', e.message));
    }, delayMs);
    this.timer.unref?.();
  }

  async syncAll() {
    if (!enabled || this.syncing) return { success: false, skipped: true };
    this.syncing = true;
    try {
      const c = this.client();
      if (!await c.exists()) throw new Error(`Container ${containerName} não existe ou a Managed Identity não possui acesso.`);
      if (!fs.existsSync(backupDir)) return { success: true, uploaded: 0, unchanged: 0 };
      let uploaded = 0;
      let unchanged = 0;
      const walk = (dir: string): string[] => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => {
        const p = path.join(dir, e.name); return e.isDirectory() ? walk(p) : [p];
      });
      for (const file of walk(backupDir)) {
        const rel = path.relative(backupDir, file).split(path.sep).join('/');
        const hash = this.hashFile(file);
        if (this.lastHashes.get(rel) === hash) { unchanged++; continue; }
        await c.getBlockBlobClient(`${prefix}/${rel}`).uploadFile(file, {
          blobHTTPHeaders: { blobContentType: rel.endsWith('.json') ? 'application/json' : 'application/octet-stream' },
          metadata: { chamassoBackup: 'true', sha256: hash },
        });
        this.lastHashes.set(rel, hash);
        uploaded++;
      }
      const index = JSON.stringify({ schema: 'chamasso-azure-recovery/v1', updatedAt: new Date().toISOString(), account, container: containerName, prefix, uploaded, unchanged });
      await c.getBlockBlobClient('recovery/recovery-index.json').upload(index, Buffer.byteLength(index), { blobHTTPHeaders: { blobContentType: 'application/json' } });
      console.log(`[AzureBlob] AZURE UPLOAD ✓ ${uploaded} arquivo(s) enviado(s), ${unchanged} inalterado(s).`);
      return { success: true, uploaded, unchanged, account, container: containerName };
    } catch (err: any) {
      console.error('[AzureBlob] AZURE UPLOAD ✗', err?.message || err);
      throw err;
    } finally { this.syncing = false; }
  }

  async restoreAll() {
    if (!enabled) return { success: false, skipped: true, reason: 'disabled' };
    const c = this.client();
    if (!await c.exists()) throw new Error(`Container ${containerName} não encontrado ou sem permissão.`);
    fs.mkdirSync(backupDir, { recursive: true, mode: 0o700 });
    let downloaded = 0;
    for await (const blob of c.listBlobsFlat({ prefix: `${prefix}/` })) {
      if (!blob.name || blob.name.endsWith('/')) continue;
      const rel = blob.name.slice(prefix.length + 1);
      if (!rel || rel.includes('..')) continue;
      const dest = path.join(backupDir, ...rel.split('/'));
      fs.mkdirSync(path.dirname(dest), { recursive: true, mode: 0o700 });
      await c.getBlobClient(blob.name).downloadToFile(dest);
      downloaded++;
      try { this.lastHashes.set(rel, this.hashFile(dest)); } catch { /* ignore */ }
    }
    console.log(`[AzureBlob] AZURE RESTORE ✓ ${downloaded} blob(s) restaurado(s) para ${backupDir}.`);
    return { success: true, downloaded, directory: backupDir, account, container: containerName };
  }
}

export const azureBlobBackupService = new AzureBlobBackupService();
