# Chamasso 2.2.0 — Azure Blob Recovery

- Integração `@azure/identity` + `@azure/storage-blob`.
- Autenticação passwordless com `ManagedIdentityCredential` da VM Azure.
- Storage Account: `chamasso`; container: `container-chamasso`.
- Sincronização automática (debounce) das imagens locais de recuperação para `recovery/users/`.
- Recuperação automática do Azure antes de servir a aplicação após reinstalação/restart.
- Mesclagem idempotente das imagens recuperadas no armazenamento Chamasso.
- Endpoints Super Admin: `GET /api/admin/azure/status`, `POST /api/admin/azure/sync`, `POST /api/admin/azure/restore`.
- Nenhuma Access Key, Connection String, SAS ou Client Secret é gravada no projeto.

## Permissão Azure necessária
Na Storage Account `chamasso`, atribua à Managed Identity da VM a role `Storage Blob Data Contributor` no escopo da conta ou do container.
