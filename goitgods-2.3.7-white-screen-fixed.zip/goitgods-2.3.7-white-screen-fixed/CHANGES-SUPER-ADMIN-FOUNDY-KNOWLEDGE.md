# GOITGODS / PASQUARED — Super Admin, Microsoft Foundry e Bases de Conhecimento

## Primeira instalação
- Removidas credenciais padrão e senhas fixas do código.
- Removido o reset automático de credenciais.
- No primeiro acesso ao Painel Admin o sistema exige: nome, usuário, e-mail, senha e confirmação.
- Senha com mínimo de 12 caracteres.
- Senha armazenada com `scrypt` + salt; comparação com `timingSafeEqual`.
- Token administrativo gerado com `crypto.randomBytes`.
- Todos os endpoints administrativos (exceto `setup-status`, `setup-super-admin` e `login`) exigem `x-admin-token` ou Bearer token.
- O instalador gera senha aleatória para o MariaDB e preserva a existente em reinstalações.

## Microsoft Foundry
Nova aba **IA, Bases & Infra**.

O Super Admin pode configurar o projeto Foundry e mapear cada papel lógico a um agente:
1. RESEARCH_ORCHESTRATOR — conduz a anamnese investigativa e o plano de pesquisa.
2. PASQUARED_REASONER — estrutura premissas, claims, evidências e incertezas.
3. SOURCE_ANALYST / APOLLO — qualidade, independência e rastreabilidade de fontes.
4. ARES_CRITIC — tentativa de refutação e procura de contraevidências.
5. HADES_RISK — auditoria de riscos, lacunas, contaminação e excesso de confiança.
6. ZEUS_ARBITER — arbitragem epistemológica final.
7. BOOK_ARCHITECT — estrutura do trabalho/livro.
8. BOOK_WRITER — redação baseada apenas no ledger verificado.
9. FACT_CHECKER — conferência final de claims, referências e consistência.

Cada mapeamento aceita:
- Prompt Agent
- Hosted Agent
- Modelo/deployment direto
- Project endpoint
- Agent name / Agent ID (quando aplicável)
- deployment/model
- autenticação Microsoft Entra ID ou API key
- instruções específicas por função

Segredos digitados no painel são persistidos em `data/super_admin_secrets.json` com permissão 0600 e nunca são devolvidos integralmente pelo endpoint de leitura.

## Bases de conhecimento
Registro administrativo com bases padrão:
- Crossref
- OpenAlex
- PubMed / NCBI
- Europe PMC

Também permite cadastrar REST JSON ou conectores customizados, com domínio, URL, autenticação e modo de sincronização.

Controles:
- habilitar/desabilitar base
- editar base
- sincronizar uma base
- sincronizar todas as bases habilitadas
- visualizar status da última sincronização
- data/hora da sincronização
- mensagem de erro/sucesso
- quantidade informada/estimada de registros no endpoint

Nesta versão, “sincronizar” valida o conector e recupera metadados de amostra/contagem. A ingestão integral/local de milhões de registros deve ser feita por jobs paginados, respeitando limites e licenças de cada provedor.

## Governança
Novos parâmetros globais:
- exigir fonte para afirmações factuais
- mínimo de fontes independentes
- rejeitar citações inventadas/não verificadas
- sincronizar conectores na inicialização
- impedir diagnóstico médico automatizado por padrão
- impedir resposta jurídica como aconselhamento profissional por padrão

## Novos endpoints
- GET `/api/v2/admin/registry`
- PATCH `/api/v2/admin/registry/foundry`
- PATCH `/api/v2/admin/registry/policies`
- POST `/api/v2/admin/registry/agents`
- DELETE `/api/v2/admin/registry/agents/:id`
- POST `/api/v2/admin/registry/knowledge-bases`
- DELETE `/api/v2/admin/registry/knowledge-bases/:id`
- POST `/api/v2/admin/registry/knowledge-bases/:id/sync`
- POST `/api/v2/admin/registry/knowledge-bases/sync-all`
