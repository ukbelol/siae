const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

for (let i = 1060; i < 1080; i++) {
  console.log(i+1, lines[i]);
}
console.log("----");
for (let i = 1130; i < 1150; i++) {
  console.log(i+1, lines[i]);
}
console.log("----");
for (let i = 1195; i < 1215; i++) {
  console.log(i+1, lines[i]);
}
