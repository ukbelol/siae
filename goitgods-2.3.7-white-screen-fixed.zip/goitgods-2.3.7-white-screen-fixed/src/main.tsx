import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import {AppErrorBoundary} from './components/AppErrorBoundary';
import './index.css';

declare global {
  interface Window {
    __GOITGODS_BOOTSTRAPPED__?: boolean;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error('Elemento #root não encontrado em index.html');
}

window.addEventListener('error', event => {
  console.error('[GOITGODS] Browser runtime error:', event.error || event.message);
});
window.addEventListener('unhandledrejection', event => {
  console.error('[GOITGODS] Unhandled promise rejection:', event.reason);
});

createRoot(rootElement).render(
  <StrictMode>
    <AppErrorBoundary>
      <App />
    </AppErrorBoundary>
  </StrictMode>,
);

requestAnimationFrame(() => {
  window.__GOITGODS_BOOTSTRAPPED__ = true;
  document.getElementById('goitgods-bootstrap-diagnostic')?.remove();
});
