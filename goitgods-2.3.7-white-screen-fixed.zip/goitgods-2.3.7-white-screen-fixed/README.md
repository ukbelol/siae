<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ddb1ddb5-eca1-4d25-9526-99bf9b79bb45

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Anamnese de Pesquisa Acadêmica (PASQUARED + GOITGODS)

A versão modificada inclui um fluxo de anamnese de pesquisa direcionado por matéria/área, nível acadêmico e ano/série. O protocolo adapta rigor, linguagem, metodologia e quantidade mínima indicativa de fontes para Fundamental I/II, Médio, Técnico, Graduação, Pós-graduação, Mestrado, Doutorado ou Outro.

Novos endpoints:
- `POST /api/v3/anamnesis/start` — devolve o roteiro de perguntas da anamnese.
- `POST /api/v3/anamnesis/protocol` — transforma respostas em protocolo de pesquisa.
- `POST /api/v3/anamnesis/evaluate` — executa PASQUARED/GOITGODS e devolve avaliação das premissas, ledger, riscos e próximas ações.

Fluxo: identificação → delimitação → objetivos → premissas → evidências → método → limites → PASQUARED → triangulação → GOITGODS → ARES → HADES → MVED → ZEUS → protocolo/resultados.

Após descompactar, valide com:
```bash
npm install
npm run lint
npm run build
```


## Dynamic multidomain research (v3.3)

This build adds a step-by-step investigative anamnesis and real academic metadata retrieval. The router detects the knowledge domain and selects providers automatically. Crossref and OpenAlex are used across disciplines; PubMed/NCBI and Europe PMC are also queried for biomedical, radiology, biological, psychology and psychoanalysis topics. GOITGODS receives the retrieved evidence packet and PASQUARED records traceable claims; lack of evidence is represented as `INSUFFICIENT_EVIDENCE`.

New endpoints: `/api/v3/anamnesis/dynamic/start`, `/api/v3/anamnesis/dynamic/answer`, `/api/v3/anamnesis/dynamic/:sessionId`.

See `CHANGES-MULTIDOMAIN-DYNAMIC-RESEARCH.md` and `.env.example`.

## Super Admin — primeira instalação e infraestrutura

A versão 2.2 não possui credenciais administrativas padrão. Abra o Painel Admin após a instalação e crie o Super Admin no assistente de primeira execução. Em seguida acesse **IA, Bases & Infra** para configurar o Microsoft Foundry, mapear os agentes PASQUARED/GOITGODS, cadastrar bases de conhecimento e executar sincronizações.

Consulte `CHANGES-SUPER-ADMIN-FOUNDY-KNOWLEDGE.md` para o mapa de agentes e os novos endpoints.


## HTTPS / Let's Encrypt

O instalador `install-gods.sh` configura Apache e solicita um certificado válido para `goitgods.pasquared.space`. O e-mail ACME é obrigatório e validado antes da chamada ao Certbot.

Execução recomendada:

```bash
sudo ./install-gods.sh --certbot-email administrador@seudominio.com
```

Por padrão, `www.goitgods.pasquared.space` só é incluído no certificado se resolver no DNS (`CERTBOT_INCLUDE_WWW=auto`). Para solicitar apenas o domínio principal, use `--no-www`; para exigir também o alias WWW, use `--with-www`.

O instalador interrompe a emissão se o domínio principal não resolver, valida os arquivos do certificado após o Certbot, recarrega o Apache e executa `certbot renew --dry-run`.
