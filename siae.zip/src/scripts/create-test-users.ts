import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import admin from 'firebase-admin';

// Initialize Firebase
const firebaseKeyPath = path.join(process.cwd(), 'public', 'firebase-key.json');
if (fs.existsSync(firebaseKeyPath)) {
  const serviceAccount = JSON.parse(fs.readFileSync(firebaseKeyPath, 'utf8'));
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
  });
} else {
  console.error("Firebase key não encontrada em", firebaseKeyPath);
  process.exit(1);
}

const firestore = admin.firestore();

async function run() {
  const assistidoEmail = "assistido@siae.space";
  const trabalhadorEmail = "trabalhador@siae.space";
  const representanteEmail = "representante@siae.space";

  const assistidoPass = await bcrypt.hash("Ass@Siae-123", 10);
  const trabalhadorPass = await bcrypt.hash("Tra@Siae-123", 10);
  const representantePass = await bcrypt.hash("Rep@Siae-123", 10);

  // Users data
  const users = [
    {
      role: 'assisted',
      email: assistidoEmail,
      password: assistidoPass,
      first_name: 'Usuário',
      last_name: 'Assistido',
      cpf: '34567890123',
      dob: '01/01/1980',
    },
    {
      role: 'worker',
      email: trabalhadorEmail,
      password: trabalhadorPass,
      first_name: 'Usuário',
      last_name: 'Trabalhador',
      cpf: '23456789012',
      dob: '01/01/1980',
    },
    {
      role: 'representative',
      email: representanteEmail,
      password: representantePass,
      first_name: 'Representante',
      last_name: 'Casa',
      cpf: '12345678901',
      dob: '01/01/1980',
    }
  ];

  try {
    for (const u of users) {
      await firestore.collection('users').doc(u.cpf).set({
        ...u,
        created_at: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
    }

    console.log("Usuários teste inseridos no FIREBASE com sucesso.");

    const houseCnpj = "11111111000100";
    
    // Save House in Firebase
    await firestore.collection('houses').doc(houseCnpj).set({
      representative_cpf: '12345678901', 
      name: "Casa esp virtual 01",
      cnpj: houseCnpj,
      street: "rua sem nome",
      number: "1",
      city: "ukbelol",
      state: "Sp"
    }, { merge: true });

    // Save operating hours & assistances
    const assistances = ["Passe", "Heiki", "Auricultura", "Apometria"];
    
    await firestore.collection('houses').doc(houseCnpj).collection('config').doc('details').set({
      operating_hours: "Segunda a Domingo, das 00:00 as 23:59",
      assistances: assistances,
      assistances_availability: "Segunda a Domingo, todos os dias"
    }, { merge: true });

    console.log("Casa espírita, horários e tipos de assistências inseridos no Firebase com sucesso.");

  } catch(e) {
    console.error("Erro inserindo no Firebase:", e);
  } finally {
    process.exit(0);
  }
}

run();
