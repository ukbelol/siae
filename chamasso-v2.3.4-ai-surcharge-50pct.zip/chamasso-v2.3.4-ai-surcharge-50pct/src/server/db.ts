import fs from 'fs';
import path from 'path';
import pg from 'pg';
import { hashPassword, verifyPassword } from './auth.ts';
import { azureBlobBackupService } from './azureBlobBackup.ts';
import type {
  ChamassoTariffSettings,
  MercadoPagoSettings,
  PasqcoinSettings,
  PasqcoinMintBatch,
  PasqcoinTransaction,
  SocialPost,
  SocialComment,
  SocialReactionType,
  SocialLandingPageData,
  User,
  BillToPay,
  BillToReceive,
} from '../types.ts';

const { Pool } = pg;

// Tipagem dos Modelos Principais
export interface SystemSetting {
  key: string;
  value: any;
  description: string;
  updatedAt: string;
}

export interface SuperAdminRecord {
  id: string;
  email: string;
  passwordHash: string;
  role: 'SUPER_ADMIN';
  permissions: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DatabaseStore {
  settings: Record<string, SystemSetting>;
  superAdmins: Record<string, SuperAdminRecord>;
  users: Record<string, any>;
  rooms: Record<string, any>;
  roomMessages: Record<string, any[]>;
  relationshipLevels: Record<string, any>;
  friendships: Record<string, any>;
  standardConferences: Record<string, any>;
  auditLogs: any[];
  securityNotifications: any[];
  rechargeTransactions: Record<string, any>;
  pasqcoinBatches?: PasqcoinMintBatch[];
  pasqcoinTransactions?: PasqcoinTransaction[];
  registrationBonuses?: Record<string, any>; // CPF -> concessão única de boas-vindas
  socialPosts?: Record<string, SocialPost>;
  billsToPay?: Record<string, BillToPay>;
  billsToReceive?: Record<string, BillToReceive>;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'db_chamasso_store.json');
const PROFILE_BACKUP_DIR = process.env.CHAMASSO_PROFILE_BACKUP_DIR || path.join(DATA_DIR, 'profile-backups');
const USER_MEDIA_ROOT = process.env.USER_MEDIA_ROOT || '/var/lib/chamasso/user-media';

// Pool PostgreSQL opcional (quando PG estiver ativo no ambiente de produção VPS)
let pgPool: pg.Pool | null = null;
let isPgConnected = false;

function initPgPool() {
  const host = process.env.PGHOST || process.env.SQL_HOST || '127.0.0.1';
  const user = process.env.PGUSER || process.env.SQL_USER || 'user_chamasso';
  const password = process.env.PGPASSWORD || process.env.SQL_PASSWORD || '';
  const database = process.env.PGDATABASE || process.env.SQL_DB_NAME || 'db_chamasso';
  const port = parseInt(process.env.PGPORT || '5432', 10);

  try {
    pgPool = new Pool({
      host,
      port,
      user,
      password,
      database,
      connectionTimeoutMillis: 3000,
    });

    pgPool.on('error', (err) => {
      // Falhas normais quando PG não está rodando no container
      isPgConnected = false;
    });

    // Teste leve não bloqueante
    pgPool
      .query('SELECT 1')
      .then(() => {
        isPgConnected = true;
        console.log(`[Database] Conexão ativa com PostgreSQL em ${host}:${port}/${database} (user: ${user})`);
      })
      .catch(() => {
        isPgConnected = false;
      });
  } catch (err) {
    isPgConnected = false;
  }
}

// Inicia verificação do pool
initPgPool();

// Carga Inicial Padrão
function getInitialStore(): DatabaseStore {
  return {
    settings: {
      app_info: {
        key: 'app_info',
        value: {
          appName: 'chamasso live chat',
          version: '1.0.0',
          environment: 'production',
          sgbd: 'PostgreSQL 15',
          dbName: 'db_chamasso',
          dbUser: 'user_chamasso',
        },
        description: 'Informações gerais da aplicação e banco de dados',
        updatedAt: new Date().toISOString(),
      },
      domain_config: {
        key: 'domain_config',
        value: {
          domain: 'chamasso.pasquared.space',
          adminEmail: 'rogeriogomes11@ukbelol.space',
          sslEnabled: true,
          webServer: 'Apache 2.4.59 (mod_proxy)',
        },
        description: 'Configuração de domínio público e certificados SSL',
        updatedAt: new Date().toISOString(),
      },
      conference_defaults: {
        key: 'conference_defaults',
        value: {
          maxMatrixCameras: 15,
          speakerSlots: 14,
          maxChildRooms: 8,
          allowRaiseHand: true,
        },
        description: 'Parâmetros padrão para salas de videoconferência',
        updatedAt: new Date().toISOString(),
      },
      security_policy: {
        key: 'security_policy',
        value: {
          requireCpf: true,
          require2FA: true,
          totalDisposableCodes: 11,
          sessionTimeoutMinutes: 120,
        },
        description: 'Políticas de autenticação, CPF e 2FA',
        updatedAt: new Date().toISOString(),
      },
      tariffs_config: {
        key: 'tariffs_config',
        value: {
          billingEnabled: true, // Ativar ou suspender a cobrança do bate-papo
          ratePerMinute: 0.01, // Padrão R$ 0,01 (um centavo de real por minuto)
          minRechargeAmount: 5.0, // Recargas a partir de R$ 5,00
          rechargeValidityDays: 30, // Validade dos créditos de 30 dias após 1ª entrada em sala ou contato direto
        },
        description: 'Tarifas Chamasso: Cobrança por minuto e validade dos créditos',
        updatedAt: new Date().toISOString(),
      },
      mercadopago_config: {
        key: 'mercadopago_config',
        value: {
          activeEnvironment: 'test',
          test: {
            publicKey: process.env.MERCADOPAGO_TEST_PUBLIC_KEY || '',
            accessToken: process.env.MERCADOPAGO_TEST_ACCESS_TOKEN || '',
            webhookUrl: 'https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=test',
            redirectUrl: 'https://chamasso.pasquared.space/app?payment=success&environment=test',
          },
          production: {
            publicKey: process.env.MERCADOPAGO_PROD_PUBLIC_KEY || process.env.MERCADOPAGO_PUBLIC_KEY || '',
            accessToken: process.env.MERCADOPAGO_PROD_ACCESS_TOKEN || process.env.MERCADOPAGO_ACCESS_TOKEN || '',
            webhookUrl: 'https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=production',
            redirectUrl: 'https://chamasso.pasquared.space/app?payment=success&environment=production',
          },
        },
        description: 'Configuração Mercado Pago separada por ambiente: Teste e Produção',
        updatedAt: new Date().toISOString(),
      },
      pasqcoin_config: {
        key: 'pasqcoin_config',
        value: {
          enabled: true,
          name: 'pasqcoin',
          symbol: 'PASQ',
          secondsPerCoin: 600,
          pricePerCoin: 1.00,
          batchSize: 1141,
          autoReplenishThresholdPercent: 20,
          expirationDays: 30,
          totalMinted: 1141,
          availableReserve: 1141,
          circulatingInWallets: 0,
          autoReplenishEnabled: true,
          lastMintAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        description: 'Parâmetros e estoque da moeda virtual pasqcoin para tempo e desbloqueio do chat',
        updatedAt: new Date().toISOString(),
      },
    },
    superAdmins: {},
    users: {},
    rooms: {},
    roomMessages: {},
    relationshipLevels: {},
    friendships: {},
    standardConferences: {},
    auditLogs: [],
    securityNotifications: [],
    rechargeTransactions: {},
    pasqcoinBatches: [
      {
        id: 'batch_init_001',
        batchNumber: 1,
        amount: 1141,
        trigger: 'initial',
        timestamp: new Date().toISOString(),
        reserveBefore: 0,
        reserveAfter: 1141,
        notes: 'Emissão inicial automática de 1.141 pasqcoins disponíveis para compra',
      },
    ],
    pasqcoinTransactions: [],
    registrationBonuses: {},
    socialPosts: {
      post_welcome_01: {
        id: 'post_welcome_01',
        authorId: 'usr_rogerio_admin',
        authorName: 'Ukbelol',
        authorLastName: 'Pasquared',
        authorAvatar: '/fenix_chamas.gif',
        authorEmail: 'rogeriogomes11@ukbelol.space',
        authorNickname: 'Fundador Chamasso',
        content: '👋 Sejam bem-vindos à nossa Rede Social Chamasso Live Chat! Aqui você pode criar sua linha do tempo, compartilhar fotos, vídeos, notas de voz, interagir no feed, trocar Pasqcoins e conectar-se por live chat em tempo real com áudio, vídeo e arquivos de alta qualidade. Personalize seu perfil público ou restrito nas configurações!',
        mediaType: 'image',
        mediaUrl: '/fenix_chamas.gif',
        privacy: 'public',
        createdAt: new Date().toISOString(),
        reactions: {
          usr_rogerio_admin: 'love',
        },
        comments: [
          {
            id: 'comm_01',
            postId: 'post_welcome_01',
            authorId: 'usr_rogerio_admin',
            authorName: 'Suporte Chamasso',
            authorAvatar: '/fenix_chamas.gif',
            content: 'Dica: Você pode alternar seu perfil entre Público e Restrito a qualquer momento! 🛡️',
            createdAt: new Date().toISOString(),
          },
        ],
        sharesCount: 12,
      },
    },
    billsToPay: {
      bill_01: {
        id: 'bill_01',
        description: 'Servidor VPS Cloud Debian 12 (Infraestrutura Chamasso)',
        category: 'vps_infra',
        amount: 149.90,
        dueDate: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
        status: 'pending',
        beneficiary: 'HostVPS Cloud Provider',
        notes: 'VPS dedicada para WebRTC, Nginx e servidor Node/PostgreSQL.',
        createdAt: new Date().toISOString(),
      },
      bill_02: {
        id: 'bill_02',
        description: 'Renovação Anual Domínio chamasso.pasquared.space e Wildcard SSL',
        category: 'domain_ssl',
        amount: 69.00,
        dueDate: new Date(Date.now() + 25 * 86400000).toISOString().split('T')[0],
        status: 'pending',
        beneficiary: 'Registro DNS & Cert SSL',
        notes: 'Domínio de produção oficial chamasso.pasquared.space.',
        createdAt: new Date().toISOString(),
      },
      bill_03: {
        id: 'bill_03',
        description: 'Banda Excedente e Servidor TURN/STUN WebRTC Coturn',
        category: 'webrtc_bandwidth',
        amount: 89.50,
        dueDate: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0],
        status: 'paid',
        paidAt: new Date(Date.now() - 2 * 86400000).toISOString(),
        beneficiary: 'Global WebRTC Relay Network',
        notes: 'Banda para streaming de vídeo em alta definição.',
        createdAt: new Date().toISOString(),
      },
    },
    billsToReceive: {
      rec_01: {
        id: 'rec_01',
        description: 'Lote de Recargas Chamasso via PIX Automatizado',
        customerName: 'Usuários Bate-Papo Chamasso',
        customerEmail: 'financeiro@chamasso.pasquared.space',
        category: 'recharge_chamasso',
        amount: 380.00,
        dueDate: new Date().toISOString().split('T')[0],
        status: 'received',
        receivedAt: new Date().toISOString(),
        method: 'pix',
        createdAt: new Date().toISOString(),
      },
      rec_02: {
        id: 'rec_02',
        description: 'Aquisição de Lote de Pasqcoins (Tempo & Desbloqueio Chat)',
        customerName: 'Membros Ativos Rede Chamasso',
        customerEmail: 'pasqcoin@chamasso.pasquared.space',
        category: 'custom_plan',
        amount: 114.10,
        dueDate: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
        status: 'pending',
        method: 'pix',
        createdAt: new Date().toISOString(),
      },
      rec_03: {
        id: 'rec_03',
        description: 'Assinatura Sala Corporativa Exclusiva (8 Câmeras Filhas)',
        customerName: 'Grupo Corporativo Beta S/A',
        customerEmail: 'contato@betacorp.com.br',
        category: 'corporate_room',
        amount: 290.00,
        dueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
        status: 'pending',
        method: 'ticket',
        createdAt: new Date().toISOString(),
      },
    },
  };
}

class PersistentDatabase {
  private store: DatabaseStore;

  constructor() {
    this.store = this.loadStore();
    this.ensureSuperAdminCredentials();
  }

  private loadStore(): DatabaseStore {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(STORE_FILE)) {
        const raw = fs.readFileSync(STORE_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        // Garante estrutura completa
        const base = getInitialStore();
        const loaded: DatabaseStore = {
          ...base,
          ...parsed,
          settings: { ...base.settings, ...(parsed.settings || {}) },
          superAdmins: { ...base.superAdmins, ...(parsed.superAdmins || {}) },
          rechargeTransactions: parsed.rechargeTransactions || {},
          roomMessages: parsed.roomMessages || {},
          pasqcoinBatches: parsed.pasqcoinBatches || base.pasqcoinBatches || [],
          pasqcoinTransactions: parsed.pasqcoinTransactions || base.pasqcoinTransactions || [],
          registrationBonuses: parsed.registrationBonuses || base.registrationBonuses || {},
          socialPosts: parsed.socialPosts || base.socialPosts || {},
          billsToPay: parsed.billsToPay || base.billsToPay || {},
          billsToReceive: parsed.billsToReceive || base.billsToReceive || {},
        };
        this.restoreProfileImagesIntoStore(loaded);
        return loaded;
      }
    } catch (err) {
      console.error('[Database] Erro ao carregar arquivo de persistência:', err);
    }

    const initial = getInitialStore();
    this.restoreProfileImagesIntoStore(initial);
    this.saveStore(initial);
    return initial;
  }

  private saveStore(dataToSave?: DatabaseStore) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const data = dataToSave || this.store;
      fs.writeFileSync(STORE_FILE, JSON.stringify(data, null, 2), 'utf-8');
      this.writeAllProfileImages(data);
      azureBlobBackupService.scheduleSync();
    } catch (err) {
      console.error('[Database] Erro ao salvar persistência no disco:', err);
    }
  }

  /**
   * "Imagem do perfil" de recuperação de desastre.
   * Cada usuário recebe um snapshot independente em diretório persistente fora da aplicação.
   * O snapshot contém cadastro/perfil, carteira PASQcoin, posts, amizades, mensagens de sala,
   * transações PASQcoin e cópias de mídias locais referenciadas pelo perfil/posts/mensagens.
   */
  private resolveProfileBackupDir(): string {
    try {
      fs.mkdirSync(PROFILE_BACKUP_DIR, { recursive: true, mode: 0o700 });
      return PROFILE_BACKUP_DIR;
    } catch {
      const fallback = path.join(DATA_DIR, 'profile-backups');
      fs.mkdirSync(fallback, { recursive: true });
      return fallback;
    }
  }

  private collectMediaUrls(value: any, out = new Set<string>()): Set<string> {
    if (typeof value === 'string') {
      if (/^(\/|\.\/)?(uploads|media|gallery|user-media)\//i.test(value) || /^data:(image|video|audio)\//i.test(value)) out.add(value);
      return out;
    }
    if (Array.isArray(value)) value.forEach((v) => this.collectMediaUrls(v, out));
    else if (value && typeof value === 'object') Object.values(value).forEach((v) => this.collectMediaUrls(v, out));
    return out;
  }

  private writeAllProfileImages(data: DatabaseStore) {
    try {
      const root = this.resolveProfileBackupDir();
      for (const user of Object.values(data.users || {})) {
        if (!user?.id) continue;
        const uid = String(user.id).replace(/[^a-zA-Z0-9_-]/g, '_');
        const userDir = path.join(root, uid);
        const mediaDir = path.join(userDir, 'media');
        fs.mkdirSync(mediaDir, { recursive: true, mode: 0o700 });
        const posts = Object.values(data.socialPosts || {}).filter((p: any) => p.authorId === user.id);
        const friendships = Object.values(data.friendships || {}).filter((f: any) => f.senderId === user.id || f.receiverId === user.id);
        const roomMessages: Record<string, any[]> = {};
        for (const [roomId, messages] of Object.entries(data.roomMessages || {})) {
          const mine = (messages || []).filter((m: any) => m.senderId === user.id || m.receiverId === user.id);
          if (mine.length) roomMessages[roomId] = mine;
        }
        const pasqcoinTransactions = (data.pasqcoinTransactions || []).filter((t: any) => t.userId === user.id || t.fromUserId === user.id || t.toUserId === user.id);
        const snapshot: any = {
          schema: 'chamasso-user-profile-image/v1', userId: user.id, createdAt: new Date().toISOString(),
          user, pasqcoinBalance: Number(user.pasqcoins || 0), posts, friendships, roomMessages, pasqcoinTransactions,
          mediaFiles: [] as any[],
        };
        const urls = this.collectMediaUrls({ user, posts, roomMessages });
        for (const url of urls) {
          if (url.startsWith('data:')) continue; // já está integralmente contido no JSON
          const rel = url.replace(/^\.?\//, '');
          const candidates = [path.join(process.cwd(), rel), path.join(process.cwd(), 'public', rel), path.join(DATA_DIR, rel), ...(rel.startsWith('user-media/') ? [path.join(USER_MEDIA_ROOT, rel.slice('user-media/'.length))] : [])];
          const src = candidates.find((c) => fs.existsSync(c) && fs.statSync(c).isFile());
          if (!src) continue;
          const safeName = `${Buffer.from(rel).toString('hex').slice(0, 32)}_${path.basename(rel)}`;
          const dst = path.join(mediaDir, safeName);
          fs.copyFileSync(src, dst);
          snapshot.mediaFiles.push({ originalUrl: url, originalRelativePath: rel, backupName: safeName });
        }
        const tmp = path.join(userDir, 'profile-image.json.tmp');
        fs.writeFileSync(tmp, JSON.stringify(snapshot, null, 2), { encoding: 'utf-8', mode: 0o600 });
        fs.renameSync(tmp, path.join(userDir, 'profile-image.json'));
      }
    } catch (err) {
      console.error('[ProfileBackup] Falha ao criar imagem de perfil:', err);
    }
  }

  private restoreProfileImagesIntoStore(target: DatabaseStore) {
    try {
      const root = this.resolveProfileBackupDir();
      for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
        if (!entry.isDirectory()) continue;
        const manifest = path.join(root, entry.name, 'profile-image.json');
        if (!fs.existsSync(manifest)) continue;
        const snap = JSON.parse(fs.readFileSync(manifest, 'utf-8'));
        if (!snap?.user?.id) continue;
        const id = snap.user.id;
        // Snapshot persistente prevalece quando o usuário sumiu após reinstalação.
        if (!target.users[id]) target.users[id] = snap.user;
        else if (Number(snap.pasqcoinBalance || 0) > Number(target.users[id].pasqcoins || 0)) target.users[id].pasqcoins = snap.pasqcoinBalance;
        for (const p of snap.posts || []) if (p?.id && !target.socialPosts?.[p.id]) (target.socialPosts ||= {})[p.id] = p;
        for (const f of snap.friendships || []) if (f?.id && !target.friendships[f.id]) target.friendships[f.id] = f;
        for (const [roomId, msgs] of Object.entries(snap.roomMessages || {})) {
          const existing = (target.roomMessages ||= {})[roomId] || [];
          const ids = new Set(existing.map((m: any) => m.id));
          for (const m of msgs as any[]) if (!ids.has(m.id)) existing.push(m);
          target.roomMessages[roomId] = existing.slice(-1000);
        }
        const txIds = new Set((target.pasqcoinTransactions || []).map((t: any) => t.id));
        for (const t of snap.pasqcoinTransactions || []) if (!txIds.has(t.id)) (target.pasqcoinTransactions ||= []).push(t);
        for (const mf of snap.mediaFiles || []) {
          const src = path.join(root, entry.name, 'media', path.basename(mf.backupName || ''));
          const rel = String(mf.originalRelativePath || '').replace(/^\.?\//, '');
          if (!rel || rel.includes('..') || !fs.existsSync(src)) continue;
          const dst = rel.startsWith('user-media/') ? path.join(USER_MEDIA_ROOT, rel.slice('user-media/'.length)) : path.join(process.cwd(), rel);
          if (!fs.existsSync(dst)) { fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.copyFileSync(src, dst); }
        }
      }
    } catch (err) {
      console.error('[ProfileBackup] Falha ao restaurar imagens de perfil:', err);
    }
  }

  public reloadProfileRecoveryImages() {
    this.restoreProfileImagesIntoStore(this.store);
    this.saveStore();
    return { success: true, users: Object.keys(this.store.users || {}).length };
  }

  public createProfileRecoveryImage(userId?: string) {
    this.writeAllProfileImages(this.store);
    const root = this.resolveProfileBackupDir();
    if (!userId) return { success: true, directory: root, users: Object.keys(this.store.users || {}).length };
    const uid = String(userId).replace(/[^a-zA-Z0-9_-]/g, '_');
    const file = path.join(root, uid, 'profile-image.json');
    return { success: fs.existsSync(file), directory: path.dirname(file), userId };
  }

  public ensureSuperAdminCredentials() {
    const adminEmail = process.env.SUPER_ADMIN_EMAIL || 'roger577@ukbelol.space';
    const configuredPassword = process.env.SUPER_ADMIN_PASSWORD;
    const configuredHash = process.env.SUPER_ADMIN_PASSWORD_HASH;
    const existing = this.store.superAdmins[adminEmail];

    if (!existing && !configuredPassword && !configuredHash) {
      console.warn('[Security] Super Admin não provisionado: defina SUPER_ADMIN_PASSWORD ou SUPER_ADMIN_PASSWORD_HASH no .env.');
      return;
    }

    const passwordHash = configuredHash || (configuredPassword ? hashPassword(configuredPassword) : existing?.passwordHash);
    if (!passwordHash || !passwordHash.startsWith('scrypt$')) {
      console.warn('[Security] Hash legado/plaintext de Super Admin ignorado. Configure uma nova senha via SUPER_ADMIN_PASSWORD.');
      return;
    }

    this.store.superAdmins[adminEmail] = {
      id: existing?.id || 'adm_super_master', email: adminEmail, passwordHash,
      role: 'SUPER_ADMIN', permissions: ['ALL'], isActive: true,
      createdAt: existing?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(),
    };
    this.saveStore();
  }

  // --- CONFIGURAÇÕES DO SISTEMA ---
  public getSettings(): Record<string, SystemSetting> {
    return this.store.settings;
  }

  public getSetting(key: string): SystemSetting | undefined {
    return this.store.settings[key];
  }

  public saveSetting(key: string, value: any, description?: string): SystemSetting {
    const existing = this.store.settings[key];
    const updated: SystemSetting = {
      key,
      value,
      description: description || existing?.description || 'Configuração salva pelo Super Admin',
      updatedAt: new Date().toISOString(),
    };
    this.store.settings[key] = updated;
    this.saveStore();
    return updated;
  }

  // --- SUPER ADMIN ---
  public verifySuperAdmin(email: string, passwordAttempt: string): SuperAdminRecord | null {
    const admin = this.store.superAdmins[email];
    if (!admin || !admin.isActive) return null;
    return verifyPassword(passwordAttempt, admin.passwordHash) ? admin : null;
  }

  public getSuperAdmin(email: string): SuperAdminRecord | undefined {
    return this.store.superAdmins[email];
  }

  // --- USUÁRIOS ---
  public getUsers(): any[] {
    return Object.values(this.store.users);
  }

  public getUser(id: string): any | undefined {
    return this.store.users[id];
  }

  public getUserByEmail(email: string): any | undefined {
    return Object.values(this.store.users).find((u) => u.googleEmail === email);
  }

  public getUserByCpf(cpf: string): any | undefined {
    return Object.values(this.store.users).find((u) => u.cpf === cpf);
  }

  public saveUser(user: any): any {
    this.store.users[user.id] = user;
    this.saveStore();
    return user;
  }

  public deleteUser(id: string): boolean {
    if (this.store.users[id]) {
      delete this.store.users[id];
      this.saveStore();
      return true;
    }
    return false;
  }

  // --- SALAS ---
  public getRooms(): any[] {
    return Object.values(this.store.rooms);
  }

  public getRoom(id: string): any | undefined {
    return this.store.rooms[id];
  }

  public saveRoom(room: any): any {
    this.store.rooms[room.id] = room;
    this.saveStore();
    return room;
  }

  public deleteRoom(id: string): boolean {
    if (this.store.rooms[id]) {
      delete this.store.rooms[id];
      this.saveStore();
      return true;
    }
    return false;
  }

  // --- MENSAGENS DE SALA (persistência local durável; PostgreSQL pode ser adotado como primário) ---
  public getRoomMessages(roomId: string): any[] { return this.store.roomMessages?.[roomId] || []; }
  public saveRoomMessages(roomId: string, messages: any[]): any[] {
    if (!this.store.roomMessages) this.store.roomMessages = {};
    this.store.roomMessages[roomId] = messages.slice(-1000);
    this.saveStore();
    return this.store.roomMessages[roomId];
  }
  public deleteRoomMessages(roomId: string) {
    if (this.store.roomMessages) delete this.store.roomMessages[roomId];
    this.saveStore();
  }

  // --- NÍVEIS DE RELACIONAMENTO ---
  public getRelationshipLevels(): any[] {
    return Object.values(this.store.relationshipLevels);
  }

  public saveRelationshipLevel(level: any): any {
    this.store.relationshipLevels[level.id] = level;
    this.saveStore();
    return level;
  }

  public deleteRelationshipLevel(id: string): boolean {
    if (this.store.relationshipLevels[id]) {
      delete this.store.relationshipLevels[id];
      this.saveStore();
      return true;
    }
    return false;
  }

  public setAllRelationshipLevels(levels: any[]) {
    this.store.relationshipLevels = {};
    for (const lvl of levels) {
      this.store.relationshipLevels[lvl.id] = lvl;
    }
    this.saveStore();
  }

  // --- AMIZADES ---
  public getFriendships(): any[] {
    return Object.values(this.store.friendships);
  }

  public saveFriendship(friendship: any): any {
    this.store.friendships[friendship.id] = friendship;
    this.saveStore();
    return friendship;
  }

  // --- VIDEOCONFERÊNCIA PADRÃO ---
  public getStandardConference(roomId: string): any | undefined {
    return this.store.standardConferences[roomId];
  }

  public saveStandardConference(roomId: string, data: any): any {
    this.store.standardConferences[roomId] = {
      ...data,
      updatedAt: new Date().toISOString(),
    };
    this.saveStore();
    return this.store.standardConferences[roomId];
  }

  // --- LOGS DE AUDITORIA ---
  public getAuditLogs(): any[] {
    return this.store.auditLogs;
  }

  public addAuditLog(log: any) {
    this.store.auditLogs.unshift(log);
    if (this.store.auditLogs.length > 500) {
      this.store.auditLogs = this.store.auditLogs.slice(0, 500);
    }
    this.saveStore();
  }

  // --- NOTIFICAÇÕES ---
  public getSecurityNotifications(): any[] {
    return this.store.securityNotifications;
  }

  public addSecurityNotification(notification: any) {
    this.store.securityNotifications.unshift(notification);
    if (this.store.securityNotifications.length > 200) {
      this.store.securityNotifications = this.store.securityNotifications.slice(0, 200);
    }
    this.saveStore();
  }

  // --- TRANSAÇÕES DE RECARGA E MERCADO PAGO ---
  public getTransactions(): any[] {
    return Object.values(this.store.rechargeTransactions || {});
  }

  public getRechargeTransactions(): any[] {
    return Object.values(this.store.rechargeTransactions || {}).sort((a: any, b: any) => {
      return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    });
  }

  public getTransaction(id: string): any | undefined {
    return (this.store.rechargeTransactions || {})[id];
  }

  public saveTransaction(tx: any): any {
    if (!this.store.rechargeTransactions) {
      this.store.rechargeTransactions = {};
    }
    this.store.rechargeTransactions[tx.id] = tx;
    this.saveStore();
    return tx;
  }

  public createRechargeTransaction(tx: any): any {
    return this.saveTransaction(tx);
  }

  // --- TARIFAS CHAMASSO & MERCADO PAGO SETTINGS ---
  public getTariffSettings(): ChamassoTariffSettings {
    const defaultSettings: ChamassoTariffSettings = {
      billingEnabled: true,
      unlockFeeEnabled: true,
      ratePerMinute: 0.01,
      minRechargeAmount: 5.0,
      rechargeValidityDays: 30,
    };
    const saved = this.getSetting('tariffs_config');
    if (saved && saved.value) {
      return {
        ...defaultSettings,
        ...saved.value,
        billingEnabled: typeof saved.value.billingEnabled === 'boolean' ? saved.value.billingEnabled : defaultSettings.billingEnabled,
        unlockFeeEnabled: typeof saved.value.unlockFeeEnabled === 'boolean'
          ? saved.value.unlockFeeEnabled
          : defaultSettings.unlockFeeEnabled,
        ratePerMinute: typeof saved.value.ratePerMinute === 'number' && !isNaN(saved.value.ratePerMinute)
          ? saved.value.ratePerMinute
          : defaultSettings.ratePerMinute,
        minRechargeAmount: typeof saved.value.minRechargeAmount === 'number' && !isNaN(saved.value.minRechargeAmount)
          ? saved.value.minRechargeAmount
          : defaultSettings.minRechargeAmount,
        rechargeValidityDays: typeof saved.value.rechargeValidityDays === 'number' && !isNaN(saved.value.rechargeValidityDays)
          ? saved.value.rechargeValidityDays
          : defaultSettings.rechargeValidityDays,
      };
    }
    return defaultSettings;
  }

  public saveTariffSettings(settings: Partial<ChamassoTariffSettings>) {
    const current = this.getTariffSettings();
    const merged: ChamassoTariffSettings = {
      billingEnabled: typeof settings.billingEnabled === 'boolean' ? settings.billingEnabled : current.billingEnabled,
      unlockFeeEnabled: typeof settings.unlockFeeEnabled === 'boolean'
        ? settings.unlockFeeEnabled
        : current.unlockFeeEnabled,
      ratePerMinute: typeof settings.ratePerMinute === 'number' && !isNaN(settings.ratePerMinute)
        ? Math.max(0, settings.ratePerMinute)
        : current.ratePerMinute,
      minRechargeAmount: typeof settings.minRechargeAmount === 'number' && !isNaN(settings.minRechargeAmount)
        ? Math.max(1, settings.minRechargeAmount)
        : current.minRechargeAmount,
      rechargeValidityDays: typeof settings.rechargeValidityDays === 'number' && !isNaN(settings.rechargeValidityDays)
        ? Math.max(1, settings.rechargeValidityDays)
        : current.rechargeValidityDays,
    };
    this.saveSetting('tariffs_config', merged, 'Tarifas Chamasso: Cobrança por minuto, desbloqueio e validade dos créditos');
    this.saveStore();
    return this.getTariffSettings();
  }

  private getDefaultMercadoPagoProfile(environment: 'test' | 'production') {
    const isTest = environment === 'test';
    return {
      publicKey: isTest
        ? (process.env.MERCADOPAGO_TEST_PUBLIC_KEY || '')
        : (process.env.MERCADOPAGO_PROD_PUBLIC_KEY || process.env.MERCADOPAGO_PUBLIC_KEY || ''),
      accessToken: isTest
        ? (process.env.MERCADOPAGO_TEST_ACCESS_TOKEN || '')
        : (process.env.MERCADOPAGO_PROD_ACCESS_TOKEN || process.env.MERCADOPAGO_ACCESS_TOKEN || ''),
      webhookUrl: isTest
        ? (process.env.MERCADOPAGO_TEST_WEBHOOK_URL || 'https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=test')
        : (process.env.MERCADOPAGO_PROD_WEBHOOK_URL || process.env.MERCADOPAGO_WEBHOOK_URL || 'https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=production'),
      redirectUrl: isTest
        ? (process.env.MERCADOPAGO_TEST_REDIRECT_URL || 'https://chamasso.pasquared.space/app?payment=success&environment=test')
        : (process.env.MERCADOPAGO_PROD_REDIRECT_URL || process.env.MERCADOPAGO_REDIRECT_URL || 'https://chamasso.pasquared.space/app?payment=success&environment=production'),
    };
  }

  private getMercadoPagoStoredConfig(): any {
    const saved = this.getSetting('mercadopago_config');
    const value = saved?.value || {};

    // Formato novo: dois perfis independentes.
    if (value.test && value.production) {
      return {
        activeEnvironment: value.activeEnvironment === 'test' ? 'test' : 'production',
        test: { ...this.getDefaultMercadoPagoProfile('test'), ...value.test },
        production: { ...this.getDefaultMercadoPagoProfile('production'), ...value.production },
      };
    }

    // Migração transparente do formato antigo (um único conjunto + sandboxMode).
    const legacyEnvironment: 'test' | 'production' = value.sandboxMode === true ? 'test' : 'production';
    const migrated = {
      activeEnvironment: legacyEnvironment,
      test: this.getDefaultMercadoPagoProfile('test'),
      production: this.getDefaultMercadoPagoProfile('production'),
    };
    const legacyProfile = {
      publicKey: typeof value.publicKey === 'string' ? value.publicKey : '',
      accessToken: typeof value.accessToken === 'string' ? value.accessToken : '',
      webhookUrl: typeof value.webhookUrl === 'string' ? value.webhookUrl : this.getDefaultMercadoPagoProfile(legacyEnvironment).webhookUrl,
      redirectUrl: typeof value.redirectUrl === 'string' ? value.redirectUrl : this.getDefaultMercadoPagoProfile(legacyEnvironment).redirectUrl,
    };
    migrated[legacyEnvironment] = { ...migrated[legacyEnvironment], ...legacyProfile };
    return migrated;
  }

  public getMercadoPagoSettings(environment?: 'test' | 'production'): MercadoPagoSettings {
    const config = this.getMercadoPagoStoredConfig();
    const selected: 'test' | 'production' = environment || config.activeEnvironment;
    const profile = config[selected] || this.getDefaultMercadoPagoProfile(selected);
    return {
      ...profile,
      sandboxMode: selected === 'test',
      environment: selected,
    };
  }

  public setMercadoPagoActiveEnvironment(environment: 'test' | 'production') {
    const config = this.getMercadoPagoStoredConfig();
    config.activeEnvironment = environment;
    this.saveSetting(
      'mercadopago_config',
      config,
      'Configuração Mercado Pago com credenciais independentes para Teste e Produção'
    );
    this.saveStore();
    return this.getMercadoPagoSettings(environment);
  }

  public saveMercadoPagoSettings(settings: Partial<MercadoPagoSettings>, environment?: 'test' | 'production') {
    const config = this.getMercadoPagoStoredConfig();
    const selected: 'test' | 'production' = environment
      || settings.environment
      || (settings.sandboxMode === true ? 'test' : settings.sandboxMode === false ? 'production' : config.activeEnvironment);
    const current = config[selected] || this.getDefaultMercadoPagoProfile(selected);

    config[selected] = {
      publicKey: typeof settings.publicKey === 'string' ? settings.publicKey.trim() : current.publicKey,
      accessToken: typeof settings.accessToken === 'string' ? settings.accessToken.trim() : current.accessToken,
      webhookUrl: typeof settings.webhookUrl === 'string' ? settings.webhookUrl.trim() : current.webhookUrl,
      redirectUrl: typeof settings.redirectUrl === 'string' ? settings.redirectUrl.trim() : current.redirectUrl,
    };
    config.activeEnvironment = selected;

    this.saveSetting(
      'mercadopago_config',
      config,
      'Configuração Mercado Pago com credenciais independentes para Teste e Produção'
    );
    this.saveStore();
    return this.getMercadoPagoSettings(selected);
  }

  // --- PASQCOIN (MOEDA VIRTUAL DE TEMPO E DESBLOQUEIO) ---
  public getPasqcoinSettings(): PasqcoinSettings {
    const defaultSettings: PasqcoinSettings = {
      enabled: true,
      name: 'pasqcoin',
      symbol: 'PASQ',
      secondsPerCoin: 600, // 600 segundos por 1 moeda (1 pasqcoin = 10 minutos de chat desbloqueado)
      pricePerCoin: 1.00, // R$ 1,00 por pasqcoin
      batchSize: 1141, // 1.141 gerados por vez
      autoReplenishThresholdPercent: 20, // 20%
      expirationDays: 30, // Validade em dias padrão
      totalMinted: 1141,
      availableReserve: 1141,
      circulatingInWallets: 0,
      autoReplenishEnabled: true,
      lastMintAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const saved = this.getSetting('pasqcoin_config');
    if (saved && saved.value) {
      const merged = { ...defaultSettings, ...saved.value } as PasqcoinSettings;
      // Migra somente a tarifa padrão legada; valores personalizados são preservados.
      if (Number(saved.value.secondsPerCoin) === 60 && Number(saved.value.pricePerCoin) === 0.01) {
        merged.secondsPerCoin = 600;
        merged.pricePerCoin = 1.00;
        this.saveSetting('pasqcoin_config', merged, 'Parâmetros e estoque da moeda virtual pasqcoin');
      }
      return merged;
    }
    return defaultSettings;
  }

  public savePasqcoinSettings(settings: Partial<PasqcoinSettings>): PasqcoinSettings {
    const current = this.getPasqcoinSettings();
    const merged: PasqcoinSettings = {
      ...current,
      ...settings,
      updatedAt: new Date().toISOString(),
    };
    this.saveSetting('pasqcoin_config', merged, 'Parâmetros e estoque da moeda virtual pasqcoin');
    return this.getPasqcoinSettings();
  }

  public getPasqcoinBatches(): PasqcoinMintBatch[] {
    if (!this.store.pasqcoinBatches || this.store.pasqcoinBatches.length === 0) {
      this.store.pasqcoinBatches = [
        {
          id: 'batch_init_001',
          batchNumber: 1,
          amount: 1141,
          trigger: 'initial',
          timestamp: new Date().toISOString(),
          reserveBefore: 0,
          reserveAfter: 1141,
          notes: 'Emissão inicial automática de 1.141 pasqcoins disponíveis para compra',
        },
      ];
      this.saveStore();
    }
    return this.store.pasqcoinBatches;
  }

  public mintPasqcoinBatch(
    amount = 1141,
    trigger: 'initial' | 'auto_replenish_20' | 'manual_admin' = 'manual_admin',
    notes?: string
  ) {
    const settings = this.getPasqcoinSettings();
    const reserveBefore = settings.availableReserve;
    const reserveAfter = reserveBefore + amount;

    settings.availableReserve = reserveAfter;
    settings.totalMinted = (settings.totalMinted || 0) + amount;
    settings.lastMintAt = new Date().toISOString();
    this.savePasqcoinSettings(settings);

    const batches = this.getPasqcoinBatches();
    const newBatch: PasqcoinMintBatch = {
      id: `batch_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      batchNumber: batches.length + 1,
      amount,
      trigger,
      timestamp: new Date().toISOString(),
      reserveBefore,
      reserveAfter,
      notes: notes || (
        trigger === 'auto_replenish_20'
          ? `Gatilho de 20% atingido: Reserva atingiu ≤ 20% da quantidade total. Novo lote de ${amount} PASQ gerado automaticamente.`
          : `Geração de lote de ${amount} pasqcoins efetuada pelo Super Admin.`
      ),
    };

    batches.unshift(newBatch);
    this.store.pasqcoinBatches = batches;
    this.saveStore();

    return { settings: this.getPasqcoinSettings(), batch: newBatch };
  }

  public checkAndTriggerAutoReplenish(): { triggered: boolean; batch?: PasqcoinMintBatch } {
    const settings = this.getPasqcoinSettings();
    if (!settings.autoReplenishEnabled) return { triggered: false };

    // Limiar dos 20%: 20% do lote padrão (ex: 1141 * 0.20 = 228.2)
    const threshold = Math.ceil(settings.batchSize * (settings.autoReplenishThresholdPercent / 100));

    if (settings.availableReserve <= threshold) {
      const result = this.mintPasqcoinBatch(
        settings.batchSize,
        'auto_replenish_20',
        `Reposição Automática disparada: Estoque restante (${settings.availableReserve} PASQ) atingiu o limite de 20% (≤ ${threshold} PASQ). Novo lote de ${settings.batchSize} PASQ gerado automaticamente.`
      );
      return { triggered: true, batch: result.batch };
    }

    return { triggered: false };
  }

  public getPasqcoinTransactions(): PasqcoinTransaction[] {
    return this.store.pasqcoinTransactions || [];
  }

  public buyPasqcoin(
    userId: string,
    amountCoins: number,
    paymentMethod: 'balance' | 'pix' | 'credit_card' | 'admin' = 'balance'
  ) {
    const user = this.getUser(userId);
    if (!user) {
      throw new Error('Usuário não encontrado.');
    }

    const settings = this.getPasqcoinSettings();
    if (amountCoins <= 0) {
      throw new Error('Quantidade de Pasqcoins deve ser maior que zero.');
    }

    if (settings.availableReserve < amountCoins) {
      // Uma compra já paga nunca deve falhar apenas por estoque virtual baixo.
      // Gera lotes suficientes antes de concluir o crédito, respeitando o tamanho configurado.
      const batchSize = Math.max(1, Number(settings.batchSize) || 1141);
      const missing = amountCoins - settings.availableReserve;
      const batchesNeeded = Math.ceil(missing / batchSize);
      for (let i = 0; i < batchesNeeded; i += 1) {
        this.mintPasqcoinBatch(batchSize, 'auto_replenish_20', 'Reposição automática para honrar compra confirmada de PASQcoin.');
      }
      Object.assign(settings, this.getPasqcoinSettings());
    }

    const pricePaid = Math.round(amountCoins * settings.pricePerCoin * 100) / 100;

    // Se o pagamento for com saldo em R$ da conta:
    if (paymentMethod === 'balance') {
      const currentBalance = typeof user.balance === 'number' ? user.balance : 0;
      if (currentBalance < pricePaid) {
        throw new Error(`Saldo insuficiente na conta (R$ ${currentBalance.toFixed(2)}). Custo da compra: R$ ${pricePaid.toFixed(2)}.`);
      }
      user.balance = Math.max(0, Math.round((currentBalance - pricePaid) * 100) / 100);
    }

    // Credita na carteira do usuário
    user.pasqcoins = Number(((user.pasqcoins || 0) + amountCoins).toFixed(6));
    this.saveUser(user);

    // Deduz da reserva disponível
    settings.availableReserve = Number((settings.availableReserve - amountCoins).toFixed(6));
    settings.circulatingInWallets = Number(((settings.circulatingInWallets || 0) + amountCoins).toFixed(6));
    this.savePasqcoinSettings(settings);

    // Registra transação
    const tx: PasqcoinTransaction = {
      id: `tx_pasq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      userName: `${user.name} ${user.lastName || ''}`.trim(),
      userEmail: user.googleEmail,
      type: 'purchase',
      amountCoins,
      pricePaid,
      paymentMethod,
      chatDurationSeconds: amountCoins * settings.secondsPerCoin,
      timestamp: new Date().toISOString(),
      balanceAfter: user.pasqcoins,
    };

    if (!this.store.pasqcoinTransactions) this.store.pasqcoinTransactions = [];
    this.store.pasqcoinTransactions.unshift(tx);
    this.saveStore();

    // Verifica gatilho automático de 20%
    const replenishResult = this.checkAndTriggerAutoReplenish();

    return {
      success: true,
      transaction: tx,
      user,
      settings: this.getPasqcoinSettings(),
      autoReplenished: replenishResult.triggered,
      newBatch: replenishResult.batch,
    };
  }

  /** Concede UMA única bonificação de boas-vindas por CPF.
   *  1 PASQ = 60 segundos; 60 PASQ = 60 minutos de texto, áudio ou vídeo.
   *  A trava por CPF impede nova contemplação mesmo se houver tentativa de recriar conta.
   */
  public grantNewRegistrationBonus(userId: string, cpf: string, minutes = 60) {
    const user = this.getUser(userId);
    if (!user) throw new Error('Usuário não encontrado para concessão do bônus.');
    const cpfKey = String(cpf || '').replace(/\\D/g, '');
    if (!cpfKey) throw new Error('CPF obrigatório para concessão do bônus.');
    this.store.registrationBonuses ||= {};
    if (this.store.registrationBonuses[cpfKey]) {
      return { granted: false, reason: 'cpf_already_contemplated', user };
    }

    const settings = this.getPasqcoinSettings();
    const secondsPerCoin = Math.max(1, Number(settings.secondsPerCoin) || 600);
    const coins = Number(((minutes * 60) / secondsPerCoin).toFixed(6));
    user.pasqcoins = Number(((Number(user.pasqcoins) || 0) + coins).toFixed(6));
    this.store.registrationBonuses[cpfKey] = {
      cpf: cpfKey, userId, minutesGranted: minutes, pasqcoinsGranted: coins,
      grantedAt: new Date().toISOString(), benefit: 'new_registration_60_minutes'
    };
    settings.circulatingInWallets = Number(((settings.circulatingInWallets || 0) + coins).toFixed(6));
    settings.totalMinted = Number(((settings.totalMinted || 0) + coins).toFixed(6));
    this.savePasqcoinSettings(settings);
    const tx: PasqcoinTransaction = {
      id: `tx_welcome_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId, userName: `${user.name} ${user.lastName || ''}`.trim(), userEmail: user.googleEmail,
      type: 'registration_bonus', amountCoins: coins, chatDurationSeconds: minutes * 60,
      paymentMethod: 'admin', timestamp: new Date().toISOString(), balanceAfter: user.pasqcoins
    };
    this.store.pasqcoinTransactions ||= [];
    this.store.pasqcoinTransactions.unshift(tx);
    this.store.users[userId] = user;
    this.saveStore();
    return { granted: true, minutesGranted: minutes, pasqcoinsGranted: coins, user, transaction: tx };
  }

  public adminCreditPasqcoins(userId: string, amountCoins: number, notes?: string) {
    const user = this.getUser(userId);
    if (!user) throw new Error('Usuário não encontrado.');

    const settings = this.getPasqcoinSettings();
    user.pasqcoins = (user.pasqcoins || 0) + amountCoins;
    this.saveUser(user);

    settings.circulatingInWallets = (settings.circulatingInWallets || 0) + amountCoins;
    this.savePasqcoinSettings(settings);

    const tx: PasqcoinTransaction = {
      id: `tx_pasq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      userName: `${user.name} ${user.lastName || ''}`.trim(),
      userEmail: user.googleEmail,
      type: 'admin_bonus',
      amountCoins,
      paymentMethod: 'admin',
      chatDurationSeconds: amountCoins * settings.secondsPerCoin,
      timestamp: new Date().toISOString(),
      balanceAfter: user.pasqcoins,
    };

    if (!this.store.pasqcoinTransactions) this.store.pasqcoinTransactions = [];
    this.store.pasqcoinTransactions.unshift(tx);
    this.saveStore();

    return { success: true, user, transaction: tx };
  }

  public addPasqcoinTransaction(tx: PasqcoinTransaction): PasqcoinTransaction {
    if (!this.store.pasqcoinTransactions) this.store.pasqcoinTransactions = [];
    this.store.pasqcoinTransactions.unshift(tx);
    this.saveStore();
    return tx;
  }

  public consumePasqcoinForChat(userId: string, roomId = 'general', secondsElapsed = 1) {
    const user = this.getUser(userId);
    if (!user) throw new Error('Usuário não encontrado.');
    const settings = this.getPasqcoinSettings();
    const secondsPerCoin = Math.max(1, Number(settings.secondsPerCoin) || 600);
    const safeSeconds = Math.max(0, Math.min(Number(secondsElapsed) || 0, 300));
    // CHAMASSO: VIP e a conta oficial AI/PASQUARED nunca são cobrados.
    const userAccountType = String((user as any).accountType || (user as any).account_type || 'USER').toUpperCase();
    if (user.isFreeAccess || userAccountType === 'AI') {
      return { success: true, user, vip: !!user.isFreeAccess, aiAccount: userAccountType === 'AI', billingMultiplier: 0, deductedCoins: 0, consumedSeconds: safeSeconds, pasqcoinsRemaining: Number(user.pasqcoins) || 0, secondsRemaining: null, secondsPerCoin, hasMoreCoins: true };
    }

    // Sobretaxa IA: usuário comum conversando com AI/PASQUARED paga 50% a mais.
    // A identificação é feita no servidor pelos participantes da sala, nunca por um
    // accountType enviado pelo navegador. Ex.: tarifa normal 2 PASQ => 3 PASQ com IA.
    const room = this.getRoom(roomId);
    const participantIds = Array.isArray(room?.participants)
      ? room.participants.map((p: any) => p?.userId).filter(Boolean)
      : [];
    const hasAiParticipant = participantIds.some((participantId: string) => {
      if (participantId === userId) return false;
      const participant = this.getUser(participantId);
      return String((participant as any)?.accountType || (participant as any)?.account_type || 'USER').toUpperCase() === 'AI';
    });
    const billingMultiplier = hasAiParticipant ? 1.5 : 1;
    const currentCoins = Math.max(0, Number(user.pasqcoins) || 0);
    if (currentCoins <= 0) {
      throw new Error('Saldo insuficiente de Pasqcoin.');
    }

    // Consumo fracionário: cada segundo consome 1/secondsPerCoin PASQ.
    // Mantemos 6 casas decimais para a carteira e nunca deixamos saldo negativo.
    const requestedCoins = (safeSeconds / secondsPerCoin) * billingMultiplier;
    const deductedCoins = Math.min(currentCoins, requestedCoins);
    const newCoins = Math.max(0, Number((currentCoins - deductedCoins).toFixed(6)));
    const actualSecondsConsumed = Math.min(safeSeconds, (currentCoins * secondsPerCoin) / billingMultiplier);
    user.pasqcoins = newCoins;
    this.saveUser(user);

    settings.circulatingInWallets = Math.max(
      0,
      Number(((settings.circulatingInWallets || 0) - deductedCoins).toFixed(6))
    );
    this.savePasqcoinSettings(settings);

    const tx: PasqcoinTransaction = {
      id: `tx_pasq_use_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      userName: `${user.name} ${user.lastName || ''}`.trim(),
      userEmail: user.googleEmail,
      type: 'chat_usage',
      amountCoins: -Number(deductedCoins.toFixed(6)),
      chatDurationSeconds: Number(actualSecondsConsumed.toFixed(3)),
      roomId,
      timestamp: new Date().toISOString(),
      balanceAfter: newCoins,
    };
    this.addPasqcoinTransaction(tx);

    return {
      success: true,
      user,
      transaction: tx,
      deductedCoins: Number(deductedCoins.toFixed(6)),
      consumedSeconds: Number(actualSecondsConsumed.toFixed(3)),
      pasqcoinsRemaining: newCoins,
      secondsRemaining: Math.floor(newCoins * secondsPerCoin),
      secondsPerCoin,
      billingMultiplier,
      aiSurchargePercent: hasAiParticipant ? 50 : 0,
      hasMoreCoins: newCoins > 0,
    };
  }

  // --- GESTÃO DE SALDO, CRÉDITOS E TARIFAS CHAMASSO ---
  public getUserBalanceInfo(userId: string) {
    const user = this.getUser(userId);
    if (!user) return { balance: 0, rawBalance: 0, pasqcoins: 0, isExpired: false, isFreeAccess: false, hasCredits: false };

    const balance = typeof user.balance === 'number' ? user.balance : 0;
    const pasqcoins = typeof user.pasqcoins === 'number' ? user.pasqcoins : 0;
    let isExpired = false;

    if (user.rechargeExpiresAt) {
      const expDate = new Date(user.rechargeExpiresAt).getTime();
      if (Date.now() > expDate && balance > 0) {
        isExpired = true;
      }
    }

    const effectiveBalance = isExpired ? 0 : balance;
    // Acesso tarifado agora é determinado pela carteira PASQcoin; saldo em R$ é legado e não desbloqueia interação.
    const hasCredits = pasqcoins > 0 || !!user.isFreeAccess;

    return {
      balance: effectiveBalance,
      rawBalance: balance,
      pasqcoins,
      isFreeAccess: !!user.isFreeAccess,
      hasCredits,
      firstInteractionAt: user.firstInteractionAt,
      rechargeExpiresAt: user.rechargeExpiresAt,
      isExpired,
    };
  }

  public addUserBalance(
    userId: string,
    amount: number,
    transactionIdOrValidity?: string | number,
    method?: string,
    validityDays = 30
  ) {
    const user = this.getUser(userId);
    if (!user) return null;

    const currentBalance = typeof user.balance === 'number' ? user.balance : 0;
    const newBalance = Math.round((currentBalance + amount) * 100) / 100;
    user.balance = newBalance;

    const actualValidity = typeof transactionIdOrValidity === 'number' ? transactionIdOrValidity : validityDays;

    // Se já havia primeira interação registrada, estende a validade
    if (user.firstInteractionAt) {
      const expDate = new Date();
      expDate.setDate(expDate.getDate() + actualValidity);
      user.rechargeExpiresAt = expDate.toISOString();
    }

    this.saveUser(user);
    return user;
  }

  public registerFirstInteractionIfNeeded(userId: string, validityDays = 30) {
    const user = this.getUser(userId);
    if (!user) return null;

    if (!user.firstInteractionAt) {
      user.firstInteractionAt = new Date().toISOString();
      const expDate = new Date();
      expDate.setDate(expDate.getDate() + validityDays);
      user.rechargeExpiresAt = expDate.toISOString();
      this.saveUser(user);
    }
    return user;
  }

  public deductMinuteBalance(userId: string, customRate?: number) {
    const user = this.getUser(userId);
    if (!user) return { success: false, reason: 'user_not_found', balance: 0, hasBalance: false };

    const tariff = this.getTariffSettings();

    // Se a cobrança/desbloqueio geral estiver desativada ou usuário tiver acesso free:
    if (!tariff.billingEnabled || !tariff.unlockFeeEnabled || user.isFreeAccess) {
      return {
        success: true,
        deducted: 0,
        balance: user.balance || 0,
        pasqcoins: user.pasqcoins || 0,
        isFreeAccess: true,
        hasBalance: true,
      };
    }

    // Se o usuário possui saldo em Pasqcoin, desconta 1 pasqcoin por minuto de chat
    const pasqSettings = this.getPasqcoinSettings();
    if (pasqSettings.enabled && (user.pasqcoins || 0) > 0) {
      user.pasqcoins = Math.max(0, (user.pasqcoins || 0) - 1);
      this.saveUser(user);
      return {
        success: true,
        deducted: 0,
        deductedPasqcoin: 1,
        pasqcoins: user.pasqcoins,
        balance: user.balance || 0,
        usedCurrency: 'pasqcoin',
        hasBalance: true,
        isExhausted: user.pasqcoins <= 0 && (user.balance || 0) <= 0,
        firstInteractionAt: user.firstInteractionAt,
        rechargeExpiresAt: user.rechargeExpiresAt,
      };
    }

    this.registerFirstInteractionIfNeeded(userId, tariff.rechargeValidityDays);

    const balanceInfo = this.getUserBalanceInfo(userId);
    if (balanceInfo.isExpired) {
      user.balance = 0;
      this.saveUser(user);
      return { success: false, reason: 'expired', balance: 0, isExpired: true, hasBalance: false };
    }

    if (balanceInfo.balance <= 0) {
      return { success: false, reason: 'insufficient_balance', balance: 0, hasBalance: false };
    }

    const rate = typeof customRate === 'number' && !isNaN(customRate) ? customRate : tariff.ratePerMinute;
    const newBalance = Math.max(0, Math.round((balanceInfo.balance - rate) * 1000) / 1000);
    user.balance = newBalance;
    this.saveUser(user);

    return {
      success: true,
      deducted: rate,
      balance: newBalance,
      pasqcoins: user.pasqcoins || 0,
      hasBalance: newBalance > 0 || (user.pasqcoins || 0) > 0,
      isExhausted: newBalance <= 0 && (user.pasqcoins || 0) <= 0,
      firstInteractionAt: user.firstInteractionAt,
      rechargeExpiresAt: user.rechargeExpiresAt,
    };
  }

  // ==============================================================================
  // REDE SOCIAL & LANDING PAGE POR USUÁRIO
  // ==============================================================================

  public getSocialPosts(filters?: { authorId?: string; viewerId?: string }): SocialPost[] {
    const allPosts: SocialPost[] = Object.values(this.store.socialPosts || {});
    // Ordena do mais recente para o mais antigo
    let list = allPosts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    if (filters?.authorId) {
      list = list.filter((p) => p.authorId === filters.authorId);
    }

    if (filters?.viewerId) {
      const viewerId = filters.viewerId;
      list = list.filter((p) => {
        if (p.privacy === 'public') return true;
        if (p.authorId === viewerId) return true;
        // Se for friends, verifica se é amigo
        const areFriends = this.areUsersFriends(p.authorId, viewerId);
        return areFriends;
      });
    }

    return list;
  }

  public saveSocialPost(post: SocialPost): SocialPost {
    if (!this.store.socialPosts) {
      this.store.socialPosts = {};
    }
    this.store.socialPosts[post.id] = post;
    this.saveStore();
    return post;
  }

  public deleteSocialPost(postId: string, requesterId: string): boolean {
    if (!this.store.socialPosts || !this.store.socialPosts[postId]) {
      return false;
    }
    const post = this.store.socialPosts[postId];
    if (post.authorId !== requesterId && requesterId !== 'usr_rogerio_admin') {
      return false;
    }
    delete this.store.socialPosts[postId];
    this.saveStore();
    return true;
  }

  public reactToPost(postId: string, userId: string, reactionType: SocialReactionType): SocialPost | null {
    if (!this.store.socialPosts || !this.store.socialPosts[postId]) {
      return null;
    }
    const post = this.store.socialPosts[postId];
    if (!post.reactions) {
      post.reactions = {};
    }

    // Se já tinha a mesma reação, remove (toggle de reação)
    if (post.reactions[userId] === reactionType) {
      delete post.reactions[userId];
    } else {
      post.reactions[userId] = reactionType;
    }

    this.saveStore();
    return post;
  }

  public commentOnPost(postId: string, comment: SocialComment): SocialPost | null {
    if (!this.store.socialPosts || !this.store.socialPosts[postId]) {
      return null;
    }
    const post = this.store.socialPosts[postId];
    if (!post.comments) {
      post.comments = [];
    }
    post.comments.push(comment);
    this.saveStore();
    return post;
  }

  public areUsersFriends(userAId: string, userBId: string): boolean {
    if (userAId === userBId) return true;
    const friendships = Object.values(this.store.friendships || {});
    for (const f of friendships as any[]) {
      if (f.status === 'accepted') {
        if (
          (f.senderId === userAId && f.receiverId === userBId) ||
          (f.senderId === userBId && f.receiverId === userAId)
        ) {
          return true;
        }
      }
    }
    return false;
  }

  public getSocialLandingPageData(targetUserId: string, viewerId?: string): SocialLandingPageData | null {
    const user = this.getUser(targetUserId);
    if (!user) return null;

    const isOwner = viewerId === targetUserId;
    const isFriend = isOwner || (viewerId ? this.areUsersFriends(targetUserId, viewerId) : false);

    // Checagem de Perfil Restrito:
    // Se o usuário configurou perfil restrito e o visitante não for o próprio dono nem amigo aceito:
    const isProfileRestricted =
      user.profilePrivacy === 'restricted' ||
      user.profilePrivacy === 'private' ||
      user.privacySettings?.isProfileRestricted === true;

    const isRestrictedView = !isOwner && !isFriend && isProfileRestricted;

    // Busca amigos do usuário
    const allFriendships = Object.values(this.store.friendships || {}) as any[];
    const friendUserIds: string[] = [];
    for (const f of allFriendships) {
      if (f.status === 'accepted') {
        if (f.senderId === targetUserId) friendUserIds.push(f.receiverId);
        else if (f.receiverId === targetUserId) friendUserIds.push(f.senderId);
      }
    }

    const friendsList = friendUserIds
      .map((id) => this.getUser(id))
      .filter((u): u is User => !!u)
      .map((u) => ({
        id: u.id,
        name: u.name,
        lastName: u.lastName,
        avatarUrl: u.avatarUrl,
        status: u.status,
      }));

    // Posts do usuário (se restrito e não for amigo, esconde os posts privados)
    const userPosts = this.getSocialPosts({ authorId: targetUserId, viewerId });
    const visiblePosts = isRestrictedView ? [] : userPosts;

    // Fotos extraídas dos posts com imagem e foto de perfil/capa
    const photos: string[] = [];
    if (user.avatarUrl) photos.push(user.avatarUrl);
    if (user.coverUrl) photos.push(user.coverUrl);
    for (const m of (user.galleryMedia || [])) { if (m.type === 'image' && m.url) photos.push(m.url); }
    for (const p of userPosts) {
      if (p.mediaType === 'image' && p.mediaUrl) {
        photos.push(p.mediaUrl);
      }
    }

    return {
      user: {
        ...user,
        // Oculta dados sensíveis se visualizado por terceiros
        cpf: isOwner ? user.cpf : (user.cpf ? `${user.cpf.slice(0, 3)}.***.***-${user.cpf.slice(-2)}` : ''),
        twoFactorSecret: '',
        disposableCodes: isOwner ? user.disposableCodes : [],
      },
      isOwner,
      isFriend,
      isRestrictedView,
      posts: visiblePosts,
      friendsCount: friendsList.length,
      friends: isRestrictedView ? [] : friendsList,
      photos: isRestrictedView ? (user.avatarUrl ? [user.avatarUrl] : []) : Array.from(new Set(photos)),
      photosCount: (user.galleryMedia || []).filter((m: any) => m.type === 'image').length,
      totalFriends: friendsList.length,
    };
  }

  public updateUserProfile(userId: string, data: Partial<User>): User | null {
    const user = this.getUser(userId);
    if (!user) return null;

    if (data.name) user.name = data.name;
    if (data.lastName) user.lastName = data.lastName;
    if (data.bio !== undefined) user.bio = data.bio;
    if (data.avatarUrl) user.avatarUrl = data.avatarUrl;
    if (data.coverUrl) user.coverUrl = data.coverUrl;
    if (data.city !== undefined) user.city = data.city;
    if (data.hometown !== undefined) user.hometown = data.hometown;
    if (data.work !== undefined) user.work = data.work;
    if (data.education !== undefined) user.education = data.education;
    if (data.relationshipStatus !== undefined) user.relationshipStatus = data.relationshipStatus;
    if (data.profilePrivacy) user.profilePrivacy = data.profilePrivacy;
    if (data.privacySettings) {
      user.privacySettings = {
        ...(user.privacySettings || {
          whoCanSeePosts: 'public',
          whoCanAddFriend: 'everyone',
          whoCanSeeFriendsList: 'public',
          whoCanMessage: 'everyone',
          isProfileRestricted: false,
        }),
        ...data.privacySettings,
      };
    }

    this.saveUser(user);
    return user;
  }

  public updateUserPrivacy(
    userId: string,
    profilePrivacy: 'public' | 'restricted' | 'friends_only' | 'private',
    privacySettings?: any
  ): User | null {
    const user = this.getUser(userId);
    if (!user) return null;

    user.profilePrivacy = profilePrivacy;
    if (privacySettings) {
      user.privacySettings = {
        ...(user.privacySettings || {
          whoCanSeePosts: 'public',
          whoCanAddFriend: 'everyone',
          whoCanSeeFriendsList: 'public',
          whoCanMessage: 'everyone',
          isProfileRestricted: false,
        }),
        ...privacySettings,
        isProfileRestricted: profilePrivacy === 'restricted' || profilePrivacy === 'private' || privacySettings.isProfileRestricted,
      };
    } else {
      user.privacySettings = {
        ...(user.privacySettings || {
          whoCanSeePosts: 'public',
          whoCanAddFriend: 'everyone',
          whoCanSeeFriendsList: 'public',
          whoCanMessage: 'everyone',
          isProfileRestricted: false,
        }),
        isProfileRestricted: profilePrivacy === 'restricted' || profilePrivacy === 'private',
      };
    }

    this.saveUser(user);
    return user;
  }

  // --- STATUS GERAL DO BANCO E SUPABASE BACKUP EXPORT/IMPORT ---
  public getExportData() {
    return {
      store: this.store,
      totalRecords: Object.keys(this.store.users || {}).length + Object.keys(this.store.rooms || {}).length + Object.keys(this.store.settings || {}).length,
      recordsCount: {
        users: Object.keys(this.store.users || {}).length,
        rooms: Object.keys(this.store.rooms || {}).length,
        settings: Object.keys(this.store.settings || {}).length,
      },
    };
  }

  public importData(data: any) {
    if (data && data.store) {
      this.store = data.store;
      this.saveStore();
    }
    const usersCount = data?.recordsCount?.users || Object.keys(this.store.users || {}).length;
    return {
      success: true,
      usersRestored: usersCount,
      totalRecords: data?.totalRecords || 0,
    };
  }

  // ==============================================================================
  // GESTÃO FINANCEIRA (CONTAS A PAGAR, CONTAS A RECEBER E CLIENTES)
  // ==============================================================================

  public getBillsToPay(): BillToPay[] {
    if (!this.store.billsToPay) {
      this.store.billsToPay = {};
    }
    return Object.values(this.store.billsToPay).sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    );
  }

  public saveBillToPay(bill: Partial<BillToPay>): BillToPay {
    if (!this.store.billsToPay) {
      this.store.billsToPay = {};
    }
    const id = bill.id || `bill_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const existing = (this.store.billsToPay[id] || {}) as Partial<BillToPay>;
    const updated: BillToPay = {
      id,
      description: bill.description || existing.description || 'Conta sem descrição',
      category: bill.category || existing.category || 'other',
      amount: typeof bill.amount === 'number' ? bill.amount : parseFloat(bill.amount as any) || 0,
      dueDate: bill.dueDate || existing.dueDate || new Date().toISOString().split('T')[0],
      status: bill.status || existing.status || 'pending',
      paidAt: bill.status === 'paid' ? (bill.paidAt || new Date().toISOString()) : undefined,
      beneficiary: bill.beneficiary || existing.beneficiary || 'Fornecedor',
      notes: bill.notes !== undefined ? bill.notes : existing.notes,
      createdAt: existing.createdAt || new Date().toISOString(),
    };
    this.store.billsToPay[id] = updated;
    this.saveStore();
    return updated;
  }

  public deleteBillToPay(id: string): boolean {
    if (this.store.billsToPay && this.store.billsToPay[id]) {
      delete this.store.billsToPay[id];
      this.saveStore();
      return true;
    }
    return false;
  }

  public getBillsToReceive(): BillToReceive[] {
    if (!this.store.billsToReceive) {
      this.store.billsToReceive = {};
    }
    return Object.values(this.store.billsToReceive).sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    );
  }

  public saveBillToReceive(bill: Partial<BillToReceive>): BillToReceive {
    if (!this.store.billsToReceive) {
      this.store.billsToReceive = {};
    }
    const id = bill.id || `rec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const existing = (this.store.billsToReceive[id] || {}) as Partial<BillToReceive>;
    const updated: BillToReceive = {
      id,
      description: bill.description || existing.description || 'Recebimento sem descrição',
      customerName: bill.customerName || existing.customerName || 'Cliente',
      customerEmail: bill.customerEmail || existing.customerEmail || '',
      customerId: bill.customerId || existing.customerId,
      category: bill.category || existing.category || 'recharge_chamasso',
      amount: typeof bill.amount === 'number' ? bill.amount : parseFloat(bill.amount as any) || 0,
      dueDate: bill.dueDate || existing.dueDate || new Date().toISOString().split('T')[0],
      status: bill.status || existing.status || 'pending',
      receivedAt: bill.status === 'received' ? (bill.receivedAt || new Date().toISOString()) : undefined,
      method: bill.method || existing.method || 'pix',
      transactionId: bill.transactionId || existing.transactionId,
      createdAt: existing.createdAt || new Date().toISOString(),
    };
    this.store.billsToReceive[id] = updated;
    this.saveStore();
    return updated;
  }

  public deleteBillToReceive(id: string): boolean {
    if (this.store.billsToReceive && this.store.billsToReceive[id]) {
      delete this.store.billsToReceive[id];
      this.saveStore();
      return true;
    }
    return false;
  }

  public updateClientFinancialStatus(
    userId: string,
    isBlocked?: boolean,
    isFreeAccess?: boolean,
    blockReason?: string,
    balanceAdjust?: number
  ): User | null {
    const user = this.getUser(userId);
    if (!user) return null;

    if (typeof isBlocked === 'boolean') {
      user.isBlocked = isBlocked;
      if (isBlocked && blockReason) {
        user.blockReason = blockReason;
      } else if (!isBlocked) {
        user.blockReason = undefined;
      }
    }

    if (typeof isFreeAccess === 'boolean') {
      user.isFreeAccess = isFreeAccess;
    }

    if (typeof balanceAdjust === 'number' && !isNaN(balanceAdjust)) {
      user.balance = Math.max(0, balanceAdjust);
    }

    this.saveUser(user);
    return user;
  }

  public resetUserDisposableCodes(userId: string): { user: User; codes: string[]; txtContent: string } | null {
    const user = this.getUser(userId);
    if (!user) return null;

    // Gera 11 novos códigos descartáveis aleatórios de 8 dígitos
    const newCodes: string[] = [];
    for (let i = 0; i < 11; i++) {
      const code = Math.floor(10000000 + Math.random() * 90000000).toString();
      newCodes.push(code);
    }

    user.disposableCodes = newCodes.map((code) => ({ code, used: false }));
    this.saveUser(user);

    const txtContent = `=====================================================================
CHAMASSO LIVE CHAT - REDE SOCIAL & SEGURANÇA 2FA
CÓDIGOS PROVISÓRIOS / DESCARTÁVEIS DE RECUPERAÇÃO E ACESSO
=====================================================================

Usuário: ${user.name} ${user.lastName}
E-mail: ${user.googleEmail}
CPF: ${user.cpf || 'Não informado'}
Data de Emissão: ${new Date().toLocaleString('pt-BR')}
Domínio do Sistema: chamasso.pasquared.space

INSTRUÇÕES IMPORTANTES:
1. Estes 11 códigos de 8 dígitos são de uso único e emergencial.
2. Cada código pode ser utilizado apenas UMA única vez para autenticação em 2 etapas.
3. Guarde este arquivo em local seguro e confidencial. Não compartilhe com terceiros.
4. Quando restar apenas 1 código, solicite nova redefinição na administração.

LISTA DE 11 CÓDIGOS DESCARTÁVEIS VÁLIDOS:
---------------------------------------------------------------------
${newCodes.map((c, idx) => `[ Código ${String(idx + 1).padStart(2, '0')} / 11 ] : ${c}`).join('\n')}
---------------------------------------------------------------------

Suporte Técnico Chamasso: suporte@chamasso.pasquared.space
Servidor Seguro: https://chamasso.pasquared.space
=====================================================================`;

    return {
      user,
      codes: newCodes,
      txtContent,
    };
  }

  public getStatus() {
    return {
      sgbd: 'PostgreSQL 15 (compatível)',
      dbName: 'db_chamasso',
      dbUser: 'user_chamasso',
      superAdminEmail: 'roger577@ukbelol.space',
      superAdminRole: 'SUPER_ADMIN',
      superAdminPermissions: ['ALL'],
      isPgConnected,
      storageMode: isPgConnected ? 'PostgreSQL (db_chamasso) + Cache Local' : 'Armazenamento Persistente em Disco (Durable Storage)',
      persistenceFile: STORE_FILE,
      recordsCount: {
        settings: Object.keys(this.store.settings).length,
        superAdmins: Object.keys(this.store.superAdmins).length,
        users: Object.keys(this.store.users).length,
        rooms: Object.keys(this.store.rooms).length,
        relationshipLevels: Object.keys(this.store.relationshipLevels).length,
        friendships: Object.keys(this.store.friendships).length,
        auditLogs: this.store.auditLogs.length,
      },
    };
  }
}

export const dbManager = new PersistentDatabase();
