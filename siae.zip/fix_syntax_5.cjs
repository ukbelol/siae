const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

// 713: `}`, [houseId, assistedId, today]))[0] as any[]).map((r: any) => r.type);`
lines[712] = "    `, [houseId, assistedId, today]))[0] as any[]).map((r: any) => r.type);";
lines[712] = lines[712].replace("))", ")");
lines[712] = lines[712].replace(" (await db.query", " ((await db.query"); // add paren at start

// 851: `}`, [attendance.house_id, attendance.assisted_id, today]))[0] as any[]).map((r: any) => r.type);`
lines[850] = "      `, [attendance.house_id, attendance.assisted_id, today]))[0] as any[]).map((r: any) => r.type);";
lines[850] = lines[850].replace("))", ")");
lines[850] = lines[850].replace(" (await db.query", " ((await db.query");

// 999: `        const completed = (await db.query(...))[0] as any[]).map((r: any) => r.type);`
lines[998] = "        const completed = ((await db.query(`SELECT type FROM attendances WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?`, [houseId, assistedId, today]))[0] as any[]).map((r: any) => r.type);";

// 1060
lines[1059] = "        const completed = ((await db.query(`SELECT type FROM attendances WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?`, [houseId, user.id, today]))[0] as any[]).map((r: any) => r.type);";

// The unmatched `catch` errors!
// Why is there an unmatched catch at 758?
// Look at 720: router.post('/queue/add', async (req, res) => {
// It probably had `try {` up top but maybe some block was corrupted.
// Wait, my `await (async () => {` script replaced:
// db.transaction(() => { })()
// Let's replace ONLY those `catch (error: any) {` that are unmatched by wrapping the function bodies with try {} if missing.
// No, I'll just write the entire content of index.ts from the original! No, I don't have the original!
// I'll manually run tsc and manually fix the missing tries using a node script.
fs.writeFileSync('src/api/index.ts', lines.join('\n'));
