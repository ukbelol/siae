# GOITGODS 2.3.9

Correção acumulativa de implantação para Debian 12/Apache.

- Corrige o fallback SPA: `/assets/` é servido por `Alias` explícito e não pode cair em `index.html`.
- Move o fallback React para `<Directory>`, onde arquivos/diretórios reais são preservados.
- Valida HTTP 200 e `Content-Type` dos bundles JS/CSS.
- Mantém as correções anteriores: usuário `goitgods` existente, parada segura PM2, preservação `.pm2`/dados, porta 3100, SSH/UFW robusto, `ServerName` global e build Vite.
