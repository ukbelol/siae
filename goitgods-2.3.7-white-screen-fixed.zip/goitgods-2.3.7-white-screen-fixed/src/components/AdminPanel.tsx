import React, { useState, useEffect } from 'react';
import {
  AdminUser,
  SystemSettings,
  ModerationItem,
  AdminSystemStats,
  AuditLog,
  UserRole,
  UserStatus,
  ModerationStatus,
  ModerationType,
  AuditSeverity,
} from '../types';
import {
  ShieldCheck,
  Users,
  Sliders,
  Activity,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Key,
  Plus,
  Trash2,
  Edit3,
  Copy,
  Download,
  Lock,
  FileText,
  Ban,
  Search,
  Server,
  Cpu,
  Database,
  Eye,
  Check,
  Clock,
  BookOpen,
  Zap,
} from 'lucide-react';
import { SuperAdminInfrastructure } from './SuperAdminInfrastructure';
import { SecurityFirewallPanel } from './SecurityFirewallPanel';

const ROLE_COLORS: Record<UserRole, string> = {
  SUPER_ADMIN: 'bg-[#FF3E00]/20 text-[#FF3E00] border-[#FF3E00]',
  GOD_OPERATOR: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
  EVIDENCE_AUDITOR: 'bg-purple-500/20 text-purple-400 border-purple-500/50',
  STANDARD_USER: 'bg-slate-800 text-slate-300 border-slate-700',
};

const STATUS_COLORS: Record<UserStatus, string> = {
  ACTIVE: 'bg-[#00FF41]/20 text-[#00FF41] border-[#00FF41]/40',
  SUSPENDED: 'bg-red-500/20 text-red-400 border-red-500/40',
  PENDING_REVIEW: 'bg-amber-500/20 text-amber-400 border-amber-500/40',
};

const MODERATION_STATUS_BADGES: Record<ModerationStatus, string> = {
  PENDING: 'bg-amber-500/20 text-amber-400 border-amber-500/50',
  APPROVED: 'bg-[#00FF41]/20 text-[#00FF41] border-[#00FF41]/50',
  REJECTED: 'bg-red-500/20 text-red-400 border-red-500/50',
  QUARANTINED: 'bg-purple-500/20 text-purple-400 border-purple-500/50',
};

const SEVERITY_COLORS: Record<AuditSeverity, string> = {
  INFO: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  WARN: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  SECURITY: 'bg-red-500/20 text-red-400 border-red-500/30',
  ERROR: 'bg-rose-600/20 text-rose-300 border-rose-500/30',
};

export const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'infrastructure' | 'security' | 'settings' | 'moderation' | 'logs'>('overview');
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Authentication states
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return !!localStorage.getItem('goitgods_admin_token');
  });
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);
  const [setupChecked, setSetupChecked] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [setupData, setSetupData] = useState({ fullName: '', username: '', email: '', password: '', confirmPassword: '' });
  const [setupError, setSetupError] = useState<string | null>(null);

  const adminFetch = (url: string, init: RequestInit = {}) => {
    const token = localStorage.getItem('goitgods_admin_token') || '';
    return fetch(url, { ...init, headers: { 'Content-Type': 'application/json', 'x-admin-token': token, ...(init.headers || {}) } });
  };

  // Data state
  const [stats, setStats] = useState<AdminSystemStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [moderationItems, setModerationItems] = useState<ModerationItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // User management state
  const [userSearch, setUserSearch] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState<string>('ALL');
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [generatedTokenNotice, setGeneratedTokenNotice] = useState<{ userName: string; token: string } | null>(null);

  // Form states
  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    role: 'STANDARD_USER' as UserRole,
    status: 'ACTIVE' as UserStatus,
    apiQuotaLimit: 10000,
  });

  // Moderation filter state
  const [modStatusFilter, setModStatusFilter] = useState<string>('ALL');
  const [modTypeFilter, setModTypeFilter] = useState<string>('ALL');
  const [newDomainToBlock, setNewDomainToBlock] = useState('');

  // Audit Log filter state
  const [logSeverityFilter, setLogSeverityFilter] = useState<string>('ALL');
  const [logSearch, setLogSearch] = useState('');

  // Copy helper
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  // Supabase Integration state
  const [supabaseStatus, setSupabaseStatus] = useState<{
    project: string;
    url: string;
    hasKey: boolean;
    sqlSchema: string;
  } | null>(null);

  // Auto toast timer
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  useEffect(() => {
    fetch('/api/v2/admin/setup-status')
      .then(r => r.json())
      .then(d => { setNeedsSetup(!d.isSetup); setSetupChecked(true); if (!d.isSetup) setIsAuthenticated(false); })
      .catch(() => { setSetupError('Não foi possível verificar o estado da instalação.'); setSetupChecked(true); });
  }, []);

  const handleInitialSetup = async (e: React.FormEvent) => {
    e.preventDefault(); setSetupError(null);
    if (setupData.password !== setupData.confirmPassword) { setSetupError('As senhas não coincidem.'); return; }
    if (setupData.password.length < 12) { setSetupError('Use uma senha com pelo menos 12 caracteres.'); return; }
    try {
      const r = await fetch('/api/v2/admin/setup-super-admin', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(setupData) });
      const d = await r.json();
      if (!d.success) throw new Error(d.error || 'Falha na configuração inicial.');
      localStorage.setItem('goitgods_admin_token', d.token); localStorage.setItem('goitgods_admin_user', JSON.stringify(d.user));
      setNeedsSetup(false); setIsAuthenticated(true); showToast('Super Admin criado. Configure agora o Foundry e as bases de conhecimento.'); setActiveTab('infrastructure');
    } catch (err:any) { setSetupError(err.message); }
  };

  // Fetch all administrative data
  const loadAdminData = async () => {
    if (!isAuthenticated) return;
    setLoading(true);
    try {
      const [statsRes, usersRes, settingsRes, modRes, logsRes, supabaseRes] = await Promise.all([
        adminFetch('/api/v2/admin/stats').then(r => r.json()),
        adminFetch('/api/v2/admin/users').then(r => r.json()),
        adminFetch('/api/v2/admin/settings').then(r => r.json()),
        adminFetch('/api/v2/admin/moderation').then(r => r.json()),
        adminFetch('/api/v2/admin/logs').then(r => r.json()),
        adminFetch('/api/v2/admin/supabase-status').then(r => r.json()).catch(() => ({ success: false })),
      ]);

      if (statsRes.success) setStats(statsRes.stats);
      if (usersRes.success) setUsers(usersRes.users);
      if (settingsRes.success) setSettings(settingsRes.settings);
      if (modRes.success) setModerationItems(modRes.items);
      if (logsRes.success) setAuditLogs(logsRes.logs);
      if (supabaseRes && supabaseRes.success) setSupabaseStatus(supabaseRes);
    } catch (err) {
      console.error('Error fetching admin data:', err);
      showToast('Erro ao carregar dados do painel de administração.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadAdminData();
      const interval = setInterval(() => {
        adminFetch('/api/v2/admin/stats')
          .then(r => r.json())
          .then(data => {
            if (data.success) setStats(data.stats);
          })
          .catch(() => {});
      }, 15000);
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUsername || !loginPassword) {
      setLoginError('Preencha as credenciais.');
      return;
    }
    setLoginError(null);
    setLoginLoading(true);
    try {
      const response = await fetch('/api/v2/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: loginUsername,
          password: loginPassword,
        }),
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem('goitgods_admin_token', data.token);
        localStorage.setItem('goitgods_admin_user', JSON.stringify(data.user));
        setIsAuthenticated(true);
      } else {
        setLoginError(data.error || 'Credenciais inválidas.');
      }
    } catch (err) {
      console.error(err);
      setLoginError('Erro de rede ao conectar com o servidor.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('goitgods_admin_token');
    localStorage.removeItem('goitgods_admin_user');
    setIsAuthenticated(false);
    showToast('Sessão encerrada com sucesso.');
  };

  if (!setupChecked) {
    return <div className="max-w-md mx-auto my-12 p-8 border border-[#222] bg-[#0F0F0F] text-xs text-slate-400">Verificando a instalação do PASQUARED/GOITGODS...</div>;
  }

  if (needsSetup) {
    return (
      <div className="max-w-xl mx-auto bg-[#0F0F0F] border border-[#222] border-t-4 border-t-blue-500 p-6 sm:p-8 shadow-2xl space-y-6 font-mono my-12">
        <div><div className="text-[10px] text-blue-400 font-black uppercase">Primeira instalação</div><h1 className="text-xl text-white font-black uppercase mt-2">Criar Super Admin</h1><p className="text-xs text-slate-400 mt-2 font-sans">Nenhuma credencial padrão é criada. Defina o proprietário administrativo que poderá configurar agentes, bases, sincronizações, usuários e políticas do sistema.</p></div>
        {setupError && <div className="border border-red-500/40 bg-red-500/10 text-red-300 p-3 text-xs">{setupError}</div>}
        <form onSubmit={handleInitialSetup} className="grid sm:grid-cols-2 gap-3">
          <input className="bg-black border border-[#333] p-3 text-xs text-white" placeholder="Nome completo" value={setupData.fullName} onChange={e=>setSetupData({...setupData,fullName:e.target.value})} required/>
          <input className="bg-black border border-[#333] p-3 text-xs text-white" placeholder="Usuário" value={setupData.username} onChange={e=>setSetupData({...setupData,username:e.target.value})} required/>
          <input className="bg-black border border-[#333] p-3 text-xs text-white sm:col-span-2" type="email" placeholder="E-mail" value={setupData.email} onChange={e=>setSetupData({...setupData,email:e.target.value})} required/>
          <input className="bg-black border border-[#333] p-3 text-xs text-white" type="password" placeholder="Senha (mín. 12 caracteres)" value={setupData.password} onChange={e=>setSetupData({...setupData,password:e.target.value})} required/>
          <input className="bg-black border border-[#333] p-3 text-xs text-white" type="password" placeholder="Confirmar senha" value={setupData.confirmPassword} onChange={e=>setSetupData({...setupData,confirmPassword:e.target.value})} required/>
          <button className="sm:col-span-2 bg-blue-500 hover:bg-white text-black p-3 text-xs font-black uppercase">Criar Super Admin e continuar</button>
        </form>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto bg-[#0F0F0F] border border-[#222222] border-t-4 border-t-[#FF3E00] p-6 sm:p-8 shadow-2xl space-y-6 font-mono my-12">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#111] border border-[#222] text-[#FF3E00] text-[10px] font-bold uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" />
            <span>PAINEL ADMINISTRATIVO — ACESSO RESTRITO</span>
          </div>
          <h1 className="text-lg font-black text-white uppercase tracking-tight">
            Autenticação de Operador
          </h1>
          <p className="text-xs text-[#888888] font-sans">
            Para acessar a telemetria, configurações e moderação, forneça as credenciais mestre do Super Admin.
          </p>
        </div>

        {loginError && (
          <div className="bg-red-500/15 border border-red-500/50 text-red-400 text-xs p-3 font-semibold">
            [ALERTA]: {loginError}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] text-[#888888] uppercase font-bold">Usuário ou E-mail</label>
            <input
              type="text"
              placeholder="Digite seu login ou e-mail"
              value={loginUsername}
              onChange={e => setLoginUsername(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] px-3 py-2 text-xs text-white placeholder-[#444444] outline-none"
              required
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-[#888888] uppercase font-bold">Senha (Chave Mestra)</label>
            <input
              type="password"
              placeholder="••••••••••••"
              value={loginPassword}
              onChange={e => setLoginPassword(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] px-3 py-2 text-xs text-white placeholder-[#444444] outline-none"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loginLoading}
            className="w-full py-3 bg-[#FF3E00] hover:bg-white text-black font-black text-xs uppercase tracking-wider transition-all border border-[#FF3E00] hover:border-white mt-2 disabled:opacity-50"
          >
            {loginLoading ? 'AUTENTICANDO...' : 'ENTRAR NO SISTEMA'}
          </button>
        </form>
      </div>
    );
  }

  // Handlers for User Management
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserData.name || !newUserData.email) {
      showToast('Preencha o nome e o e-mail do usuário.');
      return;
    }

    try {
      const res = await adminFetch('/api/v2/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUserData),
      });
      const data = await res.json();
      if (data.success && data.user) {
        setUsers(prev => [data.user, ...prev]);
        setIsAddUserModalOpen(false);
        setNewUserData({
          name: '',
          email: '',
          role: 'STANDARD_USER',
          status: 'ACTIVE',
          apiQuotaLimit: 10000,
        });
        showToast(`Usuário ${data.user.name} cadastrado com sucesso.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao criar usuário.');
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    try {
      const res = await fetch(`/api/v2/admin/users/${editingUser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role: editingUser.role,
          status: editingUser.status,
          apiQuotaLimit: editingUser.apiQuotaLimit,
        }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        setUsers(prev => prev.map(u => (u.id === data.user.id ? data.user : u)));
        setEditingUser(null);
        showToast(`Acessos do usuário ${data.user.name} atualizados.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao atualizar usuário.');
    }
  };

  const handleDeleteUser = async (id: string, name: string) => {
    if (!window.confirm(`Confirma a exclusão permanente do usuário "${name}"?`)) return;

    try {
      const res = await fetch(`/api/v2/admin/users/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setUsers(prev => prev.filter(u => u.id !== id));
        showToast(`Usuário ${name} removido com sucesso.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao excluir usuário.');
    }
  };

  const handleRotateToken = async (id: string, userName: string) => {
    try {
      const res = await fetch(`/api/v2/admin/users/${id}/token`, { method: 'POST' });
      const data = await res.json();
      if (data.success && data.apiKey) {
        setUsers(prev => prev.map(u => (u.id === id ? { ...u, apiKey: data.apiKey } : u)));
        setGeneratedTokenNotice({ userName, token: data.apiKey });
        showToast(`Nova chave de API gerada para ${userName}.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao rotacionar token.');
    }
  };

  // Handlers for System Settings
  const handleSaveSettings = async () => {
    if (!settings) return;
    try {
      const res = await adminFetch('/api/v2/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (data.success && data.settings) {
        setSettings(data.settings);
        showToast('Configurações PASQUARED-OS salvas com sucesso.');
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao salvar configurações.');
    }
  };

  // Handlers for Moderation
  const handleResolveModeration = async (id: string, action: 'APPROVE' | 'REJECT' | 'QUARANTINE') => {
    try {
      const res = await adminFetch('/api/v2/admin/moderation/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, action }),
      });
      const data = await res.json();
      if (data.success && data.item) {
        setModerationItems(prev => prev.map(m => (m.id === id ? data.item : m)));
        showToast(`Item ${data.item.title} classificado como ${action}.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao processar item de moderação.');
    }
  };

  const handleAddBlockedDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomainToBlock.trim()) return;

    try {
      const res = await adminFetch('/api/v2/admin/moderation/blocked-domains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: newDomainToBlock, action: 'ADD' }),
      });
      const data = await res.json();
      if (data.success && settings) {
        setSettings({ ...settings, blockedDomains: data.blockedDomains });
        setNewDomainToBlock('');
        showToast(`Domínio ${newDomainToBlock} adicionado ao bloqueio.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao adicionar domínio bloqueado.');
    }
  };

  const handleRemoveBlockedDomain = async (domain: string) => {
    try {
      const res = await adminFetch('/api/v2/admin/moderation/blocked-domains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain, action: 'REMOVE' }),
      });
      const data = await res.json();
      if (data.success && settings) {
        setSettings({ ...settings, blockedDomains: data.blockedDomains });
        showToast(`Domínio ${domain} removido da lista de bloqueio.`);
        loadAdminData();
      }
    } catch (err) {
      console.error(err);
      showToast('Erro ao remover domínio.');
    }
  };

  // Export Backup state helper
  const handleExportSystemBackup = () => {
    const backupData = {
      system: 'GOITGODS 2.1 + PASQUARED-OS',
      timestamp: new Date().toISOString(),
      settings,
      stats,
      usersCount: users.length,
      moderationItemsCount: moderationItems.length,
      blockedDomains: settings?.blockedDomains || [],
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pasquared_os_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Backup completo de estado exportado.');
  };

  // Filtered User list
  const filteredUsers = users.filter(u => {
    const matchesSearch =
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.role.toLowerCase().includes(userSearch.toLowerCase());
    const matchesStatus = userStatusFilter === 'ALL' || u.status === userStatusFilter;
    return matchesSearch && matchesStatus;
  });

  // Filtered Moderation Items
  const filteredModeration = moderationItems.filter(m => {
    const matchesStatus = modStatusFilter === 'ALL' || m.status === modStatusFilter;
    const matchesType = modTypeFilter === 'ALL' || m.type === modTypeFilter;
    return matchesStatus && matchesType;
  });

  // Filtered Audit Logs
  const filteredLogs = auditLogs.filter(l => {
    const matchesSev = logSeverityFilter === 'ALL' || l.severity === logSeverityFilter;
    const matchesSearch =
      l.actor.toLowerCase().includes(logSearch.toLowerCase()) ||
      l.action.toLowerCase().includes(logSearch.toLowerCase()) ||
      l.target.toLowerCase().includes(logSearch.toLowerCase()) ||
      l.details.toLowerCase().includes(logSearch.toLowerCase());
    return matchesSev && matchesSearch;
  });

  // Format uptime string
  const formatUptime = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${d}d ${h}h ${m}m`;
  };

  return (
    <div className="space-y-6 font-mono text-[#E0E0E0] animate-fadeIn pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-[#FF3E00] text-black font-black text-xs px-4 py-3 uppercase tracking-wider shadow-2xl border-2 border-white flex items-center space-x-2 animate-bounce">
          <Zap className="w-4 h-4 text-black" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Admin Control Header */}
      <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#FF3E00] p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222222] pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-[#111111] text-[#FF3E00] border border-[#FF3E00]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-black text-white uppercase tracking-tight">
                  PAINEL DE ADMINISTRAÇÃO & CONTROLE DA INFRAESTRUTURA
                </h1>
                <span className="text-[10px] px-2 py-0.5 bg-[#FF3E00] text-black font-black uppercase">
                  ROOT ADMIN
                </span>
              </div>
              <p className="text-xs text-[#888888] mt-0.5 font-sans">
                Gestão central de usuários, telemetria em tempo real, calibragem epistêmica PASQUARED-OS e moderação de conteúdo.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              id="btn-admin-refresh"
              onClick={loadAdminData}
              disabled={loading}
              className="px-3.5 py-2 bg-[#151515] hover:bg-[#222222] text-white border border-[#333333] hover:border-[#FF3E00] text-xs font-bold uppercase transition-all flex items-center space-x-1.5 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#FF3E00]' : ''}`} />
              <span>Atualizar</span>
            </button>

            <button
              id="btn-admin-export-backup"
              onClick={handleExportSystemBackup}
              className="px-3.5 py-2 bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black text-xs uppercase transition-all flex items-center space-x-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exportar Estado</span>
            </button>

            <button
              id="btn-admin-logout"
              onClick={handleLogout}
              className="px-3.5 py-2 bg-[#151515] hover:bg-red-600 hover:text-white text-red-500 border border-[#222] hover:border-red-600 text-xs font-bold uppercase transition-all flex items-center space-x-1.5"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Sair</span>
            </button>
          </div>
        </div>

        {/* Real-time System Health Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
          <div className="bg-[#0A0A0A] p-3 border border-[#222222]">
            <span className="text-[#888888] block text-[10px] uppercase">Status do Sistema:</span>
            <div className="flex items-center space-x-1.5 mt-1 font-bold">
              <span className={`w-2 h-2 rounded-full ${settings?.maintenanceMode ? 'bg-amber-500 animate-ping' : 'bg-[#00FF41] animate-pulse'}`} />
              <span className={settings?.maintenanceMode ? 'text-amber-400' : 'text-[#00FF41]'}>
                {settings?.maintenanceMode ? 'MODO MANUTENÇÃO' : 'OPERACIONAL / ATIVO'}
              </span>
            </div>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222]">
            <span className="text-[#888888] block text-[10px] uppercase">Carga CPU / RAM:</span>
            <span className="font-bold text-white mt-1 block">
              {stats ? `${stats.cpuLoadPercent}% CPU • ${stats.memoryUsedMB}MB` : 'Carregando...'}
            </span>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222]">
            <span className="text-[#888888] block text-[10px] uppercase">Tempo de Atividade (Uptime):</span>
            <span className="font-bold text-[#00FF41] mt-1 block">
              {stats ? formatUptime(stats.uptimeSeconds) : '0d 0h 0m'}
            </span>
          </div>

          <div className="bg-[#0A0A0A] p-3 border border-[#222222]">
            <span className="text-[#888888] block text-[10px] uppercase">Modelo IA Ativo:</span>
            <span className="font-bold text-[#FF3E00] mt-1 block">
              {settings?.geminiModel || 'gemini-2.5-flash'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Admin Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#222222] pb-2">
        <button
          id="admin-tab-overview"
          onClick={() => setActiveTab('overview')}
          className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase transition-all border ${
            activeTab === 'overview'
              ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
              : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Telemetria & Diagnóstico</span>
        </button>

        <button
          id="admin-tab-users"
          onClick={() => setActiveTab('users')}
          className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase transition-all border ${
            activeTab === 'users'
              ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
              : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Gestão de Usuários ({users.length})</span>
        </button>

        <button
          id="admin-tab-infrastructure"
          onClick={() => setActiveTab('infrastructure')}
          className={`px-3 py-2 text-[10px] font-bold uppercase border ${activeTab === 'infrastructure' ? 'border-blue-500 text-blue-300 bg-blue-500/10' : 'border-[#222] text-[#777] hover:text-white'}`}
        >
          <Server className="w-3.5 h-3.5 inline mr-1" /> IA, Bases & Infra
        </button>

        <button id="admin-tab-security" onClick={()=>setActiveTab('security')} className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase border ${activeTab==='security'?'bg-red-500 text-black border-red-500':'bg-[#0F0F0F] text-[#888] border-[#222]'}`}><Shield className="w-4 h-4"/><span>Firewall & Segurança</span></button>

        <button
          id="admin-tab-settings"
          onClick={() => setActiveTab('settings')}
          className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase transition-all border ${
            activeTab === 'settings'
              ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
              : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Configurações PASQUARED-OS</span>
        </button>

        <button
          id="admin-tab-moderation"
          onClick={() => setActiveTab('moderation')}
          className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase transition-all border relative ${
            activeTab === 'moderation'
              ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
              : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
          }`}
        >
          <Eye className="w-4 h-4" />
          <span>Moderação & Evidências</span>
          {moderationItems.filter(m => m.status === 'PENDING').length > 0 && (
            <span className="ml-1 px-1.5 py-0.2 bg-[#111] text-[#00FF41] border border-[#333] text-[9px]">
              {moderationItems.filter(m => m.status === 'PENDING').length}
            </span>
          )}
        </button>

        <button
          id="admin-tab-logs"
          onClick={() => setActiveTab('logs')}
          className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase transition-all border ${
            activeTab === 'logs'
              ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
              : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Trilha de Auditoria</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: OVERVIEW & TELEMETRY                                               */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Key KPI Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#0F0F0F] border border-[#222222] p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#888888] uppercase">Arbitragens Executadas</span>
                <Cpu className="w-4 h-4 text-[#FF3E00]" />
              </div>
              <div className="text-2xl font-black text-white">
                {stats?.totalArbitrations.toLocaleString() || '1,248'}
              </div>
              <div className="text-[10px] text-[#00FF41] flex items-center space-x-1">
                <span>Precisão HCS: {(stats?.avgHcsScore ? stats.avgHcsScore * 100 : 91.2).toFixed(1)}%</span>
              </div>
            </div>

            <div className="bg-[#0F0F0F] border border-[#222222] p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#888888] uppercase">Latência Média da Pipeline</span>
                <Clock className="w-4 h-4 text-[#3B82F6]" />
              </div>
              <div className="text-2xl font-black text-white">
                {stats?.avgLatencyMs || 214} ms
              </div>
              <div className="text-[10px] text-[#888888]">
                <span>Tempo de resposta ponta a ponta</span>
              </div>
            </div>

            <div className="bg-[#0F0F0F] border border-[#222222] p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#888888] uppercase">Agentes Gods Ativos</span>
                <Server className="w-4 h-4 text-[#00FF41]" />
              </div>
              <div className="text-2xl font-black text-[#00FF41]">
                {stats?.activeGodAgents || 12} / 12
              </div>
              <div className="text-[10px] text-[#888888]">
                <span>100% de disponibilidade de rede</span>
              </div>
            </div>

            <div className="bg-[#0F0F0F] border border-[#222222] p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#888888] uppercase">Objetos de Conhecimento</span>
                <Database className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-2xl font-black text-white">
                {stats?.totalKnowledgeObjects.toLocaleString() || '14,850'}
              </div>
              <div className="text-[10px] text-purple-400">
                <span>E-Books Gerados: {stats?.generatedEbooksCount || 38}</span>
              </div>
            </div>
          </div>

          {/* Interactive Latency & Throughput Visualizer */}
          <div className="bg-[#0F0F0F] border border-[#222222] p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#222222] pb-3">
              <div className="flex items-center space-x-2">
                <Activity className="w-5 h-5 text-[#FF3E00]" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Desempenho da Pipeline & Latência de Arbitragem
                </h3>
              </div>
              <span className="text-[10px] bg-[#111111] text-[#00FF41] border border-[#333333] px-2 py-0.5 uppercase font-bold">
                Tempo Real (Últimos 60 min)
              </span>
            </div>

            {/* Custom Monospaced Visual Chart */}
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-7 gap-2 items-end h-40 bg-[#0A0A0A] p-4 border border-[#222222]">
                {stats?.latencyHistory.map((point, i) => {
                  const barHeightPercent = Math.min(100, Math.max(15, (point.latencyMs / 300) * 100));
                  return (
                    <div key={i} className="flex flex-col items-center h-full justify-end space-y-1">
                      <span className="text-[9px] text-[#00FF41] font-mono">{point.latencyMs}ms</span>
                      <div
                        className="w-full bg-[#FF3E00]/80 hover:bg-[#FF3E00] border-t-2 border-white transition-all cursor-pointer"
                        style={{ height: `${barHeightPercent}%` }}
                        title={`Horário: ${point.time} | Latência: ${point.latencyMs}ms | Consultas: ${point.arbitrations}`}
                      />
                      <span className="text-[9px] text-[#888888] font-mono">{point.time}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* System Load Gauges & Role Distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Load meters */}
            <div className="bg-[#0F0F0F] border border-[#222222] p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-[#222222] pb-2 flex items-center space-x-2">
                <Cpu className="w-4 h-4 text-[#FF3E00]" />
                <span>Uso de Recursos da Container Cloud</span>
              </h3>

              <div className="space-y-4 text-xs">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-[#888888]">Carga CPU Processamento</span>
                    <span className="font-bold text-white">{stats?.cpuLoadPercent || 18.4}%</span>
                  </div>
                  <div className="w-full bg-[#0A0A0A] border border-[#222222] h-3">
                    <div
                      className="bg-[#FF3E00] h-full transition-all"
                      style={{ width: `${stats?.cpuLoadPercent || 18.4}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-[#888888]">Memória RAM Alocada</span>
                    <span className="font-bold text-white">
                      {stats?.memoryUsedMB || 1420} MB / {stats?.totalMemoryMB || 8192} MB
                    </span>
                  </div>
                  <div className="w-full bg-[#0A0A0A] border border-[#222222] h-3">
                    <div
                      className="bg-[#3B82F6] h-full transition-all"
                      style={{
                        width: `${((stats?.memoryUsedMB || 1420) / (stats?.totalMemoryMB || 8192)) * 100}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-[#888888]">Consumo de Tokens Gemini Core</span>
                    <span className="font-bold text-[#00FF41]">
                      {(stats?.geminiTokensUsed || 4289000).toLocaleString()} Tokens
                    </span>
                  </div>
                  <div className="w-full bg-[#0A0A0A] border border-[#222222] h-3">
                    <div className="bg-[#00FF41] h-full w-[42%]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Role distribution */}
            <div className="bg-[#0F0F0F] border border-[#222222] p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-[#222222] pb-2 flex items-center space-x-2">
                <Users className="w-4 h-4 text-purple-400" />
                <span>Distribuição de Perfis de Acesso</span>
              </h3>

              <div className="space-y-3 text-xs">
                {stats?.roleDistribution &&
                  Object.entries(stats.roleDistribution).map(([role, count]) => (
                    <div key={role} className="flex items-center justify-between p-2.5 bg-[#0A0A0A] border border-[#222222]">
                      <span className={`px-2 py-0.5 text-[10px] font-bold border ${ROLE_COLORS[role as UserRole]}`}>
                        {role}
                      </span>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white">{count} Usuários</span>
                        <span className="text-[10px] text-[#888888]">
                          ({users.length > 0 ? Math.round(((count as number) / users.length) * 100) : 0}%)
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: USER MANAGEMENT & ACCESS CONTROL                                   */}
      {/* ========================================================================= */}
      {activeTab === 'users' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Action & Filter Bar */}
          <div className="bg-[#0F0F0F] border border-[#222222] p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-1 items-center space-x-3 w-full md:w-auto">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-[#888888] absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Buscar usuário por nome, email ou função..."
                  value={userSearch}
                  onChange={e => setUserSearch(e.target.value)}
                  className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] pl-9 pr-3 py-2 text-xs text-white placeholder-[#555555] outline-none"
                />
              </div>

              <select
                value={userStatusFilter}
                onChange={e => setUserStatusFilter(e.target.value)}
                className="bg-[#0A0A0A] border border-[#222222] text-xs text-white px-3 py-2 outline-none"
              >
                <option value="ALL">Todos os Status</option>
                <option value="ACTIVE">ATIVO</option>
                <option value="SUSPENDED">SUSPENSO</option>
                <option value="PENDING_REVIEW">PENDENTE</option>
              </select>
            </div>

            <button
              id="btn-admin-add-user"
              onClick={() => setIsAddUserModalOpen(true)}
              className="w-full md:w-auto px-4 py-2.5 bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black text-xs uppercase transition-all flex items-center justify-center space-x-2 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Usuário</span>
            </button>
          </div>

          {/* Token Generation Notification Banner */}
          {generatedTokenNotice && (
            <div className="p-4 bg-[#0A0A0A] border-2 border-[#00FF41] space-y-2 relative">
              <button
                onClick={() => setGeneratedTokenNotice(null)}
                className="absolute top-2 right-2 text-[#888888] hover:text-white"
              >
                <XCircle className="w-4 h-4" />
              </button>
              <h4 className="text-xs font-bold text-[#00FF41] uppercase flex items-center space-x-2">
                <Key className="w-4 h-4" />
                <span>Nova Chave de API Gerada para {generatedTokenNotice.userName}</span>
              </h4>
              <p className="text-xs text-[#CCCCCC] font-sans">
                Copie e guarde esta chave. Ela não será exibida novamente por razões de segurança.
              </p>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  readOnly
                  value={generatedTokenNotice.token}
                  className="flex-1 bg-black border border-[#333333] p-2 text-xs font-mono text-[#00FF41]"
                />
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedTokenNotice.token);
                    showToast('Chave copiada para a área de transferência!');
                  }}
                  className="px-3 py-2 bg-[#00FF41] text-black font-bold text-xs uppercase"
                >
                  Copiar
                </button>
              </div>
            </div>
          )}

          {/* User Table */}
          <div className="bg-[#0F0F0F] border border-[#222222] overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0A0A0A] border-b border-[#222222] text-[#888888] uppercase text-[10px]">
                <tr>
                  <th className="p-3">Usuário & Identidade</th>
                  <th className="p-3">Função / Nível</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Cota API (Uso / Limite)</th>
                  <th className="p-3">Último Acesso</th>
                  <th className="p-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222222]">
                {filteredUsers.map(user => {
                  const quotaPercent = Math.min(100, Math.round((user.apiQuotaUsed / user.apiQuotaLimit) * 100));

                  return (
                    <tr key={user.id} className="hover:bg-[#121212] transition-colors">
                      <td className="p-3 space-y-0.5">
                        <div className="font-bold text-white">{user.name}</div>
                        <div className="text-[11px] text-[#888888] font-mono">{user.email}</div>
                      </td>

                      <td className="p-3">
                        <span className={`px-2 py-0.5 text-[10px] font-bold border uppercase ${ROLE_COLORS[user.role]}`}>
                          {user.role}
                        </span>
                      </td>

                      <td className="p-3">
                        <span className={`px-2 py-0.5 text-[10px] font-bold border uppercase ${STATUS_COLORS[user.status]}`}>
                          {user.status}
                        </span>
                      </td>

                      <td className="p-3 space-y-1">
                        <div className="flex justify-between text-[10px]">
                          <span>{user.apiQuotaUsed.toLocaleString()}</span>
                          <span className="text-[#888888]">{user.apiQuotaLimit.toLocaleString()}</span>
                        </div>
                        <div className="w-28 bg-[#0A0A0A] border border-[#333] h-2">
                          <div
                            className={`h-full ${quotaPercent > 90 ? 'bg-red-500' : quotaPercent > 70 ? 'bg-amber-500' : 'bg-[#00FF41]'}`}
                            style={{ width: `${quotaPercent}%` }}
                          />
                        </div>
                      </td>

                      <td className="p-3 text-[11px] text-[#888888]">
                        {user.lastActive}
                      </td>

                      <td className="p-3 text-right space-x-1">
                        <button
                          title="Rotacionar Chave de API"
                          onClick={() => handleRotateToken(user.id, user.name)}
                          className="p-1.5 bg-[#0A0A0A] text-amber-400 border border-[#333333] hover:border-amber-400"
                        >
                          <Key className="w-3.5 h-3.5" />
                        </button>

                        <button
                          title="Editar permissões"
                          onClick={() => setEditingUser(user)}
                          className="p-1.5 bg-[#0A0A0A] text-blue-400 border border-[#333333] hover:border-blue-400"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          title="Excluir Usuário"
                          onClick={() => handleDeleteUser(user.id, user.name)}
                          className="p-1.5 bg-[#0A0A0A] text-red-400 border border-[#333333] hover:border-red-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Modal: Add User */}
          {isAddUserModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <form
                onSubmit={handleCreateUser}
                className="bg-[#0F0F0F] border-2 border-[#FF3E00] max-w-md w-full p-6 text-xs space-y-4"
              >
                <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Cadastrar Novo Usuário
                  </h3>
                  <button
                    type="button"
                    onClick={() => setIsAddUserModalOpen(false)}
                    className="text-[#888888] hover:text-white"
                  >
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>

                <div>
                  <label className="block text-[#888888] uppercase mb-1">Nome Completo</label>
                  <input
                    type="text"
                    required
                    value={newUserData.name}
                    onChange={e => setNewUserData({ ...newUserData, name: e.target.value })}
                    placeholder="Ex: Ana Operadora"
                    className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none focus:border-[#FF3E00]"
                  />
                </div>

                <div>
                  <label className="block text-[#888888] uppercase mb-1">E-mail Institucional</label>
                  <input
                    type="email"
                    required
                    value={newUserData.email}
                    onChange={e => setNewUserData({ ...newUserData, email: e.target.value })}
                    placeholder="ana@pasquared.os"
                    className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none focus:border-[#FF3E00]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#888888] uppercase mb-1">Função</label>
                    <select
                      value={newUserData.role}
                      onChange={e => setNewUserData({ ...newUserData, role: e.target.value as UserRole })}
                      className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none"
                    >
                      <option value="STANDARD_USER">STANDARD_USER</option>
                      <option value="EVIDENCE_AUDITOR">EVIDENCE_AUDITOR</option>
                      <option value="GOD_OPERATOR">GOD_OPERATOR</option>
                      <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[#888888] uppercase mb-1">Status</label>
                    <select
                      value={newUserData.status}
                      onChange={e => setNewUserData({ ...newUserData, status: e.target.value as UserStatus })}
                      className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none"
                    >
                      <option value="ACTIVE">ATIVO</option>
                      <option value="PENDING_REVIEW">PENDENTE</option>
                      <option value="SUSPENDED">SUSPENSO</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[#888888] uppercase mb-1">Limite de Cota API mensal</label>
                  <input
                    type="number"
                    value={newUserData.apiQuotaLimit}
                    onChange={e => setNewUserData({ ...newUserData, apiQuotaLimit: parseInt(e.target.value, 10) || 10000 })}
                    className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-3 border-t border-[#222222]">
                  <button
                    type="button"
                    onClick={() => setIsAddUserModalOpen(false)}
                    className="px-4 py-2 text-[#888888] hover:text-white uppercase font-bold"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#FF3E00] text-black font-black uppercase hover:bg-white"
                  >
                    Criar Usuário
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Modal: Edit User */}
          {editingUser && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <form
                onSubmit={handleUpdateUser}
                className="bg-[#0F0F0F] border-2 border-[#3B82F6] max-w-md w-full p-6 text-xs space-y-4"
              >
                <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Editar Acesso: {editingUser.name}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="text-[#888888] hover:text-white"
                  >
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>

                <div>
                  <label className="block text-[#888888] uppercase mb-1">Função / Perfil</label>
                  <select
                    value={editingUser.role}
                    onChange={e => setEditingUser({ ...editingUser, role: e.target.value as UserRole })}
                    className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none"
                  >
                    <option value="STANDARD_USER">STANDARD_USER</option>
                    <option value="EVIDENCE_AUDITOR">EVIDENCE_AUDITOR</option>
                    <option value="GOD_OPERATOR">GOD_OPERATOR</option>
                    <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#888888] uppercase mb-1">Status da Conta</label>
                  <select
                    value={editingUser.status}
                    onChange={e => setEditingUser({ ...editingUser, status: e.target.value as UserStatus })}
                    className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none"
                  >
                    <option value="ACTIVE">ATIVO</option>
                    <option value="SUSPENDED">SUSPENSO</option>
                    <option value="PENDING_REVIEW">PENDENTE</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#888888] uppercase mb-1">Cota de Requisições Mensal</label>
                  <input
                    type="number"
                    value={editingUser.apiQuotaLimit}
                    onChange={e => setEditingUser({ ...editingUser, apiQuotaLimit: parseInt(e.target.value, 10) || 10000 })}
                    className="w-full bg-[#0A0A0A] border border-[#222222] p-2 text-white outline-none"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-3 border-t border-[#222222]">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-4 py-2 text-[#888888] hover:text-white uppercase font-bold"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#3B82F6] text-white font-black uppercase hover:bg-white hover:text-black"
                  >
                    Salvar Alterações
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: SYSTEM SETTINGS                                                    */}
      {/* ========================================================================= */}
      {activeTab === 'infrastructure' && <SuperAdminInfrastructure />}
      {activeTab === 'security' && <SecurityFirewallPanel />}

      {activeTab === 'settings' && settings && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#0F0F0F] border border-[#222222] p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-[#222222] pb-4">
              <div>
                <h2 className="text-base font-black text-white uppercase tracking-wider">
                  Parâmetros Globais do PASQUARED-OS
                </h2>
                <p className="text-xs text-[#888888] font-sans">
                  Ajuste fino de ponderação de evidência MVED, limiar KGS de gap de conhecimento e rigor adversarial ARES.
                </p>
              </div>

              <button
                id="btn-save-settings"
                onClick={handleSaveSettings}
                className="px-5 py-2.5 bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black text-xs uppercase transition-all"
              >
                Salvar Configurações
              </button>
            </div>

            {/* General Toggles Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white uppercase">Modo de Manutenção do Sistema</span>
                  <input
                    type="checkbox"
                    checked={settings.maintenanceMode}
                    onChange={e => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                    className="w-4 h-4 accent-[#FF3E00]"
                  />
                </div>
                <p className="text-[11px] text-[#888888] font-sans">
                  Suspende pesquisas públicas para manutenção preventiva da infraestrutura.
                </p>
              </div>

              <div className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white uppercase">HADES Auto-Quarentena de Risco</span>
                  <input
                    type="checkbox"
                    checked={settings.hadesAutoQuarantine}
                    onChange={e => setSettings({ ...settings, hadesAutoQuarantine: e.target.checked })}
                    className="w-4 h-4 accent-[#00FF41]"
                  />
                </div>
                <p className="text-[11px] text-[#888888] font-sans">
                  Isola preventivamente fontes ou afirmações cujo indicador de contradição ultrapasse 80%.
                </p>
              </div>
            </div>

            {/* Threshold Sliders */}
            <div className="space-y-6 pt-2">
              <div className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-2">
                <div className="flex justify-between">
                  <span className="font-bold text-white uppercase">Limiar KGS de Auto-Evolução (Gap Knowledge Score)</span>
                  <span className="text-[#00FF41] font-bold">{settings.kgsThreshold}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="0.95"
                  step="0.05"
                  value={settings.kgsThreshold}
                  onChange={e => setSettings({ ...settings, kgsThreshold: parseFloat(e.target.value) })}
                  className="w-full accent-[#00FF41]"
                />
                <p className="text-[10px] text-[#888888] font-sans">
                  Quando o gap de conhecimento de um tema ultrapassa esse score, o sistema dispara a síntese em sandbox de um novo especialista Olympus.
                </p>
              </div>

              <div className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-2">
                <div className="flex justify-between">
                  <span className="font-bold text-white uppercase">Modelo Generativo Gemini Core</span>
                  <span className="text-[#FF3E00] font-bold">{settings.geminiModel}</span>
                </div>
                <select
                  value={settings.geminiModel}
                  onChange={e => setSettings({ ...settings, geminiModel: e.target.value })}
                  className="w-full bg-black border border-[#333333] p-2 text-white text-xs outline-none"
                >
                  <option value="gemini-2.5-flash">gemini-2.5-flash (Ultrarrápido • Padrão)</option>
                  <option value="gemini-2.5-pro">gemini-2.5-pro (Raciocínio Profundo & MVED Ampliado)</option>
                  <option value="gemini-1.5-pro-preview">gemini-1.5-pro-preview (Legado)</option>
                </select>
              </div>

              {/* MVED Weight Distribution Sliders */}
              <div className="bg-[#0A0A0A] p-4 border border-[#222222] space-y-4">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-[#222222] pb-2">
                  Matriz de Ponderação MVED 2.0 (Validação de Evidências Multi-Vetor)
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 text-xs">
                  <div>
                    <label className="block text-[#888888] uppercase mb-1">M1: Evidência Directa</label>
                    <input
                      type="number"
                      step="0.05"
                      min="0"
                      max="1"
                      value={settings.mvedWeights.evidence}
                      onChange={e =>
                        setSettings({
                          ...settings,
                          mvedWeights: { ...settings.mvedWeights, evidence: parseFloat(e.target.value) || 0 },
                        })
                      }
                      className="w-full bg-black border border-[#333] p-2 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[#888888] uppercase mb-1">M2: Coerência Lógica</label>
                    <input
                      type="number"
                      step="0.05"
                      min="0"
                      max="1"
                      value={settings.mvedWeights.logic}
                      onChange={e =>
                        setSettings({
                          ...settings,
                          mvedWeights: { ...settings.mvedWeights, logic: parseFloat(e.target.value) || 0 },
                        })
                      }
                      className="w-full bg-black border border-[#333] p-2 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[#888888] uppercase mb-1">M3: Relevância Temática</label>
                    <input
                      type="number"
                      step="0.05"
                      min="0"
                      max="1"
                      value={settings.mvedWeights.relevance}
                      onChange={e =>
                        setSettings({
                          ...settings,
                          mvedWeights: { ...settings.mvedWeights, relevance: parseFloat(e.target.value) || 0 },
                        })
                      }
                      className="w-full bg-black border border-[#333] p-2 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[#888888] uppercase mb-1">M4: Penalidade Risco</label>
                    <input
                      type="number"
                      step="0.05"
                      min="0"
                      max="1"
                      value={settings.mvedWeights.risk}
                      onChange={e =>
                        setSettings({
                          ...settings,
                          mvedWeights: { ...settings.mvedWeights, risk: parseFloat(e.target.value) || 0 },
                        })
                      }
                      className="w-full bg-black border border-[#333] p-2 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[#888888] uppercase mb-1">M5: Consenso Gods</label>
                    <input
                      type="number"
                      step="0.05"
                      min="0"
                      max="1"
                      value={settings.mvedWeights.consensus}
                      onChange={e =>
                        setSettings({
                          ...settings,
                          mvedWeights: { ...settings.mvedWeights, consensus: parseFloat(e.target.value) || 0 },
                        })
                      }
                      className="w-full bg-black border border-[#333] p-2 text-white font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Microsoft AI Foundry Configuration & Agent Parameterization */}
              <div className="bg-[#0A0A0A] p-5 border border-[#222222] space-y-6">
                <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#FF3E00]" />
                    <h3 className="text-xs font-black text-white uppercase tracking-wider">
                      Microsoft AI Foundry & Agent Model Parameterization (PASQUARED & GOITGODS)
                    </h3>
                  </div>
                  <span className="px-2 py-0.5 bg-[#FF3E00]/10 text-[#FF3E00] border border-[#FF3E00]/30 text-[10px] font-bold uppercase">
                    Model Catalog
                  </span>
                </div>

                <p className="text-xs text-[#888888] font-sans">
                  Configure as chaves de API, endpoints e deployments do Microsoft AI Foundry para alimentar os agentes de IA de suporte do PASQUARED-OS na orquestração epistemológica e geração de livros de alta qualidade.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1.5">
                    <label className="block text-white font-bold uppercase text-[11px]">Microsoft AI Foundry API Key</label>
                    <input
                      type="password"
                      placeholder="azure_ai_foundry_key_..."
                      value={settings.microsoftFoundryApiKey || ''}
                      onChange={e => setSettings({ ...settings, microsoftFoundryApiKey: e.target.value })}
                      className="w-full bg-black border border-[#333333] p-2.5 text-white text-xs outline-none focus:border-[#FF3E00]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-white font-bold uppercase text-[11px]">API Endpoint / Model Catalog URL</label>
                    <input
                      type="text"
                      placeholder="https://models.inference.ai.azure.com"
                      value={settings.microsoftFoundryEndpoint || ''}
                      onChange={e => setSettings({ ...settings, microsoftFoundryEndpoint: e.target.value })}
                      className="w-full bg-black border border-[#333333] p-2.5 text-white text-xs outline-none focus:border-[#FF3E00]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-white font-bold uppercase text-[11px]">Deployment Name (Azure AI)</label>
                    <input
                      type="text"
                      placeholder="gpt-4o-deployment"
                      value={settings.microsoftFoundryDeployment || ''}
                      onChange={e => setSettings({ ...settings, microsoftFoundryDeployment: e.target.value })}
                      className="w-full bg-black border border-[#333333] p-2.5 text-white text-xs outline-none focus:border-[#FF3E00]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-white font-bold uppercase text-[11px]">Modelo Padrão Microsoft Foundry</label>
                    <select
                      value={settings.microsoftFoundryModel || 'gpt-4o'}
                      onChange={e => setSettings({ ...settings, microsoftFoundryModel: e.target.value })}
                      className="w-full bg-black border border-[#333333] p-2.5 text-white text-xs outline-none focus:border-[#FF3E00]"
                    >
                      <option value="gpt-4o">gpt-4o (Azure OpenAI • Recomendado para Raciocínio & Livros)</option>
                      <option value="gpt-4o-mini">gpt-4o-mini (Rápido • Triagem e Auditoria HADES)</option>
                      <option value="Phi-4">Phi-4 (Microsoft Small Language Model • Lógica & Matemática)</option>
                      <option value="Mistral-Large-2407">Mistral-Large-2407 (Síntese Acadêmica Complexa)</option>
                      <option value="Cohere-Command-R-Plus">Cohere-Command-R-Plus (RAG & Pesquisa Multi-Fonte)</option>
                      <option value="Llama-3.3-70B-Instruct">Llama-3.3-70B-Instruct (Validação Adversarial ARES)</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-white font-bold uppercase text-[11px]">PASQUARED Core Orchestrator Model</label>
                    <select
                      value={settings.pasquaredAgentModel || 'gpt-4o'}
                      onChange={e => setSettings({ ...settings, pasquaredAgentModel: e.target.value })}
                      className="w-full bg-black border border-[#333333] p-2.5 text-white text-xs outline-none focus:border-[#FF3E00]"
                    >
                      <option value="gpt-4o">gpt-4o (Melhor Orquestrador PFA e Triangulação Epistemológica)</option>
                      <option value="Cohere-Command-R-Plus">Cohere-Command-R-Plus (Especialista em RAG Acadêmico)</option>
                      <option value="Mistral-Large-2407">Mistral-Large-2407 (Análise Rigorosa)</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-white font-bold uppercase text-[11px]">GOITGODS E-Book Generator Model</label>
                    <select
                      value={settings.goitgodsAgentModel || 'gpt-4o'}
                      onChange={e => setSettings({ ...settings, goitgodsAgentModel: e.target.value })}
                      className="w-full bg-black border border-[#333333] p-2.5 text-white text-xs outline-none focus:border-[#FF3E00]"
                    >
                      <option value="gpt-4o">gpt-4o (Qualidade de Redação Literária e Científica Superior)</option>
                      <option value="Mistral-Large-2407">Mistral-Large-2407 (Excelente Coerência de Longo Prazo)</option>
                      <option value="Llama-3.3-70B-Instruct">Llama-3.3-70B-Instruct (Estilo Narrativo Robusto)</option>
                    </select>
                  </div>
                </div>

                {/* AI Model Recommendations Guide */}
                <div className="border border-[#222] bg-[#050505] p-4 space-y-3">
                  <h4 className="text-xs font-bold text-[#FF3E00] uppercase tracking-wider">
                    Guia Oficial de Recomendação de Modelos de IA por Função (PASQUARED & GOITGODS)
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] text-gray-300 font-sans">
                    <div className="bg-black p-3 border border-[#222]">
                      <span className="font-bold text-white block mb-1">🏛️ ZEUS (Arbitragem Epistemic & Síntese Final)</span>
                      <p className="text-[#888]"><b>Recomendado:</b> `gpt-4o` (Azure OpenAI)</p>
                      <p className="text-[10px] text-gray-400 mt-1">Essencial para ponderação final de consenso entre os 12 deuses e resolução de contradições críticas no Ledger.</p>
                    </div>

                    <div className="bg-black p-3 border border-[#222]">
                      <span className="font-bold text-white block mb-1">📚 GOITGODS (Geração de Livros de Alta Qualidade)</span>
                      <p className="text-[#888]"><b>Recomendado:</b> `gpt-4o` ou `Mistral-Large-2407`</p>
                      <p className="text-[10px] text-gray-400 mt-1">Garante coesão narrativa monumental, estrutura impecável por capítulos e rigor de citação acadêmica.</p>
                    </div>

                    <div className="bg-black p-3 border border-[#222]">
                      <span className="font-bold text-white block mb-1">🔍 PASQUARED Core (Orquestração & PFA)</span>
                      <p className="text-[#888]"><b>Recomendado:</b> `gpt-4o` ou `Cohere-Command-R-Plus`</p>
                      <p className="text-[10px] text-gray-400 mt-1">Perfeito para decomposição de pesquisas complexas, plano de investigação e triangulação multi-fonte.</p>
                    </div>

                    <div className="bg-black p-3 border border-[#222]">
                      <span className="font-bold text-white block mb-1">⚔️ ARES & HADES (Auditoria de Risco & Red-Teaming)</span>
                      <p className="text-[#888]"><b>Recomendado:</b> `gpt-4o-mini` ou `Phi-4`</p>
                      <p className="text-[10px] text-gray-400 mt-1">Alta velocidade e precisão em auditorias de viés, detecção de contaminação e testes de refutação adversarial.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Supabase Integration status card */}
              {supabaseStatus && (
                <div className="bg-[#0A0A0A] p-5 border border-[#222222] space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222222] pb-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-[#00FF41] animate-pulse" />
                      <h3 className="text-xs font-black text-white uppercase tracking-wider">
                        Sincronização Ativa: Supabase Database ({supabaseStatus.project})
                      </h3>
                    </div>
                    <span className="px-2 py-0.5 bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/30 text-[10px] font-bold uppercase">
                      Integrado
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="space-y-1">
                      <span className="text-[#888888] block uppercase text-[10px]">URL do Projeto Supabase:</span>
                      <span className="text-[#00FF41] block truncate">{supabaseStatus.url}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[#888888] block uppercase text-[10px]">Persistência em Nuvem:</span>
                      <span className={supabaseStatus.hasKey ? 'text-[#00FF41]' : 'text-amber-400'}>
                        {supabaseStatus.hasKey 
                          ? 'ATIVA (Credenciais SUPABASE_ANON_KEY configuradas)' 
                          : 'MODO SANDBOX LOCAL (Configure SUPABASE_ANON_KEY no arquivo .env)'}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white uppercase tracking-wider block">
                        Inicialização de Tabelas do Supabase
                      </span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(supabaseStatus.sqlSchema);
                          showToast('Script SQL copiado para a área de transferência!');
                        }}
                        className="px-3 py-1 bg-[#111111] hover:bg-[#FF3E00] hover:text-black text-[#FF3E00] border border-[#222222] hover:border-[#FF3E00] text-[10px] font-bold uppercase transition-all"
                      >
                        Copiar Script SQL
                      </button>
                    </div>
                    <p className="text-[11px] text-[#888888] font-sans">
                      Se você ainda não criou as tabelas no seu projeto Supabase, clique no botão acima, abra o <b>SQL Editor</b> no painel da Supabase, cole o script e clique em <b>Run</b>. Isso criará as tabelas de autenticação, usuários e logs instantaneamente.
                    </p>
                    <pre className="w-full bg-[#050505] border border-[#1a1a1a] p-3 text-[10px] text-gray-400 overflow-x-auto font-mono max-h-36 overflow-y-auto">
                      {supabaseStatus.sqlSchema}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: MODERATION & EPISTEMIC AUDIT                                       */}
      {/* ========================================================================= */}
      {activeTab === 'moderation' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Moderation Controls Header */}
          <div className="bg-[#0F0F0F] border border-[#222222] p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-[#888888] uppercase font-bold">Status:</span>
              {(['ALL', 'PENDING', 'APPROVED', 'REJECTED', 'QUARANTINED'] as const).map(st => (
                <button
                  key={st}
                  onClick={() => setModStatusFilter(st)}
                  className={`px-3 py-1 text-xs uppercase font-bold border ${
                    modStatusFilter === st
                      ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                      : 'bg-[#0A0A0A] text-[#888888] border-[#222222] hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-xs text-[#888888] uppercase font-bold">Tipo:</span>
              {(['ALL', 'CLAIM', 'MANUSCRIPT', 'SOURCE_DOMAIN'] as const).map(tp => (
                <button
                  key={tp}
                  onClick={() => setModTypeFilter(tp)}
                  className={`px-2.5 py-1 text-xs uppercase font-bold border ${
                    modTypeFilter === tp
                      ? 'bg-[#00FF41] text-black border-[#00FF41]'
                      : 'bg-[#0A0A0A] text-[#888888] border-[#222222] hover:text-white'
                  }`}
                >
                  {tp}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of Moderation Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredModeration.map(item => (
              <div
                key={item.id}
                className="bg-[#0F0F0F] border border-[#222222] p-4 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-[#111] text-[#00FF41] border border-[#333]">
                      [{item.type}] {item.epistemicType ? `• ${item.epistemicType}` : ''}
                    </span>

                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 border ${MODERATION_STATUS_BADGES[item.status]}`}>
                      {item.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-white">{item.title}</h3>
                  <p className="text-xs text-[#CCCCCC] font-sans leading-relaxed">{item.description}</p>

                  <div className="bg-[#0A0A0A] p-2.5 border border-[#222222] text-[11px] space-y-1 font-mono">
                    <div className="text-amber-400">Motivo: {item.flagReason}</div>
                    <div className="text-[#888888] flex justify-between">
                      <span>Submetido por: {item.submittedBy}</span>
                      <span>Confiança: {(item.confidenceScore * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#222222] flex items-center justify-end space-x-2">
                  <button
                    onClick={() => handleResolveModeration(item.id, 'REJECT')}
                    className="px-3 py-1.5 bg-[#0A0A0A] hover:bg-red-500 hover:text-white border border-red-500/50 text-red-400 font-bold text-xs uppercase transition-all"
                  >
                    Rejeitar
                  </button>

                  <button
                    onClick={() => handleResolveModeration(item.id, 'QUARANTINE')}
                    className="px-3 py-1.5 bg-[#0A0A0A] hover:bg-purple-600 hover:text-white border border-purple-500/50 text-purple-400 font-bold text-xs uppercase transition-all"
                  >
                    Quarentena
                  </button>

                  <button
                    onClick={() => handleResolveModeration(item.id, 'APPROVE')}
                    className="px-3 py-1.5 bg-[#00FF41] text-black font-black text-xs uppercase hover:bg-white transition-all"
                  >
                    Aprovar
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Blocked Domains Manager Section */}
          <div className="bg-[#0F0F0F] border border-[#222222] p-5 space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-[#222222] pb-2 flex items-center space-x-2">
              <Ban className="w-4 h-4 text-red-500" />
              <span>Gerenciador de Domínios & Fontes Bloqueadas (Blacklist)</span>
            </h3>

            <form onSubmit={handleAddBlockedDomain} className="flex gap-2">
              <input
                type="text"
                placeholder="Ex: dominio-nao-confiavel.com"
                value={newDomainToBlock}
                onChange={e => setNewDomainToBlock(e.target.value)}
                className="flex-1 bg-[#0A0A0A] border border-[#222222] px-3 py-2 text-xs text-white outline-none focus:border-[#FF3E00]"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase transition-all"
              >
                Bloquear Domínio
              </button>
            </form>

            <div className="flex flex-wrap gap-2 text-xs">
              {settings?.blockedDomains.map(dom => (
                <div key={dom} className="px-3 py-1.5 bg-[#0A0A0A] border border-red-500/30 text-red-400 flex items-center space-x-2">
                  <span>{dom}</span>
                  <button
                    onClick={() => handleRemoveBlockedDomain(dom)}
                    className="text-[#888888] hover:text-white"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: AUDIT LOGS                                                         */}
      {/* ========================================================================= */}
      {activeTab === 'logs' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Logs Filter Bar */}
          <div className="bg-[#0F0F0F] border border-[#222222] p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md w-full">
              <Search className="w-4 h-4 text-[#888888] absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Filtrar logs por agente, ação ou detalhes..."
                value={logSearch}
                onChange={e => setLogSearch(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#222222] focus:border-[#FF3E00] pl-9 pr-3 py-2 text-xs text-white placeholder-[#555555] outline-none"
              />
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-xs text-[#888888] uppercase">Severidade:</span>
              {(['ALL', 'INFO', 'WARN', 'SECURITY', 'ERROR'] as const).map(sev => (
                <button
                  key={sev}
                  onClick={() => setLogSeverityFilter(sev)}
                  className={`px-3 py-1 text-xs uppercase font-bold border ${
                    logSeverityFilter === sev
                      ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                      : 'bg-[#0A0A0A] text-[#888888] border-[#222222] hover:text-white'
                  }`}
                >
                  {sev}
                </button>
              ))}
            </div>
          </div>

          {/* Audit Logs Table */}
          <div className="bg-[#0F0F0F] border border-[#222222] overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0A0A0A] border-b border-[#222222] text-[#888888] uppercase text-[10px]">
                <tr>
                  <th className="p-3">Horário</th>
                  <th className="p-3">Severidade</th>
                  <th className="p-3">Agente / Ator</th>
                  <th className="p-3">Ação Realizada</th>
                  <th className="p-3">Alvo / Requisito</th>
                  <th className="p-3">Detalhes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222222]">
                {filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-[#121212]">
                    <td className="p-3 text-[11px] text-[#888888] whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </td>

                    <td className="p-3">
                      <span className={`px-2 py-0.5 text-[9px] font-bold border uppercase ${SEVERITY_COLORS[log.severity]}`}>
                        {log.severity}
                      </span>
                    </td>

                    <td className="p-3 font-bold text-white">{log.actor}</td>
                    <td className="p-3 text-[#FF3E00] font-bold">{log.action}</td>
                    <td className="p-3 text-[#CCCCCC]">{log.target}</td>
                    <td className="p-3 text-[11px] text-[#888888] font-sans">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
