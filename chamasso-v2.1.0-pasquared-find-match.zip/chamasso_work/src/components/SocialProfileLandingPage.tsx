import React, { useState, useEffect } from 'react';
import {
  Camera,
  Edit3,
  Lock,
  Globe,
  Users,
  Shield,
  MessageSquare,
  Video,
  Phone,
  Image as ImageIcon,
  Smile,
  Send,
  MoreHorizontal,
  Share2,
  Heart,
  ThumbsUp,
  MapPin,
  Briefcase,
  GraduationCap,
  Calendar,
  Eye,
  CheckCircle2,
  Sparkles,
  Coins,
  ArrowLeft,
  Settings,
  Flame,
  Clock,
  Radio,
  FileText,
  X,
  UserPlus,
  UserCheck,
} from 'lucide-react';
import type {
  User,
  SocialPost,
  SocialComment,
  SocialReactionType,
  SocialLandingPageData,
} from '../types.ts';
import { NicknameModal } from './NicknameModal.tsx';
import { getUserDisplayName } from '../utils/nickname.ts';
import { PasquaredMatchTab } from './PasquaredMatchTab.tsx';

interface SocialProfileLandingPageProps {
  targetUserId: string;
  currentUser: User | null;
  onBackToChat: () => void;
  onOpenLiveChatRoom?: (roomId?: string) => void;
  onOpenPasqcoinShop?: () => void;
  onOpenSocialProfile?: (userId: string) => void;
}

export const SocialProfileLandingPage: React.FC<SocialProfileLandingPageProps> = ({
  targetUserId,
  currentUser,
  onBackToChat,
  onOpenLiveChatRoom,
  onOpenPasqcoinShop,
  onOpenSocialProfile,
}) => {
  const [data, setData] = useState<SocialLandingPageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'posts' | 'about' | 'friends' | 'photos' | 'privacy' | 'pasqcoin' | 'findmatch'>('posts');
  
  // Post creation
  const [postContent, setPostContent] = useState('');
  const [postMediaUrl, setPostMediaUrl] = useState('');
  const [postMediaType, setPostMediaType] = useState<'image' | 'video' | 'audio' | 'document' | undefined>(undefined);
  const [postPrivacy, setPostPrivacy] = useState<'public' | 'friends'>('public');
  const [isSubmittingPost, setIsSubmittingPost] = useState(false);
  const [showMediaInput, setShowMediaInput] = useState(false);

  // Comment inputs per post
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [activeReactionPicker, setActiveReactionPicker] = useState<string | null>(null);

  // Edit profile modal / mode
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [showNicknameModal, setShowNicknameModal] = useState(false);
  const [editName, setEditName] = useState('');
  const [editLastName, setEditLastName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editWork, setEditWork] = useState('');
  const [editEducation, setEditEducation] = useState('');
  const [editRelationship, setEditRelationship] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const [editCoverUrl, setEditCoverUrl] = useState('');

  // Privacy Settings modal
  const [privacySetting, setPrivacySetting] = useState<'public' | 'restricted'>('public');
  const [privacyMsg, setPrivacyMsg] = useState('');

  const fetchProfileData = async () => {
    try {
      setLoading(true);
      const viewerId = currentUser?.id || '';
      const res = await fetch(`/api/users/${targetUserId}/landing-page?viewerId=${viewerId}`);
      if (!res.ok) {
        throw new Error('Falha ao carregar perfil');
      }
      const json: SocialLandingPageData = await res.json();
      setData(json);
      setPrivacySetting(json.user.profilePrivacy === 'restricted' ? 'restricted' : 'public');

      // Populate edit states
      setEditName(json.user.name);
      setEditLastName(json.user.lastName);
      setEditBio(json.user.bio || '');
      setEditCity(json.user.city || '');
      setEditWork(json.user.work || '');
      setEditEducation(json.user.education || '');
      setEditRelationship(json.user.relationshipStatus || 'Solteiro(a)');
      setEditAvatarUrl(json.user.avatarUrl || '');
      setEditCoverUrl(json.user.coverUrl || '');
    } catch (err) {
      console.error('Erro ao buscar dados do perfil:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfileData();
  }, [targetUserId, currentUser?.id]);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || (!postContent.trim() && !postMediaUrl.trim())) return;

    try {
      setIsSubmittingPost(true);
      const res = await fetch('/api/feed/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorLastName: currentUser.lastName,
          authorAvatar: currentUser.avatarUrl || '/fenix_chamas.gif',
          authorEmail: currentUser.googleEmail,
          content: postContent.trim(),
          mediaType: postMediaType,
          mediaUrl: postMediaUrl.trim() || undefined,
          privacy: postPrivacy,
        }),
      });

      const json = await res.json();
      if (json.success && json.post) {
        setPostContent('');
        setPostMediaUrl('');
        setPostMediaType(undefined);
        setShowMediaInput(false);
        // Add to local state
        setData((prev) => {
          if (!prev) return prev;
          return {
            ...prev,
            posts: [json.post, ...prev.posts],
          };
        });
      }
    } catch (err) {
      console.error('Erro ao postar:', err);
    } finally {
      setIsSubmittingPost(false);
    }
  };

  const handleReact = async (postId: string, reaction: SocialReactionType) => {
    if (!currentUser) return;
    try {
      setActiveReactionPicker(null);
      const res = await fetch(`/api/feed/posts/${postId}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          reaction,
        }),
      });
      const json = await res.json();
      if (json.success && json.post) {
        setData((prev) => {
          if (!prev) return prev;
          return {
            ...prev,
            posts: prev.posts.map((p) => (p.id === postId ? json.post : p)),
          };
        });
      }
    } catch (err) {
      console.error('Erro ao reagir:', err);
    }
  };

  const handleComment = async (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!currentUser || !text) return;

    try {
      const res = await fetch(`/api/feed/posts/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorId: currentUser.id,
          authorName: `${currentUser.name} ${currentUser.lastName}`,
          authorAvatar: currentUser.avatarUrl || '/fenix_chamas.gif',
          content: text,
        }),
      });
      const json = await res.json();
      if (json.success && json.post) {
        setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
        setData((prev) => {
          if (!prev) return prev;
          return {
            ...prev,
            posts: prev.posts.map((p) => (p.id === postId ? json.post : p)),
          };
        });
      }
    } catch (err) {
      console.error('Erro ao comentar:', err);
    }
  };

  const handleSaveProfile = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/users/${currentUser.id}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName.trim(),
          lastName: editLastName.trim(),
          bio: editBio.trim(),
          city: editCity.trim(),
          work: editWork.trim(),
          education: editEducation.trim(),
          relationshipStatus: editRelationship,
          avatarUrl: editAvatarUrl.trim() || undefined,
          coverUrl: editCoverUrl.trim() || undefined,
        }),
      });
      const json = await res.json();
      if (json.success) {
        setIsEditingProfile(false);
        fetchProfileData();
      }
    } catch (err) {
      console.error('Erro ao salvar perfil:', err);
    }
  };

  const handleSavePrivacy = async (newPrivacy: 'public' | 'restricted') => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/users/${currentUser.id}/privacy`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profilePrivacy: newPrivacy,
          privacySettings: {
            whoCanSeePosts: newPrivacy === 'restricted' ? 'friends' : 'public',
            whoCanAddFriend: 'everyone',
            whoCanSeeFriendsList: newPrivacy === 'restricted' ? 'friends' : 'public',
            whoCanMessage: 'everyone',
            isProfileRestricted: newPrivacy === 'restricted',
          },
        }),
      });
      const json = await res.json();
      if (json.success) {
        setPrivacySetting(newPrivacy);
        setPrivacyMsg(`Perfil atualizado com sucesso para ${newPrivacy === 'restricted' ? 'Restrito (Privado)' : 'Público'}!`);
        setTimeout(() => setPrivacyMsg(''), 3500);
        fetchProfileData();
      }
    } catch (err) {
      console.error('Erro ao salvar privacidade:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[#0F172A] text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-[#22D3EE] border-t-transparent" />
          <p className="text-sm font-medium text-slate-400">Carregando perfil social...</p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex h-screen w-full flex-col items-center justify-center bg-[#0F172A] text-white p-4">
        <p className="text-lg font-bold text-slate-300 mb-4">Perfil não encontrado ou inacessível.</p>
        <button
          onClick={onBackToChat}
          className="rounded-xl bg-[#22D3EE] px-4 py-2 font-bold text-black hover:brightness-110"
        >
          Voltar ao Live Chat
        </button>
      </div>
    );
  }

  const { user, isOwner, isFriend, isRestrictedView, posts, friends, photosCount, totalFriends } = data;

  const reactionEmojis: Record<SocialReactionType, { emoji: string; label: string; color: string }> = {
    like: { emoji: '👍', label: 'Curtir', color: 'text-blue-400' },
    love: { emoji: '❤️', label: 'Amei', color: 'text-red-400' },
    care: { emoji: '🥰', label: 'Força', color: 'text-amber-400' },
    haha: { emoji: '😆', label: 'Haha', color: 'text-yellow-400' },
    wow: { emoji: '😮', label: 'Uau', color: 'text-yellow-300' },
    sad: { emoji: '😢', label: 'Triste', color: 'text-amber-300' },
    angry: { emoji: '😡', label: 'Grr', color: 'text-orange-500' },
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-[#E2E8F0] font-sans pb-16">
      {/* Top Profile Bar */}
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-[#1E293B] bg-[#0F172A]/95 px-4 py-2.5 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToChat}
            className="flex items-center gap-2 rounded-xl bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-[#334155] transition"
          >
            <ArrowLeft className="h-4 w-4 text-[#22D3EE]" />
            <span>Voltar ao Chat & Salas</span>
          </button>

          <div className="hidden sm:flex items-center gap-2">
            <span className="text-sm font-black italic tracking-wider text-white">
              CHAMASSO <span className="text-[#22D3EE]">SOCIAL</span>
            </span>
            <span className="rounded-full bg-cyan-500/10 px-2 py-0.5 text-[10px] font-bold text-[#22D3EE] border border-cyan-500/20">
              {user.profilePrivacy === 'restricted' ? 'Perfil Restrito' : 'Perfil Público'}
            </span>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2">
          {onOpenPasqcoinShop && (
            <button
              onClick={onOpenPasqcoinShop}
              className="flex items-center gap-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 px-3 py-1 text-xs font-bold text-amber-300 hover:bg-amber-500/25 transition"
              title="Comprar Pasqcoins"
            >
              <Coins className="h-3.5 w-3.5 text-amber-400" />
              <span>{Number(currentUser?.pasqcoins || 0).toFixed(6)} PASQ</span>
            </button>
          )}

          {onOpenLiveChatRoom && (
            <button
              onClick={() => onOpenLiveChatRoom()}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-3 py-1.5 text-xs font-bold text-black shadow-md hover:brightness-110 active:scale-95 transition"
            >
              <Radio className="h-3.5 w-3.5 animate-pulse" />
              <span className="hidden md:inline">Entrar no Live Chat</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Profile Canvas Container */}
      <div className="mx-auto max-w-5xl">
        {/* COVER PHOTO SECTION */}
        <div className="relative h-48 sm:h-72 md:h-80 w-full overflow-hidden rounded-b-2xl bg-gradient-to-br from-slate-800 to-slate-900 border-b border-[#1E293B]">
          <img
            src={user.coverUrl || '/fenix_chamas.gif'}
            alt="Foto de capa"
            className="h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#090D16] via-transparent to-transparent opacity-80" />

          {isOwner && (
            <button
              onClick={() => setIsEditingProfile(true)}
              className="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-xl bg-black/60 backdrop-blur-md px-3 py-1.5 text-xs font-bold text-white hover:bg-black/80 border border-white/20 transition"
            >
              <Camera className="h-4 w-4 text-[#22D3EE]" />
              <span>Editar capa</span>
            </button>
          )}
        </div>

        {/* PROFILE HEADER (Avatar, Name, Quick Action Buttons) */}
        <div className="relative px-4 sm:px-8 pb-4">
          <div className="flex flex-col md:flex-row items-center md:items-end justify-between -mt-16 md:-mt-20 gap-4">
            {/* Avatar & User Details */}
            <div className="flex flex-col md:flex-row items-center md:items-end gap-4 text-center md:text-left">
              <div className="relative group">
                <div className="h-32 w-32 md:h-36 md:w-36 rounded-full border-4 border-[#090D16] bg-slate-800 overflow-hidden shadow-2xl">
                  <img
                    src={user.avatarUrl || '/fenix_chamas.gif'}
                    alt={user.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                {isOwner && (
                  <button
                    onClick={() => setIsEditingProfile(true)}
                    className="absolute bottom-1 right-1 rounded-full bg-[#22D3EE] p-2 text-black shadow-lg hover:brightness-110"
                    title="Trocar avatar"
                  >
                    <Camera className="h-4 w-4" />
                  </button>
                )}
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-center md:justify-start gap-2">
                  <h1 className="text-2xl md:text-3xl font-black text-white">
                    {user.name} {user.lastName}
                  </h1>
                  <CheckCircle2 className="h-5 w-5 text-[#22D3EE]" title="Perfil 2FA Verificado" />
                  {user.profilePrivacy === 'restricted' ? (
                    <span className="flex items-center gap-1 rounded-full bg-amber-500/20 px-2 py-0.5 text-[11px] font-bold text-amber-300 border border-amber-500/30">
                      <Lock className="h-3 w-3" /> Restrito
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 rounded-full bg-emerald-500/20 px-2 py-0.5 text-[11px] font-bold text-emerald-300 border border-emerald-500/30">
                      <Globe className="h-3 w-3" /> Público
                    </span>
                  )}
                </div>

                {/* Nickname no Bate-Papo & Status de Identidade */}
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-0.5">
                  {user.nickname ? (
                    <div className="inline-flex items-center gap-1.5 rounded-lg bg-[#22D3EE]/15 border border-[#22D3EE]/40 px-2.5 py-0.5 text-xs font-bold text-[#22D3EE]">
                      <Sparkles className="h-3.5 w-3.5 text-[#22D3EE]" />
                      <span>Nickname no Chat: <strong>@{user.nickname}</strong></span>
                      {isOwner && (
                        <button
                          onClick={() => setShowNicknameModal(true)}
                          className="ml-1 text-[10px] uppercase font-bold text-slate-400 hover:text-white underline transition"
                        >
                          Alterar
                        </button>
                      )}
                    </div>
                  ) : isOwner ? (
                    <button
                      onClick={() => setShowNicknameModal(true)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#22D3EE]/20 to-[#F472B6]/20 border border-[#22D3EE]/40 px-2.5 py-0.5 text-xs font-bold text-[#22D3EE] hover:brightness-125 transition"
                      title="Clique para criar um nickname de até 8 caracteres"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-[#22D3EE]" />
                      <span>+ Criar Nickname (Opcional)</span>
                    </button>
                  ) : null}
                </div>

                <p className="text-xs text-slate-400">
                  {totalFriends} amigos cadastrados • {photosCount} fotos
                </p>

                {user.bio && (
                  <p className="text-xs text-slate-300 max-w-md italic mt-1">"{user.bio}"</p>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              {isOwner ? (
                <>
                  <button
                    onClick={() => setShowNicknameModal(true)}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#0F172A] to-[#1E293B] px-3.5 py-2 text-xs font-bold text-[#22D3EE] hover:border-[#22D3EE]/60 border border-[#22D3EE]/30 shadow-sm transition"
                  >
                    <Sparkles className="h-4 w-4 text-[#22D3EE]" />
                    <span>{user.nickname ? `@${user.nickname}` : 'Criar Nickname'}</span>
                  </button>
                  <button
                    onClick={() => setIsEditingProfile(true)}
                    className="flex items-center gap-1.5 rounded-xl bg-[#1E293B] px-4 py-2 text-xs font-bold text-white hover:bg-[#334155] border border-slate-700 transition"
                  >
                    <Edit3 className="h-4 w-4 text-[#22D3EE]" />
                    <span>Editar Perfil</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('privacy')}
                    className="flex items-center gap-1.5 rounded-xl bg-cyan-950/60 px-4 py-2 text-xs font-bold text-[#22D3EE] hover:bg-cyan-900/60 border border-cyan-500/30 transition"
                  >
                    <Shield className="h-4 w-4" />
                    <span>Privacidade ({user.profilePrivacy === 'restricted' ? 'Restrito' : 'Público'})</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-blue-500 px-4 py-2 text-xs font-bold text-black shadow-md hover:brightness-110 transition"
                  >
                    <UserPlus className="h-4 w-4" />
                    <span>Adicionar Amigo</span>
                  </button>
                  <button
                    onClick={() => onOpenLiveChatRoom && onOpenLiveChatRoom()}
                    className="flex items-center gap-1.5 rounded-xl bg-[#1E293B] px-4 py-2 text-xs font-bold text-white hover:bg-[#334155] border border-slate-700 transition"
                  >
                    <MessageSquare className="h-4 w-4 text-[#22D3EE]" />
                    <span>Enviar Mensagem</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* PRIVACY WARNING BANNER IF RESTRICTED VIEW */}
          {isRestrictedView && !isOwner && (
            <div className="mt-4 flex items-center gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs text-amber-200">
              <Lock className="h-5 w-5 shrink-0 text-amber-400" />
              <div>
                <p className="font-bold text-amber-300">Perfil Restrito</p>
                <p className="text-[11px] text-amber-200/90">
                  {user.name} configurou seu perfil como restrito. Apenas amigos confirmados podem visualizar
                  publicações completas, amigos e fotos privadas.
                </p>
              </div>
            </div>
          )}

          {/* PROFILE TABS NAVIGATION */}
          <div className="mt-6 flex border-b border-[#1E293B] overflow-x-auto no-scrollbar gap-1">
            {[
              { id: 'posts', label: 'Publicações' },
              { id: 'about', label: 'Sobre' },
              { id: 'friends', label: `Amigos (${totalFriends})` },
              { id: 'photos', label: 'Fotos' },
              { id: 'findmatch', label: 'Lista find Match' },
              { id: 'pasqcoin', label: 'Pasqcoins & Live Chat' },
              { id: 'privacy', label: 'Configurações de Privacidade' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`whitespace-nowrap px-4 py-3 text-xs font-bold transition-all border-b-2 ${
                  activeTab === tab.id
                    ? 'border-[#22D3EE] text-[#22D3EE]'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* MAIN BODY GRID: LEFT SIDEBAR (ABOUT) & RIGHT FEED (POSTS) */}
        <div className="px-4 sm:px-8 mt-4 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* LEFT COLUMN: INTRO / ABOUT SUMMARY */}
          <div className="md:col-span-5 space-y-4">
            {/* Intro Card */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 shadow-md space-y-3">
              <h3 className="text-sm font-black text-white">Apresentação</h3>

              {user.bio && (
                <p className="text-xs text-slate-300 text-center py-1 border-b border-[#1E293B]">
                  {user.bio}
                </p>
              )}

              <div className="space-y-2.5 text-xs text-slate-300 pt-1">
                {user.city && (
                  <div className="flex items-center gap-2.5">
                    <MapPin className="h-4 w-4 text-slate-400 shrink-0" />
                    <span>Mora em <strong className="text-white">{user.city}</strong></span>
                  </div>
                )}
                {user.work && (
                  <div className="flex items-center gap-2.5">
                    <Briefcase className="h-4 w-4 text-slate-400 shrink-0" />
                    <span>Trabalha em <strong className="text-white">{user.work}</strong></span>
                  </div>
                )}
                {user.education && (
                  <div className="flex items-center gap-2.5">
                    <GraduationCap className="h-4 w-4 text-slate-400 shrink-0" />
                    <span>Estudou em <strong className="text-white">{user.education}</strong></span>
                  </div>
                )}
                {user.relationshipStatus && (
                  <div className="flex items-center gap-2.5">
                    <Heart className="h-4 w-4 text-rose-400 shrink-0" />
                    <span>Status: <strong className="text-white">{user.relationshipStatus}</strong></span>
                  </div>
                )}
                <div className="flex items-center gap-2.5">
                  <Calendar className="h-4 w-4 text-slate-400 shrink-0" />
                  <span>Membro desde {new Date(user.createdAt).toLocaleDateString('pt-BR')}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Shield className="h-4 w-4 text-[#22D3EE] shrink-0" />
                  <span>Segurança 2FA (TOTP): <strong className="text-emerald-400">Ativa</strong></span>
                </div>
              </div>

              {isOwner && (
                <button
                  onClick={() => setIsEditingProfile(true)}
                  className="w-full rounded-xl bg-[#1E293B] py-2 text-xs font-bold text-slate-200 hover:bg-[#334155] transition"
                >
                  Editar detalhes
                </button>
              )}
            </div>

            {/* Quick Friends Grid Card */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-white">Amigos</h3>
                  <p className="text-[11px] text-slate-400">{totalFriends} amigos</p>
                </div>
                <button
                  onClick={() => setActiveTab('friends')}
                  className="text-xs text-[#22D3EE] hover:underline"
                >
                  Ver todos
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {friends.slice(0, 6).map((friend) => (
                  <div key={friend.id} className="text-center group cursor-pointer">
                    <div className="aspect-square rounded-xl overflow-hidden bg-slate-800 border border-[#1E293B] group-hover:border-[#22D3EE] transition">
                      <img
                        src={friend.avatarUrl || '/fenix_chamas.gif'}
                        alt={friend.name}
                        className="h-full w-full object-cover group-hover:scale-105 transition"
                      />
                    </div>
                    <p className="text-[10px] font-bold text-slate-300 truncate mt-1">
                      {friend.name}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: MAIN CONTENT (TABS CONTENT) */}
          <div className="md:col-span-7 space-y-4">
            {/* TAB: PUBLICAÇÕES */}
            {activeTab === 'posts' && (
              <>
                {/* CREATE POST BOX (If Owner or Allowed Friend) */}
                {isOwner && (
                  <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 shadow-md">
                    <div className="flex items-center gap-3">
                      <img
                        src={user.avatarUrl || '/fenix_chamas.gif'}
                        alt={user.name}
                        className="h-10 w-10 rounded-full object-cover border border-[#22D3EE]/40"
                      />
                      <input
                        type="text"
                        value={postContent}
                        onChange={(e) => setPostContent(e.target.value)}
                        placeholder={`No que você está pensando, ${user.name}?`}
                        className="w-full rounded-full bg-[#090D16] border border-[#1E293B] px-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#22D3EE]"
                      />
                    </div>

                    {showMediaInput && (
                      <div className="mt-3 p-3 rounded-xl bg-[#090D16] border border-[#1E293B] space-y-2">
                        <div className="flex items-center justify-between text-xs text-slate-300">
                          <span>Anexar Mídia ou Link de Arquivo:</span>
                          <button
                            type="button"
                            onClick={() => setShowMediaInput(false)}
                            className="text-slate-500 hover:text-white"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <input
                          type="url"
                          value={postMediaUrl}
                          onChange={(e) => setPostMediaUrl(e.target.value)}
                          placeholder="https://exemplo.com/foto.jpg ou .mp4"
                          className="w-full rounded-lg bg-[#0F172A] border border-[#1E293B] px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-[#22D3EE]"
                        />
                        <div className="flex gap-2">
                          {(['image', 'video', 'audio', 'document'] as const).map((type) => (
                            <button
                              key={type}
                              type="button"
                              onClick={() => setPostMediaType(type)}
                              className={`rounded-md px-2 py-1 text-[10px] font-bold capitalize ${
                                postMediaType === type
                                  ? 'bg-[#22D3EE] text-black'
                                  : 'bg-[#1E293B] text-slate-400'
                              }`}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="mt-3 flex items-center justify-between border-t border-[#1E293B] pt-3">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setShowMediaInput(true);
                            setPostMediaType('image');
                          }}
                          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs text-slate-300 hover:bg-[#1E293B] transition"
                        >
                          <ImageIcon className="h-4 w-4 text-emerald-400" />
                          <span>Foto/Vídeo</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenLiveChatRoom && onOpenLiveChatRoom()}
                          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs text-slate-300 hover:bg-[#1E293B] transition"
                        >
                          <Video className="h-4 w-4 text-rose-400" />
                          <span>Ao Vivo</span>
                        </button>
                        <select
                          value={postPrivacy}
                          onChange={(e) => setPostPrivacy(e.target.value as any)}
                          className="bg-[#090D16] border border-[#1E293B] text-[11px] rounded-lg px-2 py-1 text-slate-300 focus:outline-none"
                        >
                          <option value="public">Público</option>
                          <option value="friends">Amigos</option>
                        </select>
                      </div>

                      <button
                        type="button"
                        onClick={handleCreatePost}
                        disabled={isSubmittingPost || (!postContent.trim() && !postMediaUrl.trim())}
                        className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-blue-500 px-4 py-1.5 text-xs font-bold text-black shadow-md hover:brightness-110 active:scale-95 disabled:opacity-50 transition"
                      >
                        {isSubmittingPost ? 'Publicando...' : 'Publicar'}
                      </button>
                    </div>
                  </div>
                )}

                {/* POSTS LIST */}
                <div className="space-y-4">
                  {posts.length === 0 ? (
                    <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-8 text-center text-slate-400">
                      <MessageSquare className="mx-auto h-8 w-8 text-slate-600 mb-2" />
                      <p className="text-sm font-bold text-slate-300">Nenhuma publicação ainda</p>
                      <p className="text-xs text-slate-500 mt-1">
                        {isRestrictedView
                          ? 'Publicações ocultas pelo modo Perfil Restrito.'
                          : 'As publicações deste membro aparecerão aqui.'}
                      </p>
                    </div>
                  ) : (
                    posts.map((post) => {
                      const totalReactions = Object.values(post.reactions || {}).length;
                      const userReaction = currentUser?.id ? post.reactions?.[currentUser.id] : undefined;

                      return (
                        <div
                          key={post.id}
                          className="rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-md p-4 space-y-3"
                        >
                          {/* Post Header */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <img
                                src={post.authorAvatar || '/fenix_chamas.gif'}
                                alt={post.authorName}
                                className="h-10 w-10 rounded-full object-cover border border-[#1E293B]"
                              />
                              <div>
                                <h4 className="text-xs font-bold text-white">
                                  {post.authorName} {post.authorLastName}
                                </h4>
                                <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                                  <span>{new Date(post.createdAt).toLocaleString('pt-BR')}</span>
                                  <span>•</span>
                                  {post.privacy === 'friends' ? (
                                    <Users className="h-3 w-3 text-slate-400" title="Amigos" />
                                  ) : (
                                    <Globe className="h-3 w-3 text-slate-400" title="Público" />
                                  )}
                                </div>
                              </div>
                            </div>
                            <button className="text-slate-400 hover:text-white p-1">
                              <MoreHorizontal className="h-4 w-4" />
                            </button>
                          </div>

                          {/* Post Content */}
                          {post.content && (
                            <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                              {post.content}
                            </p>
                          )}

                          {/* Media preview */}
                          {post.mediaUrl && (
                            <div className="rounded-xl overflow-hidden border border-[#1E293B] max-h-96 bg-black flex items-center justify-center">
                              {post.mediaType === 'video' ? (
                                <video src={post.mediaUrl} controls className="w-full max-h-96 object-contain" />
                              ) : post.mediaType === 'audio' ? (
                                <audio src={post.mediaUrl} controls className="w-full p-4" />
                              ) : (
                                <img
                                  src={post.mediaUrl}
                                  alt="Mídia da postagem"
                                  className="w-full object-contain max-h-96"
                                />
                              )}
                            </div>
                          )}

                          {/* Reaction Counter & Comment Count */}
                          <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-[#1E293B] pb-2 pt-1">
                            <div className="flex items-center gap-1">
                              {totalReactions > 0 && (
                                <>
                                  <span className="flex -space-x-1">
                                    <span className="inline-block rounded-full bg-blue-500 p-0.5 text-[9px] text-white">
                                      👍
                                    </span>
                                    <span className="inline-block rounded-full bg-red-500 p-0.5 text-[9px] text-white">
                                      ❤️
                                    </span>
                                  </span>
                                  <span>{totalReactions}</span>
                                </>
                              )}
                            </div>
                            <span>{post.comments?.length || 0} comentários</span>
                          </div>

                          {/* Interactive Action Bar (Like, Comment, Share) */}
                          <div className="relative flex items-center justify-between pt-1 border-b border-[#1E293B] pb-2 text-xs">
                            {/* Reaction Picker Popover */}
                            {activeReactionPicker === post.id && (
                              <div className="absolute -top-10 left-0 flex items-center gap-1.5 rounded-full bg-[#0A0C10] border border-[#22D3EE]/40 p-1.5 shadow-2xl z-20 animate-in fade-in">
                                {(['like', 'love', 'care', 'haha', 'wow', 'sad', 'angry'] as SocialReactionType[]).map(
                                  (r) => (
                                    <button
                                      key={r}
                                      onClick={() => handleReact(post.id, r)}
                                      className="text-lg hover:scale-130 transition-transform p-1"
                                      title={reactionEmojis[r].label}
                                    >
                                      {reactionEmojis[r].emoji}
                                    </button>
                                  )
                                )}
                              </div>
                            )}

                            <button
                              onClick={() => {
                                if (activeReactionPicker === post.id) {
                                  setActiveReactionPicker(null);
                                } else {
                                  setActiveReactionPicker(post.id);
                                }
                              }}
                              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-bold transition ${
                                userReaction
                                  ? reactionEmojis[userReaction].color
                                  : 'text-slate-400 hover:bg-[#1E293B]'
                              }`}
                            >
                              <span>{userReaction ? reactionEmojis[userReaction].emoji : '👍'}</span>
                              <span>{userReaction ? reactionEmojis[userReaction].label : 'Curtir'}</span>
                            </button>

                            <button
                              onClick={() => {
                                const input = document.getElementById(`comment-input-${post.id}`);
                                input?.focus();
                              }}
                              className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-slate-400 hover:bg-[#1E293B] transition"
                            >
                              <MessageSquare className="h-4 w-4" />
                              <span>Comentar</span>
                            </button>

                            <button
                              onClick={() => alert('Link da publicação copiado para a área de transferência!')}
                              className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-slate-400 hover:bg-[#1E293B] transition"
                            >
                              <Share2 className="h-4 w-4" />
                              <span>Compartilhar</span>
                            </button>
                          </div>

                          {/* Comments List */}
                          <div className="space-y-2 pt-1">
                            {post.comments?.map((comment) => (
                              <div key={comment.id} className="flex items-start gap-2 text-xs">
                                <img
                                  src={comment.authorAvatar || '/fenix_chamas.gif'}
                                  alt={comment.authorName}
                                  className="h-7 w-7 rounded-full object-cover"
                                />
                                <div className="rounded-2xl bg-[#090D16] border border-[#1E293B] px-3 py-2 flex-1">
                                  <span className="font-bold text-white block">
                                    {comment.authorName}
                                  </span>
                                  <span className="text-slate-300">{comment.content}</span>
                                </div>
                              </div>
                            ))}

                            {/* Comment Input */}
                            <div className="flex items-center gap-2 pt-2">
                              <input
                                id={`comment-input-${post.id}`}
                                type="text"
                                value={commentInputs[post.id] || ''}
                                onChange={(e) =>
                                  setCommentInputs({ ...commentInputs, [post.id]: e.target.value })
                                }
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') handleComment(post.id);
                                }}
                                placeholder="Escreva um comentário..."
                                className="w-full rounded-full bg-[#090D16] border border-[#1E293B] px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#22D3EE]"
                              />
                              <button
                                onClick={() => handleComment(post.id)}
                                className="rounded-full bg-[#22D3EE] p-1.5 text-black hover:brightness-110"
                              >
                                <Send className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </>
            )}

            {/* TAB: SOBRE */}
            {activeTab === 'about' && (
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-md space-y-6">
                <h3 className="text-base font-black text-white border-b border-[#1E293B] pb-3">
                  Informações Gerais e Biografia
                </h3>

                <div className="space-y-4 text-xs">
                  <div>
                    <h4 className="font-bold text-[#22D3EE] uppercase tracking-wider text-[11px] mb-1">
                      Biografia
                    </h4>
                    <p className="text-slate-300">{user.bio || 'Nenhuma biografia configurada.'}</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div className="p-3 rounded-xl bg-[#090D16] border border-[#1E293B]">
                      <span className="text-[10px] text-slate-500 block uppercase">Cidade Atual</span>
                      <span className="font-bold text-white">{user.city || 'Não informado'}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#090D16] border border-[#1E293B]">
                      <span className="text-[10px] text-slate-500 block uppercase">Profissão / Trabalho</span>
                      <span className="font-bold text-white">{user.work || 'Não informado'}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#090D16] border border-[#1E293B]">
                      <span className="text-[10px] text-slate-500 block uppercase">Educação</span>
                      <span className="font-bold text-white">{user.education || 'Não informado'}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-[#090D16] border border-[#1E293B]">
                      <span className="text-[10px] text-slate-500 block uppercase">Relacionamento</span>
                      <span className="font-bold text-white">{user.relationshipStatus || 'Solteiro(a)'}</span>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-cyan-200">
                    <p className="font-bold text-white mb-1">Privacidade do Perfil:</p>
                    <p className="text-slate-400">
                      Este perfil está atualmente no modo{' '}
                      <strong className="text-[#22D3EE]">
                        {user.profilePrivacy === 'restricted' ? 'Restrito (Privado)' : 'Público'}
                      </strong>
                      . Você pode alternar esta configuração a qualquer momento na aba Configurações de Privacidade.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: AMIGOS */}
            {activeTab === 'friends' && (
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-md space-y-4">
                <h3 className="text-base font-black text-white border-b border-[#1E293B] pb-3">
                  Amigos de {user.name} ({totalFriends})
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {friends.map((f) => (
                    <div
                      key={f.id}
                      className="flex items-center gap-3 p-3 rounded-xl bg-[#090D16] border border-[#1E293B]"
                    >
                      <img
                        src={f.avatarUrl || '/fenix_chamas.gif'}
                        alt={f.name}
                        className="h-12 w-12 rounded-xl object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-white truncate">{f.name}</p>
                        <p className="text-[10px] text-emerald-400">Amigo confirmado</p>
                      </div>
                      <button
                        onClick={() => onOpenLiveChatRoom && onOpenLiveChatRoom()}
                        className="rounded-lg bg-[#1E293B] p-2 text-[#22D3EE] hover:bg-[#334155]"
                        title="Conversar no Chat"
                      >
                        <MessageSquare className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: FOTOS */}
            {activeTab === 'photos' && (
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-md space-y-4">
                <h3 className="text-base font-black text-white border-b border-[#1E293B] pb-3">
                  Galeria de Fotos
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="aspect-square rounded-xl overflow-hidden bg-slate-800 border border-[#1E293B]">
                    <img
                      src={user.avatarUrl || '/fenix_chamas.gif'}
                      alt="Avatar"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="aspect-square rounded-xl overflow-hidden bg-slate-800 border border-[#1E293B]">
                    <img
                      src={user.coverUrl || '/fenix_chamas.gif'}
                      alt="Capa"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  {posts
                    .filter((p) => p.mediaUrl && p.mediaType === 'image')
                    .map((p) => (
                      <div
                        key={p.id}
                        className="aspect-square rounded-xl overflow-hidden bg-slate-800 border border-[#1E293B]"
                      >
                        <img src={p.mediaUrl} alt="Post" className="h-full w-full object-cover" />
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* TAB: LISTA FIND MATCH - PASQUARED */}
            {activeTab === 'findmatch' && isOwner && currentUser && (
              <PasquaredMatchTab currentUser={currentUser} onOpenProfile={onOpenSocialProfile} />
            )}
            {activeTab === 'findmatch' && !isOwner && (
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 text-xs text-slate-400">A Lista find Match é privada e visível somente ao proprietário do perfil.</div>
            )}

            {/* TAB: PASQCOIN & LIVE CHAT */}
            {activeTab === 'pasqcoin' && (
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-md space-y-5">
                <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
                  <div>
                    <h3 className="text-base font-black text-white flex items-center gap-2">
                      <Coins className="h-5 w-5 text-amber-400" />
                      <span>Pasqcoins & Contagem Progressiva no Chat</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Moeda virtual oficial que vale tempo de conexão e desbloqueia recursos do chat
                    </p>
                  </div>
                  {onOpenPasqcoinShop && (
                    <button
                      onClick={onOpenPasqcoinShop}
                      className="rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 px-4 py-2 text-xs font-black text-black hover:brightness-110"
                    >
                      Adquirir Moedas
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-[#090D16] border border-amber-500/30">
                    <span className="text-[11px] text-amber-400/90 font-bold block uppercase tracking-wider">
                      Saldo Atual de Pasqcoin
                    </span>
                    <span className="text-3xl font-black text-white mt-1 block">
                      {Number(user.pasqcoins || 0).toFixed(6)}{' '}
                      <span className="text-sm font-normal text-amber-400">PASQ</span>
                    </span>
                    <p className="text-[11px] text-slate-400 mt-2">
                      Cada Pasqcoin equivale a tempo cronometrado de conexão e live chat.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#090D16] border border-cyan-500/30">
                    <span className="text-[11px] text-cyan-400/90 font-bold block uppercase tracking-wider">
                      Regra da Contagem Progressiva
                    </span>
                    <span className="text-sm font-bold text-white mt-1 block">
                      Inicia ao enviar a 1ª Mensagem
                    </span>
                    <p className="text-[11px] text-slate-400 mt-2">
                      Ao enviar sua primeira mensagem em qualquer sala, o cronômetro progressivo de 1 até os segundos estipulados por Pasqcoin é ativado no painel administrativo do chat.
                    </p>
                  </div>
                </div>

                <div className="rounded-xl bg-cyan-950/40 border border-cyan-500/20 p-4 text-xs text-cyan-200 flex items-start gap-3">
                  <Radio className="h-5 w-5 text-[#22D3EE] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-white">Live Chat, Voz, Vídeo e Arquivos</h5>
                    <p className="text-slate-300 mt-1">
                      A rede social é 100% sincronizada com o Live Chat. Todos os participantes possuem perfil social, podem enviar fotos, áudios e vídeos diretamente nos canais de texto ou participar de conferências audiovisuais simultâneas.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: PRIVACIDADE */}
            {activeTab === 'privacy' && (
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-md space-y-6">
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <Shield className="h-5 w-5 text-[#22D3EE]" />
                    <span>Configurações de Privacidade do Perfil</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Defina se o seu perfil na rede social é Aberto/Público ou Restrito/Privado aos amigos.
                  </p>
                </div>

                {privacyMsg && (
                  <div className="rounded-xl bg-emerald-500/20 border border-emerald-500/30 p-3 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{privacyMsg}</span>
                  </div>
                )}

                {isOwner ? (
                  <div className="space-y-4">
                    <div
                      onClick={() => handleSavePrivacy('public')}
                      className={`cursor-pointer rounded-2xl p-4 border transition ${
                        privacySetting === 'public'
                          ? 'border-[#22D3EE] bg-[#22D3EE]/10'
                          : 'border-[#1E293B] bg-[#090D16] hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Globe className="h-5 w-5 text-[#22D3EE]" />
                        <div>
                          <h4 className="text-xs font-bold text-white">Perfil Público (Padrão)</h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Qualquer usuário cadastrado no chamasso live chat pode ver suas publicações, fotos e biografia.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div
                      onClick={() => handleSavePrivacy('restricted')}
                      className={`cursor-pointer rounded-2xl p-4 border transition ${
                        privacySetting === 'restricted'
                          ? 'border-amber-400 bg-amber-500/10'
                          : 'border-[#1E293B] bg-[#090D16] hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Lock className="h-5 w-5 text-amber-400" />
                        <div>
                          <h4 className="text-xs font-bold text-white">
                            Perfil Restrito (Modo Privado)
                          </h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Apenas seus amigos adicionados e confirmados podem ver suas publicações completas, amigos e fotos. Pessoas de fora verão apenas a apresentação básica com o selo de perfil restrito.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    Apenas o titular deste perfil pode modificar as regras de visibilidade.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* EDIT PROFILE MODAL */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
              <h3 className="text-base font-black text-white">Editar Perfil da Rede Social</h3>
              <button
                onClick={() => setIsEditingProfile(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Nome</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Sobrenome</label>
                  <input
                    type="text"
                    value={editLastName}
                    onChange={(e) => setEditLastName(e.target.value)}
                    className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Biografia</label>
                <textarea
                  rows={2}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  placeholder="Conte um pouco sobre você..."
                  className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Cidade</label>
                  <input
                    type="text"
                    value={editCity}
                    onChange={(e) => setEditCity(e.target.value)}
                    placeholder="Ex: São Paulo, SP"
                    className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Trabalho</label>
                  <input
                    type="text"
                    value={editWork}
                    onChange={(e) => setEditWork(e.target.value)}
                    placeholder="Ex: Engenheiro de Software"
                    className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Educação</label>
                  <input
                    type="text"
                    value={editEducation}
                    onChange={(e) => setEditEducation(e.target.value)}
                    placeholder="Ex: USP, Harvard, etc."
                    className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Status de Relacionamento</label>
                  <select
                    value={editRelationship}
                    onChange={(e) => setEditRelationship(e.target.value)}
                    className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                  >
                    <option value="Solteiro(a)">Solteiro(a)</option>
                    <option value="Em um relacionamento sério">Em um relacionamento sério</option>
                    <option value="Noivo(a)">Noivo(a)</option>
                    <option value="Casado(a)">Casado(a)</option>
                    <option value="É complicado">É complicado</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">URL da Foto de Capa</label>
                <input
                  type="url"
                  value={editCoverUrl}
                  onChange={(e) => setEditCoverUrl(e.target.value)}
                  placeholder="https://exemplo.com/capa.jpg"
                  className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">URL da Foto de Perfil (Avatar)</label>
                <input
                  type="url"
                  value={editAvatarUrl}
                  onChange={(e) => setEditAvatarUrl(e.target.value)}
                  placeholder="https://exemplo.com/avatar.jpg"
                  className="w-full rounded-xl bg-[#090D16] border border-[#1E293B] px-3 py-2 text-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 border-t border-[#1E293B] pt-4">
              <button
                onClick={() => setIsEditingProfile(false)}
                className="rounded-xl bg-[#1E293B] px-4 py-2 text-xs font-bold text-slate-300 hover:bg-[#334155]"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveProfile}
                className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-blue-500 px-5 py-2 text-xs font-black text-black hover:brightness-110"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE NICKNAME */}
      {isOwner && currentUser && (
        <NicknameModal
          currentUser={{ ...currentUser, ...(data?.user || {}) }}
          isOpen={showNicknameModal}
          onClose={() => setShowNicknameModal(false)}
          onNicknameUpdated={(updatedUser) => {
            if (data) {
              setData({
                ...data,
                user: {
                  ...data.user,
                  nickname: updatedUser.nickname,
                  nicknameType: updatedUser.nicknameType,
                },
              });
            }
          }}
        />
      )}
    </div>
  );
};
