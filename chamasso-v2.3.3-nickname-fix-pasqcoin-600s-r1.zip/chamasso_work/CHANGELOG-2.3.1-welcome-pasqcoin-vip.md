# Chamasso v2.3.1 — Bônus de cadastro e VIP

- Novo cadastro recebe uma única contemplação equivalente a 60 minutos de uso (60 PASQ no padrão 1 PASQ/minuto), válida para consumo tarifado de texto, áudio e vídeo.
- Benefício controlado pelo CPF e concedido somente na criação de uma conta nova; CPF já contemplado não recebe novamente.
- Nova tabela PostgreSQL `new_registration_pasqcoin_bonus`, com CPF como chave primária.
- Nova coluna `users.is_free_access` para persistir o status VIP.
- Corrigida a tela Financeiro > Clientes: frontend usava endpoint e nomes de campos incompatíveis com o backend (`hasFreeAccess` vs `isFreeAccess`).
- Botão agora alterna entre "Tornar VIP (uso livre)" e "Remover VIP", persistindo `isFreeAccess`.
