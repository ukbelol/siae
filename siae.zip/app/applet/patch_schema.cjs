const fs = require('fs');
let file = 'src/lib/schema.ts';
let t = fs.readFileSync(file, 'utf8');

const newTables = `
CREATE TABLE IF NOT EXISTS mercadopago_config (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  access_token TEXT,
  public_key TEXT,
  redirect_url TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  stock INTEGER DEFAULT 0,
  image_url TEXT,
  status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  user_id INTEGER NOT NULL,
  house_id INTEGER,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'paid', 'cancelled', 'delivered')),
  payment_method TEXT DEFAULT 'pix',
  payment_id TEXT,
  qr_code TEXT,
  qr_code_base64 TEXT,
  ticket_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);
`;

t = t.replace(';\n`;', `;\n${newTables}\n\`;`);
fs.writeFileSync(file, t);
console.log('Schema updated');
