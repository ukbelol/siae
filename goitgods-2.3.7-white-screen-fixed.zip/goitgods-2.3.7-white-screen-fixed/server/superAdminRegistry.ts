import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export type AgentRole =
  | 'RESEARCH_ORCHESTRATOR'
  | 'PASQUARED_REASONER'
  | 'SOURCE_ANALYST'
  | 'ARES_CRITIC'
  | 'HADES_RISK'
  | 'ZEUS_ARBITER'
  | 'BOOK_ARCHITECT'
  | 'BOOK_WRITER'
  | 'FACT_CHECKER';

export interface FoundryAgentConfig {
  id: string;
  role: AgentRole;
  label: string;
  enabled: boolean;
  agentType: 'PROMPT_AGENT' | 'HOSTED_AGENT' | 'MODEL_DIRECT';
  projectEndpoint: string;
  agentName?: string;
  agentId?: string;
  modelDeployment?: string;
  apiVersion?: string;
  authMode: 'API_KEY' | 'ENTRA_ID';
  secretRef?: string;
  instructions?: string;
  lastTestAt?: string;
  lastTestOk?: boolean;
  lastTestMessage?: string;
  remoteVersion?: string;
  remoteStatus?: 'LOCAL' | 'CREATED' | 'ACTIVE' | 'ERROR';
  lastPublishedAt?: string;
}

export type KnowledgeProviderType = 'CROSSREF' | 'OPENALEX' | 'PUBMED' | 'EUROPE_PMC' | 'REST_JSON' | 'CUSTOM';

export interface KnowledgeBaseConfig {
  id: string;
  name: string;
  provider: KnowledgeProviderType;
  domains: string[];
  enabled: boolean;
  baseUrl: string;
  authMode: 'NONE' | 'API_KEY' | 'BEARER';
  secretRef?: string;
  queryTemplate?: string;
  syncMode: 'METADATA' | 'FULL_TEXT_WHEN_ALLOWED';
  lastSyncAt?: string;
  lastSyncStatus?: 'NEVER' | 'RUNNING' | 'OK' | 'ERROR';
  lastSyncMessage?: string;
  lastItemCount?: number;
}

export interface AdminRegistryState {
  foundry: {
    tenantId?: string;
    subscriptionId?: string;
    resourceGroup?: string;
    projectName?: string;
    defaultProjectEndpoint?: string;
    defaultAuthMode: 'API_KEY' | 'ENTRA_ID';
    clientId?: string;
    defaultModelDeployment?: string;
    hasClientSecret?: boolean;
  };
  agents: FoundryAgentConfig[];
  knowledgeBases: KnowledgeBaseConfig[];
  policies: {
    requireSourceForFactualClaim: boolean;
    minimumIndependentSources: number;
    rejectInventedCitations: boolean;
    allowMedicalDiagnosis: boolean;
    allowLegalOpinionAsProfessionalAdvice: boolean;
    syncOnStartup: boolean;
  };
}

const DATA_DIR = path.join(process.cwd(), 'data');
const STATE_FILE = path.join(DATA_DIR, 'super_admin_registry.json');
const SECRET_FILE = path.join(DATA_DIR, 'super_admin_secrets.json');

const defaultAgents: FoundryAgentConfig[] = [
  { id: 'agent_research', role: 'RESEARCH_ORCHESTRATOR', label: 'Research Orchestrator', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Planeja a anamnese investigativa e decide quais fontes consultar.' },
  { id: 'agent_pasq', role: 'PASQUARED_REASONER', label: 'PASQUARED Reasoner', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Estrutura premissas, claims, evidências, incertezas e relações.' },
  { id: 'agent_source', role: 'SOURCE_ANALYST', label: 'Source Analyst / Apollo', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Avalia qualidade, independência e rastreabilidade das fontes.' },
  { id: 'agent_ares', role: 'ARES_CRITIC', label: 'ARES Critic', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Tenta refutar premissas e procura contraevidências.' },
  { id: 'agent_hades', role: 'HADES_RISK', label: 'HADES Risk Auditor', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Audita risco, contaminação, lacunas e excesso de confiança.' },
  { id: 'agent_zeus', role: 'ZEUS_ARBITER', label: 'ZEUS Epistemic Arbiter', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Arbitra evidências e classifica o estado epistemológico.' },
  { id: 'agent_architect', role: 'BOOK_ARCHITECT', label: 'Book Architect', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Converte o ledger verificado em estrutura de trabalho/livro.' },
  { id: 'agent_writer', role: 'BOOK_WRITER', label: 'Book Writer', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Redige apenas com base no ledger e no pacote de pesquisa do capítulo.' },
  { id: 'agent_fact', role: 'FACT_CHECKER', label: 'Fact Checker', enabled: true, agentType: 'PROMPT_AGENT', projectEndpoint: '', authMode: 'ENTRA_ID', instructions: 'Confere afirmações, referências, citações e consistência final.' },
];

const defaultKnowledgeBases: KnowledgeBaseConfig[] = [
  { id: 'kb_crossref', name: 'Crossref', provider: 'CROSSREF', domains: ['MULTIDISCIPLINAR'], enabled: true, baseUrl: 'https://api.crossref.org', authMode: 'NONE', syncMode: 'METADATA', lastSyncStatus: 'NEVER' },
  { id: 'kb_openalex', name: 'OpenAlex', provider: 'OPENALEX', domains: ['MULTIDISCIPLINAR'], enabled: true, baseUrl: 'https://api.openalex.org', authMode: 'NONE', syncMode: 'METADATA', lastSyncStatus: 'NEVER' },
  { id: 'kb_pubmed', name: 'PubMed / NCBI', provider: 'PUBMED', domains: ['MEDICINA','RADIOLOGIA','PSICOLOGIA','CIENCIAS_BIOLOGICAS'], enabled: true, baseUrl: 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils', authMode: 'API_KEY', syncMode: 'METADATA', lastSyncStatus: 'NEVER' },
  { id: 'kb_europepmc', name: 'Europe PMC', provider: 'EUROPE_PMC', domains: ['MEDICINA','RADIOLOGIA','CIENCIAS_BIOLOGICAS'], enabled: true, baseUrl: 'https://www.ebi.ac.uk/europepmc/webservices/rest', authMode: 'NONE', syncMode: 'METADATA', lastSyncStatus: 'NEVER' },
];

class SuperAdminRegistry {
  private state: AdminRegistryState;
  private secrets: Record<string,string> = {};

  constructor() {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    this.state = this.loadState();
    this.secrets = this.loadSecrets();
  }

  private loadState(): AdminRegistryState {
    try { if (fs.existsSync(STATE_FILE)) return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch {}
    return {
      foundry: { defaultAuthMode: 'ENTRA_ID' },
      agents: defaultAgents,
      knowledgeBases: defaultKnowledgeBases,
      policies: {
        requireSourceForFactualClaim: true,
        minimumIndependentSources: 2,
        rejectInventedCitations: true,
        allowMedicalDiagnosis: false,
        allowLegalOpinionAsProfessionalAdvice: false,
        syncOnStartup: false,
      },
    };
  }

  private loadSecrets(): Record<string,string> {
    try { if (fs.existsSync(SECRET_FILE)) return JSON.parse(fs.readFileSync(SECRET_FILE, 'utf8')); } catch {}
    return {};
  }

  private persist() {
    fs.writeFileSync(STATE_FILE, JSON.stringify(this.state, null, 2));
    fs.writeFileSync(SECRET_FILE, JSON.stringify(this.secrets, null, 2), { mode: 0o600 });
  }

  getState() {
    return {
      ...this.state,
      foundry: { ...this.state.foundry, hasClientSecret: !!this.secrets['foundry_client_secret'] },
      agents: this.state.agents.map(a => ({ ...a, hasSecret: !!(a.secretRef && this.secrets[a.secretRef]), secretRef: a.secretRef ? 'configured' : undefined })),
      knowledgeBases: this.state.knowledgeBases.map(k => ({ ...k, hasSecret: !!(k.secretRef && this.secrets[k.secretRef]), secretRef: k.secretRef ? 'configured' : undefined })),
    };
  }

  updateFoundry(patch: Partial<AdminRegistryState['foundry']> & { clientSecret?: string }) {
    const { clientSecret, ...safePatch } = patch as any;
    if (clientSecret) this.secrets['foundry_client_secret'] = clientSecret;
    this.state.foundry = { ...this.state.foundry, ...safePatch }; this.persist(); return this.getState().foundry;
  }

  getFoundryRuntimeConfig() { return { ...this.state.foundry, clientSecret: this.secrets['foundry_client_secret'] }; }
  getAgentRuntime(id: string) { return this.state.agents.find(a => a.id === id); }
  getAllAgentRuntime() { return this.state.agents; }
  markAgentProvisioned(id: string, patch: Partial<FoundryAgentConfig>) { const a=this.state.agents.find(x=>x.id===id); if(!a) throw new Error('Agente não encontrado'); Object.assign(a, patch); this.persist(); return this.getState().agents.find((x:any)=>x.id===id); }
  updatePolicies(patch: Partial<AdminRegistryState['policies']>) { this.state.policies = { ...this.state.policies, ...patch }; this.persist(); return this.state.policies; }

  upsertAgent(input: Partial<FoundryAgentConfig> & { role: AgentRole; label: string }) {
    const id = input.id || `agent_${crypto.randomUUID()}`;
    const current = this.state.agents.find(a => a.id === id);
    const next: FoundryAgentConfig = {
      id, role: input.role, label: input.label, enabled: input.enabled ?? true,
      agentType: input.agentType || 'PROMPT_AGENT', projectEndpoint: input.projectEndpoint || this.state.foundry.defaultProjectEndpoint || '',
      agentName: input.agentName, agentId: input.agentId, modelDeployment: input.modelDeployment,
      apiVersion: input.apiVersion || 'v1', authMode: input.authMode || this.state.foundry.defaultAuthMode,
      secretRef: current?.secretRef, instructions: input.instructions || current?.instructions,
    };
    if ((input as any).secret) { next.secretRef = `secret_agent_${id}`; this.secrets[next.secretRef] = String((input as any).secret); }
    const idx = this.state.agents.findIndex(a => a.id === id);
    if (idx >= 0) this.state.agents[idx] = { ...this.state.agents[idx], ...next }; else this.state.agents.push(next);
    this.persist(); return this.getState().agents.find((a:any) => a.id === id);
  }

  deleteAgent(id: string) { const a = this.state.agents.find(x => x.id === id); if (a?.secretRef) delete this.secrets[a.secretRef]; this.state.agents = this.state.agents.filter(x => x.id !== id); this.persist(); }

  upsertKnowledgeBase(input: Partial<KnowledgeBaseConfig> & { name: string; provider: KnowledgeProviderType; baseUrl: string }) {
    const id = input.id || `kb_${crypto.randomUUID()}`; const current = this.state.knowledgeBases.find(k => k.id === id);
    const next: KnowledgeBaseConfig = {
      id, name: input.name, provider: input.provider, domains: input.domains || ['MULTIDISCIPLINAR'], enabled: input.enabled ?? true,
      baseUrl: input.baseUrl, authMode: input.authMode || 'NONE', secretRef: current?.secretRef, queryTemplate: input.queryTemplate,
      syncMode: input.syncMode || 'METADATA', lastSyncAt: current?.lastSyncAt, lastSyncStatus: current?.lastSyncStatus || 'NEVER', lastSyncMessage: current?.lastSyncMessage, lastItemCount: current?.lastItemCount,
    };
    if ((input as any).secret) { next.secretRef = `secret_kb_${id}`; this.secrets[next.secretRef] = String((input as any).secret); }
    const idx = this.state.knowledgeBases.findIndex(k => k.id === id); if (idx >= 0) this.state.knowledgeBases[idx] = next; else this.state.knowledgeBases.push(next);
    this.persist(); return this.getState().knowledgeBases.find((k:any) => k.id === id);
  }

  deleteKnowledgeBase(id: string) { const k = this.state.knowledgeBases.find(x => x.id === id); if (k?.secretRef) delete this.secrets[k.secretRef]; this.state.knowledgeBases = this.state.knowledgeBases.filter(x => x.id !== id); this.persist(); }

  async syncKnowledgeBase(id: string) {
    const kb = this.state.knowledgeBases.find(k => k.id === id); if (!kb) throw new Error('Base não encontrada');
    kb.lastSyncStatus = 'RUNNING'; this.persist();
    try {
      let url = kb.baseUrl;
      if (kb.provider === 'CROSSREF') url += '/works?query=science&rows=1';
      else if (kb.provider === 'OPENALEX') url += '/works?search=science&per-page=1';
      else if (kb.provider === 'PUBMED') url += '/esearch.fcgi?db=pubmed&term=science&retmax=1&retmode=json';
      else if (kb.provider === 'EUROPE_PMC') url += '/search?query=science&pageSize=1&format=json';
      const headers: Record<string,string> = { 'Accept': 'application/json', 'User-Agent': 'PASQUARED-GOITGODS/2.2' };
      const secret = kb.secretRef ? this.secrets[kb.secretRef] : undefined;
      if (secret && kb.authMode === 'BEARER') headers.Authorization = `Bearer ${secret}`;
      if (secret && kb.authMode === 'API_KEY' && kb.provider === 'PUBMED') url += `&api_key=${encodeURIComponent(secret)}`;
      else if (secret && kb.authMode === 'API_KEY') headers['x-api-key'] = secret;
      const response = await fetch(url, { headers, signal: AbortSignal.timeout(12000) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body: any = await response.json().catch(() => ({}));
      kb.lastItemCount = Number(body?.message?.['total-results'] ?? body?.meta?.count ?? body?.esearchresult?.count ?? body?.hitCount ?? 1);
      kb.lastSyncAt = new Date().toISOString(); kb.lastSyncStatus = 'OK'; kb.lastSyncMessage = 'Conector validado e metadados acessíveis.';
    } catch (e:any) { kb.lastSyncAt = new Date().toISOString(); kb.lastSyncStatus = 'ERROR'; kb.lastSyncMessage = e?.message || 'Falha de sincronização'; }
    this.persist(); return this.getState().knowledgeBases.find((k:any) => k.id === id);
  }

  async syncAll() { const results = []; for (const kb of this.state.knowledgeBases.filter(k => k.enabled)) results.push(await this.syncKnowledgeBase(kb.id)); return results; }
}

export const superAdminRegistry = new SuperAdminRegistry();
