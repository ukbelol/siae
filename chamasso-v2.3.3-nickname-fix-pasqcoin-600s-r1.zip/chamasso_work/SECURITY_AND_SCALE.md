# Chamasso Live Chat — Segurança, WebRTC e Escala

## O que mudou nesta revisão

- Senhas de usuário usam `scrypt` com salt individual. Hashes SHA-256 legados são migrados automaticamente no próximo login válido.
- Super Admin não possui mais senha fixa no código, SQL, interface ou JSON. A credencial é provisionada por `.env`.
- Sessões são assinadas (HMAC-SHA256) e entregues em cookie `HttpOnly`, `SameSite=Lax` e `Secure` em produção.
- Todas as rotas `/api/admin/*` exigem sessão `SUPER_ADMIN`.
- WebSocket não confia mais em `userId`, `userName` ou `isModerator` enviados pelo navegador; a identidade vem da sessão.
- Mutações da API exigem sessão autenticada, salvo cadastro/login e webhook de pagamento.
- Videoconferência clássica agora cria `RTCPeerConnection`, negocia SDP/ICE, recebe mídia remota e substitui a faixa de vídeo durante compartilhamento de tela.
- Configuração ICE vem de `/api/webrtc/config`; STUN e TURN são controlados por ambiente.
- Mensagens de salas passam a ser persistidas no armazenamento durável local (limite de 1000 mensagens por sala), além das estruturas já persistidas.
- Instalador provisiona Redis e Coturn e gera segredos únicos de sessão, banco, TURN e Super Admin.
- PM2 foi mantido em uma única instância no modo P2P para preservar consistência do estado WebSocket. Horizontalização deve usar Redis Pub/Sub + estado compartilhado e, para vídeo em escala, SFU.

## Arquitetura recomendada para lançamento

Apache/HTTPS -> Node/Express + WebSocket -> PostgreSQL/armazenamento persistente
                                      -> Coturn (STUN/TURN)
                                      -> Redis (cache/presença/pubsub futuro)

No modo atual, WebRTC é P2P e recomendado para salas pequenas. Para muitas câmeras simultâneas, use `WEBRTC_MODE=sfu` e integre LiveKit, mediasoup ou outro SFU. O endpoint `/api/webrtc/config` já expõe `SFU_URL` para essa evolução.

## Variáveis importantes

Consulte `.env.example`. Nunca versionar `.env` real.

- `SESSION_SECRET`
- `SUPER_ADMIN_EMAIL`
- `SUPER_ADMIN_PASSWORD` ou hash gerenciado fora do repositório
- `PGPASSWORD`
- `TURN_URLS`, `TURN_USERNAME`, `TURN_PASSWORD`
- `REDIS_URL`
- `SFU_URL`

## Antes de inaugurar

1. Rotacione todas as credenciais que já tenham aparecido em versões anteriores do projeto, especialmente Supabase, banco e Super Admin.
2. Aponte `chamasso.pasquared.space` para o servidor e confirme HTTPS válido.
3. Teste câmera/áudio entre dois dispositivos em redes diferentes (por exemplo, Wi-Fi e 5G) para validar TURN.
4. Teste login de usuário, 2FA, logout e expiração de sessão.
5. Teste que `/api/admin/*` retorna 403 sem sessão administrativa.
6. Faça backup do diretório `data/` e do PostgreSQL.
7. Para salas acima de ~4–6 câmeras simultâneas, planeje SFU antes de crescimento de tráfego.
