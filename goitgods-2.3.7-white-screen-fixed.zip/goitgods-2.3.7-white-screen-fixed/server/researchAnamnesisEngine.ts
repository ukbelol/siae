import { pasquaredOrchestrator } from './pasquaredOrchestrator';
import type {
  AcademicLevel,
  ResearchAnamnesisInput,
  ResearchAnamnesisQuestion,
  ResearchAnamnesisProtocol,
  ResearchAnamnesisResult,
  PremiseEvaluation,
} from '../src/types';

const LEVEL_DEPTH: Record<AcademicLevel, { rigor: number; language: string; expectedSources: number; method: string }> = {
  'FUNDAMENTAL_I': { rigor: 0.35, language: 'simples, concreta e didática', expectedSources: 3, method: 'pesquisa orientada e comparação básica de fontes' },
  'FUNDAMENTAL_II': { rigor: 0.45, language: 'didática com introdução a conceitos acadêmicos', expectedSources: 4, method: 'pesquisa bibliográfica introdutória, comparação e síntese' },
  'MEDIO': { rigor: 0.58, language: 'acadêmica introdutória', expectedSources: 6, method: 'pesquisa bibliográfica, problema, hipótese, evidências e conclusão' },
  'TECNICO': { rigor: 0.64, language: 'técnica aplicada', expectedSources: 6, method: 'pesquisa aplicada, requisitos, evidências técnicas e validação prática' },
  'GRADUACAO': { rigor: 0.74, language: 'acadêmica formal', expectedSources: 8, method: 'revisão bibliográfica, problema, hipótese, método, análise e discussão' },
  'POS_GRADUACAO': { rigor: 0.82, language: 'acadêmica avançada', expectedSources: 10, method: 'revisão crítica, delimitação metodológica e análise comparativa' },
  'MESTRADO': { rigor: 0.90, language: 'científica avançada', expectedSources: 15, method: 'estado da arte, problema original, método explícito, triangulação e discussão crítica' },
  'DOUTORADO': { rigor: 0.96, language: 'científica especializada', expectedSources: 20, method: 'lacuna original, estado da arte, método reproduzível, triangulação forte e contribuição inédita' },
  'OUTRO': { rigor: 0.65, language: 'adaptada ao público informado', expectedSources: 7, method: 'pesquisa estruturada com validação de evidências' },
};

export class ResearchAnamnesisEngine {
  public getQuestions(input: Partial<ResearchAnamnesisInput> = {}): ResearchAnamnesisQuestion[] {
    const base: ResearchAnamnesisQuestion[] = [
      { id: 'subjectArea', stage: 'IDENTIFICACAO', question: 'Qual é a área do conhecimento ou matéria principal?', required: true, kind: 'text', help: 'Ex.: História, Biologia, Direito, Informática, Matemática.' },
      { id: 'academicLevel', stage: 'IDENTIFICACAO', question: 'Qual é o nível escolar ou acadêmico da pesquisa?', required: true, kind: 'level', help: 'Fundamental, médio, técnico, graduação, pós-graduação, mestrado, doutorado etc.' },
      { id: 'schoolYear', stage: 'IDENTIFICACAO', question: 'Qual é o ano/série, semestre ou período, quando aplicável?', required: false, kind: 'text' },
      { id: 'topic', stage: 'DELIMITACAO', question: 'Qual é o tema central que você deseja pesquisar?', required: true, kind: 'textarea' },
      { id: 'problem', stage: 'DELIMITACAO', question: 'Qual pergunta ou problema a pesquisa deve responder?', required: true, kind: 'textarea', help: 'Prefira uma pergunta investigável, específica e não apenas descritiva.' },
      { id: 'scope', stage: 'DELIMITACAO', question: 'Qual recorte deseja usar (tempo, lugar, população, tecnologia, obra ou contexto)?', required: false, kind: 'textarea' },
      { id: 'generalObjective', stage: 'OBJETIVOS', question: 'Qual é o objetivo geral do trabalho?', required: true, kind: 'textarea' },
      { id: 'specificObjectives', stage: 'OBJETIVOS', question: 'Quais objetivos específicos precisam ser cumpridos?', required: false, kind: 'textarea', help: 'Separe por ponto e vírgula ou por linha.' },
      { id: 'premises', stage: 'PREMISSAS', question: 'Quais hipóteses, premissas ou ideias iniciais você acredita serem verdadeiras?', required: false, kind: 'textarea', help: 'O GOITGODS tentará confirmá-las, limitar seu alcance ou refutá-las.' },
      { id: 'knownFacts', stage: 'EVIDENCIAS', question: 'Que fatos, dados, autores ou fontes você já conhece sobre o tema?', required: false, kind: 'textarea' },
      { id: 'sourceRequirements', stage: 'EVIDENCIAS', question: 'Há fontes obrigatórias, autores, bases ou período de publicação exigidos?', required: false, kind: 'textarea' },
      { id: 'methodPreference', stage: 'METODO', question: 'Existe metodologia exigida pelo professor, instituição ou programa?', required: false, kind: 'textarea', help: 'Ex.: bibliográfica, documental, estudo de caso, revisão sistemática, qualitativa, quantitativa.' },
      { id: 'constraints', stage: 'LIMITES', question: 'Quais são os limites do trabalho?', required: false, kind: 'textarea', help: 'Ex.: páginas, palavras, prazo, norma ABNT/APA, fontes permitidas, idioma.' },
      { id: 'outputType', stage: 'ENTREGA', question: 'Qual deve ser o produto final?', required: true, kind: 'select', options: ['Pesquisa escolar', 'Trabalho acadêmico', 'Artigo', 'TCC', 'Monografia', 'Dissertação', 'Tese', 'Relatório técnico', 'Livro/E-book', 'Outro'] },
    ];
    return base;
  }

  public buildProtocol(input: ResearchAnamnesisInput): ResearchAnamnesisProtocol {
    const profile = LEVEL_DEPTH[input.academicLevel] || LEVEL_DEPTH.OUTRO;
    const specificObjectives = this.splitItems(input.specificObjectives);
    const premises = this.splitItems(input.premises);
    const stages = [
      '1. Delimitar tema, problema e recorte.',
      '2. Formular objetivos e premissas testáveis.',
      '3. Definir palavras-chave e estratégia de busca.',
      '4. Levantar fontes primárias, secundárias e bases adequadas à matéria.',
      '5. Avaliar autoria, autoridade, data, relevância e independência das fontes.',
      '6. Extrair claims/evidências e classificá-los epistemologicamente no PASQUARED.',
      '7. Triangular fontes independentes e registrar concordâncias e divergências.',
      '8. Submeter premissas aos especialistas GOITGODS e ao ataque adversarial ARES.',
      '9. Auditar lacunas, vieses e riscos com HADES; calcular MVED e arbitrar com ZEUS.',
      '10. Organizar argumentos, resultados, limitações, conclusão e referências.',
      '11. Revisar coerência, adequação ao nível acadêmico e rastreabilidade das afirmações.',
    ];

    return {
      protocolId: `anam_${Date.now()}`,
      subjectArea: input.subjectArea.trim(),
      academicLevel: input.academicLevel,
      schoolYear: input.schoolYear?.trim() || '',
      topic: input.topic.trim(),
      problem: input.problem.trim(),
      scope: input.scope?.trim() || 'A definir durante a pesquisa',
      generalObjective: input.generalObjective.trim(),
      specificObjectives,
      premises,
      method: input.methodPreference?.trim() || profile.method,
      sourceRequirements: input.sourceRequirements?.trim() || `Priorizar pelo menos ${profile.expectedSources} fontes relevantes e, quando possível, independentes.`,
      constraints: input.constraints?.trim() || '',
      outputType: input.outputType,
      pedagogicalProfile: {
        rigor: profile.rigor,
        language: profile.language,
        expectedMinimumSources: profile.expectedSources,
        requiresOriginalContribution: ['MESTRADO', 'DOUTORADO'].includes(input.academicLevel),
        requiresExplicitMethodology: !['FUNDAMENTAL_I', 'FUNDAMENTAL_II'].includes(input.academicLevel),
      },
      researchStages: stages,
      searchStrategy: this.makeSearchStrategy(input),
    };
  }

  public async evaluate(input: ResearchAnamnesisInput): Promise<ResearchAnamnesisResult> {
    this.validate(input);
    const protocol = this.buildProtocol(input);
    const query = this.composeResearchQuery(protocol);
    const research = await pasquaredOrchestrator.orchestrateResearch(query, [protocol.subjectArea]);
    const premiseEvaluations = this.evaluatePremises(protocol.premises, research.ledger.claims, research.godOutputs);

    return {
      protocol,
      research,
      premiseEvaluations,
      readiness: this.calculateReadiness(input, protocol),
      nextActions: this.makeNextActions(protocol, premiseEvaluations),
    };
  }

  private evaluatePremises(premises: string[], claims: any[], gods: any[]): PremiseEvaluation[] {
    return premises.map((premise, index) => {
      const tokens = this.tokens(premise);
      const related = claims
        .map((c: any) => ({ c, score: this.overlap(tokens, this.tokens(c.claim)) }))
        .sort((a: any, b: any) => b.score - a.score)
        .slice(0, 3);
      const best = related[0];
      const evidenceStrength = best?.score || 0;
      let verdict: PremiseEvaluation['verdict'] = 'INSUFFICIENT_EVIDENCE';
      if (best && evidenceStrength >= 0.28) {
        verdict = ['VERIFIED', 'SUPPORTED'].includes(best.c.status) ? 'SUPPORTED' :
          best.c.status === 'REJECTED' ? 'REFUTED' :
          best.c.status === 'DISPUTED' ? 'DISPUTED' : 'PROVISIONAL';
      }
      const specialistNotes = gods.slice(0, 4).map((g: any) => `${g.god_id}: ${g.reasoning_summary}`);
      return {
        premiseId: `prem_${index + 1}`,
        premise,
        verdict,
        confidence: Number(Math.min(0.95, 0.35 + evidenceStrength * 1.8).toFixed(3)),
        supportingClaimIds: related.filter((x: any) => x.score >= 0.18).map((x: any) => x.c.claim_id),
        counterarguments: gods.flatMap((g: any) => g.counterarguments || []).slice(0, 4),
        uncertainties: best?.c?.uncertainties || ['A premissa precisa de evidência externa mais específica.'],
        specialistNotes,
      };
    });
  }

  private composeResearchQuery(p: ResearchAnamnesisProtocol): string {
    return [
      `Área: ${p.subjectArea}. Nível: ${p.academicLevel}${p.schoolYear ? ` (${p.schoolYear})` : ''}.`,
      `Tema: ${p.topic}.`,
      `Problema de pesquisa: ${p.problem}.`,
      `Recorte: ${p.scope}.`,
      `Objetivo geral: ${p.generalObjective}.`,
      p.specificObjectives.length ? `Objetivos específicos: ${p.specificObjectives.join('; ')}.` : '',
      p.premises.length ? `Premissas a testar: ${p.premises.join('; ')}.` : '',
      `Método esperado: ${p.method}.`,
      `Produza evidências adequadas ao nível ${p.academicLevel}, distinguindo fato, inferência, hipótese, controvérsia e insuficiência de evidência.`
    ].filter(Boolean).join(' ');
  }

  private makeSearchStrategy(input: ResearchAnamnesisInput): string[] {
    const q = input.topic.trim();
    const area = input.subjectArea.trim();
    return [
      `"${q}" ${area}`,
      `"${q}" revisão literatura ${area}`,
      `"${q}" evidências controvérsias`,
      input.problem ? `"${q}" ${input.problem.slice(0, 100)}` : `"${q}" estado da arte`,
    ];
  }

  private makeNextActions(protocol: ResearchAnamnesisProtocol, evaluations: PremiseEvaluation[]): string[] {
    const actions = ['Executar busca documental/bibliográfica nas bases apropriadas à matéria.', 'Registrar cada evidência no PASQUARED antes de redigir conclusões.'];
    if (evaluations.some(e => e.verdict === 'INSUFFICIENT_EVIDENCE')) actions.push('Buscar evidência adicional para as premissas classificadas como insuficientes.');
    if (evaluations.some(e => e.verdict === 'DISPUTED')) actions.push('Criar seção de controvérsias e apresentar as interpretações concorrentes.');
    if (protocol.pedagogicalProfile.requiresOriginalContribution) actions.push('Explicitar a lacuna científica e a contribuição original pretendida.');
    return actions;
  }

  private calculateReadiness(input: ResearchAnamnesisInput, protocol: ResearchAnamnesisProtocol) {
    const required = [input.subjectArea, input.academicLevel, input.topic, input.problem, input.generalObjective, input.outputType];
    const completeness = required.filter(Boolean).length / required.length;
    const premiseBonus = protocol.premises.length ? 0.05 : 0;
    const methodBonus = input.methodPreference ? 0.05 : 0;
    const score = Number(Math.min(1, completeness * 0.9 + premiseBonus + methodBonus).toFixed(2));
    return { score, status: score >= 0.9 ? 'READY' : score >= 0.7 ? 'NEEDS_REFINEMENT' : 'INCOMPLETE' } as const;
  }

  private validate(input: ResearchAnamnesisInput) {
    const missing = ['subjectArea', 'academicLevel', 'topic', 'problem', 'generalObjective', 'outputType'].filter(k => !(input as any)[k]);
    if (missing.length) throw new Error(`Campos obrigatórios ausentes na anamnese: ${missing.join(', ')}`);
  }

  private splitItems(value?: string): string[] {
    if (!value) return [];
    return value.split(/\n|;/).map(v => v.trim().replace(/^[-•]\s*/, '')).filter(Boolean);
  }

  private tokens(text: string): Set<string> {
    return new Set(text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(t => t.length > 3));
  }

  private overlap(a: Set<string>, b: Set<string>): number {
    if (!a.size || !b.size) return 0;
    let hits = 0; a.forEach(t => { if (b.has(t)) hits++; });
    return hits / Math.max(1, Math.min(a.size, b.size));
  }
}

export const researchAnamnesisEngine = new ResearchAnamnesisEngine();
