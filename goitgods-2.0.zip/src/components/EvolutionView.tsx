import React, { useState } from 'react';
import { 
  Cpu, 
  GitMerge, 
  PlusCircle, 
  Trash2, 
  Activity, 
  Layers, 
  ShieldCheck, 
  Box, 
  Sparkles,
  Server
} from 'lucide-react';
import { GODS_LIST } from '../data/godsData';

export const EvolutionView: React.FC = () => {
  const [gods, setGods] = useState(GODS_LIST);
  const [kgsScore, setKgsScore] = useState<number>(0.28); // Low knowledge gap
  const [gapStatus, setGapStatus] = useState<string>('Ecossistema em Equilíbrio. Cobertura Temática: 92%');

  // Trigger God Creation
  const handleSynthesizeGod = () => {
    const newGod = {
      id: `god-syn-${Date.now()}` as any,
      name: 'PROMETHEUS',
      title: 'Inovação Disruptiva & Transferência Tecnológica',
      domain: 'Disruptive Tech / Knowledge Transfer',
      namespace: 'prometheus',
      specialties: ['Síntese de Tecnologias Limites', 'Transferência de Conhecimento Complexo'],
      reasoningStrategy: 'Sintetizador Heurístico para evasão de estagnação.',
      iconName: 'Zap',
      color: '#F97316',
      minReplicas: 2,
      maxReplicas: 10,
      gpsScore: 0.94,
    };

    setGods([...gods, newGod]);
    setKgsScore(0.12);
    setGapStatus('Novo God Sintetizado com Sucesso: PROMETHEUS instanciado via Kubernetes Operator.');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-mono">
              <Cpu className="w-3.5 h-3.5" />
              <span>Olympus Evolution Engine • Kubernetes Controller</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-serif font-black text-white">
              Evolução Auto-Organizável do Olimpo
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Algoritmo de auto-organização contínua: OBSERVE → MEASURE → DISCOVER → CREATE → TEST → DEPLOY → EVALUATE → PROMOTE → MERGE → RETIRE → REBALANCE.
            </p>
          </div>

          <button
            onClick={handleSynthesizeGod}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold px-5 py-3 rounded-xl text-xs font-mono transition-all shadow-lg shadow-purple-500/20 flex items-center space-x-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Sintetizar Novo God (KGS Trigger)</span>
          </button>
        </div>
      </div>

      {/* KGS Metric Indicator Card */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Knowledge Gap Score (KGS)</span>
          <div className="text-2xl font-serif font-black text-purple-400">
            {(kgsScore * 100).toFixed(1)}%
          </div>
          <p className="text-[11px] text-slate-400">
            KGS = DomainDemand × (1 - Coverage) × Uncertainty
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Status de Cobertura de Domínios</span>
          <div className="text-sm font-semibold text-emerald-400 flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4" />
            <span>{gapStatus}</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Monitoramento de redundâncias e lacunas ontológicas em tempo real.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2">
          <span className="text-xs font-mono text-slate-400 uppercase">Kubernetes CRD Operator</span>
          <div className="text-sm font-semibold text-cyan-400 flex items-center space-x-1.5">
            <Server className="w-4 h-4" />
            <span>goitgods-olympus-controller</span>
          </div>
          <p className="text-[11px] text-slate-400">
            CRD kind: God (apiVersion: goitgods.io/v1)
          </p>
        </div>
      </div>

      {/* Active God Replicas & Namespaces Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <h3 className="font-serif font-bold text-lg text-white flex items-center space-x-2">
            <Box className="w-5 h-5 text-purple-400" />
            <span>Topologia de Namespaces Kubernetes & God Replicas ({gods.length} Gods)</span>
          </h3>
          <span className="text-xs font-mono text-slate-400">Auto-Scaling HPA Ativo</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {gods.map((god) => (
            <div 
              key={god.id}
              className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: god.color }} />
                  <span className="font-serif font-bold text-sm text-white">{god.name}</span>
                </div>
                <span className="text-[10px] font-mono bg-slate-900 text-purple-300 border border-slate-800 px-2 py-0.5 rounded">
                  ns/{god.namespace}
                </span>
              </div>

              <p className="text-xs text-slate-400 line-clamp-1">{god.title}</p>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>Replicas: {god.minReplicas} / {god.maxReplicas}</span>
                <span className="text-emerald-400">GPS: {(god.gpsScore * 100).toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
