import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark';
}

export default function Logo({ className = "w-8 h-8", variant = 'light' }: LogoProps) {
  // The user should upload the attached image to /public/logo.png
  return (
    <div className={`relative inline-block ${className}`}>
      <img 
        src="/logo-HSM.jpg" 
        alt="Hair Smart Mall" 
        className="w-full h-full object-contain"
        onError={(e) => {
          // Fallback to a styled placeholder if the image is not found
          (e.target as HTMLImageElement).style.display = 'none';
          const parent = (e.target as HTMLImageElement).parentElement;
          if (parent) {
            parent.classList.add('flex', 'items-center', 'justify-center', 'font-bold', 'rounded-lg', 'overflow-hidden');
            if (variant === 'light') {
              parent.style.backgroundColor = '#ffffff';
              parent.style.color = '#004785';
            } else {
              parent.style.backgroundColor = '#004785';
              parent.style.color = '#ffffff';
            }
            parent.innerText = 'HSM';
          }
        }}
        referrerPolicy="no-referrer"
      />
    </div>
  );
}
