import React from 'react';
import { X, ShieldCheck, Scale, FileText, CheckCircle2, Clock, AlertTriangle, CreditCard, Lock } from 'lucide-react';

interface TermsOfUseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsOfUseModal: React.FC<TermsOfUseModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] text-slate-200 shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0A0C10] px-6 py-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="rounded-xl border border-[#22D3EE]/30 bg-[#22D3EE]/10 p-2 text-[#22D3EE]">
              <Scale className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                Termos de Uso e Condições Gerais
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                chamasso live chat • Atualizado em Setembro de 2026
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm leading-relaxed text-slate-300">
          {/* Introdução */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#22D3EE] font-bold text-xs uppercase tracking-wider">
              <FileText className="h-4 w-4" />
              1. Identificação da Plataforma e Objeto do Serviço
            </div>
            <p>
              O <strong className="text-white">chamasso live chat</strong> (<span className="text-[#22D3EE] font-mono">chamasso.pasquared.space</span>) é uma plataforma de comunicação em tempo real destinada a interações sociais, paquera, amizade e videoconferências coletivas e 1-a-1. O sistema oferece recursos de transmissão de áudio, vídeo via webcam em alta definição, mensagens de texto, compartilhamento de tela e arquivos multimídia.
            </p>
            <p>
              Ao utilizar a plataforma, o usuário declara ter lido, compreendido e aceito integralmente estes Termos de Uso e a Política de Privacidade vinculada, submetendo-se à legislação brasileira aplicável, em especial ao Marco Civil da Internet (Lei nº 12.965/2014) e ao Código de Defesa do Consumidor (Lei nº 8.078/1990).
            </p>
          </div>

          {/* Autenticação, CPF e 2FA */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#F472B6] font-bold text-xs uppercase tracking-wider">
              <Lock className="h-4 w-4" />
              2. Cadastro, Validação de CPF e Segurança de Dois Fatores (2FA)
            </div>
            <p>
              Para acessar os serviços completos do chamasso live chat, é obrigatório o cadastro contendo nome civil, data de nascimento, e-mail do Google e <strong className="text-white">Cadastro de Pessoas Físicas (CPF) válido</strong>. Cada CPF poderá estar vinculado a apenas uma conta na plataforma.
            </p>
            <p>
              A segurança de acesso é resguardada por <strong className="text-white">Autenticação de Dois Fatores (2FA)</strong> baseada no protocolo TOTP e por uma cartela exclusiva de <strong className="text-[#22D3EE]">11 Códigos de Uso Único (Descartáveis)</strong> gerados no primeiro acesso. É de responsabilidade exclusiva do usuário manter seus códigos e credenciais sob estrito sigilo.
            </p>
          </div>

          {/* Tarifas Chamasso, Cobrança por Minuto e Saldo */}
          <div className="rounded-xl border border-[#22D3EE]/30 bg-gradient-to-br from-[#0F172A] to-[#1E293B]/40 p-4 space-y-3">
            <div className="flex items-center gap-2 text-[#22D3EE] font-bold text-xs uppercase tracking-wider">
              <CreditCard className="h-4 w-4" />
              3. Tarifas Chamasso, Cobrança por Minuto e Desbloqueio de Funcionalidades
            </div>
            <div className="space-y-2 text-slate-300">
              <p>
                <strong className="text-white">3.1. Regra de Saldo Positivo:</strong> Os serviços de conexão direta com um único usuário (áudio/vídeo privado 1-a-1) ou a conexão de ingresso em sala de bate-papo para transmitir áudio, vídeo pela webcam e digitar mensagens de texto no chat coletivo <strong className="text-emerald-400">só serão possíveis caso o usuário possua saldo positivo de PASQcoin</strong> em sua carteira digital.
              </p>
              <p>
                <strong className="text-white">3.2. Desbloqueio e Início da Cobrança:</strong> Uma vez que o usuário possua saldo positivo de PASQcoin, o sistema desbloqueia as ferramentas interativas e inicia o consumo proporcional ao tempo. Cada segundo desconta uma fração de PASQcoin conforme o parâmetro <strong className="text-[#22D3EE] font-mono">segundos por PASQ</strong> configurado pela plataforma.
              </p>
              <p>
                <strong className="text-white">3.3. Reajuste de Tarifas pelo Super Admin:</strong> O valor da tarifa por minuto poderá ser reajustado periodicamente pela administração da plataforma na seção <em className="text-white">"Tarifas Chamasso"</em> do painel administrativo restrito do Super Admin.
              </p>
              <p>
                <strong className="text-white">3.4. Ativação ou Suspensão Discricionária das Tarifas:</strong> O Super Administrador possui a prerrogativa de <strong className="text-white">ativar ou suspender temporariamente a cobrança de tarifas</strong> do bate-papo. Quando a cobrança estiver suspensa (desligada), todas as funcionalidades de interação serão liberadas gratuitamente a todos os participantes.
              </p>
              <p>
                <strong className="text-white">3.5. Modo Observador / Visualização Apenas:</strong> Caso o botão de ativar tarifas esteja ligado e o usuário não possua créditos (saldo zerado ou esgotado), <strong className="text-amber-400">será permitido exclusivamente visualizar o bate-papo da sala sem entrar ativamente nela</strong> (ou seja, modo ouvinte/observador, sem permissão para transmitir vídeo, ativar microfone, solicitar palavra ou digitar mensagens).
              </p>
            </div>
          </div>

          {/* Pacotes de Recarga e Validade de 30 Dias */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#FACC15] font-bold text-xs uppercase tracking-wider">
              <Clock className="h-4 w-4" />
              4. Pacotes de Recarga e Prazo de Validade de 30 Dias
            </div>
            <p>
              <strong className="text-white">4.1. Valor Mínimo de Recarga:</strong> As recargas de saldo serão disponibilizadas em pacotes pré-pagos a partir do <strong className="text-emerald-400 font-bold">valor mínimo de R$ 5,00 (cinco reais)</strong>, com opções para carregar quantias superiores conforme a conveniência do participante (por exemplo: R$ 10,00, R$ 20,00, R$ 50,00 ou valor avulso).
            </p>
            <p>
              <strong className="text-white">4.2. Expiração em 30 Dias:</strong> Os créditos adquiridos possuem prazo de validade de <strong className="text-rose-400 font-bold">30 (trinta) dias corridos</strong>, cuja contagem é iniciada automaticamente a partir da <strong className="text-white">primeira entrada em sala de bate-papo ou do primeiro contato direto realizado com algum usuário</strong> após a referida recarga. Expirado o prazo de 30 dias sem a utilização total do saldo, os minutos remanescentes daquele ciclo serão expirados.
            </p>
          </div>

          {/* Integração Mercado Pago */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#38BDF8] font-bold text-xs uppercase tracking-wider">
              <CheckCircle2 className="h-4 w-4" />
              5. Processamento de Pagamentos via Mercado Pago
            </div>
            <p>
              As transações financeiras, cobranças e liquidações são operacionalizadas pela instituição financeira parceira <strong className="text-white">Mercado Pago</strong> (MercadoPago.com Representações Ltda.), por meio de API segura, chaves criptográficas (API Key e Secret Key), links de redirecionamento e Webhooks automatizados para liberação em tempo real de recargas efetuadas via <strong className="text-emerald-400">PIX instantâneo</strong>, cartão de crédito ou boleto bancário.
            </p>
          </div>

          {/* Regras de Conduta e Moderação */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase tracking-wider">
              <AlertTriangle className="h-4 w-4" />
              6. Diretrizes de Conduta, Moderação e Banimento
            </div>
            <p>
              É terminantemente vedada a transmissão ou veiculação de conteúdos que promovam assédio, pedofilia, discriminação, discursos de ódio, violência ou pirataria. Os moderadores das salas e o Super Administrador possuem autoridade técnica e administrativa para suspender, silenciar ou aplicar banimento temporário ou permanente a infratores, registrando os incidentes em logs perenes de auditoria.
            </p>
          </div>

          {/* Legislação e Foro */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-1">
            <div className="flex items-center gap-2 text-slate-400 font-bold text-xs uppercase tracking-wider">
              <ShieldCheck className="h-4 w-4" />
              7. Foro de Eleição e Legislação Aplicável
            </div>
            <p className="text-slate-400">
              Estes Termos de Uso são regidos e interpretados segundo as Leis da República Federativa do Brasil. Fica eleito o foro da Comarca de domicílio do usuário para dirimir eventuais litígios decorrentes deste instrumento.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#1E293B] bg-[#0A0C10] px-6 py-3 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-mono">
            chamasso.pasquared.space • SGBD PostgreSQL db_chamasso
          </span>
          <button
            onClick={onClose}
            className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-1.5 text-xs font-black text-black hover:brightness-110 transition"
          >
            Entendido e Ciente
          </button>
        </div>
      </div>
    </div>
  );
};
