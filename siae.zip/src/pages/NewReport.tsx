import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Send } from 'lucide-react';

export default function NewReport() {
  const navigate = useNavigate();
  const { houseId } = useParams();
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const userStr = localStorage.getItem('siae_user');
    if (!userStr) return navigate('/login');
    const user = JSON.parse(userStr);

    setLoading(true);
    try {
      const res = await fetch(`/api/houses/${houseId}/assisted/${user.id}/reports`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problemDescription: description })
      });
      if (!res.ok) throw new Error('Erro ao enviar relato');
      alert('Relato enviado com sucesso! Aguarde a triagem do setor de acolhimento.');
      navigate('/dashboard');
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-indigo-600 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-4">
          <button onClick={() => navigate('/dashboard')} className="p-2 hover:bg-indigo-700 rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-xl">Novo Relato</h1>
        </div>
      </header>

      <main className="flex-1 max-w-3xl w-full mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Descreva o motivo da sua busca por atendimento</h2>
          <p className="text-gray-600 mb-6">
            Este relato será lido apenas pelo setor de acolhimento da casa espírita para direcionar o melhor tratamento para você.
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Seu Relato</label>
              <textarea
                required
                rows={8}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Descreva o que está sentindo, suas dificuldades ou o motivo de buscar ajuda..."
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Send className="w-5 h-5" />
              {loading ? 'Enviando...' : 'Enviar Relato'}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
