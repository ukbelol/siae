import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, ChevronRight } from 'lucide-react';

export default function SuperAdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forceChange, setForceChange] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return setError('Preencha os dados.');
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/login-supersu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro no login');

      if (data.forcePasswordChange) {
        setForceChange(true);
      } else {
        localStorage.setItem('siae_token', data.token);
        localStorage.setItem('siae_user', JSON.stringify(data.user));
        navigate('/super-admin-panel');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) return setError('As senhas não coincidem.');
    if (newPassword.length < 6) return setError('A nova senha deve ter pelo menos 6 caracteres.');
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/change-password-supersu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, currentPassword: password, newPassword })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao trocar senha');

      localStorage.setItem('siae_token', data.token);
      localStorage.setItem('siae_user', JSON.stringify(data.user));
      navigate('/super-admin-panel');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-gray-900 border border-gray-800 p-8 flex flex-col justify-center rounded-2xl shadow-xl">
        <div className="flex flex-col flex-1 items-center">
          <div className="w-16 h-16 bg-gray-800 rounded-2xl flex items-center justify-center mb-6 border border-gray-700">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-center text-3xl font-bold text-white mb-2">
            Acesso Restrito
          </h2>
          <p className="text-center text-sm text-gray-400 mb-8">
            Painel Administrativo Root
          </p>
        </div>

        {error && (
          <div className="bg-red-900/50 border border-red-500 text-red-200 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        {!forceChange ? (
          <form className="mt-8 space-y-6" onSubmit={handleLogin}>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-300">E-mail Administrativo</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="mt-1 block w-full px-4 py-3 bg-gray-800 border-gray-700 text-white rounded-lg focus:ring-gray-500 focus:border-gray-500 transition-colors"
                  placeholder="admin@appa.siae.space"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-300">Chave de Segurança</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="mt-1 block w-full px-4 py-3 bg-gray-800 border-gray-700 text-white rounded-lg focus:ring-gray-500 focus:border-gray-500 transition-colors"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-black bg-white hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-all"
            >
              {loading ? 'Validando...' : 'Autenticar'}
              <ChevronRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        ) : (
          <form className="mt-8 space-y-6" onSubmit={handleReset}>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-amber-500 mb-4 bg-amber-900/20 p-3 rounded-lg border border-amber-900/50">
                  Atenção: Por motivos de segurança, você precisa registrar uma nova chave de acesso no primeiro login.
                </p>
                <label className="text-sm font-medium text-gray-300">Nova Chave de Acesso</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="mt-1 block w-full px-4 py-3 bg-gray-800 border-gray-700 text-white rounded-lg focus:ring-gray-500 focus:border-gray-500 transition-colors"
                  placeholder="Nova senha secreta"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-300">Confirmar Nova Chave</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  className="mt-1 block w-full px-4 py-3 bg-gray-800 border-gray-700 text-white rounded-lg focus:ring-gray-500 focus:border-gray-500 transition-colors"
                  placeholder="Repita a nova senha"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-black bg-white hover:bg-gray-200 transition-colors"
            >
              {loading ? 'Atualizando...' : 'Definir Nova Chave'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
