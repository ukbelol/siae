import React, { useState } from 'react';
import { Brain, CheckCircle2, X } from 'lucide-react';

interface Props { isOpen:boolean; onCancel:()=>void; onAccept:()=>void; }
export function AIMediationConsentModal({isOpen,onCancel,onAccept}:Props){
  const [accepted,setAccepted]=useState(false);
  if(!isOpen) return null;
  return <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
    <div className="w-full max-w-lg rounded-2xl border border-[#22D3EE]/40 bg-[#0F172A] shadow-2xl">
      <div className="flex items-center justify-between border-b border-[#1E293B] p-4">
        <div className="flex items-center gap-3"><Brain className="h-6 w-6 text-[#22D3EE]"/><div><h3 className="font-bold text-white">Mediação Psicossocial por IA</h3><p className="text-xs text-slate-400">Mediadora IA PASQUARED</p></div></div>
        <button type="button" onClick={onCancel} className="p-2 text-slate-400 hover:text-white"><X className="h-5 w-5"/></button>
      </div>
      <div className="space-y-4 p-5 text-sm text-slate-300">
        <p>Deseja prosseguir a conversa com a Mediadora IA PASQUARED?</p>
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-amber-100"><strong>Acréscimo de 50%:</strong> esta modalidade consome 1,5× a tarifa normal de PASQcoin aplicável à conversa.</div>
        <p className="text-xs text-slate-400">O recurso oferece apoio e mediação psicossocial assistida por inteligência artificial. Não substitui atendimento psicológico, médico, jurídico ou serviços de emergência.</p>
        <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-[#334155] bg-[#0A0C10] p-3">
          <input type="checkbox" checked={accepted} onChange={e=>setAccepted(e.target.checked)} className="mt-0.5 h-4 w-4"/>
          <span className="text-xs"><strong className="text-white">Li e aceito os Termos de Uso</strong> e concordo com o acréscimo de 50% no consumo de PASQcoin desta modalidade.</span>
        </label>
      </div>
      <div className="flex gap-2 border-t border-[#1E293B] p-4">
        <button type="button" onClick={onCancel} className="flex-1 rounded-xl border border-[#334155] py-2.5 text-sm font-semibold text-slate-300">Cancelar</button>
        <button type="button" disabled={!accepted} onClick={()=>{if(accepted)onAccept();}} className="flex-1 rounded-xl bg-[#22D3EE] py-2.5 text-sm font-bold text-[#082F49] disabled:cursor-not-allowed disabled:opacity-40"><CheckCircle2 className="mr-1 inline h-4 w-4"/>Aceitar e prosseguir</button>
      </div>
    </div>
  </div>;
}
