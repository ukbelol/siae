# Chamasso 2.0.1 — Mercado Pago Teste/Produção

- Separação persistente das credenciais Mercado Pago em dois perfis: `test` e `production`.
- Alternância no painel do Super Admin passa a carregar o perfil salvo do ambiente selecionado.
- Alternância também atualiza o ambiente ativo no backend sem sobrescrever as chaves do outro ambiente.
- Public Key, Access Token, Webhook URL e Redirect URL são independentes por ambiente.
- Endpoint de teste usa explicitamente o ambiente exibido no painel.
- Migração automática do formato legado (`sandboxMode` + um único conjunto de chaves).
- Variáveis `.env` específicas para teste e produção.
- Seed SQL atualizado para o novo formato.

## Variáveis novas

- `MERCADOPAGO_TEST_PUBLIC_KEY`
- `MERCADOPAGO_TEST_ACCESS_TOKEN`
- `MERCADOPAGO_TEST_WEBHOOK_URL`
- `MERCADOPAGO_TEST_REDIRECT_URL`
- `MERCADOPAGO_PROD_PUBLIC_KEY`
- `MERCADOPAGO_PROD_ACCESS_TOKEN`
- `MERCADOPAGO_PROD_WEBHOOK_URL`
- `MERCADOPAGO_PROD_REDIRECT_URL`

As variáveis legadas `MERCADOPAGO_PUBLIC_KEY` e `MERCADOPAGO_ACCESS_TOKEN` continuam sendo aceitas como fallback de produção.
