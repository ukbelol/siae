import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function Terms() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <div className="bg-indigo-600 px-6 py-8 sm:p-10 relative overflow-hidden">
          <Link to="/" className="inline-flex items-center text-indigo-100 hover:text-white mb-6 transition-colors relative z-10">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Voltar para o início
          </Link>
          <h1 className="text-3xl font-bold text-white mb-2 relative z-10">Termos de Compromisso</h1>
          <p className="text-indigo-100 relative z-10">Sistema Integrado de Assistência Espírita (SIAE)</p>
        </div>
        
        <div className="px-6 py-8 sm:p-10 max-w-none text-gray-700 space-y-6">
          <p>
            Bem-vindo ao <strong>SIAE - Sistema Integrado de Assistência Espírita</strong>. Ao utilizar nosso sistema como Trabalhador, Assistido ou Administrador de uma Casa Espírita, você concorda expressamente com as condições e termos estabelecidos abaixo, fundamentados na confidencialidade, ética e nos preceitos de caridade.
          </p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">1. Do Propósito do Sistema</h2>
          <p>
            O SIAE tem como objetivo facilitar a gestão de atendimentos em Casas Espíritas, organizando filas, histórico de tratamentos (como passes, desobsessão e atendimento fraterno) e escalas de trabalhadores.
          </p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">2. Do Acesso e Uso (Trabalhadores e Casas Espíritas)</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>O acesso às informações dos assistidos é estritamente confidencial e deve ser usado <strong>apenas e exclusivamente</strong> para o propósito do atendimento espiritual e acompanhamento do tratamento.</li>
            <li>O compartilhamento de login, senhas ou a utilização de crachás/tags NFC por terceiros é expressamente proibido.</li>
            <li>Qualquer anotação ou relatório gerado na plataforma (triagem, receituário espiritual) não constitui substituição ou aconselhamento médico, psicológico ou psiquiátrico profissional.</li>
          </ul>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">3. Da Identificação e Tags NFC</h2>
          <p>
            Para agilizar o fluxo e garantir a ordem na casa espírita, o sistema admite a vinculação do assistido ou do trabalhador a um dispositivo físico (Tag NFC / Crachá). 
            A tag serve única e exclusivamente como um token de identificação local para facilitar o check-in na fila e nas salas de atendimento. A perda da tag deve ser notificada à Casa Espírita.
          </p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">4. Do Compromisso Voluntário</h2>
          <p>
            Os tratamentos e atendimentos registrados no sistema são de caráter religioso/espiritual, oferecidos gratuitamente, sem promessa de cura física. O registro no sistema não cria vínculo de prestação de serviços civis entre o assistido e a Casa Espírita.
          </p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">5. Modificações dos Termos</h2>
          <p>
            Reservamo-nos o direito de modificar o presente termo para adaptá-lo a novas demandas operacionais, legislativas (como a LGPD) ou doutrinárias, mediante aviso prévio aos usuários cadastrados.
          </p>
          
          <div className="mt-12 pt-8 border-t border-gray-100 flex justify-end">
            <p className="text-sm text-gray-400">Última atualização: {new Date().toLocaleDateString('pt-BR')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
