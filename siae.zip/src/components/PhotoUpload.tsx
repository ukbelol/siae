import React, { useState } from 'react';
import { Upload, Loader2, User } from 'lucide-react';

export default function PhotoUpload({ currentPhoto, onUploadComplete }: { currentPhoto?: string, onUploadComplete: (url: string) => void }) {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState(currentPhoto);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert("A imagem deve ter no máximo 2MB");
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('photo', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setPreview(data.photoUrl);
      onUploadComplete(data.photoUrl);
    } catch (err: any) {
      alert("Erro no upload: " + err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative w-24 h-24 rounded-full border-4 border-gray-100 shadow-md bg-white overflow-hidden flex items-center justify-center">
        {preview ? (
          <img src={preview} alt="Profile" className="w-full h-full object-cover" />
        ) : (
          <User className="w-12 h-12 text-gray-400" />
        )}
        {uploading && (
          <div className="absolute inset-0 bg-white/70 flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
          </div>
        )}
      </div>
      <label className="cursor-pointer bg-white border border-gray-300 hover:border-indigo-500 hover:text-indigo-600 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-2">
        <Upload className="w-4 h-4" /> Escolher Foto
        <input type="file" accept="image/*" className="hidden" onChange={handleUpload} disabled={uploading} />
      </label>
    </div>
  );
}
