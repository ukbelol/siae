import React from 'react';
import { Cpu, ShieldCheck, BookOpen, Layers, Sparkles, Activity } from 'lucide-react';

interface HeaderProps {
  activeTab: 'search' | 'ebooks' | 'reader' | 'olympus' | 'admin';
  setActiveTab: (tab: 'search' | 'ebooks' | 'reader' | 'olympus' | 'admin') => void;
  ebookCount: number;
  openEbookCount: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  ebookCount,
  openEbookCount,
}) => {
  return (
    <header className="bg-[#0D0D0D] border-b border-[#222222] text-[#E0E0E0] sticky top-0 z-40 backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Identity */}
        <div
          className="flex items-center space-x-3 cursor-pointer select-none"
          onClick={() => setActiveTab('search')}
        >
          <div className="w-10 h-10 border border-[#FF3E00] bg-[#111111] flex items-center justify-center text-[#FF3E00] shadow-[0_0_15px_rgba(255,62,0,0.15)]">
            <Cpu className="w-5 h-5 font-bold" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-black text-xl tracking-tighter text-white">
                GOITGODS <span className="text-[#FF3E00]">2.0.1</span>
              </span>
              <span className="text-[9px] font-mono font-bold tracking-widest px-2 py-0.5 uppercase bg-[#1A1A1A] text-[#00FF41] border border-[#333333]">
                PASQUARED-OS
              </span>
            </div>
            <p className="text-[10px] text-[#666666] font-mono tracking-wider uppercase hidden sm:block">
              Core System Interface • Multi-Agent Arbitration
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1 sm:space-x-2">
          <button
            id="nav-tab-search"
            onClick={() => setActiveTab('search')}
            className={`flex items-center space-x-2 px-3.5 py-2 text-xs font-mono font-bold uppercase tracking-wider transition-all border ${
              activeTab === 'search'
                ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Pesquisar & Arbitrar</span>
          </button>

          <button
            id="nav-tab-ebooks"
            onClick={openEbookCount}
            className={`flex items-center space-x-2 px-3.5 py-2 text-xs font-mono font-bold uppercase tracking-wider transition-all border ${
              activeTab === 'ebooks' || activeTab === 'reader'
                ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>E-Books</span>
            {ebookCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 text-[9px] font-mono font-bold bg-[#0A0A0A] text-[#00FF41] border border-[#222]">
                {ebookCount}
              </span>
            )}
          </button>

          <button
            id="nav-tab-olympus"
            onClick={() => setActiveTab('olympus')}
            className={`flex items-center space-x-2 px-3.5 py-2 text-xs font-mono font-bold uppercase tracking-wider transition-all border ${
              activeTab === 'olympus'
                ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Rede Olympus</span>
          </button>

          <button
            id="nav-tab-admin"
            onClick={() => setActiveTab('admin')}
            className={`flex items-center space-x-2 px-3.5 py-2 text-xs font-mono font-bold uppercase tracking-wider transition-all border ${
              activeTab === 'admin'
                ? 'bg-[#FF3E00] text-black border-[#FF3E00]'
                : 'bg-[#0F0F0F] text-[#888888] border-[#222222] hover:text-white hover:border-[#444444]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Painel Admin</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
