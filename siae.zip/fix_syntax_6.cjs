const fs = require('fs');

let t = fs.readFileSync('src/api/index.ts', 'utf8');

// Fix `split('T')[0] as any[]`
t = t.replace(/\.split\('T'\)\[0\] as any\[\]/g, ".split('T')[0]");

// Fix info.insertId since my regex turned `const info = stmt.run()` into `await db.query()` without destructuring
// In line: const info = await db.query(x) as any;
// It should be `const [info] = await db.query(x) as any;`
// We fixed this previously but maybe missed some.
t = t.replace(/const info = await db\.query\((.*?)\)/g, "const [info] = await db.query($1)");

// 229 `.all(`
t = t.replace(/await db\.query\((.*?)\)\.all\(/g, "(await db.query($1, [");

// stmt vs stmtCommand
t = t.replace(/db\.query\(stmt,/g, "db.query(stmtCommand,");
t = t.replace(/conn\.query\(insertCmd,/g, "await conn.query(insertCmd,");
t = t.replace(/await db\.query\(stmtCommand\.replace\(/g, "await db.query(stmtCommand.replace(");
t = t.replace(/\(await db\.query\(stmtCommand, \[(.*?)\]\)\)\[0\];/g, "await db.query(stmtCommand, [$1]);");

fs.writeFileSync('src/api/index.ts', t);

// Fix build script for backup
let b = fs.readFileSync('src/lib/backup.ts', 'utf8');
b = b.replace(/const config = getBackupConfig\(\);/g, "const config = await getBackupConfig();");
fs.writeFileSync('src/lib/backup.ts', b);
