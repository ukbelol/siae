/**
 * Algoritmo Oficial de Validação de CPF (Receita Federal do Brasil)
 */

export function cleanCPF(cpf: string): string {
  return cpf.replace(/\D/g, '');
}

export function formatCPF(value: string): string {
  const digits = cleanCPF(value).slice(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
  if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
  return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9, 11)}`;
}

export function isValidCPF(cpfInput: string): boolean {
  const cpf = cleanCPF(cpfInput);

  // Deve possuir exatamente 11 dígitos numéricos
  if (cpf.length !== 11) {
    return false;
  }

  // CPFs com todos os dígitos iguais são inválidos pela Receita Federal
  if (/^(\d)\1{10}$/.test(cpf)) {
    return false;
  }

  // Validação do 1º Dígito Verificador
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i), 10) * (10 - i);
  }
  let firstCheckDigit = 11 - (sum % 11);
  if (firstCheckDigit >= 10) {
    firstCheckDigit = 0;
  }

  if (firstCheckDigit !== parseInt(cpf.charAt(9), 10)) {
    return false;
  }

  // Validação do 2º Dígito Verificador
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cpf.charAt(i), 10) * (11 - i);
  }
  let secondCheckDigit = 11 - (sum % 11);
  if (secondCheckDigit >= 10) {
    secondCheckDigit = 0;
  }

  return secondCheckDigit === parseInt(cpf.charAt(10), 10);
}
