/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Scissors, Calendar, Users, DollarSign, LogOut, Search, MapPin, Clock, CheckCircle } from 'lucide-react';

// --- Pages ---
import LandingPage from './pages/LandingPage';
import ClientLogin from './pages/ClientLogin';
import SalonLogin from './pages/SalonLogin';
import SuperAdminLogin from './pages/SuperAdminLogin';
import ClientDashboard from './pages/ClientDashboard';
import SalonDashboard from './pages/SalonDashboard';
import SalonPublicPage from './pages/SalonPublicPage';
import SuperAdminDashboard from './pages/SuperAdminDashboard';
import PaymentFeedback from './pages/PaymentFeedback';
import CheckoutPage from './pages/CheckoutPage';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login/client" element={<ClientLogin />} />
        <Route path="/login/salon" element={<SalonLogin />} />
        <Route path="/login/superadmin" element={<SuperAdminLogin />} />
        <Route path="/dashboard/client" element={<ClientDashboard />} />
        <Route path="/dashboard/salon" element={<SalonDashboard />} />
        <Route path="/dashboard/admin" element={<SuperAdminDashboard />} />
        <Route path="/salon/:id" element={<SalonPublicPage />} />
        <Route path="/checkout/:appointmentId" element={<CheckoutPage />} />
        <Route path="/payment/feedback" element={<PaymentFeedback />} />
      </Routes>
    </Router>
  );
}
