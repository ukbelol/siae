import React, { useState } from 'react';
import { X, PlusCircle, Globe, Lock, Flame, Coffee, Heart, Music, ShieldCheck, MapPin, Sparkles } from 'lucide-react';
import type { User, Room } from '../types.ts';
import { BRAZIL_STATES, CHAT_THEMES } from '../data/brazilLocationsAndThemes.ts';

interface CreateRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onRoomCreated: (newRoom: Room) => void;
}

export const CreateRoomModal: React.FC<CreateRoomModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onRoomCreated,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'paquera' | 'amizade' | 'romance' | 'musica'>('paquera');
  const [selectedUf, setSelectedUf] = useState('SP');
  const [selectedCity, setSelectedCity] = useState('São Paulo (Capital)');
  const [selectedThemeId, setSelectedThemeId] = useState('amizade_sincera');
  const [type, setType] = useState<'public' | 'private'>('public');
  const [maxParticipants, setMaxParticipants] = useState('50');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const currentState = BRAZIL_STATES.find((s) => s.uf === selectedUf) || BRAZIL_STATES[0];
  const currentTheme = CHAT_THEMES.find((t) => t.id === selectedThemeId) || CHAT_THEMES[0];

  const handleStateChange = (uf: string) => {
    setSelectedUf(uf);
    const st = BRAZIL_STATES.find((s) => s.uf === uf);
    if (st && st.popularCities.length > 0) {
      setSelectedCity(st.popularCities[0]);
    }
  };

  const handleFillSuggestedName = () => {
    setName(`${currentTheme.icon} ${currentState.uf} - ${selectedCity}: ${currentTheme.label}`);
    setDescription(`Bate-papo de ${selectedCity} (${currentState.name}) com foco em ${currentTheme.label}. Seja bem-vindo(a) para conversar com áudio e vídeo!`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Informe um nome para a sala.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
          category,
          type,
          maxParticipants: parseInt(maxParticipants) || 50,
          creatorId: currentUser.id,
          creatorName: `${currentUser.name} ${currentUser.lastName}`,
          creatorEmail: currentUser.googleEmail,
          state: currentState.uf,
          stateName: currentState.name,
          city: selectedCity,
          theme: currentTheme.id,
          themeLabel: currentTheme.label,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao criar a sala.');
      }

      onRoomCreated(data);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Falha ao criar sala.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="mb-5 flex items-center gap-3">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onClose();
            }}
            title="Ir para a página inicial"
            className="relative w-12 h-12 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_15px_rgba(34,211,238,0.4)] shrink-0 bg-[#0A0C10] block cursor-pointer hover:scale-105 active:scale-95 transition-transform"
          >
            <img
              src="/fenix_chamas.gif"
              alt="chamasso live chat"
              className="w-full h-full object-cover"
            />
          </a>
          <div>
            <h2 className="text-xl font-black uppercase italic tracking-tight text-white">Criar Nova Sala de Bate-Papo</h2>
            <p className="text-xs text-slate-400">
              Você será o moderador desta sala com controle de áudio, vídeo e bloqueios
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Seletor de Estado, Cidade e Tema */}
          <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10]/60 p-3.5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-[#22D3EE]" />
                <span>Localização & Tema da Sala (Bate-Papo Brasil)</span>
              </span>
              <button
                type="button"
                onClick={handleFillSuggestedName}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-[#22D3EE] hover:text-[#F472B6] transition"
              >
                <Sparkles className="h-3 w-3" />
                <span>Preencher Nome/Assunto</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Estado (UF):</label>
                <select
                  value={selectedUf}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-2.5 py-2 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                >
                  {BRAZIL_STATES.map((st) => (
                    <option key={st.uf} value={st.uf}>
                      {st.uf} - {st.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Cidade:</label>
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-2.5 py-2 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                >
                  {currentState.popularCities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Tema da Sala:</label>
                <select
                  value={selectedThemeId}
                  onChange={(e) => {
                    setSelectedThemeId(e.target.value);
                    const t = CHAT_THEMES.find((x) => x.id === e.target.value);
                    if (t) {
                      if (t.category === 'paquera') setCategory('paquera');
                      else if (t.category === 'amizade') setCategory('amizade');
                    }
                  }}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-2.5 py-2 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                >
                  {CHAT_THEMES.map((theme) => (
                    <option key={theme.id} value={theme.id}>
                      {theme.icon} {theme.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Nome da Sala:
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: SP - São Paulo: Amizade Sincera ☕"
              className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-[#E2E8F0] placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Descrição / Assunto da Conversa:
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva o propósito da conversa para atrair pessoas com a mesma sintonia..."
              className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2 text-xs text-[#E2E8F0] placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Categoria:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
              >
                <option value="paquera">❤️ Paquera & Match</option>
                <option value="amizade">☕ Amizade & Papo</option>
                <option value="romance">🌹 Romance a Dois</option>
                <option value="musica">🎵 Música & Voz</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Limite de Participantes:
              </label>
              <input
                type="number"
                min="2"
                max="50"
                value={maxParticipants}
                onChange={(e) => setMaxParticipants(e.target.value)}
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
              />
            </div>
          </div>

          {/* Modalidade da Sala: Pública vs Privada */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-2">
              Modalidade e Controle de Acesso:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Opção Pública */}
              <div
                onClick={() => setType('public')}
                className={`cursor-pointer rounded-2xl border p-3.5 transition ${
                  type === 'public'
                    ? 'border-[#22D3EE] bg-[#22D3EE]/10 shadow-lg shadow-[#22D3EE]/10'
                    : 'border-[#1E293B] bg-[#0A0C10]/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Globe className={`h-4 w-4 ${type === 'public' ? 'text-[#22D3EE]' : 'text-slate-400'}`} />
                  <span className={`text-xs font-bold ${type === 'public' ? 'text-[#22D3EE]' : 'text-slate-200'}`}>
                    Sala Pública
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Livre para entrar e sair para todos os visitantes logados. Como moderador, você pode bloquear
                  inconvenientes por minutos, horas, dias ou meses.
                </p>
              </div>

              {/* Opção Privada */}
              <div
                onClick={() => setType('private')}
                className={`cursor-pointer rounded-2xl border p-3.5 transition ${
                  type === 'private'
                    ? 'border-[#F472B6] bg-[#F472B6]/10 shadow-lg shadow-[#F472B6]/10'
                    : 'border-[#1E293B] bg-[#0A0C10]/60 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Lock className={`h-4 w-4 ${type === 'private' ? 'text-[#F472B6]' : 'text-slate-400'}`} />
                  <span className={`text-xs font-bold ${type === 'private' ? 'text-[#F472B6]' : 'text-slate-200'}`}>
                    Sala Privada (Com Apresentação)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Controle total de pedidos de ingresso. O pretendente deve se apresentar e explicar o motivo de
                  entrar para você aprovar ou recusar.
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-2 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="w-2/3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition disabled:opacity-50"
            >
              {loading ? 'Criando Sala...' : 'Criar e Entrar na Sala'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
