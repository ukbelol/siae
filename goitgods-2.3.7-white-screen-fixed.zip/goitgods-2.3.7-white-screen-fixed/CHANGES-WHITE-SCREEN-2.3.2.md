# GOITGODS 2.3.2 — correção de tela branca

## Diagnóstico
O instalador 2.3.1 permitia continuar após `npm run build` falhar (`|| log_warn`). Isso podia instalar Apache/PM2 com `dist/` ausente, parcial ou antigo.

## Correções
- build npm agora é obrigatório e fatal em caso de erro;
- validação de `dist/index.html`, `dist/server.cjs` e bundles `dist/assets/*.js|css`;
- smoke tests HTTP e HTTPS para frontend e `/api/v2/health`;
- `DirectoryIndex index.html` explícito no Apache;
- Error Boundary React para impedir tela branca silenciosa;
- diagnóstico de bootstrap no `index.html` quando o bundle não inicia;
- novo `repair-white-screen.sh` para reparar uma instalação existente sem reinstalar banco/SSL;
- versão atualizada para 2.3.2.

## Reparo de servidor já instalado
Copie os arquivos desta versão para `/opt/goitgods` (preservando `.env` e `data/`) e execute:

```bash
sudo ./repair-white-screen.sh
```

Depois recarregue o navegador com Ctrl+F5.
