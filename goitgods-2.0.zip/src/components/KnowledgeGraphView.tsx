import React, { useState } from 'react';
import { 
  Network, 
  Hourglass, 
  HelpCircle, 
  Sparkles, 
  Layers, 
  AlertCircle, 
  ChevronRight, 
  Search,
  Filter
} from 'lucide-react';
import { SearchParametersResult, ChronosTimelineEvent } from '../types';

interface KnowledgeGraphViewProps {
  searchResult: SearchParametersResult | null;
}

type NarrativeMode = 'FACTUAL' | 'ANALYTICAL' | 'OLYMPUS_CHRONICLE';

export const KnowledgeGraphView: React.FC<KnowledgeGraphViewProps> = ({ searchResult }) => {
  const [narrativeMode, setNarrativeMode] = useState<NarrativeMode>('ANALYTICAL');
  const [selectedNode, setSelectedNode] = useState<any | null>(null);

  // Counterfactual simulation state
  const [counterVariable, setCounterVariable] = useState<string>('Se o financiamento tivesse sido cortado no início');
  const [counterResult, setCounterResult] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const topicName = searchResult?.topic || 'Revolução Industrial';

  // Sample Nodes for Knowledge Graph (Neo4j concept)
  const nodes = [
    { id: 'node-1', label: topicName, type: 'EVENT', domain: 'História / Tecnologia', confidence: 0.98 },
    { id: 'node-2', label: 'PASQUARED-OS PCK', type: 'KERNEL', domain: 'Cognitive Engine', confidence: 0.99 },
    { id: 'node-3', label: 'Cluster ZEUS', type: 'GOD', domain: 'Governance', confidence: 0.95 },
    { id: 'node-4', label: 'Cluster ATHENA', type: 'GOD', domain: 'Strategy & Logic', confidence: 0.93 },
    { id: 'node-5', label: 'Base Wikipedia Pública', type: 'SOURCE', domain: 'Public Enciclopedia', confidence: 0.92 },
    { id: 'node-6', label: 'Gênese & Início', type: 'CLAIM', domain: 'Cronologia', confidence: 0.94 },
    { id: 'node-7', label: 'Fatores Causadores', type: 'CLAIM', domain: 'Causalidade', confidence: 0.91 },
    { id: 'node-8', label: 'Decisão de Arbitragem', type: 'DECISION', domain: 'Olympus Verdict', confidence: 0.92 },
  ];

  // Sample Timeline Events for CHRONOS Engine
  const timelineEvents: ChronosTimelineEvent[] = [
    {
      id: 'ev-1',
      date: 'Fase Inicial',
      title: 'Gênese & Diagnóstico do Problema',
      description: searchResult?.chronologicalSequence.inicio || 'Surgimento das premissas e identificação das lacunas estruturais iniciais.',
      actors: ['Pesquisadores Pioneiros', 'Instituições de Vanguarda'],
      organizations: ['PASQUARED Core Labs', 'Arquivos Históricos'],
      location: 'Global / Ecossistema Distribuído',
      causes: ['Necessidade de automação', 'Incoerências nos modelos anteriores'],
      consequences: ['Formulação da primeira ontologia POKO'],
      sources: ['Enciclopédias Públicas', 'Artigos Fundacionais'],
      domains: ['História', 'Tecnologia'],
      technologies: ['Grafo Semântico', 'UCL Language'],
      uncertainties: ['Gargalos temporais de datação exata'],
      narrativeMode: {
        factual: `Fato Histórico Verificado: Em sua gênese, ${topicName} iniciou-se através de experimentos documentados em registros primários.`,
        analytical: `Análise Lógica: A transição da fase germinativa para a fase ativa foi impulsionada pela convergência de 3 fatores macroeconômicos.`,
        olympusChronicle: `CRÔNICA DO OLIMPO [FICÇÃO MITOLÓGICA]: "ATHENA observou o surgimento dos primeiros sinais e convocou HEPHAESTUS para forjar a fundação conceitual de ${topicName}."`,
      },
    },
    {
      id: 'ev-2',
      date: 'Fase de Expansão',
      title: 'Desenvolvimento e Maturação',
      description: searchResult?.chronologicalSequence.desenvolvimento || 'Aperfeiçoamento dos mecanismos de validação e expansão da base de usuários.',
      actors: ['Desenvolvedores', 'Especialistas do Olimpo'],
      organizations: ['Comunidade Global'],
      location: 'Centros Urbanos & Plataformas',
      causes: ['Demanda por escalabilidade'],
      consequences: ['Consolidação do conhecimento'],
      sources: ['Relatórios Anuais', 'Bases Públicas'],
      domains: ['Ciência', 'Sociedade'],
      technologies: ['MVED 2.0 Engine'],
      uncertainties: ['Variações regionais'],
      narrativeMode: {
        factual: `Fato Histórico: A fase de desenvolvimento registrou um crescimento de 300% em artigos e registros empíricos.`,
        analytical: `Análise Lógica: O aprendizado contínuo permitiu estabilizar os índices de erro em patamares inferiores a 2%.`,
        olympusChronicle: `CRÔNICA DO OLIMPO [FICÇÃO MITOLÓGICA]: "HERMES transmitiu as mensagens de ${topicName} por todos os reinos enquanto APOLLO testava a verdade de cada tese."`,
      },
    },
    {
      id: 'ev-3',
      date: 'Fase de Ápice',
      title: 'Meio e Consolidação do Legado',
      description: searchResult?.chronologicalSequence.meio || 'O momento de máxima repercussão e maturidade tecnológica.',
      actors: ['Governos', 'Grandes Corporações'],
      organizations: ['Conselho do Olimpo'],
      location: 'Mundial',
      causes: ['Reconhecimento universal de utilidade'],
      consequences: ['Integração ao ecossistema moderno'],
      sources: ['Bases Governamentais', 'Wikipedia'],
      domains: ['Governança', 'Estratégia'],
      technologies: ['GOITGODS 2.0 Kernel'],
      uncertainties: ['Resistência a mudanças em setores conservadores'],
      narrativeMode: {
        factual: `Fato Histórico: No seu ápice, ${topicName} tornou-se o padrão de referência adotado por múltiplas indústrias.`,
        analytical: `Análise Lógica: O valor MVED atingiu 0.92, caracterizando a máxima consistência interpretativa (ICI).`,
        olympusChronicle: `CRÔNICA DO OLIMPO [FICÇÃO MITOLÓGICA]: "ZEUS empunhou seu raio de arbitragem e declarou que a tese de ${topicName} havia alcançado o trono da sabedoria."`,
      },
    },
  ];

  const handleSimulateCounterfactual = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setCounterResult(
        `CENÁRIO CONTRAFACTUAL SIMULADO (SIMULATION ID: CTF-9921):\n` +
        `Se a variável "${counterVariable}" tivesse ocorrido, o índice de causalidade histórica (HCS) teria caído de 0.93 para 0.41. O desenvolvimento de ${topicName} teria sofrido um atraso estimado em 12 a 18 anos, resultando em uma topologia de conhecimento alternativa onde o cluster ATHENA assumiria a governança temporária.`
      );
      setIsSimulating(false);
    }, 1000);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-mono">
            <Network className="w-3.5 h-3.5" />
            <span>PASQUARED Knowledge Fabric • PKG & CHRONOS Engine</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-serif font-black text-white">
            Grafo Cognitivo & Inteligência Histórica
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl">
            Visualização topológica do Grafo de Conhecimento (PKG) com nós Neo4j-style e linha do tempo histórica em 3 modos de narrativa com simulação contrafactual.
          </p>
        </div>
      </div>

      {/* Interactive Visual Knowledge Graph (Neo4j Diagram Canvas) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-2">
            <Network className="w-5 h-5 text-emerald-400" />
            <h3 className="font-serif font-bold text-lg text-white">
              Grafo Cognitivo Ponderado G=(U,R,W)
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
            Ontologia POKO v15.8 • {nodes.length} Nós Ativos
          </span>
        </div>

        {/* Visual Graph Nodes Interactive Area */}
        <div className="relative w-full h-80 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden p-4 flex items-center justify-center">
          
          {/* Animated background grid */}
          <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />

          {/* Connected Lines SVG */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-slate-700/60 stroke-[1.5]">
            <line x1="20%" y1="50%" x2="50%" y2="25%" strokeDasharray="4 4" />
            <line x1="50%" y1="25%" x2="80%" y2="50%" />
            <line x1="20%" y1="50%" x2="35%" y2="75%" />
            <line x1="80%" y1="50%" x2="65%" y2="75%" />
            <line x1="50%" y1="25%" x2="50%" y2="75%" stroke="#eab308" strokeWidth="2" />
          </svg>

          {/* Interactive Nodes */}
          <div className="relative z-10 w-full h-full flex items-center justify-around">
            
            {/* Left Node */}
            <div 
              onClick={() => setSelectedNode(nodes[4])}
              className="bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-cyan-400 p-3 rounded-xl cursor-pointer transition-all shadow-lg text-center w-36"
            >
              <span className="text-[10px] font-mono text-cyan-400 block uppercase">SOURCE</span>
              <span className="text-xs font-bold text-white line-clamp-1">{nodes[4].label}</span>
            </div>

            {/* Central Node */}
            <div 
              onClick={() => setSelectedNode(nodes[0])}
              className="bg-amber-950/40 hover:bg-amber-900/40 border-2 border-amber-400 p-4 rounded-2xl cursor-pointer transition-all shadow-xl shadow-amber-500/10 text-center w-48 scale-110"
            >
              <span className="text-[10px] font-mono text-amber-300 block uppercase font-bold">NÓ CENTRAL (EVENT)</span>
              <span className="text-sm font-serif font-black text-white">{nodes[0].label}</span>
              <span className="text-[10px] font-mono text-emerald-400 block mt-1">KQ: 98%</span>
            </div>

            {/* Right Node */}
            <div 
              onClick={() => setSelectedNode(nodes[2])}
              className="bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-amber-400 p-3 rounded-xl cursor-pointer transition-all shadow-lg text-center w-36"
            >
              <span className="text-[10px] font-mono text-amber-400 block uppercase">GOD ARBITER</span>
              <span className="text-xs font-bold text-white line-clamp-1">{nodes[2].label}</span>
            </div>

          </div>
        </div>

        {/* Selected Node Details Box */}
        {selectedNode && (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs flex justify-between items-center">
            <div>
              <span className="text-slate-400 font-mono">Nó Selecionado:</span>{' '}
              <strong className="text-white">{selectedNode.label}</strong> ({selectedNode.type})
            </div>
            <div className="font-mono text-amber-300">
              Confiança: {(selectedNode.confidence * 100).toFixed(0)}%
            </div>
          </div>
        )}
      </div>

      {/* CHRONOS Historical Intelligence Narrative Modes */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <Hourglass className="w-6 h-6 text-purple-400" />
            <div>
              <h3 className="font-serif font-bold text-xl text-white">
                CHRONOS Engine • Narrativa Histórica em 3 Modos
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Classificação estrita: FACT, INFERENCE, FICTION nunca misturados.
              </p>
            </div>
          </div>

          {/* Narrative Mode Toggle */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setNarrativeMode('FACTUAL')}
              className={`px-3 py-1.5 rounded-lg font-mono font-semibold transition-colors ${
                narrativeMode === 'FACTUAL' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-slate-400'
              }`}
            >
              FACTUAL (Somente Fatos)
            </button>
            <button
              onClick={() => setNarrativeMode('ANALYTICAL')}
              className={`px-3 py-1.5 rounded-lg font-mono font-semibold transition-colors ${
                narrativeMode === 'ANALYTICAL' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400'
              }`}
            >
              ANALYTICAL (+ Inferências)
            </button>
            <button
              onClick={() => setNarrativeMode('OLYMPUS_CHRONICLE')}
              className={`px-3 py-1.5 rounded-lg font-mono font-semibold transition-colors ${
                narrativeMode === 'OLYMPUS_CHRONICLE' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40' : 'text-slate-400'
              }`}
            >
              OLYMPUS CHRONICLE (Crônica + Ficção)
            </button>
          </div>
        </div>

        {/* Timeline Events Stack */}
        <div className="space-y-4">
          {timelineEvents.map((ev, idx) => (
            <div key={ev.id} className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 font-mono text-xs font-bold flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <h4 className="font-serif font-bold text-base text-white">{ev.title}</h4>
                </div>
                <span className="text-xs font-mono text-purple-300 bg-purple-950 px-2.5 py-1 rounded border border-purple-800">
                  {ev.date}
                </span>
              </div>

              {/* Narrative Output box based on selected mode */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                {narrativeMode === 'FACTUAL' && (
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded uppercase font-bold">
                      CLASSIFICAÇÃO: FACT
                    </span>
                    <p className="mt-1">{ev.narrativeMode.factual}</p>
                  </div>
                )}

                {narrativeMode === 'ANALYTICAL' && (
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded uppercase font-bold">
                      CLASSIFICAÇÃO: FACT + INFERENCE
                    </span>
                    <p className="mt-1">{ev.narrativeMode.analytical}</p>
                  </div>
                )}

                {narrativeMode === 'OLYMPUS_CHRONICLE' && (
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded uppercase font-bold">
                      CLASSIFICAÇÃO: FICTION / NARRATIVA MITOLÓGICA (AVISO: FICÇÃO SIMULADA)
                    </span>
                    <p className="mt-1 italic text-purple-200">{ev.narrativeMode.olympusChronicle}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* GOITGODS Counterfactual Engine ("O que aconteceria se...") */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4 shadow-xl">
        <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <h3 className="font-serif font-bold text-lg text-white">
            GOITGODS Counterfactual Simulator ("O que aconteceria se...")
          </h3>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <input
            type="text"
            value={counterVariable}
            onChange={(e) => setCounterVariable(e.target.value)}
            placeholder="Digite uma hipótese contrafactual (ex: Se a tecnologia não estivesse disponível)..."
            className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-slate-800 focus:outline-none focus:border-amber-400 font-mono"
          />
          <button
            onClick={handleSimulateCounterfactual}
            disabled={isSimulating}
            className="w-full sm:w-auto bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold px-5 py-3 rounded-xl text-xs font-mono transition-colors whitespace-nowrap"
          >
            {isSimulating ? 'Simulando...' : 'Simular Contrafactual'}
          </button>
        </div>

        {counterResult && (
          <div className="bg-slate-950 p-4 rounded-xl border border-amber-500/30 text-xs font-mono text-amber-300 leading-relaxed whitespace-pre-wrap">
            {counterResult}
          </div>
        )}
      </div>
    </div>
  );
};
