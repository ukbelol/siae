import { Request, Response, NextFunction } from 'express';
import { db } from './db.js';

interface BlockedIpEntry {
  ip: string;
  reason: string;
  attempts: number;
  blockedAt: string;
  targetUser?: string;
}

interface FailedAttemptTracker {
  count: number;
  lastAttemptAt: string;
  targetUser?: string;
}

// In-memory caches for ultra-fast lookup
const inMemoryBlockedIps = new Set<string>();
const inMemoryFailedAttempts = new Map<string, FailedAttemptTracker>();

// Maximum allowed password failures before IP block
const MAX_FAILED_ATTEMPTS = 2;

/**
 * Extracts client IP address accurately from Request
 */
export function getClientIp(req: Request): string {
  const xForwardedFor = req.headers['x-forwarded-for'];
  if (xForwardedFor) {
    const ips = (typeof xForwardedFor === 'string' ? xForwardedFor : xForwardedFor[0]).split(',');
    const clientIp = ips[0].trim();
    if (clientIp) return clientIp;
  }
  const xRealIp = req.headers['x-real-ip'];
  if (xRealIp && typeof xRealIp === 'string' && xRealIp.trim()) {
    return xRealIp.trim();
  }
  
  let rawIp = req.ip || req.socket?.remoteAddress || '127.0.0.1';
  // Normalize IPv6 mapped IPv4 like ::ffff:127.0.0.1
  if (rawIp.startsWith('::ffff:')) {
    rawIp = rawIp.substring(7);
  }
  return rawIp;
}

/**
 * Initializes Firewall DB tables and loads blocked IPs into memory
 */
export async function initFirewall() {
  try {
    await db.query(`
      CREATE TABLE IF NOT EXISTS firewall_blocked_ips (
        id INTEGER PRIMARY KEY AUTO_INCREMENT,
        ip VARCHAR(60) UNIQUE NOT NULL,
        reason TEXT NOT NULL,
        attempts INTEGER DEFAULT 2,
        target_user VARCHAR(120),
        blocked_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await db.query(`
      CREATE TABLE IF NOT EXISTS firewall_logs (
        id INTEGER PRIMARY KEY AUTO_INCREMENT,
        ip VARCHAR(60) NOT NULL,
        event_type VARCHAR(40) NOT NULL,
        details TEXT,
        target_user VARCHAR(120),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Load active blocked IPs into memory cache
    const rows = (await db.query('SELECT ip FROM firewall_blocked_ips'))[0] as any[];
    if (Array.isArray(rows)) {
      for (const row of rows) {
        if (row?.ip) {
          inMemoryBlockedIps.add(row.ip);
        }
      }
    }
    console.log(`[SIAE FIREWALL] Firewall inicializado com sucesso. ${inMemoryBlockedIps.size} IPs bloqueados carregados.`);
  } catch (err: any) {
    console.error('[SIAE FIREWALL] Erro ao inicializar tabelas do firewall:', err?.message || err);
  }
}

/**
 * Checks if an IP address is blocked
 */
export function isIpBlocked(ip: string): boolean {
  return inMemoryBlockedIps.has(ip);
}

/**
 * Records a failed password attempt for an IP.
 * Blocks the IP if failed attempts reach threshold (2 attempts).
 */
export async function recordFailedAttempt(ip: string, targetUser?: string, routeName: string = 'auth_login'): Promise<{ isBlocked: boolean; attempts: number }> {
  const current = inMemoryFailedAttempts.get(ip) || { count: 0, lastAttemptAt: new Date().toISOString(), targetUser };
  const newCount = current.count + 1;
  
  inMemoryFailedAttempts.set(ip, {
    count: newCount,
    lastAttemptAt: new Date().toISOString(),
    targetUser: targetUser || current.targetUser
  });

  // Log failed attempt event
  try {
    await db.query(
      'INSERT INTO firewall_logs (ip, event_type, details, target_user) VALUES (?, ?, ?, ?)',
      [ip, 'FAILED_LOGIN_ATTEMPT', `Tentativa incorreta de senha #${newCount} na rota ${routeName}`, targetUser || 'Desconhecido']
    );
  } catch (e) {
    console.error('[SIAE FIREWALL] Erro ao gravar log de tentativa falha:', e);
  }

  // Block IP if attempts threshold reached (>= 2)
  if (newCount >= MAX_FAILED_ATTEMPTS) {
    inMemoryBlockedIps.add(ip);
    const reason = `Bloqueio automático por Brute Force: ${newCount} tentativas com erro de senha.`;
    
    try {
      await db.query(
        'INSERT OR IGNORE INTO firewall_blocked_ips (ip, reason, attempts, target_user) VALUES (?, ?, ?, ?)',
        [ip, reason, newCount, targetUser || 'Desconhecido']
      );

      await db.query(
        'INSERT INTO firewall_logs (ip, event_type, details, target_user) VALUES (?, ?, ?, ?)',
        [ip, 'IP_BLOCKED', `IP ${ip} foi BLOQUEADO pelo Firewall após ${newCount} erros de senha`, targetUser || 'Desconhecido']
      );
    } catch (e) {
      console.error('[SIAE FIREWALL] Erro ao salvar IP bloqueado no DB:', e);
    }

    console.warn(`[SIAE FIREWALL ALERTA] IP ${ip} foi BLOQUEADO após ${newCount} tentativas incorretas de senha (Alvo: ${targetUser || 'desconhecido'}).`);
    return { isBlocked: true, attempts: newCount };
  }

  return { isBlocked: false, attempts: newCount };
}

/**
 * Resets failed attempts counter when a login succeeds
 */
export function recordSuccessfulLogin(ip: string) {
  inMemoryFailedAttempts.delete(ip);
}

/**
 * Unblocks a blocked IP address
 */
export async function unblockIp(ip: string): Promise<boolean> {
  inMemoryBlockedIps.delete(ip);
  inMemoryFailedAttempts.delete(ip);

  try {
    await db.query('DELETE FROM firewall_blocked_ips WHERE ip = ?', [ip]);
    await db.query(
      'INSERT INTO firewall_logs (ip, event_type, details) VALUES (?, ?, ?)',
      [ip, 'IP_UNBLOCKED', `IP ${ip} foi desbloqueado manualmente pelo Administrador`]
    );
    return true;
  } catch (err) {
    console.error('[SIAE FIREWALL] Erro ao desbloquear IP:', err);
    return false;
  }
}

/**
 * Unblocks all IPs
 */
export async function clearAllBlockedIps(): Promise<boolean> {
  inMemoryBlockedIps.clear();
  inMemoryFailedAttempts.clear();

  try {
    await db.query('DELETE FROM firewall_blocked_ips');
    await db.query(
      'INSERT INTO firewall_logs (ip, event_type, details) VALUES (?, ?, ?)',
      ['GLOBAL', 'ALL_UNBLOCKED', 'Todos os IPs foram desbloqueados pelo Administrador']
    );
    return true;
  } catch (err) {
    console.error('[SIAE FIREWALL] Erro ao limpar IPs bloqueados:', err);
    return false;
  }
}

/**
 * Gets list of blocked IPs
 */
export async function getBlockedIpsList(): Promise<BlockedIpEntry[]> {
  try {
    const rows = (await db.query('SELECT ip, reason, attempts, target_user as targetUser, blocked_at as blockedAt FROM firewall_blocked_ips ORDER BY blocked_at DESC'))[0] as any[];
    return rows || [];
  } catch (err) {
    console.error('[SIAE FIREWALL] Erro ao listar IPs bloqueados:', err);
    return [];
  }
}

/**
 * Gets recent firewall logs
 */
export async function getFirewallLogsList(limit: number = 50): Promise<any[]> {
  try {
    const rows = (await db.query('SELECT * FROM firewall_logs ORDER BY created_at DESC LIMIT ?', [limit]))[0] as any[];
    return rows || [];
  } catch (err) {
    console.error('[SIAE FIREWALL] Erro ao listar logs do firewall:', err);
    return [];
  }
}

/**
 * Express Middleware that enforces IP firewall blocking
 */
export function firewallMiddleware(req: Request, res: Response, next: NextFunction) {
  const clientIp = getClientIp(req);

  if (isIpBlocked(clientIp)) {
    return res.status(403).json({
      error: `[FIREWALL SIAE] Acesso Bloqueado. O seu endereço IP (${clientIp}) foi bloqueado pelo sistema de segurança devido a 2 tentativas consecutivas com erro de senha (Ataque Brute Force detectado). Entre em contato com o administrador para solicitar o desbloqueio.`,
      firewallBlocked: true,
      ip: clientIp,
      code: 'FIREWALL_IP_BLOCKED'
    });
  }

  next();
}
