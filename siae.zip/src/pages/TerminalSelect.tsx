import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MonitorPlay, Nfc, LogOut } from 'lucide-react';

export default function TerminalSelect() {
  const navigate = useNavigate();
  const [house, setHouse] = useState<any>(null);

  useEffect(() => {
    const h = localStorage.getItem('siae_terminal_house');
    if (!h) {
      navigate('/terminal');
      return;
    }
    setHouse(JSON.parse(h));
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('siae_terminal_token');
    localStorage.removeItem('siae_terminal_house');
    navigate('/terminal');
  };

  if (!house) return null;

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        <button onClick={handleLogout} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
          <LogOut className="w-5 h-5" /> Sair do Terminal
        </button>
      </div>

      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-white mb-2">{house.name}</h1>
        <p className="text-xl text-gray-400">Selecione a função deste terminal</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        <button 
          onClick={() => navigate(`/queue/${house.id}`)}
          className="bg-gray-800 border border-gray-700 hover:border-indigo-500 hover:bg-gray-750 rounded-2xl p-10 flex flex-col items-center justify-center gap-6 transition-all group"
        >
          <div className="bg-indigo-500/20 p-6 rounded-full group-hover:scale-110 transition-transform">
            <MonitorPlay className="w-16 h-16 text-indigo-400" />
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-2">Painel de Fila (TV)</h2>
            <p className="text-gray-400">Exibe as chamadas de atendimento em tempo real para o salão.</p>
          </div>
        </button>

        <button 
          onClick={() => navigate(`/terminal/nfc/${house.id}`)}
          className="bg-gray-800 border border-gray-700 hover:border-emerald-500 hover:bg-gray-750 rounded-2xl p-10 flex flex-col items-center justify-center gap-6 transition-all group"
        >
          <div className="bg-emerald-500/20 p-6 rounded-full group-hover:scale-110 transition-transform">
            <Nfc className="w-16 h-16 text-emerald-400" />
          </div>
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-2">Leitor NFC</h2>
            <p className="text-gray-400">Terminal para Check-in e Check-out de frequentadores e trabalhadores.</p>
          </div>
        </button>
      </div>
    </div>
  );
}
