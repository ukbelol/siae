import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Users, Activity, Home, Search, Calendar, Clock, CheckCircle, Play, ArrowLeft, Heart, Trash2, Edit2, Save, Key, Lock } from 'lucide-react';
import AssistedReports from '../components/AssistedReports';
import StoreAd from '../components/StoreAd';

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [houses, setHouses] = useState<any[]>([]);
  const [activeQueue, setActiveQueue] = useState<any>(null);
  const [workerActive, setWorkerActive] = useState<any>(null);
  const [workerType, setWorkerType] = useState('Passe');
  const [additionalTreatments, setAdditionalTreatments] = useState<string[]>([]);
  const [workerHouseId, setWorkerHouseId] = useState<number | null>(null);
  const [myHouses, setMyHouses] = useState<any[]>([]);

  // Representative state
  const [repHouse, setRepHouse] = useState<any>(null);
  const [view, setView] = useState('dashboard'); // 'dashboard', 'workers', 'assisted', 'assistance_types', 'operating_days'
  const [workersList, setWorkersList] = useState<any[]>([]);
  const [assistedList, setAssistedList] = useState<any[]>([]);
  const [pendingTriages, setPendingTriages] = useState<any[]>([]);
  const [queueCount, setQueueCount] = useState(0);
  const [selectedAssisted, setSelectedAssisted] = useState<any>(null);
  const [assistedHistory, setAssistedHistory] = useState<any[]>([]);
  const [assistanceTypes, setAssistanceTypes] = useState<any[]>([]);
  const [timeBlocks, setTimeBlocks] = useState<any[]>([]);
  const [editingBlock, setEditingBlock] = useState<any>(null);
  const [dayAssistances, setDayAssistances] = useState<any[]>([]);
  
  const [newType, setNewType] = useState({ name: '', description: '' });
  const [newDayAssistance, setNewDayAssistance] = useState({ dayOfWeek: 0, assistanceTypeId: '' });

  const [workerHistory, setWorkerHistory] = useState<any[]>([]);
  const [myHistory, setMyHistory] = useState<any[]>([]);
  const [myConferences, setMyConferences] = useState<any[]>([]);
  const [realtimeStats, setRealtimeStats] = useState<any | null>(null);

  // New state fields for queue calling app
  const [assistedAheadQueue, setAssistedAheadQueue] = useState<any[]>([]);
  const [assistedActiveCalled, setAssistedActiveCalled] = useState<any | null>(null);
  const [workerQueueRoom, setWorkerQueueRoom] = useState('1');
  const [workerQueueType, setWorkerQueueType] = useState('Passe');
  const [repQueueDetail, setRepQueueDetail] = useState<any[]>([]);
  const [loggedSession, setLoggedSession] = useState<any | null>(null);
  const [queueWaitingList, setQueueWaitingList] = useState<any[]>([]);
  const [attendedHistoryList, setAttendedHistoryList] = useState<any[]>([]);

  const [searchTerm, setSearchTerm] = useState('');
  const [searchService, setSearchService] = useState('');
  const [searchTime, setSearchTime] = useState('');

  const [treatmentPlan, setTreatmentPlan] = useState<any>(null);
  const [treatmentPlanTypes, setTreatmentPlanTypes] = useState<string[]>([]);
  
  // Custom password change state variables
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const handleUserChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (newPassword !== confirmPassword) {
      setPasswordError('A nova senha e a confirmação não coincidem.');
      return;
    }

    if (newPassword.length < 6) {
      setPasswordError('A nova senha deve conter pelo menos 6 caracteres.');
      return;
    }

    setIsChangingPassword(true);
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          currentPassword,
          newPassword
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao alterar a senha.');
      }

      setPasswordSuccess('Sua senha foi alterada com sucesso!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => {
        setShowPasswordModal(false);
        setPasswordSuccess('');
      }, 2000);
    } catch (err: any) {
      setPasswordError(err.message || 'Erro ao processar sua alteração de senha.');
    } finally {
      setIsChangingPassword(false);
    }
  };

  useEffect(() => {
    const userStr = localStorage.getItem('siae_user');
    if (!userStr) {
      navigate('/login');
      return;
    }
    const u = JSON.parse(userStr);
    setUser(u);
    
    // Fetch latest user data
    fetch(`/api/users/${u.id}`)
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          const updated = { ...u, ...data };
          setUser(updated);
          localStorage.setItem('siae_user', JSON.stringify(updated));
        }
      })
      .catch(console.error);

    if (u.role === 'assisted') {
      fetch(`/api/users/${u.id}/treatment-plan`)
        .then(r => r.json())
        .then(data => {
           if (Array.isArray(data)) setTreatmentPlanTypes(data);
        })
        .catch(console.error);
    }
    
    // Initial fetch handled by search effect if term is empty
  }, [navigate]);

  // Handle Realtime stats polling
  useEffect(() => {
    if (user?.role === 'representative' && repHouse?.id && view === 'dashboard') {
        const fetchStats = () => {
            fetch(`/api/houses/${repHouse.id}/realtime-stats`)
                .then(r => r.json())
                .then(setRealtimeStats)
                .catch(console.error);
        };
        fetchStats();
        // every 5 mins
        const intervalId = setInterval(fetchStats, 5 * 60 * 1000);
        return () => clearInterval(intervalId);
    }
  }, [user, repHouse, view]);

  // Presence system: every 15s heartbeats
  useEffect(() => {
    if (!user) return;
    const sendPing = () => {
      fetch('/api/presence/heartbeat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id })
      }).catch(err => console.warn('Presence ping failed:', err));
    };
    sendPing();
    const interval = setInterval(sendPing, 15000);
    return () => clearInterval(interval);
  }, [user]);

  // Assisted user: poll for the 7 people ahead in their queue
  useEffect(() => {
    if (!user || user.role !== 'assisted' || !activeQueue) {
      setAssistedAheadQueue([]);
      return;
    }
    const fetchAhead = () => {
      fetch(`/api/queue/assisted/${user.id}/ahead`)
        .then(r => r.json())
        .then(data => {
          if (Array.isArray(data)) setAssistedAheadQueue(data);
        })
        .catch(console.error);
    };
    fetchAhead();
    const interval = setInterval(fetchAhead, 5000);
    return () => clearInterval(interval);
  }, [user, activeQueue]);

  // Representative user: poll for queue-details when 'fila_atendimento' view is open
  useEffect(() => {
    if (!user || user.role !== 'representative' || !repHouse || view !== 'fila_atendimento') return;
    const fetchQueueDetail = () => {
      fetch(`/api/houses/${repHouse.id}/queue-detail`)
        .then(r => r.json())
        .then(data => {
          if (Array.isArray(data)) setRepQueueDetail(data);
        })
        .catch(console.error);
    };
    fetchQueueDetail();
    const interval = setInterval(fetchQueueDetail, 4000);
    return () => clearInterval(interval);
  }, [user, repHouse, view]);

  // Audio & Alert triggers for active called password
  const lastNotifiedCalledIdRef = React.useRef<number | null>(null);
  useEffect(() => {
    if (!user || user.role !== 'assisted') return;
    const checkCalled = async () => {
      try {
        const res = await fetch(`/api/queue/assisted/active/${user.id}`);
        if (!res.ok) {
          setAssistedActiveCalled(null);
          return;
        }
        const data = await res.json();
        if (data && data.status === 'called') {
          setAssistedActiveCalled(data);
          if (lastNotifiedCalledIdRef.current !== data.id) {
            lastNotifiedCalledIdRef.current = data.id;
            
            // Audio synthesizer beep cue
            try {
              const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
              if (AudioCtx) {
                const ctx = new AudioCtx();
                const now = ctx.currentTime;
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(523.25, now); // C5 node
                osc.frequency.setValueAtTime(659.25, now + 0.15); // E5 node
                osc.frequency.setValueAtTime(783.99, now + 0.3); // G5 node
                gain.gain.setValueAtTime(0.18, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now);
                osc.stop(now + 0.65);
              }
            } catch(e) {}
            
            alert(`ATENÇÃO: Sua senha ${data.ticket_number} foi CHAMADA para a sala ${data.room_number || '—'}. Dirija-se ao local imediatamente!`);
          }
        } else {
          setAssistedActiveCalled(null);
        }
      } catch(e) {
        console.warn('Checking active called password failed:', e);
      }
    };
    checkCalled();
    const interval = setInterval(checkCalled, 4000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    const delay = setTimeout(() => {
      if (searchTerm.length < 3 && !searchService && !searchTime) {
        if (searchTerm.length === 0) {
          fetch('/api/houses').then(res => res.json()).then(setHouses).catch(console.error);
        }
        return;
      }
      fetch(`/api/houses/search?term=${encodeURIComponent(searchTerm)}&service=${encodeURIComponent(searchService)}&time=${encodeURIComponent(searchTime)}`)
        .then(res => res.json())
        .then(setHouses)
        .catch(console.error);
    }, 400);
    return () => clearTimeout(delay);
  }, [searchTerm, searchService, searchTime]);

  useEffect(() => {
    if (!user) return;
    const u = user;
    if (u.role === 'assisted') {
      fetchActiveAssistedQueue(u.id);
      fetch(`/api/users/${u.id}/assisted-attendances`)
        .then(res => res.json())
        .then(setMyHistory)
        .catch(console.error);
      fetch(`/api/users/${u.id}/conferences`)
        .then(res => res.json())
        .then(setMyConferences)
        .catch(console.error);
      fetch(`/api/users/${u.id}/houses`)
        .then(res => res.json())
        .then(setMyHouses)
        .catch(console.error);
    } else if (u.role === 'worker') {
      fetchActiveWorkerQueue(u.id);

      // Fetch active session if any
      fetch(`/api/worker/session/active/${u.id}`)
        .then(res => res.json())
        .then(sess => {
          if (sess && !sess.error) {
            setLoggedSession(sess);
            setWorkerQueueType(sess.current_assistance_type || 'Passe');
            setWorkerQueueRoom(sess.room_number || '1');
          } else {
            setLoggedSession(null);
          }
        })
        .catch(console.error);

      fetch(`/api/users/${u.id}/worker-attendances`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) {
            setWorkerHistory(data);
            setAttendedHistoryList(data.filter((x: any) => x.status === 'completed' || x.status === 'cancelled').slice(0, 15));
          }
        })
        .catch(console.error);

      fetch(`/api/users/${u.id}/houses`)
        .then(res => res.json())
        .then(data => {
          setMyHouses(data);
          if (data && data.length > 0) {
            setWorkerHouseId(data[0].id);
          }
        })
        .catch(console.error);
    } else if (u.role === 'representative') {
      fetch(`/api/houses/rep/${u.id}`)
        .then(res => res.json())
        .then(house => {
          if (house && !house.error) {
            setRepHouse(house);
            fetchRepData(house.id);
          }
        });
    }
  }, [navigate, user]);

  // Periodic poll for worker's enqueued queue list & history
  useEffect(() => {
    if (!user || user.role !== 'worker' || !workerHouseId || !loggedSession) return;
    const pollWorkerData = () => {
      // 1. Fetch panel queues to grep waiting list for current assistance type
      fetch(`/api/queue/panel/${workerHouseId}`)
        .then(r => r.json())
        .then(result => {
          const matches = (result.byType || []).find((b: any) => b.type === loggedSession.current_assistance_type);
          if (matches) {
            setQueueWaitingList(matches.queue || []);
          } else {
            setQueueWaitingList([]);
          }
        })
        .catch(console.error);

      // 2. Fetch completed list
      fetch(`/api/users/${user.id}/worker-attendances`)
        .then(res => res.json())
        .then(data => {
          setAttendedHistoryList(data.filter((x: any) => x.status === 'completed' || x.status === 'cancelled').slice(0, 15));
        })
        .catch(console.error);

      // 3. Fetch current active attendance (keeps UI in-sync)
      fetchActiveWorkerQueue(user.id);
    };

    pollWorkerData();
    const interval = setInterval(pollWorkerData, 3000);
    return () => clearInterval(interval);
  }, [user, workerHouseId, loggedSession]);

  useEffect(() => {
    if (user?.role === 'worker' && workerHouseId) {
      fetch(`/api/houses/${workerHouseId}/assistance-types`)
        .then(r => r.json())
        .then(setAssistanceTypes)
        .catch(console.error);
    }
  }, [workerHouseId, user]);

  const [conferences, setConferences] = useState<any[]>([]);
  const [newConf, setNewConf] = useState({ title: '', description: '', theme: 'Escuro', scheduledDate: '', scheduledTime: '', participantIds: [] });

  const fetchRepData = (houseId: number) => {
    fetch(`/api/houses/${houseId}/workers`).then(r => r.json()).then(setWorkersList);
    fetch(`/api/houses/${houseId}/assisted`).then(r => r.json()).then(setAssistedList);
    fetch(`/api/houses/${houseId}/pending-reports`).then(r => r.json()).then(setPendingTriages);
    fetch(`/api/houses/${houseId}/queue-count`).then(r => r.json()).then(d => setQueueCount(d.count));
    fetch(`/api/houses/${houseId}/assistance-types`).then(r => r.json()).then(setAssistanceTypes);
    fetch(`/api/houses/${houseId}/operating-days`).then(r => r.json()).then(days => {
      const grouped: any = {};
      days.forEach((d: any) => {
        const key = `${d.open_time}-${d.close_time}`;
        if (!grouped[key]) {
          grouped[key] = { id: key, openTime: d.open_time, closeTime: d.close_time, days: [] };
        }
        grouped[key].days.push(d.day_of_week);
      });
      setTimeBlocks(Object.values(grouped));
    });
    fetch(`/api/houses/${houseId}/day-assistances`).then(r => r.json()).then(setDayAssistances);
    fetch(`/api/houses/${houseId}/conferences`).then(r => r.json()).then(setConferences);
  };

  const fetchActiveAssistedQueue = async (id: number) => {
    try {
      const res = await fetch(`/api/queue/assisted/active/${id}`);
      const data = await res.json();
      setActiveQueue(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchActiveWorkerQueue = async (id: number) => {
    try {
      const res = await fetch(`/api/queue/worker/active/${id}`);
      const data = await res.json();
      setWorkerActive(data);
    } catch (e) {
      console.error(e);
    }
  };

  const viewAssistedDetails = async (assisted: any) => {
    setSelectedAssisted(assisted);
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/assisted/${assisted.id}/history`);
      const data = await res.json();
      setAssistedHistory(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('siae_token');
    localStorage.removeItem('siae_user');
    navigate('/');
  };

  const updateWorkerStatus = async (workerId: number, status: string) => {
    if (!repHouse) return;
    try {
      await fetch(`/api/houses/${repHouse.id}/workers/${workerId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      fetchRepData(repHouse.id);
    } catch (e) { console.error(e); }
  };

  const updateAssistedStatus = async (assistedId: number, status: string) => {
    if (!repHouse) return;
    try {
      await fetch(`/api/houses/${repHouse.id}/assisted/${assistedId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      fetchRepData(repHouse.id);
    } catch (e) { console.error(e); }
  };

  const [editingType, setEditingType] = useState<any>(null);

  const addAssistanceType = async () => {
    if (!repHouse) {
      alert("Nenhuma casa espírita encontrada.");
      return;
    }
    if (!newType.name.trim()) {
      alert("Por favor, preencha o nome do serviço.");
      return;
    }
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/assistance-types`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newType)
      });
      
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao salvar: " + data.error);
        return;
      }

      setNewType({ name: '', description: '' });
      fetchRepData(repHouse.id);
      alert("Serviço salvo com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão ao salvar: " + (e as Error).message);
    }
  };

  const updateAssistanceType = async (id: number, updates: any) => {
    if (!repHouse) return;
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/assistance-types/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao editar: " + data.error);
        return;
      }
      setEditingType(null);
      fetchRepData(repHouse.id);
      alert("Editado com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão ao editar: " + (e as Error).message);
    }
  };

  const deleteAssistanceType = async (id: number) => {
    if (!repHouse) return;
    if (!window.confirm('Tem certeza que deseja excluir este serviço?')) return;
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/assistance-types/${id}`, {
        method: 'DELETE'
      });
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao excluir: " + data.error);
        return;
      }
      fetchRepData(repHouse.id);
      alert("Excluído com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão.");
    }
  };

  const addConference = async () => {
    if (!repHouse) return;
    if (!newConf.title.trim() || !newConf.scheduledDate || !newConf.scheduledTime) {
      alert("Preencha título, data e hora.");
      return;
    }
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/conferences`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConf)
      });
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao agendar: " + data.error);
        return;
      }
      setNewConf({ title: '', description: '', theme: 'Escuro', scheduledDate: '', scheduledTime: '', participantIds: [] });
      fetchRepData(repHouse.id);
      alert("Conferência agendada com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão.");
    }
  };

  const deleteConference = async (id: number) => {
    if (!repHouse) return;
    if (!window.confirm('Excluir esta conferência?')) return;
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/conferences/${id}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao excluir: " + data.error);
        return;
      }
      fetchRepData(repHouse.id);
      alert("Excluído com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão.");
    }
  };

  const saveTimeBlock = async (block: any) => {
    if (!repHouse) return;
    if (!block.openTime || !block.closeTime) {
      alert("Preencha horário inicial e final.");
      return;
    }
    const updatedBlocks = block.id && timeBlocks.find(b => b.id === block.id) 
      ? timeBlocks.map(b => (b.id === block.id ? block : b)) 
      : [...timeBlocks, { ...block, id: Math.random().toString() }];
    
    try {
      await fetch(`/api/houses/${repHouse.id}/operating-days/bulk`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeBlocks: updatedBlocks })
      });
      setTimeBlocks(updatedBlocks);
      setEditingBlock(null);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const deleteTimeBlock = async (id: string) => {
    if (!repHouse) return;
    const updatedBlocks = timeBlocks.filter(b => b.id !== id);
    try {
      await fetch(`/api/houses/${repHouse.id}/operating-days/bulk`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeBlocks: updatedBlocks })
      });
      setTimeBlocks(updatedBlocks);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const addDayAssistance = async () => {
    if (!repHouse) return;
    if (!newDayAssistance.assistanceTypeId) {
      alert("Selecione um Tipo de Assistência.");
      return;
    }
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/day-assistances`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newDayAssistance)
      });
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao vincular assistência: " + data.error);
        return;
      }
      fetchRepData(repHouse.id);
      alert("Assistência vinculada com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão.");
    }
  };

  const deleteDayAssistance = async (id: number) => {
    if (!repHouse) return;
    if (!window.confirm('Excluir esta assistência deste dia?')) return;
    try {
      const res = await fetch(`/api/houses/${repHouse.id}/day-assistances/${id}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        alert("Erro ao excluir: " + data.error);
        return;
      }
      fetchRepData(repHouse.id);
      alert("Removido com sucesso!");
    } catch (e) {
      console.error(e);
      alert("Erro de conexão.");
    }
  };

  const daysOfWeek = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  const diasSemana = [
    { id: 0, label: 'Dom' },
    { id: 1, label: 'Seg' },
    { id: 2, label: 'Ter' },
    { id: 3, label: 'Qua' },
    { id: 4, label: 'Qui' },
    { id: 5, label: 'Sex' },
    { id: 6, label: 'Sáb' },
  ];



  const handleWorkerClockIn = async () => {
    if (!workerHouseId) {
      alert('Você precisa selecionar uma casa espírita.');
      return;
    }
    try {
      const res = await fetch('/api/worker/clock-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workerId: user.id,
          houseId: workerHouseId,
          type: workerQueueType,
          roomNumber: workerQueueRoom
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setLoggedSession(data.session);
      alert('Espelho de ponto batido! Você está logado no grupo de assistência.');
    } catch(err: any) {
      alert(err.message);
    }
  };

  const handleWorkerClockOut = async () => {
    if (!workerHouseId) return;
    if (!window.confirm('Deseja realmente declarar fim de expediente e encerrar o seu ponto?')) return;
    try {
      const res = await fetch('/api/worker/clock-out', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workerId: user.id, houseId: workerHouseId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setLoggedSession(null);
      alert('Ponto batido! Expediente finalizado com sucesso.');
    } catch(err: any) {
      alert(err.message);
    }
  };

  const handleWorkerTogglePause = async () => {
    if (!workerHouseId) return;
    try {
      const res = await fetch('/api/worker/toggle-pause', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workerId: user.id, houseId: workerHouseId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setLoggedSession(prev => prev ? { ...prev, status: data.status } : null);
      alert(data.status === 'offline' ? 'Atendimento em PAUSA (descanso) ativado.' : 'Atendimento REATIVADO, pronto para novas chamadas.');
    } catch(err: any) {
      alert(err.message);
    }
  };

  const handleCallNext = async () => {
    if (!workerHouseId) {
      alert('Você não está vinculado a nenhuma casa espírita ativa.');
      return;
    }
    if (loggedSession && loggedSession.status === 'offline') {
      alert('Você está em pausa (descanso). Por favor, reative seu atendimento antes de chamar o próximo.');
      return;
    }
    const currentType = loggedSession ? loggedSession.current_assistance_type : workerType;
    try {
      const res = await fetch('/api/queue/call-next', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ houseId: workerHouseId, workerId: user.id, type: currentType })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      fetchActiveWorkerQueue(user.id);
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleCompleteAttendance = async () => {
    if (!workerActive) return;
    
    if (!window.confirm('Tem certeza que deseja concluir este atendimento?')) {
      return;
    }

    try {
      const res = await fetch('/api/queue/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          attendanceId: workerActive.id, 
          requiredTypes: treatmentPlanTypes,
          additionalTreatments
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      if (data.hasMore === false) {
        alert("Este assistido está liberado dos atendimentos daquele dia atual");
      } else {
        alert(data.message || 'Atendimento concluído!');
      }

      setAdditionalTreatments([]);
      fetchActiveWorkerQueue(user.id);
    } catch (e: any) {
      alert(e.message);
    }
  };

  if (!user) return <div className="p-8 text-center">Carregando...</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Navbar */}
      <header className="bg-indigo-600 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="SIAE Logo" className="w-8 h-8 object-contain bg-white rounded p-1" onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling?.classList.remove('hidden'); }} />
            <Home className="w-6 h-6 hidden" />
            <span className="font-bold text-xl">S.I.A.E Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium">Olá, {user.firstName || user.first_name || 'Usuário'}</span>
            <button 
              onClick={() => setShowPasswordModal(true)} 
              className="inline-flex items-center gap-1 text-sm bg-indigo-700 hover:bg-indigo-800 border border-indigo-500/50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer" 
              title="Alterar Minha Senha"
            >
              <Key className="w-4 h-4 text-indigo-200" />
              <span className="hidden sm:inline">Alterar Senha</span>
            </button>
            <button onClick={handleLogout} className="p-2 hover:bg-indigo-700 rounded-full transition-colors cursor-pointer" title="Sair do SIAE">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* REPRESENTATIVE DASHBOARD */}
        {user.role === 'representative' && (
          <div className="flex flex-col md:flex-row gap-6">
            {/* Sidebar Menu */}
            <div className="w-full md:w-64 bg-white rounded-xl shadow-sm border border-gray-100 p-4 flex flex-col gap-2 h-fit">
              <h2 className="font-bold text-gray-900 mb-2 px-2">Menu Administrativo</h2>
              <button onClick={() => setView('dashboard')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'dashboard' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Visão Geral</button>
              <button onClick={() => setView('assistance_types')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'assistance_types' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Tipos de Assistência</button>
              <button onClick={() => setView('operating_days')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'operating_days' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Dias de Funcionamento</button>
              <button onClick={() => setView('day_assistances')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'day_assistances' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Escalas de Assistência</button>
              <button onClick={() => setView('conferences')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'conferences' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Salas de Conferência</button>
              <button onClick={() => setView('workers')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'workers' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Trabalhadores</button>
              <button onClick={() => setView('assisted')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors ${view === 'assisted' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Assistidos (Todos)</button>
              <button onClick={() => setView('pending_triage')} className={`text-left px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-between ${view === 'pending_triage' ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>
                Aguardando Triagem
                {pendingTriages.length > 0 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{pendingTriages.length}</span>}
              </button>
              <button onClick={() => navigate(`/queue/${repHouse?.id}`)} className="text-left px-4 py-2 rounded-lg font-medium text-indigo-600 hover:bg-indigo-50 mt-4 border border-indigo-100">Painel de Fila (TV)</button>
            </div>

            {/* Content Area */}
            <div className="flex-1">
              {!repHouse ? (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold text-gray-900">Finalizar Cadastro</h1>
                  <p className="text-gray-500">Você precisa cadastrar e vincular uma casa espírita ao seu perfil para continuar.</p>
                  <button onClick={() => navigate('/register-house')} className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Ir para Cadastro da Casa Espírita</button>
                </div>
              ) : (
                <>
                  {view === 'dashboard' && (
                    <div className="space-y-6">
                      <h1 className="text-2xl font-bold text-gray-900">Painel Geral em Tempo Real</h1>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 border-l-4 border-l-blue-500">
                          <div className="p-3 bg-blue-100 text-blue-600 rounded-lg"><Users className="w-6 h-6" /></div>
                          <div>
                            <p className="text-sm text-gray-500 font-medium">Equipe (Ativos)</p>
                            <p className="text-2xl font-bold text-gray-900">{workersList.filter(w => w.status === 'active').length}</p>
                          </div>
                        </div>
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 border-l-4 border-l-purple-500">
                          <div className="p-3 bg-purple-100 text-purple-600 rounded-lg"><Clock className="w-6 h-6" /></div>
                          <div>
                            <p className="text-sm text-gray-500 font-medium">Assistidos em Fila</p>
                            <p className="text-2xl font-bold text-gray-900">{realtimeStats?.totalWaiting || 0}</p>
                          </div>
                        </div>
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 border-l-4 border-l-emerald-500">
                          <div className="p-3 bg-emerald-100 text-emerald-600 rounded-lg"><Activity className="w-6 h-6" /></div>
                          <div>
                            <p className="text-sm text-gray-500 font-medium">Em Atendimento</p>
                            <p className="text-2xl font-bold text-gray-900">{realtimeStats?.services?.reduce((acc: any, curr: any) => acc + curr.inProgressCount, 0) || 0}</p>
                          </div>
                        </div>
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 border-l-4 border-l-indigo-500">
                          <div className="p-3 bg-indigo-100 text-indigo-600 rounded-lg"><Heart className="w-6 h-6" /></div>
                          <div>
                            <p className="text-sm text-gray-500 font-medium">Agendados Hoje</p>
                            <p className="text-2xl font-bold text-gray-900">{realtimeStats?.totalPendingSchedules || 0}</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                        <h2 className="text-lg font-bold text-gray-900 mb-4">Fluxo por Serviço (Atualizado a cada 5min)</h2>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="border-b-2 border-gray-100 text-gray-600 text-sm">
                                <th className="py-3 px-4">Serviço</th>
                                <th className="py-3 px-4">Agendados</th>
                                <th className="py-3 px-4">Na Fila</th>
                                <th className="py-3 px-4">Sendo Atendidos</th>
                                <th className="py-3 px-4">Concluídos</th>
                                <th className="py-3 px-4 text-right">Tempo Médio & Previsão</th>
                              </tr>
                            </thead>
                            <tbody>
                              {!realtimeStats?.services?.length && (
                                <tr>
                                  <td colSpan={6} className="py-4 text-center text-gray-400">Nenhum dado capturado ainda.</td>
                                </tr>
                              )}
                              {realtimeStats?.services?.map((svc: any, idx: number) => (
                                <tr key={idx} className="border-b border-gray-50 hover:bg-gray-50 text-sm">
                                  <td className="py-3 px-4 font-bold text-indigo-700">{svc.serviceName}</td>
                                  <td className="py-3 px-4">{svc.pendingSchedules} esc.</td>
                                  <td className="py-3 px-4">
                                    <span className="font-bold flex items-center gap-1">
                                      <Users className="w-4 h-4 text-gray-400" /> {svc.waitingCount} logados
                                    </span>
                                  </td>
                                  <td className="py-3 px-4">
                                    <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-xs font-bold">{svc.inProgressCount} ativos</span>
                                  </td>
                                  <td className="py-3 px-4">
                                    <span className="text-green-600 font-medium">{svc.completedCount}</span>
                                  </td>
                                  <td className="py-3 px-4 text-right">
                                    <p className="font-medium text-gray-700">Média: ~{Math.round(svc.avgTimeMinutes)}m/pessoa</p>
                                    <p className="text-xs text-gray-400">Termina (Fila): +{svc.estimatedWaitTime}m</p>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

              {view === 'assistance_types' && (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold text-gray-900">Tipos de Assistência</h1>
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-lg font-bold mb-4">Adicionar Nova Assistência</h2>
                    <div className="flex gap-4">
                      <input type="text" placeholder="Nome da Assistência (ex: Passe)" value={newType.name} onChange={e => setNewType({...newType, name: e.target.value})} className="flex-1 border rounded-lg p-2" />
                      <input type="text" placeholder="Descrição" value={newType.description} onChange={e => setNewType({...newType, description: e.target.value})} className="flex-2 border rounded-lg p-2" />
                      <button onClick={addAssistanceType} className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-indigo-700">Salvar Assistência</button>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <table className="w-full text-left">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="p-4">Nome</th>
                          <th className="p-4">Descrição</th>
                          <th className="p-4">Status</th>
                          <th className="p-4">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {assistanceTypes.map(t => (
                          <tr key={t.id} className="border-b border-gray-50">
                            {editingType && editingType.id === t.id ? (
                              <>
                                <td className="p-4">
                                  <input type="text" value={editingType.name} onChange={e => setEditingType({...editingType, name: e.target.value})} className="border rounded px-2 py-1 w-full" />
                                </td>
                                <td className="p-4">
                                  <input type="text" value={editingType.description} onChange={e => setEditingType({...editingType, description: e.target.value})} className="border rounded px-2 py-1 w-full" />
                                </td>
                                <td className="p-4">
                                  <select value={editingType.status} onChange={e => setEditingType({...editingType, status: e.target.value})} className="border rounded px-2 py-1">
                                    <option value="active">Ativo</option>
                                    <option value="inactive">Inativo</option>
                                  </select>
                                </td>
                                <td className="p-4 flex gap-2">
                                  <button onClick={() => updateAssistanceType(t.id, editingType)} className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">Salvar</button>
                                  <button onClick={() => setEditingType(null)} className="bg-gray-400 text-white px-3 py-1 rounded text-sm hover:bg-gray-500">Cancelar</button>
                                </td>
                              </>
                            ) : (
                              <>
                                <td className="p-4 font-bold text-gray-900">{t.name}</td>
                                <td className="p-4 text-gray-600">{t.description}</td>
                                <td className="p-4">
                                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${t.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                                    {t.status === 'active' ? 'Ativo' : 'Inativo'}
                                  </span>
                                </td>
                                <td className="p-4 flex gap-2">
                                  <button onClick={() => setEditingType(t)} className="text-indigo-600 hover:text-indigo-800 text-sm font-medium">Editar</button>
                                  <button onClick={() => updateAssistanceType(t.id, { name: t.name, description: t.description, status: t.status === 'active' ? 'inactive' : 'active' })} className="text-amber-600 hover:text-amber-800 text-sm font-medium">
                                    {t.status === 'active' ? 'Desativar' : 'Ativar'}
                                  </button>
                                  <button onClick={() => deleteAssistanceType(t.id)} className="text-red-600 hover:text-red-800 text-sm font-medium">Excluir</button>
                                </td>
                              </>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {view === 'conferences' && (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold text-gray-900">Salas de Videoconferência</h1>
                  <p className="text-gray-600">Crie salas para tratamento simultâneo de vários assistidos e copie o link para compartilhar.</p>
                  
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-lg font-bold mb-4">Formulário de Criação de Sala de Videoconferência Agendada</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Nome da Sala</label>
                        <input type="text" placeholder="Nome (ex: Passe Coletivo)" value={newConf.title} onChange={e => setNewConf({...newConf, title: e.target.value})} className="border rounded-lg p-2 w-full" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tema / Assunto</label>
                        <input type="text" placeholder="Assunto (ex: Passe Coletivo Coletivo)" value={newConf.description} onChange={e => setNewConf({...newConf, description: e.target.value})} className="border rounded-lg p-2 w-full" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Data</label>
                        <input type="date" value={newConf.scheduledDate} onChange={e => setNewConf({...newConf, scheduledDate: e.target.value})} className="border rounded-lg p-2 w-full" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Hora</label>
                        <input type="time" value={newConf.scheduledTime} onChange={e => setNewConf({...newConf, scheduledTime: e.target.value})} className="border rounded-lg p-2 w-full" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Estilo Visual / Tema do Vídeo</label>
                        <select value={newConf.theme} onChange={e => setNewConf({...newConf, theme: e.target.value})} className="border rounded-lg p-2 w-full">
                          <option value="Escuro">Espírito Escuro (Escuro)</option>
                          <option value="Claro">Luz Clarificada (Claro)</option>
                          <option value="Azul">Irradiação Azul (Azul)</option>
                          <option value="Roxo">Aura Violeta (Roxo)</option>
                          <option value="Verde">Cura e Fluido Verde (Verde)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="mt-4 border-t pt-4">
                      <h3 className="font-medium text-sm text-gray-700 mb-2">Convocar Participantes (Opcional - eles verão no painel deles):</h3>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-40 overflow-y-auto bg-gray-50 p-2 rounded border">
                        {assistedList.map(a => (
                          <label key={a.id} className="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" checked={newConf.participantIds.includes(a.id as never)} onChange={(e) => {
                              if (e.target.checked) setNewConf({...newConf, participantIds: [...newConf.participantIds, a.id as never]});
                              else setNewConf({...newConf, participantIds: newConf.participantIds.filter(id => id !== a.id)});
                            }} className="rounded text-indigo-600 focus:ring-indigo-500" />
                            {a.first_name} {a.last_name}
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6">
                      <button onClick={addConference} className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700 transition flex items-center gap-2">
                        Criar Sala de Videoconferência
                      </button>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <table className="w-full text-left">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="p-4">Título</th>
                          <th className="p-4">Data/Hora</th>
                          <th className="p-4">Link de Acesso</th>
                          <th className="p-4">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {conferences.length === 0 ? (
                          <tr><td colSpan={4} className="p-4 text-center text-gray-500">Nenhuma conferência agendada.</td></tr>
                        ) : conferences.map(c => (
                          <tr key={c.id} className="border-b border-gray-50">
                            <td className="p-4 font-bold text-gray-900">
                              {c.title}
                              <p className="text-xs text-gray-500 font-normal">{c.description}</p>
                              <div className="text-xs mt-1 text-indigo-600">
                                {c.participants?.length > 0 ? `${c.participants.length} convocado(s)` : ''}
                              </div>
                            </td>
                            <td className="p-4 text-gray-600">{new Date(c.scheduled_date + 'T' + c.scheduled_time).toLocaleString()}</td>
                            <td className="p-4">
                              <div className="flex flex-col gap-2">
                                <a href={`/room/${c.room_name}`} target="_blank" className="bg-blue-100 text-blue-700 px-3 py-1 rounded text-sm text-center font-bold inline-block hover:bg-blue-200">
                                  Entrar na Sala
                                </a>
                                <button onClick={() => {
                                  const link = `${window.location.origin}/room/${c.room_name}`;
                                  navigator.clipboard.writeText(`Participe da videoconferência do SIAE: ${link}`);
                                  alert('Link da sala copiado com sucesso!');
                                }} className="text-xs text-gray-500 border rounded px-2 py-1 hover:bg-gray-100">
                                  Copiar Link
                                </button>
                              </div>
                            </td>
                            <td className="p-4">
                              <button onClick={() => deleteConference(c.id)} className="text-red-600 hover:text-red-800 text-sm font-medium">Excluir</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {view === 'operating_days' && (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold text-gray-900">Horários de Funcionamento</h1>
                  
                  <div className="mb-6">
                    <button 
                      onClick={() => setEditingBlock({ openTime: '', closeTime: '', days: [] })} 
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
                    >
                      <Calendar className="w-4 h-4" /> Adicionar Horário
                    </button>
                  </div>

                  {editingBlock && (
                    <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 mb-6 shadow-sm">
                      <h4 className="font-bold text-gray-800 mb-4 text-lg">{editingBlock.id ? 'Editar Horário' : 'Novo Horário'}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Horário Inicial</label>
                          <input type="time" value={editingBlock.openTime} onChange={e => setEditingBlock({...editingBlock, openTime: e.target.value})} className="w-full border rounded-lg p-2" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Horário Final</label>
                          <input type="time" value={editingBlock.closeTime} onChange={e => setEditingBlock({...editingBlock, closeTime: e.target.value})} className="w-full border rounded-lg p-2" />
                        </div>
                      </div>
                      <div className="mb-6">
                        <label className="block text-sm font-medium text-gray-700 mb-3">Dias da Semana</label>
                        <div className="flex flex-wrap gap-4">
                          {diasSemana.map(d => (
                            <label key={d.id} className="flex items-center gap-2 cursor-pointer bg-white border px-3 py-2 rounded-lg hover:border-indigo-400 transition-colors">
                              <input 
                                type="checkbox" 
                                checked={editingBlock.days.includes(d.id)}
                                onChange={(e) => {
                                  const checked = e.target.checked;
                                  setEditingBlock((prev: any) => ({
                                    ...prev, 
                                    days: checked ? [...prev.days, d.id] : prev.days.filter((x: number) => x !== d.id)
                                  }))
                                }}
                                className="w-5 h-5 text-indigo-600 accent-indigo-600"
                              />
                              <span className="text-sm font-medium select-none text-gray-700">{d.label}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-3">
                        <button onClick={() => saveTimeBlock(editingBlock)} className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium shadow-sm hover:bg-indigo-700 flex items-center gap-2"><Save className="w-4 h-4"/> Salvar na Tabela</button>
                        <button onClick={() => setEditingBlock(null)} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-lg font-medium hover:bg-gray-300">Cancelar</button>
                      </div>
                    </div>
                  )}

                  <div className="overflow-x-auto border rounded-xl mb-6 shadow-sm">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-gray-100 border-b">
                          <th className="p-4 font-bold text-gray-700 border-r w-1/4">Horário</th>
                          <th className="p-4 font-bold text-gray-700 text-center" colSpan={7}>Dias da Semana</th>
                          <th className="p-4 font-bold text-gray-700 w-32 text-right">Ações</th>
                        </tr>
                        <tr className="bg-gray-50 border-b text-sm">
                          <th className="p-2 border-r text-center font-medium text-gray-500">Início - Fim</th>
                          {diasSemana.map(d => (
                            <th key={d.id} className="p-2 text-center text-xs text-gray-500 border-r">{d.label}</th>
                          ))}
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {timeBlocks.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="p-8 text-center text-gray-500">Nenhum horário parametrizado. Clique em "Adicionar Horário".</td>
                          </tr>
                        ) : timeBlocks.map((block) => (
                          <tr key={block.id} className="border-b hover:bg-gray-50 transition-colors">
                            <td className="p-4 font-bold text-indigo-900 border-r text-center whitespace-nowrap">{block.openTime || '--:--'} às {block.closeTime || '--:--'}</td>
                            {diasSemana.map(d => (
                              <td key={d.id} className="p-4 text-center border-r bg-white">
                                <input type="checkbox" readOnly checked={block.days.includes(d.id)} className="w-5 h-5 accent-indigo-600 cursor-default" />
                              </td>
                            ))}
                            <td className="p-4 text-right whitespace-nowrap">
                              <button onClick={() => setEditingBlock(block)} className="text-blue-600 hover:text-blue-800 p-2 mx-1 rounded-full hover:bg-blue-50 transition-colors"><Edit2 className="w-5 h-5" /></button>
                              <button onClick={() => deleteTimeBlock(block.id)} className="text-red-600 hover:text-red-800 p-2 mx-1 rounded-full hover:bg-red-50 transition-colors"><Trash2 className="w-5 h-5" /></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {view === 'day_assistances' && (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold text-gray-900">Assistências por Dia da Semana</h1>
                  
                  <div className="grid grid-cols-1 gap-6">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                      <h2 className="text-lg font-bold mb-4">Adicionar Assistência ao Dia</h2>
                      <div className="flex gap-4 items-end">
                        <div className="flex-1">
                          <label className="block text-sm text-gray-700 mb-1">Dia da Semana</label>
                          <select value={newDayAssistance.dayOfWeek} onChange={e => setNewDayAssistance({...newDayAssistance, dayOfWeek: parseInt(e.target.value)})} className="w-full border rounded-lg p-2">
                            {daysOfWeek.map((d, i) => <option key={i} value={i}>{d}</option>)}
                          </select>
                        </div>
                        <div className="flex-1">
                          <label className="block text-sm text-gray-700 mb-1">Tipo de Assistência</label>
                          <select value={newDayAssistance.assistanceTypeId} onChange={e => setNewDayAssistance({...newDayAssistance, assistanceTypeId: e.target.value})} className="w-full border rounded-lg p-2">
                            <option value="">Selecione a Assistência</option>
                            {assistanceTypes.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                          </select>
                        </div>
                        <button onClick={addDayAssistance} className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium">Vincular</button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-lg font-bold mb-4">Escala de Assistências</h2>
                    <div className="space-y-4">
                      {daysOfWeek.map((dayName, idx) => {
                        const dayAssists = dayAssistances.filter(da => da.day_of_week === idx);
                        if (dayAssists.length === 0) return null;
                        
                        return (
                          <div key={idx} className="border border-gray-200 rounded-lg p-4 flex flex-col gap-2">
                            <h3 className="font-bold text-indigo-700">{dayName}</h3>
                            <div className="flex flex-wrap gap-2">
                              {dayAssists.map(da => (
                                <span key={da.id} className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-sm flex items-center gap-2">
                                  {da.assistance_name}
                                  <button onClick={() => deleteDayAssistance(da.id)} className="text-red-500 hover:text-red-700 font-bold px-1">&times;</button>
                                </span>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                      {dayAssistances.length === 0 && <p className="text-gray-500">Nenhuma assistência vinculada na escala.</p>}
                    </div>
                  </div>
                </div>
              )}

              {view === 'workers' && (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold text-gray-900">Solicitações e Trabalhadores</h1>
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <table className="w-full text-left">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="p-4 font-medium text-gray-600">Nome</th>
                          <th className="p-4 font-medium text-gray-600">Contato</th>
                          <th className="p-4 font-medium text-gray-600">Status</th>
                          <th className="p-4 font-medium text-gray-600">Fila de Chamadas</th>
                          <th className="p-4 font-medium text-gray-600">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {workersList.map(w => (
                          <tr key={w.id} className="border-b border-gray-50">
                            <td className="p-4">
                              <p className="font-bold text-gray-900">{w.first_name} {w.last_name}</p>
                              <p className="text-sm text-gray-500">Nasc: {w.dob}</p>
                              <p className="text-sm text-gray-500">Espec: {w.specializations || '-'}</p>
                            </td>
                            <td className="p-4">
                              <p className="text-sm text-gray-900">{w.email}</p>
                              <p className="text-sm text-gray-500">{w.phone}</p>
                            </td>
                            <td className="p-4">
                              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase
                                ${w.status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 
                                  w.status === 'active' ? 'bg-green-100 text-green-700' : 
                                  w.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'}`}>
                                {w.status}
                              </span>
                            </td>
                            <td className="p-4">
                              {w.status === 'active' ? (
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox"
                                    id={`queue-chk-${w.id}`}
                                    checked={w.queue_enabled === 1}
                                    onChange={async (e) => {
                                      try {
                                        await fetch(`/api/houses/${repHouse.id}/workers/${w.id}/toggle-queue`, {
                                          method: 'POST',
                                          headers: { 'Content-Type': 'application/json' },
                                          body: JSON.stringify({ enabled: e.target.checked })
                                        });
                                        fetchRepData(repHouse.id);
                                      } catch(err) {
                                        console.error(err);
                                      }
                                    }}
                                    className="w-4 h-4 text-indigo-650 border-gray-300 rounded focus:ring-indigo-500"
                                  />
                                  <span className="text-xs font-semibold text-gray-700">Fila Habilitada</span>
                                </div>
                              ) : (
                                <span className="text-xs text-gray-400">—</span>
                              )}
                            </td>
                            <td className="p-4 flex gap-2">
                              {w.status === 'pending' && (
                                <>
                                  <button onClick={() => updateWorkerStatus(w.id, 'active')} className="text-green-600 hover:text-green-800 font-medium text-sm">Aprovar</button>
                                  <button onClick={() => updateWorkerStatus(w.id, 'rejected')} className="text-red-600 hover:text-red-800 font-medium text-sm">Recusar</button>
                                </>
                              )}
                              {w.status === 'active' && (
                                <button onClick={() => updateWorkerStatus(w.id, 'inactive')} className="text-gray-600 hover:text-gray-800 font-medium text-sm">Desativar</button>
                              )}
                              {w.status === 'inactive' && (
                                <button onClick={() => updateWorkerStatus(w.id, 'active')} className="text-indigo-600 hover:text-indigo-800 font-medium text-sm">Reativar</button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {view === 'pending_triage' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-gray-900">Assistidos Aguardando Triagem/Tratamento</h1>
                    {selectedAssisted && <button onClick={() => setSelectedAssisted(null)} className="text-gray-500 hover:text-gray-700">Voltar para Lista</button>}
                  </div>

                  {!selectedAssisted ? (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                      <table className="w-full text-left">
                        <thead className="bg-gray-50 border-b border-gray-100">
                          <tr>
                            <th className="p-4 font-medium text-gray-600">Assistido</th>
                            <th className="p-4 font-medium text-gray-600">Relato / Queixa</th>
                            <th className="p-4 font-medium text-gray-600">Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pendingTriages.length === 0 && <tr><td colSpan={3} className="p-4 text-center text-gray-500">Nenhum assistido na fila de triagem.</td></tr>}
                          {pendingTriages.map((pt, idx) => (
                            <tr key={idx} className="border-b border-gray-50">
                              <td className="p-4">
                                <p className="font-bold text-gray-900">{pt.first_name} {pt.last_name}</p>
                                <p className="text-sm text-gray-500">{pt.email}</p>
                                <p className="text-sm text-gray-500">{pt.phone}</p>
                                <p className="text-xs text-gray-400 mt-1">Enviado: {new Date(pt.created_at).toLocaleString()}</p>
                              </td>
                              <td className="p-4">
                                <p className="text-sm text-gray-800 line-clamp-3">{pt.problem_description}</p>
                              </td>
                              <td className="p-4">
                                <button onClick={() => viewAssistedDetails({ id: pt.assisted_id, first_name: pt.first_name, last_name: pt.last_name, email: pt.email, phone: pt.phone })} className="bg-indigo-600 text-white px-3 py-1 rounded text-sm hover:bg-indigo-700 font-medium">Avaliar e Aplicar Tratamento</button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                      <div className="flex justify-between items-start mb-6">
                        <div>
                          <h2 className="text-xl font-bold text-gray-900">{selectedAssisted.first_name} {selectedAssisted.last_name}</h2>
                          <p className="text-gray-600">{selectedAssisted.email} | {selectedAssisted.phone}</p>
                        </div>
                      </div>
                      
                      <div className="mb-8">
                        <h3 className="font-bold text-gray-900 mb-4 border-b pb-2">Aplicar Tratamento (Triagem)</h3>
                        {/* We use AssistedReports here to allow inline treatment assignment */}
                        <AssistedReports houseId={repHouse.id} assistedId={selectedAssisted.id} assistanceTypes={assistanceTypes} onRefresh={() => fetchRepData(repHouse.id)} />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {view === 'assisted' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-bold text-gray-900">Fichas de Assistidos e Triagem</h1>
                    {selectedAssisted && <button onClick={() => setSelectedAssisted(null)} className="text-gray-500 hover:text-gray-700">Voltar para Lista</button>}
                  </div>
                  
                  {!selectedAssisted ? (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                      <table className="w-full text-left">
                        <thead className="bg-gray-50 border-b border-gray-100">
                          <tr>
                            <th className="p-4 font-medium text-gray-600">Nome</th>
                            <th className="p-4 font-medium text-gray-600">Contato</th>
                            <th className="p-4 font-medium text-gray-600">Status</th>
                            <th className="p-4 font-medium text-gray-600">Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          {assistedList.map(a => (
                            <tr key={a.id} className="border-b border-gray-50">
                              <td className="p-4">
                                <p className="font-bold text-gray-900">{a.first_name} {a.last_name}</p>
                                <p className="text-sm text-gray-500">Nasc: {a.dob}</p>
                              </td>
                              <td className="p-4">
                                <p className="text-sm text-gray-900">{a.email}</p>
                                <p className="text-sm text-gray-500">{a.phone}</p>
                              </td>
                              <td className="p-4">
                                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${a.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                                  {a.status}
                                </span>
                              </td>
                              <td className="p-4 flex gap-3 items-center">
                                <button onClick={() => viewAssistedDetails(a)} className="text-indigo-600 hover:text-indigo-800 font-medium text-sm">Ver Ficha / Triagem</button>
                                {a.status === 'active' ? (
                                  <button onClick={() => updateAssistedStatus(a.id, 'inactive')} className="text-red-600 hover:text-red-800 font-medium text-sm">Desativar</button>
                                ) : (
                                  <button onClick={() => updateAssistedStatus(a.id, 'active')} className="text-green-600 hover:text-green-800 font-medium text-sm">Ativar</button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                      <div className="flex justify-between items-start mb-6">
                        <div>
                          <h2 className="text-xl font-bold text-gray-900">{selectedAssisted.first_name} {selectedAssisted.last_name}</h2>
                          <p className="text-gray-600">{selectedAssisted.email} | {selectedAssisted.phone}</p>
                          <p className="text-gray-500 text-sm mt-1">{selectedAssisted.street}, {selectedAssisted.city} - {selectedAssisted.state}</p>
                        </div>
                      </div>
                      
                      <div className="mb-8">
                        <h3 className="font-bold text-gray-900 mb-4 border-b pb-2">Relatos e Triagem (Acolhimento)</h3>
                        <AssistedReports houseId={repHouse.id} assistedId={selectedAssisted.id} assistanceTypes={assistanceTypes} onRefresh={() => fetchRepData(repHouse.id)} />
                      </div>

                      <h3 className="font-bold text-gray-900 mb-4 border-b pb-2">Histórico de Atendimentos</h3>
                      {assistedHistory.length === 0 ? (
                        <p className="text-gray-500">Nenhum atendimento registrado.</p>
                      ) : (
                        <div className="space-y-4">
                          {assistedHistory.map(h => (
                            <div key={h.id} className="border border-gray-100 rounded-lg p-4 bg-gray-50">
                              <div className="flex justify-between mb-2">
                                <span className="font-bold text-indigo-700">{h.type}</span>
                                <span className="text-sm text-gray-500">{new Date(h.created_at).toLocaleString()}</span>
                              </div>
                              <p className="text-sm text-gray-700"><strong>Status:</strong> {h.status}</p>
                              <p className="text-sm text-gray-700"><strong>Trabalhador:</strong> {h.worker_first ? `${h.worker_first} ${h.worker_last}` : 'Não atribuído'}</p>
                              {h.total_sessions > 0 && (
                                <p className="text-sm text-gray-700 mt-1">
                                  <strong>Sessões:</strong> {h.completed_sessions || 1} de {h.total_sessions}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
                </>
              )}
            </div>
          </div>
        )}

        {/* WORKER DASHBOARD */}
        {user.role === 'worker' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Painel do Trabalhador</h1>
            <StoreAd />
            
            {myHouses.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Minhas Casas Espíritas Associadas</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {myHouses.map(h => (
                    <div key={h.id} className="border border-indigo-100 bg-indigo-50 rounded-lg p-4 flex flex-col justify-between">
                      <div>
                        <h3 className="font-bold text-indigo-900">{h.name}</h3>
                        <p className="text-sm text-indigo-700 mt-1">{h.street}, {h.number} - {h.city}</p>
                      </div>
                      <button
                        onClick={async () => {
                          if(!window.confirm('Deseja desvincular-se desta casa?')) return;
                          try {
                            const res = await fetch(`/api/houses/${h.id}/workers/${user.id}`, { method: 'DELETE' });
                            const data = await res.json();
                            alert(data.message);
                            fetch(`/api/users/${user.id}/houses`).then(r => r.json()).then(data => { setMyHouses(data); if(data.length > 0) setWorkerHouseId(data[0].id); else setWorkerHouseId(null); });
                          } catch(e) { console.error(e); }
                        }}
                        className="mt-4 w-full bg-white text-red-600 border border-red-200 py-2 rounded-md text-sm font-bold hover:bg-red-50 transition-colors"
                      >
                        <Trash2 className="w-4 h-4 inline-block mr-1" />
                        Desvincular-se
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Vincular-se a uma Casa Espírita</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                  <input 
                    type="text" 
                    placeholder="Nome, cidade, estado..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <input 
                    type="text" 
                    placeholder="Tipo de serviço (ex: Passe)..." 
                    value={searchService}
                    onChange={(e) => setSearchService(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <input 
                    type="text" 
                    placeholder="Horário (ex: sáb, 08h)..." 
                    value={searchTime}
                    onChange={(e) => setSearchTime(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {houses.filter((h: any) => !myHouses.some(mh => mh.id === h.id)).map((house: any) => (
                  <div key={house.id} className="border border-gray-200 rounded-lg p-4 hover:border-indigo-300 transition-colors flex flex-col">
                    <h3 className="font-bold text-gray-900">{house.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{house.neighborhood}, {house.city} - {house.state}</p>
                    
                    {house.operating_hours && (
                      <div className="mt-3 text-sm text-gray-700">
                        <span className="font-semibold block">Horários:</span>
                        {house.operating_hours}
                      </div>
                    )}
                    
                    <div className="mt-3 flex flex-wrap gap-2 flex-grow">
                      {house.services?.split(',').map((s: string, i: number) => (
                        <span key={i} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">{s.trim()}</span>
                      ))}
                    </div>

                    <button 
                      onClick={async () => {
                        try {
                          const res = await fetch(`/api/houses/${house.id}/workers/link`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ workerId: user.id })
                          });
                          const data = await res.json();
                          alert(data.message);
                          fetch(`/api/users/${user.id}/houses`).then(r => r.json()).then(data => { setMyHouses(data); if(data.length > 0) setWorkerHouseId(data[0].id); });
                        } catch(e) { console.error(e); }
                      }}
                      className="mt-4 w-full bg-indigo-600 text-white py-2 rounded-md text-sm font-medium hover:bg-indigo-700"
                    >
                      Vincular-se
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* NOVO APLICATIVO DE CHAMADA DE SENHAS DE ASSISTIDOS (RESPONSIVO) */}
            <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-indigo-600 animate-pulse" />
                  <h2 className="text-xl font-bold text-gray-900">Aplicativo de Chamada de Senhas</h2>
                </div>
                <div className="flex items-center gap-2">
                  {loggedSession ? (
                    <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider
                      ${loggedSession.status === 'offline' ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800 animate-pulse'}`}>
                      {loggedSession.status === 'offline' ? '● Em Pausa / Pausado' : '● Online / Disponível'}
                    </span>
                  ) : (
                    <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs font-bold uppercase">
                      Deslogado
                    </span>
                  )}
                </div>
              </div>

              {!loggedSession ? (
                <div className="bg-gray-50 border border-gray-100 rounded-lg p-5 max-w-xl mx-auto space-y-4">
                  <p className="text-sm font-semibold text-gray-700">Primeiro, forneça os dados de atendimento para iniciar o expediente:</p>
                  
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Tipo de Assistência</label>
                      <select 
                        value={workerQueueType}
                        onChange={(e) => setWorkerQueueType(e.target.value)}
                        className="w-full rounded-lg border-gray-200 border p-3 text-sm focus:ring-indigo-500 focus:border-indigo-500 font-medium"
                      >
                        <option value="Passe">Passe</option>
                        <option value="Atendimento Fraterno">Atendimento Fraterno</option>
                        <option value="Desobsessão">Desobsessão</option>
                        <option value="Apometria">Apometria</option>
                        <option value="Cura">Cura Espiritual</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Número da Sala</label>
                      <input 
                        type="text" 
                        value={workerQueueRoom}
                        onChange={(e) => setWorkerQueueRoom(e.target.value)}
                        placeholder="Ex: Sala 3 ou Sala de Passes II"
                        className="w-full rounded-lg border-gray-200 border p-3 text-sm focus:ring-indigo-500"
                      />
                    </div>
                  </div>

                  <button 
                    onClick={handleWorkerClockIn} 
                    className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold text-sm hover:bg-indigo-700 transition-colors shadow-sm flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-4 h-4" /> Bater Ponto & Se Logar no Grupo
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Lock Screen Settings Display */}
                  <div className="bg-indigo-50/60 border border-indigo-100/60 rounded-lg p-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm text-indigo-900 font-medium">
                    <div>
                      <span className="block text-xs font-bold text-indigo-400 uppercase tracking-widest mb-0.5">Grupo sob Atendimento</span>
                      <span className="font-bold text-indigo-950 text-base">{loggedSession.current_assistance_type}</span>
                    </div>
                    <div>
                      <span className="block text-xs font-bold text-indigo-400 uppercase tracking-widest mb-0.5">Sala Designada</span>
                      <span className="font-bold text-indigo-950 text-base">Sala {loggedSession.room_number || '—'}</span>
                    </div>
                    <div>
                      <span className="block text-xs font-bold text-indigo-400 uppercase tracking-widest mb-0.5">Usuário</span>
                      <span className="font-bold text-indigo-950 text-base">{user.first_name} (Você)</span>
                    </div>
                  </div>

                  {/* Active call detail or prompt */}
                  {workerActive ? (
                    <div className="bg-indigo-600 text-white rounded-xl shadow-md p-6 relative overflow-hidden">
                      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <Users className="w-5 h-5 text-indigo-200" />
                        Atendimento em Andamento
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm border border-white/20">
                          <p className="text-xs text-indigo-200 uppercase tracking-wider font-semibold mb-1">Senha Chamada</p>
                          <p className="text-4xl font-extrabold tracking-tighter">{workerActive.ticket_number}</p>
                          <p className="text-indigo-100 font-bold text-sm mt-3 uppercase">Status: <span className="bg-amber-400 text-amber-950 font-black text-xs px-2 py-0.5 rounded-full ml-1">{workerActive.status}</span></p>
                        </div>
                        <div className="flex flex-col justify-center">
                          <p className="text-sm font-semibold text-indigo-150">Assistido:</p>
                          <p className="text-2xl font-black">{workerActive.first_name} {workerActive.last_name || ''}</p>
                          <p className="text-xs text-indigo-200 mt-2">Peça para o assistido aproximar a tag NFC para autenticar ou dê baixa para enviá-lo para sua próxima assistência.</p>
                        </div>
                      </div>

                      {/* Continuous recommendations logic (Apometria as template or similar) */}
                      {workerActive.type.toString().toLowerCase().includes('apometria') && (
                        <div className="mt-6 p-4 bg-white/10 border border-white/10 rounded-lg text-white">
                          <h4 className="font-bold text-white mb-2">Indicação de Continuidade de Tratamento</h4>
                          <div className="flex gap-2">
                            <select 
                              id="additionalTreatSelect" 
                              className="flex-1 rounded-lg border-transparent text-indigo-900 bg-white p-2 text-sm"
                            >
                              <option value="">Selecione adicionais...</option>
                              {assistanceTypes.map(t => (
                                <option key={t.id} value={t.id}>{t.name}</option>
                              ))}
                            </select>
                            <button 
                              onClick={() => {
                                const sel = document.getElementById('additionalTreatSelect') as HTMLSelectElement;
                                if (sel.value && !additionalTreatments.includes(sel.value)) {
                                  setAdditionalTreatments([...additionalTreatments, sel.value]);
                                  sel.value = '';
                                }
                              }}
                              className="bg-indigo-700 text-white px-4 py-2 border border-white/30 rounded font-bold text-sm hover:bg-indigo-800"
                            >
                              Adicionar
                            </button>
                          </div>

                          {additionalTreatments.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-3">
                              {additionalTreatments.map(tId => {
                                const tName = assistanceTypes.find(a => String(a.id) === String(tId))?.name || 'Tratamento';
                                return (
                                  <div key={tId} className="bg-white/20 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-2">
                                    <span>{tName}</span>
                                    <button onClick={() => setAdditionalTreatments(additionalTreatments.filter(id => id !== tId))} className="text-white hover:text-indigo-250">✕</button>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}

                      <div className="mt-6 flex flex-col sm:flex-row gap-3">
                        <button 
                          onClick={handleCompleteAttendance} 
                          className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-colors"
                        >
                          <CheckCircle className="w-5 h-5" /> Concluir Atendimento
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-emerald-50/70 border border-dashed border-emerald-200 rounded-lg p-8 text-center text-emerald-800">
                      <Clock className="w-12 h-12 text-emerald-500 mx-auto mb-3 animate-pulse" />
                      <p className="font-bold text-base">Nenhum Atendimento Ativo no Momento</p>
                      <p className="text-xs mt-1 mb-4 text-emerald-700">Clique em "Chamar Próximo" para chamar o próximo paciente disponível na fila de {loggedSession.current_assistance_type}.</p>
                      <button 
                        onClick={handleCallNext} 
                        className="bg-indigo-600 text-white py-2.5 px-5 rounded-lg font-bold text-xs hover:bg-indigo-700 inline-flex items-center gap-2 shadow-sm transition-colors"
                      >
                        <Play className="w-4 h-4" /> Chamar Próximo da Fila
                      </button>
                    </div>
                  )}

                  {/* Operational Controls Row */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-t border-b border-gray-100 py-6">
                    <button 
                      onClick={handleCallNext} 
                      className="bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Play className="w-4 h-4" /> Chamar Próximo
                    </button>
                    <button 
                      onClick={handleWorkerTogglePause} 
                      className="bg-amber-600 hover:bg-amber-700 text-white py-3 px-4 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Clock className="w-4 h-4" /> Pausa (Descanso)
                    </button>
                    <button 
                      onClick={handleCompleteAttendance}
                      disabled={!workerActive}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <CheckCircle className="w-4 h-4" /> Concluir
                    </button>
                    <button 
                      onClick={handleWorkerClockOut} 
                      className="bg-red-600 hover:bg-red-700 text-white py-3 px-4 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <LogOut className="w-4 h-4" /> Terminar Expediente
                    </button>
                  </div>

                  {/* Queues and attended lists */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    {/* Waiting queue list */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                      <h4 className="font-bold text-gray-800 mb-3 uppercase tracking-wider text-xs flex items-center justify-between">
                        <span>Aguardando Chamada</span>
                        <span className="bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded text-xs font-extrabold">{queueWaitingList.length}</span>
                      </h4>

                      {queueWaitingList.length === 0 ? (
                        <p className="text-xs text-gray-400 italic py-4">Fila vazia. Não há assistidos aguardando este grupo no momento.</p>
                      ) : (
                        <div className="space-y-2 max-h-[250px] overflow-y-auto">
                          {queueWaitingList.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-gray-100 shadow-sm text-xs">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs font-bold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded">
                                  {item.ticket_number}
                                </span>
                                <span className="font-medium text-gray-900">{item.first_name} {item.last_name || ''}</span>
                              </div>
                              <div className="flex items-center gap-1.55">
                                <span className={`w-2 h-2 rounded-full ${item.online_status === 'online' ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
                                <span className="text-gray-500 text-xs font-bold uppercase ml-1">{item.online_status || 'offline'}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Attended history of this session */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                      <h4 className="font-bold text-gray-800 mb-3 uppercase tracking-wider text-xs flex items-center justify-between">
                        <span>Fila de Atendidos Hoje</span>
                        <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded text-xs font-extrabold">{attendedHistoryList.length}</span>
                      </h4>

                      {attendedHistoryList.length === 0 ? (
                        <p className="text-xs text-gray-400 italic py-4">Nenhum atendimento realizado nesta sessão hoje.</p>
                      ) : (
                        <div className="space-y-2 max-h-[250px] overflow-y-auto">
                          {attendedHistoryList.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-gray-100 shadow-sm text-xs">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs font-bold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded">
                                  {item.ticket_number}
                                </span>
                                <span className="font-medium text-gray-901">{item.first_name} {item.last_name || ''}</span>
                              </div>
                              <span className={`text-xs px-2 py-0.5 rounded-full font-bold uppercase 
                                ${item.status === 'completed' ? 'bg-green-105 text-green-700' : 'bg-red-105 text-red-700'}`}>
                                {item.status === 'completed' ? 'Atendido' : 'Cancelado'}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Histórico do Trabalhador */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Meu Histórico de Atendimentos</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b-2 border-gray-100 text-gray-600 text-sm">
                      <th className="py-3 px-4">Assistido</th>
                      <th className="py-3 px-4">Tipo</th>
                      <th className="py-3 px-4">Data e Hora</th>
                      <th className="py-3 px-4">Sessões Concluídas</th>
                      <th className="py-3 px-4">Faltantes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workerHistory.map((h: any, i) => (
                      <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 text-sm">
                        <td className="py-3 px-4 font-medium">{h.assisted_first} {h.assisted_last}</td>
                        <td className="py-3 px-4">{h.type}</td>
                        <td className="py-3 px-4">{new Date(h.created_at).toLocaleString()}</td>
                        <td className="py-3 px-4">{h.completed_sessions || 1} / {h.total_sessions || 1}</td>
                        <td className="py-3 px-4">{Math.max(0, (h.total_sessions || 1) - (h.completed_sessions || 1))}</td>
                      </tr>
                    ))}
                    {workerHistory.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-4 text-center text-gray-400">Nenhum atendimento registrado.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ASSISTED DASHBOARD */}
        {user.role === 'assisted' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Meu Painel</h1>
            <StoreAd />
            
            {activeQueue ? (
              <div className="bg-indigo-600 text-white rounded-xl shadow-md p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-20">
                  <Clock className="w-32 h-32" />
                </div>
                <h2 className="text-2xl font-bold mb-2">
                  {activeQueue.status === 'waiting' ? 'Aguardando Atendimento' : 'Em Atendimento'}
                </h2>
                <p className="text-indigo-100 mb-6">Dirija-se ao painel para acompanhar sua vez.</p>
                
                <div className="bg-white/10 rounded-lg p-4 inline-block backdrop-blur-sm border border-white/20">
                  <p className="text-sm text-indigo-200 uppercase tracking-wider font-semibold mb-1">Sua Senha</p>
                  <p className="text-5xl font-black tracking-tighter">{activeQueue.ticket_number}</p>
                  <p className="mt-2 text-indigo-100 font-medium">{activeQueue.type}</p>
                </div>

                {/* UP TO 7 RECENT QUEUE TICKETS IN FRONT */}
                {assistedAheadQueue.length > 0 && (
                  <div className="mt-6 bg-white/5 border border-white/10 rounded-lg p-5">
                    <h3 className="text-sm font-bold text-white mb-3 uppercase tracking-wider flex items-center gap-2">
                      <Users className="w-4 h-4 text-indigo-200" />
                      Pessoas na sua frente na fila ({assistedAheadQueue.length})
                    </h3>
                    <div className="space-y-2">
                      {assistedAheadQueue.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-white/10 rounded px-3 py-2 border border-white/5">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs bg-indigo-500 text-white min-w-[50px] px-2 py-0.5 rounded text-center font-bold">
                              {item.ticket_number}
                            </span>
                            <span className="text-sm font-medium text-white">
                              {item.first_name} {item.last_name || ''}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className={`w-2.5 h-2.5 rounded-full ${item.online_status === 'online' ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`} />
                            <span className="text-xs text-indigo-200 font-bold uppercase">{item.online_status || 'offline'}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : <></>}

            {myHouses.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Minhas Casas Espíritas Associadas</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {myHouses.map(h => (
                    <div key={h.id} className="border border-indigo-100 bg-indigo-50 rounded-lg p-4 flex flex-col justify-between">
                      <div>
                        <h3 className="font-bold text-indigo-900">{h.name}</h3>
                        <p className="text-sm text-indigo-700 mt-1">{h.street}, {h.number} - {h.city}</p>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <button
                          onClick={() => navigate(`/report/${h.id}`)}
                          className="flex-1 bg-indigo-600 text-white border border-transparent py-2 rounded-md text-sm font-bold hover:bg-indigo-700 transition-colors"
                        >
                          Meu Relato / Triagem
                        </button>
                        <button
                          onClick={async () => {
                            if(!window.confirm('Deseja desvincular-se desta casa?')) return;
                            try {
                              const res = await fetch(`/api/houses/${h.id}/assisted/${user.id}`, { method: 'DELETE' });
                              const data = await res.json();
                              alert(data.message);
                              fetch(`/api/users/${user.id}/houses`).then(r => r.json()).then(setMyHouses);
                            } catch(e) { console.error(e); }
                          }}
                          className="w-10 flex items-center justify-center bg-white text-red-600 border border-red-200 rounded-md hover:bg-red-50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!activeQueue ? (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Vincular-se a uma Casa Espírita</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                    <input 
                      type="text" 
                      placeholder="Nome, cidade, estado..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <input 
                      type="text" 
                      placeholder="Tipo de serviço (ex: Passe)..." 
                      value={searchService}
                      onChange={(e) => setSearchService(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <input 
                      type="text" 
                      placeholder="Horário (ex: sáb, 08h)..." 
                      value={searchTime}
                      onChange={(e) => setSearchTime(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {houses.filter((h: any) => !myHouses.some(mh => mh.id === h.id)).length === 0 ? (
                    <p className="text-gray-500">Nenhuma casa espírita encontrada.</p>
                  ) : (
                    houses.filter((h: any) => !myHouses.some(mh => mh.id === h.id)).map((house: any) => (
                      <div key={house.id} className="border border-gray-200 rounded-lg p-4 hover:border-indigo-300 transition-colors">
                        <h3 className="font-bold text-gray-900">{house.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">{house.street}, {house.number} - {house.city}</p>
                        {house.operating_hours && (
                          <div className="mt-3 text-sm text-gray-700">
                            <span className="font-semibold block">Horários:</span>
                            {house.operating_hours}
                          </div>
                        )}
                        <div className="mt-3 flex flex-wrap gap-2">
                          {house.services?.split(',').map((s: string, i: number) => (
                            <span key={i} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">{s.trim()}</span>
                          ))}
                        </div>
                        <div className="mt-4 flex gap-2">
                          <button 
                            onClick={async () => {
                              try {
                                const res = await fetch(`/api/houses/${house.id}/assisted/link`, {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ assistedId: user.id })
                                });
                                const data = await res.json();
                                alert(data.message);
                                fetch(`/api/users/${user.id}/houses`).then(r => r.json()).then(setMyHouses);
                                navigate(`/report/${house.id}`);
                              } catch(e) { console.error(e); }
                            }}
                            className="flex-1 bg-indigo-100 text-indigo-700 py-2 rounded-md text-sm font-medium hover:bg-indigo-200"
                          >
                            Associar-se / Relatar
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : <></>}

            {user.recommendations && user.recommendations.trim().length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Recomendações e Leitura Diária</h2>
                
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-6">
                  <h3 className="font-bold text-blue-900 mb-2">Mensagem do Dirigente</h3>
                  <div className="text-blue-800 whitespace-pre-wrap">{user.recommendations}</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <a href="https://kardec.blog.br/evangelho-no-lar/" target="_blank" rel="noopener noreferrer" className="block p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <h4 className="font-bold text-indigo-700">Evangelho no Lar</h4>
                    <p className="text-sm text-gray-600 mt-1">Orientações passo a passo para a realização do Evangelho.</p>
                  </a>
                  <a href="https://www.febnet.org.br/" target="_blank" rel="noopener noreferrer" className="block p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <h4 className="font-bold text-indigo-700">Oração do Perdão</h4>
                    <p className="text-sm text-gray-600 mt-1">Prática diária para libertação e paz interior.</p>
                  </a>
                  <a href="https://www.febnet.org.br/" target="_blank" rel="noopener noreferrer" className="block p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <h4 className="font-bold text-indigo-700">Oração do Anjo Guardião</h4>
                    <p className="text-sm text-gray-600 mt-1">Conexão com seu protetor espiritual.</p>
                  </a>
                </div>
              </div>
            )}

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Minhas Conferências Agendadas</h2>
              {myConferences.length === 0 ? (
                <p className="text-gray-500">Nenhuma conferência agendada para você no momento.</p>
              ) : (
                <div className="space-y-4">
                  {myConferences.map((c: any) => (
                    <div key={c.id} className="border p-4 rounded-lg flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-indigo-700">{c.title}</h3>
                        <p className="text-sm text-gray-600">{c.description}</p>
                        <p className="text-sm text-gray-500 mt-1 font-medium">{new Date(c.scheduled_date + 'T' + c.scheduled_time).toLocaleString()}</p>
                      </div>
                      <a href={`/room/${c.room_name}`} target="_blank" className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-bold">
                        Entrar na Sala
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {treatmentPlan && treatmentPlan.treatments && treatmentPlan.treatments.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">{treatmentPlan.title}</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[600px]">
                    <thead>
                      <tr className="bg-indigo-50 border-y border-indigo-100 text-sm text-indigo-900">
                        <th className="py-3 px-4 font-bold">Tipo de Tratamento</th>
                        <th className="py-3 px-4 font-bold text-center">Sessões Pendentes</th>
                        <th className="py-3 px-4 font-bold text-center">Concluídas / Total</th>
                        <th className="py-3 px-4 font-bold">Histórico / Atendido por</th>
                      </tr>
                    </thead>
                    <tbody>
                      {treatmentPlan.treatments.map((t: any, idx: number) => {
                        const pending = Math.max(0, t.totalSessions - t.completedSessions);
                        return (
                          <tr key={idx} className="border-b border-gray-50 hover:bg-gray-50 text-sm">
                            <td className="py-3 px-4 font-medium text-gray-800">{t.typeName}</td>
                            <td className="py-3 px-4 text-center font-bold text-amber-600">{pending} faltam</td>
                            <td className="py-3 px-4 text-center text-emerald-600 font-bold">{t.completedSessions} / {t.totalSessions}</td>
                            <td className="py-3 px-4 text-gray-600 text-xs">
                               {t.history && t.history.length > 0 ? (
                                 <ul className="list-disc pl-4 space-y-1">
                                   {t.history.map((h: any, i: number) => (
                                     <li key={i}>{h.date} - {h.worker}</li>
                                   ))}
                                 </ul>
                               ) : <span>Sem histórico</span>}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Meu Histórico de Atendimentos</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b-2 border-gray-100 text-gray-600 text-sm">
                      <th className="py-3 px-4">Trabalhador</th>
                      <th className="py-3 px-4">Tipo</th>
                      <th className="py-3 px-4">Data e Hora</th>
                      <th className="py-3 px-4">Sessões Concluídas</th>
                      <th className="py-3 px-4">Faltantes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myHistory.map((h: any, i) => (
                      <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 text-sm">
                        <td className="py-3 px-4 font-medium">{h.worker_first ? `${h.worker_first} ${h.worker_last}` : 'Não Informado'}</td>
                        <td className="py-3 px-4">{h.type}</td>
                        <td className="py-3 px-4">{new Date(h.created_at).toLocaleString()}</td>
                        <td className="py-3 px-4">{h.completed_sessions || 1} / {h.total_sessions || 1}</td>
                        <td className="py-3 px-4">{Math.max(0, (h.total_sessions || 1) - (h.completed_sessions || 1))}</td>
                      </tr>
                    ))}
                    {myHistory.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-4 text-center text-gray-400">Nenhum atendimento registrado.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      {/* Modal de Alteração de Senha */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden transform transition-all border border-gray-100">
            <div className="bg-indigo-600 px-6 py-4 flex justify-between items-center text-white">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Lock className="w-5 h-5 text-indigo-100" />
                Alterar Minha Senha
              </h3>
              <button 
                type="button"
                onClick={() => {
                  setShowPasswordModal(false);
                  setPasswordError('');
                  setPasswordSuccess('');
                }} 
                className="text-white/80 hover:text-white hover:bg-indigo-700 p-1.5 rounded-lg transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleUserChangePassword} className="p-6 space-y-4">
              {passwordError && (
                <div id="pwd-error" className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm font-medium animate-pulse">
                  {passwordError}
                </div>
              )}
              {passwordSuccess && (
                <div id="pwd-success" className="p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm font-medium">
                  {passwordSuccess}
                </div>
              )}
              
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Senha Atual</label>
                <input 
                  required 
                  type="password" 
                  value={currentPassword} 
                  onChange={e => setCurrentPassword(e.target.value)} 
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500" 
                  placeholder="Sua senha atual"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Nova Senha</label>
                <input 
                  required 
                  type="password" 
                  value={newPassword} 
                  onChange={e => setNewPassword(e.target.value)} 
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500" 
                  placeholder="Mínimo 6 caracteres"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Confirmar Nova Senha</label>
                <input 
                  required 
                  type="password" 
                  value={confirmPassword} 
                  onChange={e => setConfirmPassword(e.target.value)} 
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500" 
                  placeholder="Repita a nova senha"
                />
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-gray-100">
                <button 
                  type="button" 
                  onClick={() => {
                    setShowPasswordModal(false);
                    setPasswordError('');
                    setPasswordSuccess('');
                  }} 
                  className="px-4 py-2 text-sm border border-gray-200 hover:bg-gray-50 rounded-lg font-bold text-gray-700 transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  disabled={isChangingPassword}
                  className="px-5 py-2 text-sm bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-sm hover:shadow transition-all flex items-center gap-1.5 disabled:opacity-55 cursor-pointer"
                >
                  {isChangingPassword ? 'Salvando...' : 'Salvar Alteração'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      </main>
    </div>
  );
}
