import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <div className="bg-emerald-600 px-6 py-8 sm:p-10 relative overflow-hidden">
          <Shield className="absolute right-[-20px] bottom-[-20px] w-48 h-48 text-emerald-500 opacity-30" />
          <Link to="/" className="inline-flex items-center text-emerald-100 hover:text-white mb-6 transition-colors relative z-10">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Voltar para o início
          </Link>
          <h1 className="text-3xl font-bold text-white mb-2 relative z-10">Política de Privacidade</h1>
          <p className="text-emerald-100 relative z-10">Conformidade com a Lei Geral de Proteção de Dados (LGPD)</p>
        </div>
        
        <div className="px-6 py-8 sm:p-10 max-w-none text-gray-700 space-y-6">
          <p>
            A sua privacidade é uma prioridade para o <strong>SIAE</strong>. Esta Política de Privacidade descreve como coletamos, usamos, armazenamos e protegemos suas informações de acordo com a <strong>Lei Geral de Proteção de Dados Pessoais (LGPD - Lei nº 13.709/2018)</strong> do Brasil.
          </p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">1. Dados que Coletamos</h2>
          <p>
            Coletamos apenas os dados pessoais mínimos necessários para a prestação do acolhimento e organização das atividades da Casa Espírita:
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li><strong>Dados Cadastrais:</strong> Nome completo, CPF, data de nascimento, e-mail e telefone.</li>
            <li><strong>Dados Sensíveis:</strong> Em virtude da natureza das atividades (instituição religiosa), poderemos registrar dados relacionados a crenças e vulnerabilidades expostas no atendimento fraterno, estritamente para o acompanhamento do seu tratamento espiritual. Todo dado sensível exige seu consentimento.</li>
            <li><strong>Dados de Frequência:</strong> Registros e horários de check-in / check-out nas filas através do número serial codificado de sua Tag NFC.</li>
          </ul>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">2. Finalidade e Base Legal do Tratamento</h2>
          <p>
            Os dados são tratados sob as seguintes premissas (Art. 7º e 11º da LGPD):
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li><strong>Consentimento:</strong> Para a vinculação a tratamentos e avaliações fraternas realizadas pela plataforma.</li>
            <li><strong>Exercício regular de direitos / Execução de atividades da Instituição:</strong> Para fins organizacionais de ordem interna de cunho religioso ou filantrópico.</li>
          </ul>
          <p>Nenhuma informação é utilizada para fins de marketing direto, publicidade de terceiros, venda ou monetização.</p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">3. Compartilhamento de Dados</h2>
          <p>
            <strong>Garantimos absoluto sigilo:</strong>
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li>Os seus dados pertencem unicamente à Casa Espírita em que você se cadastrou.</li>
            <li>Apenas os trabalhadores com perfis autorizados (Terapeutas/Atendentes) da referida casa terão acesso parcial aos seus registros, aplicando-se protocolos de mínimo acesso (Need-to-Know).</li>
            <li>Não realizamos transferência ou venda de dados para nenhuma empresa, igreja parceira ou órgão, salvo sob determinação judicial.</li>
          </ul>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">4. Segurança e Retenção</h2>
          <p>
            Adotamos medidas técnicas e administrativas, como criptografia de senhas (hash), isolamento lógico em banco de dados e controle de rotas de sistema, para evitar exposição ou perda. Armazenamos seus dados pelo tempo que for necessário para manter o acompanhamento do seu histórico, podendo você solicitar a anonimização a qualquer momento.
          </p>

          <h2 className="text-xl font-bold text-gray-900 mt-8 mb-4">5. Direitos do Titular</h2>
          <p>
            Conforme a LGPD, você tem o direito de solicitar a qualquer momento: confirmação de tratamento de dados; acesso aos dados; correção de dados incompletos; anonimização, bloqueio ou exclusão de dados desnecessários; e a revogação do consentimento, contatando o administrador de sua Casa Espírita ou diretamente pelo painel do usuário.
          </p>

          <div className="mt-12 pt-8 border-t border-gray-100 flex justify-end">
            <p className="text-sm text-gray-400">Última atualização: {new Date().toLocaleDateString('pt-BR')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
