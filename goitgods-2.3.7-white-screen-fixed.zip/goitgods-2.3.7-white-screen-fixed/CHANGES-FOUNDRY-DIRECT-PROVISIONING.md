# GOITGODS 2.3.0 — Provisionamento direto de agentes Microsoft Foundry

## Novidades
- Super Admin configura Foundry Project Endpoint, Tenant ID, Client ID, Client Secret e deployment/modelo padrão.
- Client Secret fica somente no servidor (`data/super_admin_secrets.json`, modo 0600); a API administrativa expõe apenas `hasClientSecret`.
- Teste de autenticação/acesso ao projeto Foundry.
- Criação direta de Prompt Agents via REST API v1 do Microsoft Foundry.
- Cada criação gera uma nova versão remota.
- Publicação interna = ativação da versão no endpoint estável do agente com 100% do tráfego.
- Botão individual **Criar/Publicar no Foundry**.
- Botão global **Criar arquitetura padrão PASQUARED no Foundry** para provisionar todos os Prompt Agents habilitados.
- Registro local de `agentName`, `agentId`, `remoteVersion`, `remoteStatus` e `lastPublishedAt`.
- Fluxo de autenticação service principal (OAuth 2.0 client credentials), escopo `https://ai.azure.com/.default`.

## Agentes padrão
1. Research Orchestrator
2. PASQUARED Reasoner
3. Source Analyst / Apollo
4. ARES Critic
5. HADES Risk Auditor
6. ZEUS Epistemic Arbiter
7. Book Architect
8. Book Writer
9. Fact Checker

## Requisitos no Azure/Microsoft Foundry
- Projeto Microsoft Foundry existente e Project Endpoint.
- Deployment/modelo disponível no projeto.
- App Registration / Service Principal no Microsoft Entra ID.
- Tenant ID, Client ID e Client Secret.
- RBAC adequado no projeto para criar/gerenciar agentes (por exemplo Foundry User, conforme documentação Microsoft).

## Observação sobre Hosted Agents
A criação automática 2.3.0 é deliberadamente limitada a Prompt Agents. Hosted Agents requerem código/container, artefatos de deployment e configuração adicional; o painel mantém o tipo Hosted Agent para futura extensão, mas não simula uma implantação inexistente.

## Observação sobre Microsoft 365/Teams
"Publicar" nesta versão significa ativar a versão no endpoint estável do Foundry. Publicar no catálogo Microsoft 365/Teams exige um fluxo separado com Azure Bot Service e metadados de publicação.
