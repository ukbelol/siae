# Validação desta alteração

- `tsc --noEmit` foi executado com TypeScript global 5.8.3.
- Não foram detectados erros de sintaxe nas alterações; a checagem para nos imports porque as dependências npm não estão instaladas neste ambiente (React, Express, tipos Node, Vite etc.).
- `npm install --ignore-scripts` foi tentado, mas excedeu a janela de execução do ambiente antes de criar `node_modules`.
- No servidor de destino execute `npm install && npm run lint && npm run build`.
