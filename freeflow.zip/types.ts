
export type Language = 'en' | 'fr' | 'es' | 'pt-br';

export interface Message {
  role: 'user' | 'model';
  text: string;
}

export interface EventData {
  id: string;
  title: string;
  date: string;
  description: string;
  impact: string;
}

export enum AppSection {
  DASHBOARD = 'DASHBOARD',
  INVESTIGATION = 'INVESTIGATION',
  ANALYTICS = 'ANALYTICS',
  COMMUNITY = 'COMMUNITY',
  NODES_DETAIL = 'NODES_DETAIL',
  USERS_DETAIL = 'USERS_DETAIL',
  UPTIME_DETAIL = 'UPTIME_DETAIL',
  COMMITS_DETAIL = 'COMMITS_DETAIL'
}
