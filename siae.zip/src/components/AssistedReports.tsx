import React, { useEffect, useState } from 'react';

export default function AssistedReports({ houseId, assistedId, assistanceTypes, recommendations: initialRecommendations, onRefresh }: { houseId: number, assistedId: number, assistanceTypes: any[], recommendations?: string, onRefresh?: () => void }) {
  const [reports, setReports] = useState<any[]>([]);
  const [triageData, setTriageData] = useState<{ [key: number]: { status: string, targetTreatments: {typeId: string, sessions: number}[], date: string, time: string } }>({});
  const [recommendations, setRecommendations] = useState(initialRecommendations || '');

  useEffect(() => {
    fetchReports();
    fetchUserRecommendations();
  }, [houseId, assistedId]);

  const fetchUserRecommendations = async () => {
    try {
      const res = await fetch(`/api/users/${assistedId}`);
      const data = await res.json();
      if (data.recommendations) setRecommendations(data.recommendations);
    } catch (e) {}
  };

  const fetchReports = async () => {
    try {
      const res = await fetch(`/api/houses/${houseId}/assisted/${assistedId}/reports`);
      const data = await res.json();
      setReports(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveRecommendations = async () => {
    try {
      const res = await fetch(`/api/houses/${houseId}/assisted/${assistedId}/recommendations`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recommendations })
      });
      if (!res.ok) {
        const data = await res.json();
        alert('Erro ao salvar: ' + data.error);
        return;
      }
      alert('Recomendações salvas com sucesso!');
    } catch(e) {
      console.error(e);
      alert('Erro de conexão.');
    }
  };

  const handleTriage = async (reportId: number) => {
    const data = triageData[reportId];
    if (!data || !data.status) {
      alert('Preencha o status.');
      return;
    }

    try {
      const res = await fetch(`/api/houses/${houseId}/reports/${reportId}/triage`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          status: data.status, 
          treatmentPlan: "Atribuição Multi-Plano",
          targetTreatments: JSON.stringify(data.targetTreatments || []),
          totalSessions: 1
        })
      });
      if (!res.ok) {
        const resData = await res.json();
        alert('Erro ao salvar triagem: ' + resData.error);
        return;
      }

      // Se quiser agendar e já tivermos o primeiro tratamento:
      if (data.targetTreatments && data.targetTreatments.length > 0 && data.date && data.time) {
        const schedRes = await fetch(`/api/houses/${houseId}/reports/${reportId}/schedule`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            assistanceTypeId: data.targetTreatments[0].typeId,
            scheduledDate: data.date,
            scheduledTime: data.time
          })
        });
        if (!schedRes.ok) {
          console.error("Erro no agendamento");
        }
      }

      alert('Triagem salva com sucesso!');
      fetchReports();
      if (onRefresh) onRefresh();
    } catch (e) {
      console.error(e);
      alert('Erro ao salvar triagem.');
    }
  };

  const handleAddTreatment = (reportId: number) => {
    const data = triageData[reportId] || { status: 'pending', targetTreatments: [], date: '', time: '' };
    const currentList = data.targetTreatments || [];
    setTriageData({
      ...triageData,
      [reportId]: { ...data, targetTreatments: [...currentList, { typeId: '', sessions: 1 }] }
    });
  };

  const updateTreatment = (reportId: number, index: number, field: string, value: any) => {
    const data = triageData[reportId];
    const newTreatments = [...data.targetTreatments];
    newTreatments[index] = { ...newTreatments[index], [field]: value };
    setTriageData({
      ...triageData,
      [reportId]: { ...data, targetTreatments: newTreatments }
    });
  };

  const parseTargetTreatments = (report: any) => {
    if (!report.target_treatments) return [];
    try {
      return JSON.parse(report.target_treatments);
    } catch (e) { return []; }
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-100 p-4 rounded-lg mb-6">
        <h4 className="font-bold text-blue-900 mb-2">Recomendações de Leitura e Vídeos (Somente visível ao assistido quando preenchido)</h4>
        <textarea 
          className="w-full border rounded-md p-2 h-24 mb-2"
          placeholder="Insira links, recomendações de vídeos, orações ou conteúdo que o assistido deva acessar do seu painel..."
          value={recommendations}
          onChange={(e) => setRecommendations(e.target.value)}
        />
        <button onClick={handleSaveRecommendations} className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 font-medium test-sm">Salvar Recomendações</button>
      </div>

      {reports.length === 0 ? <p className="text-gray-500">Nenhum relato encontrado para este assistido.</p> : null}
      
      {reports.map(report => {
        const tData = triageData[report.id] || { status: report.status, targetTreatments: parseTargetTreatments(report), date: '', time: '' };
        
        return (
        <div key={report.id} className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${
                report.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                report.status === 'analyzed' ? 'bg-blue-100 text-blue-700' :
                report.status === 'in_treatment' ? 'bg-indigo-100 text-indigo-700' : 'bg-green-100 text-green-700'
              }`}>
                {report.status}
              </span>
              <p className="text-sm text-gray-500 mt-2">Data: {new Date(report.created_at).toLocaleString()}</p>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg mb-4 border border-gray-100">
            <h4 className="font-bold text-gray-700 mb-2">Relato da Queixa:</h4>
            <p className="text-gray-800 whitespace-pre-wrap">{report.problem_description}</p>
          </div>

          <div className="border-t pt-4 mt-4">
            <h4 className="font-bold text-gray-900 mb-3">Ação de Triagem e Encaminhamento</h4>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select 
                className="w-full md:w-1/3 border rounded-md p-2"
                value={tData.status}
                onChange={e => setTriageData({...triageData, [report.id]: {...tData, status: e.target.value}})}
              >
                <option value="pending">Pendente</option>
                <option value="analyzed">Analisado</option>
                <option value="in_treatment">Em Tratamento</option>
                <option value="completed">Concluído</option>
              </select>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Tratamentos Sugeridos</label>
              {tData.targetTreatments.map((tt: any, i: number) => (
                <div key={i} className="flex gap-2 mb-2 items-center">
                  <select 
                    className="flex-1 border rounded-md p-2"
                    value={tt.typeId}
                    onChange={e => updateTreatment(report.id, i, 'typeId', e.target.value)}
                  >
                    <option value="">Selecione o Tratamento...</option>
                    {assistanceTypes.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                  <input 
                    type="number" 
                    placeholder="Sessões"
                    className="w-24 border rounded-md p-2"
                    value={tt.sessions}
                    onChange={e => updateTreatment(report.id, i, 'sessions', parseInt(e.target.value))}
                  />
                  <button onClick={() => {
                    const newT = [...tData.targetTreatments];
                    newT.splice(i, 1);
                    setTriageData({...triageData, [report.id]: {...tData, targetTreatments: newT}});
                  }} className="text-red-600 font-bold px-2 py-1 bg-red-50 rounded">X</button>
                </div>
              ))}
              <button className="text-indigo-600 font-bold text-sm bg-indigo-50 px-3 py-1 rounded" onClick={() => handleAddTreatment(report.id)}>+ Adicionar Tratamento</button>
            </div>

            <button 
              onClick={() => handleTriage(report.id)}
              className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
            >
              Salvar Triagem (Plano Completo)
            </button>
          </div>
        </div>
      )})}
    </div>
  );
}
