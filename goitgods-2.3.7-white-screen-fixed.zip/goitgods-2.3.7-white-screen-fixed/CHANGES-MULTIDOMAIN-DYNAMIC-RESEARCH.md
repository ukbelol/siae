# PASQUARED + GOITGODS — Dynamic Multidomain Research

## Added
- Dynamic investigative anamnesis: every answer determines the next question.
- Domain routing for medicine, law, psychology, psychoanalysis, radiology, exact sciences, biological sciences, engineering/technology, humanities, education, economics and general topics.
- Domain-specific questions (clinical population, legal jurisdiction, imaging modality, theoretical framework, formal variables, validation method, etc.).
- Real academic-source service with Crossref, OpenAlex, Europe PMC and PubMed/NCBI connectors.
- Automatic biomedical provider activation for medicine, radiology, biological sciences, psychology and psychoanalysis.
- Provider diagnostics returned to the frontend.
- Real-source deduplication, deterministic relevance/recency/independence scores, DOI/PMID metadata and SHA-256 content hashes.
- Evidence-first GOITGODS synthesis: specialists receive retrieved source packets and are forbidden from inventing references.
- If no grounded synthesis is possible, claims become `INSUFFICIENT_EVIDENCE` instead of fabricated facts.
- New routes:
  - POST `/api/v3/anamnesis/dynamic/start`
  - POST `/api/v3/anamnesis/dynamic/answer`
  - GET `/api/v3/anamnesis/dynamic/:sessionId`
- New interactive frontend for the step-by-step anamnesis.
- Medical/radiology and legal research notices in the UI.

## Important corrections
- Removed the fabricated Crossref/OpenAlex fallback source.
- PASQUARED AI-generated knowledge objects are now `UNVERIFIED` until corroborated by external retrieval.
- Removed random epistemic scoring from PASQUARED adaptive knowledge and legacy GOITGODS GPS scoring.

## Providers by domain
- All domains: Crossref + OpenAlex.
- Medicine / Radiology / Biological sciences / Psychology / Psychoanalysis: Crossref + OpenAlex + Europe PMC + PubMed/NCBI.
- Law: Crossref + OpenAlex for scholarship. Current law, statutes and case law must be verified through jurisdiction-specific official sources; this version does not mislabel academic literature as current law.

## Environment
See `.env.example` for `RESEARCH_CONTACT_EMAIL`, Crossref polite-pool email, optional OpenAlex key and optional NCBI key.
