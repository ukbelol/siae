# Validation

Static TypeScript parsing was executed with global TypeScript 5.8.3.

No project-code syntax/type diagnostics remained after filtering errors caused solely by unavailable local dependencies. This execution environment could not install npm dependencies because outbound registry resolution was unavailable, so a full `npm install && npm run lint && npm run build` could not be completed here.

Run locally/server-side:

```bash
npm install
npm run lint
npm run build
npm run dev
```

The package already declares the required dependencies in `package.json`.
