const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

lines[227] = "    const reports = (await db.query('SELECT * FROM assistance_requests WHERE house_id = ? AND assisted_id = ? ORDER BY created_at DESC', [req.params.houseId, req.params.assistedId]))[0] as any[];";
lines[228] = "";

fs.writeFileSync('src/api/index.ts', lines.join('\n'));
