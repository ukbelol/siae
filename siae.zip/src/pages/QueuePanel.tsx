import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { Volume2, Users, ChevronRight, CheckCircle2, UserCheck, Activity, Tv, Sparkles, Clock, Compass, VolumeX } from 'lucide-react';

export interface CalledItem {
  id: string | number;
  ticket_number: string;
  first_name: string;
  last_name: string;
  room_number: string;
  type: string;
  calledAt: string;
}

export default function QueuePanel() {
  const { houseId } = useParams();
  const [typesQueue, setTypesQueue] = useState<any[]>([]);
  const [lastAttended, setLastAttended] = useState<any[]>([]);
  const [callHistory, setCallHistory] = useState<CalledItem[]>([]);
  const [calledTickets, setCalledTickets] = useState<Record<string, string>>({});
  const [currentTime, setCurrentTime] = useState<string>('');
  const [audioUnlocked, setAudioUnlocked] = useState<boolean>(false);
  const audioUnlockedRef = useRef<boolean>(false);

  // Persistent volume control
  const [ttsVolume, setTtsVolume] = useState<number>(() => {
    const saved = localStorage.getItem('siae_queue_tts_volume');
    return saved !== null ? parseFloat(saved) : 1.0;
  });
  const ttsVolumeRef = useRef<number>(1.0);

  useEffect(() => {
    localStorage.setItem('siae_queue_tts_volume', String(ttsVolume));
    ttsVolumeRef.current = ttsVolume;
  }, [ttsVolume]);

  // Keep a ref of calledTickets to avoid closure issues in the sound interval
  const calledTicketsRef = useRef<Record<string, string>>({});
  useEffect(() => {
    calledTicketsRef.current = calledTickets;
  }, [calledTickets]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const tInterval = setInterval(updateTime, 1000);
    return () => clearInterval(tInterval);
  }, []);

  // Professional Audio Synthesizer to guarantee sound playback under any server configuration
  const playNativeChime = (vol = ttsVolumeRef.current) => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const now = ctx.currentTime;
      
      // Tone 1: Energetic ring chime (C5 to A5)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(523.25, now); 
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.15); 
      gain1.gain.setValueAtTime(0.12 * vol, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.55);
      
      // Tone 2: Harmonious resonance (E5 to C6 with slight delay)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(659.25, now + 0.12); 
      osc2.frequency.exponentialRampToValueAtTime(1046.5, now + 0.28); 
      gain2.gain.setValueAtTime(0.12 * vol, now + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.12);
      osc2.stop(now + 0.75);
    } catch (error) {
      console.warn('AudioContext sound failed:', error);
    }
  };

  const handleUnlockAudio = () => {
    setAudioUnlocked(true);
    audioUnlockedRef.current = true;
    playNativeChime(); // Warmup chime test
  };

  const speakOnlineTTS = (text: string, volume: number): Promise<boolean> => {
    return new Promise((resolve, reject) => {
      try {
        const cleanText = text.substring(0, 200);
        const url = `https://translate.google.com/translate_tts?ie=UTF-8&tl=pt-BR&client=tw-ob&q=${encodeURIComponent(cleanText)}`;
        
        const audio = new Audio();
        audio.src = url;
        audio.volume = volume;
        try {
          (audio as any).referrerPolicy = "no-referrer";
          audio.setAttribute('referrerpolicy', 'no-referrer');
        } catch (_) {}
        
        audio.onended = () => resolve(true);
        audio.onerror = (e) => reject(e);
        
        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise.then(() => resolve(true)).catch((err) => reject(err));
        } else {
          resolve(true);
        }
      } catch (err) {
        reject(err);
      }
    });
  };

  const handleTestSound = async () => {
    if (!audioUnlocked) {
      handleUnlockAudio();
    } else {
      playNativeChime(ttsVolume);
      
      const text = `Chamada de teste. Volume de voz em ${Math.round(ttsVolume * 100)} %`;
      
      try {
        if (window.speechSynthesis) {
          window.speechSynthesis.cancel();
        }
        await speakOnlineTTS(text, ttsVolume);
      } catch (err) {
        if (window.speechSynthesis) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.lang = 'pt-BR';
          utterance.rate = 0.9;
          utterance.volume = ttsVolume;
          const voices = window.speechSynthesis.getVoices();
          const ptVoices = voices.filter(v => v.lang.startsWith('pt'));
          const ptBRVoice = ptVoices.find(v => 
            v.name.toLowerCase().includes('maria') || 
            v.name.toLowerCase().includes('luciana') || 
            v.name.toLowerCase().includes('joana') || 
            v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('google')
          ) || ptVoices[0];
          if (ptBRVoice) {
             utterance.voice = ptBRVoice;
          }
          window.speechSynthesis.speak(utterance);
        }
      }
    }
  };

  const spokenTicketsRef = useRef<Record<string, { lastSpokenAt: number; count: number }>>({});

  const speakCall = async (ticketNumber: string, name: string, roomNumber: string, type: string) => {
    if (!audioUnlockedRef.current) return;
    
    // Spelling out ticket: A103 -> A 1 0 3
    const spelledTicket = ticketNumber.split('').join(' ');
    const text = `Assistido ${name}, senha ${spelledTicket}, dirigir-se à sala ${roomNumber}.`;

    try {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel(); // limit overlays
      }
      await speakOnlineTTS(text, ttsVolumeRef.current);
    } catch(err) {
      console.warn('Online female voice TTS failed or blocked. Using local Web Speech fallback.', err);
      if (!window.speechSynthesis) return;
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'pt-BR';
        utterance.rate = 0.85; // slower for extreme clarity
        utterance.pitch = 1.05; // slightly higher pitch to sound more feminine on default speech devices
        utterance.volume = ttsVolumeRef.current; // apply volume control
        
        const voices = window.speechSynthesis.getVoices();
        const ptVoices = voices.filter(v => v.lang.startsWith('pt'));
        const ptBRVoice = ptVoices.find(v => 
          v.name.toLowerCase().includes('maria') || 
          v.name.toLowerCase().includes('luciana') || 
          v.name.toLowerCase().includes('joana') || 
          v.name.toLowerCase().includes('francisca') ||
          v.name.toLowerCase().includes('female') ||
          v.name.toLowerCase().includes('mulher') ||
          v.name.toLowerCase().includes('helena') ||
          v.name.toLowerCase().includes('zira') ||
          v.name.toLowerCase().includes('google')
        ) || ptVoices[0];

        if (ptBRVoice) {
           utterance.voice = ptBRVoice;
        }
        window.speechSynthesis.speak(utterance);
      } catch(innerErr) {
        console.warn('Web Speech fallback failed:', innerErr);
      }
    }
  };

  useEffect(() => {
    const fetchQueue = async () => {
      try {
        const res = await fetch(`/api/queue/panel/${houseId}`);
        const data = await res.json();

        // Process dynamic call history (left column)
        const activeCalls: CalledItem[] = [];
        if (data.byType) {
          data.byType.forEach((bt: any) => {
            if (bt.currentCall && (bt.currentCall.status === 'called' || bt.currentCall.status === 'in_progress')) {
              activeCalls.push({
                id: bt.currentCall.id,
                ticket_number: bt.currentCall.ticket_number,
                first_name: bt.currentCall.first_name,
                last_name: bt.currentCall.last_name || '',
                room_number: bt.currentCall.room_number || '—',
                type: bt.type,
                calledAt: bt.currentCall.called_at || bt.currentCall.start_time || bt.currentCall.created_at || new Date().toISOString(),
              });
            }
          });
        }

        const completedOrInProgressCalls: CalledItem[] = (data.lastAttended || []).map((la: any) => ({
          id: la.id,
          ticket_number: la.ticket_number,
          first_name: la.first_name,
          last_name: la.last_name || '',
          room_number: la.room_number || '—',
          type: la.type || 'Geral',
          calledAt: la.called_at || la.start_time || la.created_at || new Date().toISOString(),
        }));

        setCallHistory((prev) => {
          const map = new Map<string, CalledItem>();
          prev.forEach(item => map.set(String(item.id), item));
          completedOrInProgressCalls.forEach(item => {
            if (!map.has(String(item.id))) {
              map.set(String(item.id), item);
            }
          });
          activeCalls.forEach(item => {
            map.set(String(item.id), item);
          });
          return Array.from(map.values()).sort((a, b) => {
            return new Date(b.calledAt).getTime() - new Date(a.calledAt).getTime();
          });
        });
        
        let playSound = false;
        const newCalledTickets: Record<string, string> = {};
        
        if (data.byType) {
          data.byType.forEach((bt: any) => {
            if (bt.currentCall && bt.currentCall.status === 'called') {
              const callId = String(bt.currentCall.id);
              const ticket = bt.currentCall.ticket_number;
              const room = bt.currentCall.room_number || '—';
              const name = `${bt.currentCall.first_name} ${bt.currentCall.last_name || ''}`;
              const type = bt.type;
              
              newCalledTickets[type] = ticket;
              
              // If the called ticket is different from what we previously knew
              if (calledTicketsRef.current[type] !== ticket) {
                playSound = true;
              }

              // Speak with TTS
              const rec = spokenTicketsRef.current[callId];
              const now = Date.now();
              if (!rec) {
                // First call: play chime and speak immediately
                speakCall(ticket, name, room, type);
                spokenTicketsRef.current[callId] = { lastSpokenAt: now, count: 1 };
              } else if (rec.count < 3 && now - rec.lastSpokenAt >= 50000) {
                // Second or third call after 50 seconds: Speak
                speakCall(ticket, name, room, type);
                spokenTicketsRef.current[callId] = { lastSpokenAt: now, count: rec.count + 1 };
              }
            }
          });
        }
        
        if (playSound) {
          // Play custom synth chime first
          playNativeChime(ttsVolumeRef.current);
          // Fallback to bell mp3 asset
          const audio = new Audio('/bell.mp3');
          audio.volume = ttsVolumeRef.current * 0.8;
          audio.play().catch(() => {});
        }
        
        if (data.byType) {
          setTypesQueue(data.byType);
          // Sync state of called tickets to prevent double sound triggers if the record hasn't changed
          const updatedTickets = { ...calledTicketsRef.current };
          data.byType.forEach((bt: any) => {
            if (bt.currentCall && bt.currentCall.status === 'called') {
              updatedTickets[bt.type] = bt.currentCall.ticket_number;
            }
          });
          setCalledTickets(updatedTickets);
        }
        
        setLastAttended(data.lastAttended || []);
      } catch (e) {
        console.error('Error fetching queue panel:', e);
      }
    };

    fetchQueue();
    const interval = setInterval(fetchQueue, 3000);
    return () => clearInterval(interval);
  }, [houseId]);

  return (
    <div className="h-screen w-screen bg-[#070b13] text-gray-100 flex flex-col font-sans select-none overflow-hidden xl:max-h-screen">
      
      {/* Top Professional Widescreen 16:9 Header */}
      <header className="bg-[#0e1322] border-b border-gray-800/65 px-8 py-3.5 flex items-center justify-between shadow-2xl shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-11 h-11 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.12)]">
            <Tv className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg lg:text-xl font-black text-white tracking-tight uppercase flex items-center gap-2.5">
              Painel de Atendimentos Ativos
              <span className="text-[9px] font-black bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded px-2 py-0.5 tracking-widest uppercase">
                Matricial 16:9
              </span>
            </h1>
            <p className="text-[10px] font-extrabold text-gray-400 tracking-wider">SIAE • SISTEMA INTEGRADO DE ATENDIMENTO ESPÍRITA</p>
          </div>
        </div>

        {/* Dynamic Controls, Sound Activator & Clock */}
        <div className="flex items-center gap-4">
          
          {/* Volume Slider and Test Button */}
          <div className="flex items-center gap-2.5 bg-gray-900/50 px-3.5 py-1.5 rounded-xl border border-gray-800/70 text-xs">
            <div className="flex items-center gap-1.5 text-gray-400 select-none">
              <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
              <span className="font-extrabold text-[10px] tracking-wider uppercase">Volume</span>
            </div>
            <input 
              id="volume-slider"
              type="range" 
              min="0" 
              max="1" 
              step="0.05" 
              value={ttsVolume} 
              onChange={(e) => setTtsVolume(parseFloat(e.target.value))}
              className="w-16 sm:w-20 md:w-24 accent-indigo-500 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer"
            />
            <span className="font-mono text-[10px] text-gray-300 font-extrabold min-w-[28px] text-right select-none">
              {Math.round(ttsVolume * 100)}%
            </span>
            <button
              id="test-sound-btn"
              onClick={handleTestSound}
              className="ml-1 bg-indigo-500/15 hover:bg-indigo-500/30 text-indigo-400 hover:text-white text-[9px] font-black tracking-widest uppercase px-2 py-1 rounded border border-indigo-500/35 transition-all duration-200 cursor-pointer"
              title="Testar Som da Chamada"
            >
              Testar
            </button>
          </div>

          {/* Audio Unlock Button for Browsers/iFrames */}
          {!audioUnlocked ? (
            <button 
              onClick={handleUnlockAudio}
              className="flex items-center gap-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-[11px] font-black tracking-wider uppercase px-3.5 py-2 rounded-xl border border-amber-500/20 transition-all duration-300 cursor-pointer animate-pulse"
            >
              <VolumeX className="w-4 h-4" />
              <span>Ativar Som</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-400 text-[10px] font-black tracking-wider uppercase px-3.5 py-2 rounded-xl border border-emerald-500/20 select-none">
              <Volume2 className="w-4 h-4 animate-bounce" />
              <span>Som Ativado</span>
            </div>
          )}

          <div className="flex items-center gap-2.5 bg-gray-900/50 px-3.5 py-2 rounded-xl border border-gray-800/70 font-mono">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold text-gray-200 tracking-wide">{currentTime}</span>
          </div>

          <div className="hidden md:flex items-center gap-2 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20">
            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
            <span className="text-[10px] font-bold text-emerald-400 tracking-widest uppercase font-mono">Sincronizado</span>
          </div>
        </div>
      </header>

      {/* Main Grid Matrix Stage - Designed strictly to fit inside a single widescreen layout with dual 16:9 columns */}
      <div className="flex-1 p-6 overflow-hidden flex gap-6 min-h-0 bg-[#070b13]">
        {/* COLUNA ESQUERDA: Últimas senhas chamadas sendo incrementadas com rolagem */}
        <div className="w-1/2 flex flex-col min-h-0 bg-[#0e1322] rounded-2xl border border-gray-800/80 shadow-2xl p-5 overflow-hidden">
          {/* Cabeçalho da Coluna Esquerda */}
          <div className="flex items-center justify-between border-b border-gray-800/60 pb-3 mb-4 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-pulse" />
              <h2 className="text-sm font-black text-white tracking-widest uppercase flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-indigo-400" />
                Painel de Chamadas Recentes
              </h2>
            </div>
            <span className="text-[9px] font-black bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 rounded px-2.5 py-0.5 tracking-wider uppercase font-mono">
              Fila Histórica
            </span>
          </div>

          {/* Destaque da Última Senha Convocada (Primeira Posição) */}
          {callHistory.length > 0 ? (
            <div className="flex flex-col gap-3 shrink-0">
              <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest block select-none">ÚLTIMA SENHA CHAMADA</span>
              <div className="bg-gradient-to-br from-indigo-950/45 via-[#111627] to-emerald-950/20 rounded-2xl border-2 border-emerald-500/50 p-5 shadow-[0_0_25px_rgba(52,211,153,0.15)] flex flex-col justify-between relative overflow-hidden transition-all duration-300">
                {/* Indicador pulsante */}
                <div className="absolute top-3.5 right-3.5 flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 text-[8px] font-black tracking-widest uppercase px-2.5 py-1 rounded-full border border-emerald-500/20 animate-pulse">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                  <span>Nova Convocação</span>
                </div>

                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-extrabold text-indigo-400 tracking-widest uppercase select-none">
                    {callHistory[0].type}
                  </span>
                  
                  <div className="flex items-center justify-between gap-4 mt-1">
                    <div className="flex flex-col">
                      <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest select-none font-sans">SENHA</span>
                      <span className="text-6xl md:text-7xl font-mono font-black text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.45)] tracking-tighter leading-none">
                        {callHistory[0].ticket_number}
                      </span>
                    </div>
                    
                    <div className="flex flex-col items-end">
                      <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest select-none font-sans">SALA / CONSULTÓRIO</span>
                      <span className="text-4xl md:text-5xl font-black text-white bg-indigo-500/15 border border-indigo-500/30 px-5 py-1 rounded-2xl font-mono shadow-[0_0_15px_rgba(99,102,241,0.15)]">
                        {callHistory[0].room_number}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-gray-800/40">
                    <span className="text-[8px] font-bold text-gray-500 tracking-widest uppercase block mb-0.5 select-none font-sans">NOME DO ASSISTIDO</span>
                    <span className="text-xl font-black text-white uppercase truncate block leading-tight">
                      {callHistory[0].first_name} {callHistory[0].last_name}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-gray-900/10 border border-dashed border-gray-800 rounded-2xl p-6 text-center text-gray-500 italic py-10 flex flex-col items-center justify-center gap-2 shrink-0">
              <Volume2 className="w-7 h-7 text-gray-700 animate-pulse" />
              <span className="text-xs font-semibold">Nenhuma chamada ativa ou recente registrada</span>
            </div>
          )}

          {/* Lista de Chamadas Anteriores que foram empurradas para baixo */}
          <div className="flex-1 flex flex-col min-h-0 mt-5 overflow-hidden">
            <div className="flex items-center justify-between mb-3 shrink-0">
              <span className="text-[10px] font-black text-gray-400 tracking-widest uppercase flex items-center gap-1.5 select-none font-sans">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                Histórico de Convocados (Rolagem)
              </span>
              {callHistory.length > 1 && (
                <span className="text-[8px] font-black text-gray-500 bg-gray-950 px-2 py-0.5 rounded border border-gray-800/60 uppercase">
                  Anteriores: {callHistory.length - 1}
                </span>
              )}
            </div>

            <div className="flex-1 overflow-y-auto pr-1 space-y-2.5 min-h-0 scrollbar-thin scrollbar-thumb-gray-800">
              {callHistory.length <= 1 ? (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-25 select-none py-6">
                  <span className="text-xs text-gray-400 font-bold italic">Aguardando mais convocações para popular histórico</span>
                </div>
              ) : (
                callHistory.slice(1).map((call, idx) => (
                  <div 
                    key={`history-${call.id}-${idx}`} 
                    className="bg-[#121827]/60 border border-gray-800/50 rounded-xl p-3 flex items-center justify-between hover:border-gray-700/50 transition-all duration-200"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      {/* Senha pequena em indigo */}
                      <span className="text-lg font-mono font-black text-indigo-300 bg-indigo-500/10 px-2.5 py-0.5 rounded-lg border border-indigo-500/20 shrink-0">
                        {call.ticket_number}
                      </span>
                      <div className="flex flex-col min-w-0">
                        <span className="font-extrabold text-xs text-gray-200 truncate uppercase leading-tight">
                          {call.first_name} {call.last_name}
                        </span>
                        <span className="text-[9px] text-gray-500 font-bold uppercase tracking-wider mt-0.5">
                          {call.type}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="flex flex-col items-end">
                        <span className="text-[8px] text-gray-500 font-bold uppercase select-none font-sans">SALA</span>
                        <span className="font-mono font-black text-xs text-white bg-gray-900/80 px-2.5 py-0.5 rounded border border-gray-800/80">
                          {call.room_number}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* COLUNA DIREITA: Todos os grupos de assistência chamando */}
        <div className="w-1/2 flex flex-col min-h-0 bg-[#0e1322] rounded-2xl border border-gray-800/80 shadow-2xl p-5 overflow-hidden">
          {/* Cabeçalho da Coluna Direita */}
          <div className="flex items-center justify-between border-b border-gray-800/60 pb-3 mb-4 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
              <h2 className="text-sm font-black text-white tracking-widest uppercase flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-400" />
                Painel Geral de Assistências
              </h2>
            </div>
            <span className="text-[9px] font-black bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded px-2.5 py-0.5 tracking-wider uppercase font-mono">
              Salas Ativas
            </span>
          </div>

          {typesQueue.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500 gap-3 py-12">
              <div className="w-14 h-14 rounded-2xl bg-gray-900/40 flex items-center justify-center border border-gray-800">
                <Compass className="w-7 h-7 text-indigo-400 animate-spin" />
              </div>
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Nenhuma Assistência Ativa</span>
              <p className="text-[10px] text-gray-500 max-w-xs text-center leading-relaxed">
                As salas aparecerão aqui dinamicamente assim que os trabalhadores registrarem início de atividade.
              </p>
            </div>
          ) : (
            <div className="flex-1 flex flex-col gap-3.5 overflow-y-auto pr-1 min-h-0 scrollbar-thin scrollbar-thumb-gray-800">
              {typesQueue.map((item) => {
                const activeCall = item.currentCall;
                const subQueue = item.nextInLine || [];
                const isCalled = activeCall && activeCall.status === 'called';

                return (
                  <div 
                    key={`matrix-col-${item.type}`} 
                    className={`rounded-xl border flex flex-col p-4 transition-all duration-300 shadow-lg shrink-0 ${
                      isCalled 
                        ? 'bg-emerald-950/10 border-emerald-500/50 ring-1 ring-emerald-500/20 shadow-[0_0_20px_rgba(52,211,153,0.06)]' 
                        : 'bg-gray-900/20 border-gray-800/70 hover:border-gray-800'
                    }`}
                  >
                    {/* Header da Assistência */}
                    <div className="flex items-center justify-between border-b border-gray-800/40 pb-2 mb-2.5">
                      <span className="font-extrabold text-xs text-gray-200 tracking-wider uppercase truncate max-w-[70%]" title={item.type}>
                        {item.type}
                      </span>
                      <div className="flex items-center gap-1.5 text-[9px] text-gray-500 font-bold uppercase select-none font-sans">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span>SALA {activeCall?.room_number || '—'}</span>
                      </div>
                    </div>

                    {/* Conteúdo Convocatório */}
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <span className="text-[8px] font-black text-gray-500 tracking-widest uppercase block mb-0.5 select-none font-sans">
                          ASSISTIDO CONVOCADO
                        </span>
                        <span className={`font-black text-base uppercase truncate block ${
                          isCalled ? 'text-emerald-300 font-extrabold' : 'text-gray-300'
                        }`}>
                          {activeCall ? `${activeCall.first_name} ${activeCall.last_name || ''}` : 'NENHUM EM ATENDIMENTO'}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <div className="flex flex-col items-center">
                          <span className="text-[8px] font-black text-indigo-400 tracking-wider uppercase mb-0.5 select-none font-sans">SENHA</span>
                          <div className={`text-3xl font-mono font-black tracking-tighter ${
                            isCalled ? 'text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]' : 'text-indigo-400'
                          }`}>
                            {activeCall ? activeCall.ticket_number : '—'}
                          </div>
                        </div>

                        <div className="h-8 w-[1px] bg-gray-800 shrink-0" />

                        <div className="flex flex-col items-center">
                          <span className="text-[8px] font-black text-indigo-400 tracking-wider uppercase mb-0.5 select-none font-sans">SALA</span>
                          <div className="text-lg font-black text-white px-2.5 py-0.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 font-mono">
                            {activeCall?.room_number || '—'}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Próximo da fila sutil */}
                    {subQueue.length > 0 && (
                      <div className="mt-3 pt-2 border-t border-gray-800/30 flex items-center justify-between text-[9px] font-sans">
                        <span className="text-gray-500 font-bold uppercase tracking-wider">
                          Próximo em fila: <strong className="text-indigo-300 uppercase font-extrabold">{subQueue[0].first_name} {subQueue[0].last_name ? subQueue[0].last_name.substring(0, 1) + '.' : ''}</strong>
                        </span>
                        <span className="text-[#5ba6ff] bg-[#5ba6ff]/10 border border-[#5ba6ff]/15 px-1.5 py-0.5 rounded font-mono font-bold text-[8px] tracking-wider shrink-0">
                          {subQueue[0].ticket_number}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Footer historical board showing last completions */}
      <footer className="bg-[#0e1322] border-t border-gray-850 px-8 py-3.5 shadow-2xl shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 text-gray-400 select-none min-w-[170px]">
            <CheckCircle2 className="w-4 h-4 text-indigo-400" />
            <h3 className="text-xs font-black text-gray-200 uppercase tracking-widest">Últimos Atendimentos</h3>
          </div>
          
          <div className="flex-1 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 w-full">
            {lastAttended.map((la) => (
              <div 
                key={`matrix-la-${la.id}`} 
                className="bg-[#070b13] border border-gray-800/70 rounded-lg px-3 py-1.5 flex flex-col items-center justify-center transition-all duration-350 hover:border-gray-700"
              >
                <span className="text-xs font-black text-gray-200 font-mono tracking-tighter">{la.ticket_number}</span>
                <span className="text-[9px] text-gray-500 font-bold truncate max-w-full text-center">
                  {la.first_name} {la.last_name ? la.last_name.substring(0, 1) + '.' : ''}
                </span>
                <span className="text-[8px] font-black text-indigo-400/80 uppercase tracking-widest scale-95">{la.type}</span>
              </div>
            ))}
            
            {/* Filler placeholder slots */}
            {Array.from({ length: Math.max(0, 6 - lastAttended.length) }).map((_, i) => (
              <div 
                key={`matrix-empty-la-${i}`} 
                className="bg-[#070b13]/30 border border-gray-800/20 border-dashed rounded-lg py-1 flex flex-col items-center justify-center opacity-20 min-h-[38px]"
              >
                <span className="text-xs text-gray-650 font-bold">-</span>
              </div>
            ))}
          </div>
        </div>
      </footer>

    </div>
  );
}
