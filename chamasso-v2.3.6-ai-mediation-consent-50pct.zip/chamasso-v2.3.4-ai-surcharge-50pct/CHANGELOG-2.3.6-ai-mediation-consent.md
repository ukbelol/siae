# Chamasso 2.3.6 — Consentimento da Mediação por IA

- Ao selecionar **Auxílio por IA — Mediação Psicossocial**, abre confirmação antes da seleção.
- Informa acréscimo de **50%** (1/2 da tarifa normal adicional), equivalente a consumo total de **1,5×** a tarifa normal.
- Exige checkbox de aceite dos Termos de Uso; botão de prosseguir permanece desabilitado sem aceite.
- Backend rejeita solicitação de mediação IA sem aceite explícito.
- Registra no objeto da solicitação data/hora do aceite e percentual vigente (50%).
- Mantém a regra existente de conta AI/PASQUARED livre de cobrança.
