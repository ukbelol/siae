import React from 'react';
import { HistoricalTimelineItem } from '../types';
import { Hourglass, Calendar, Users, Clock, Award } from 'lucide-react';

interface TimelineViewProps {
  timeline: HistoricalTimelineItem[];
}

const PHASE_COLORS: Record<string, string> = {
  INÍCIO: 'bg-[#111111] text-[#00FF41] border-[#00FF41]',
  DESENVOLVIMENTO: 'bg-[#111111] text-[#3B82F6] border-[#3B82F6]',
  MEIO: 'bg-[#111111] text-[#FF3E00] border-[#FF3E00]',
  FIM: 'bg-[#111111] text-[#EC4899] border-[#EC4899]',
  CONSEQUÊNCIAS: 'bg-[#111111] text-[#A855F7] border-[#A855F7]',
};

export const TimelineView: React.FC<TimelineViewProps> = ({ timeline }) => {
  return (
    <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#00FF41] p-5 sm:p-6 text-[#E0E0E0] space-y-6">
      <div className="flex items-center justify-between border-b border-[#222222] pb-3">
        <div className="flex items-center space-x-2">
          <Hourglass className="w-5 h-5 text-[#00FF41]" />
          <h3 className="text-sm sm:text-base font-black text-white tracking-tight uppercase">
            CHRONOS — Linha do Tempo & Causalidade Histórica
          </h3>
        </div>
        <span className="text-[10px] px-2.5 py-1 font-mono uppercase bg-[#1A1A1A] text-[#00FF41] font-bold border border-[#333333]">
          Sequência 5 Fases
        </span>
      </div>

      <p className="text-xs text-[#888888] font-mono">
        Estrutura temporal rigorosa calculada por HCS ($HCS = E \times T \times D \times C$). O parâmetro de tempo em evidência registra a duração factual observável sem inventar fases.
      </p>

      {/* Timeline Steps */}
      <div className="relative border-l-2 border-[#222222] ml-4 pl-6 space-y-6 font-mono">
        {timeline.map((item, idx) => {
          const colorClass = PHASE_COLORS[item.phase] || 'bg-[#111111] text-[#00FF41] border-[#00FF41]';

          return (
            <div key={idx} className="relative group">
              {/* Dot on Timeline */}
              <div className="absolute -left-[31px] top-1.5 w-4 h-4 bg-[#0A0A0A] border-2 border-[#00FF41] group-hover:bg-[#00FF41] transition-colors" />

              <div className="bg-[#0A0A0A] border border-[#222222] p-4 space-y-2 hover:border-[#444444] transition-all">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222222] pb-2">
                  <div className="flex items-center space-x-2">
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 border ${colorClass}`}>
                      {item.phase}
                    </span>
                    <span className="text-xs font-bold text-[#E0E0E0] flex items-center space-x-1">
                      <Calendar className="w-3.5 h-3.5 text-[#888888]" />
                      <span>{item.period}</span>
                    </span>
                  </div>

                  <div className="flex items-center space-x-3 text-[10px] font-mono text-[#888888]">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-[#00FF41]" />
                      <span>Evidência: {item.evidenceDuration}</span>
                    </span>
                    <span className="text-[#00FF41]">HCS: {(item.causalityScore * 100).toFixed(0)}%</span>
                  </div>
                </div>

                <h4 className="font-bold text-sm text-white uppercase tracking-wider">{item.event}</h4>
                <p className="text-xs text-[#CCCCCC] leading-relaxed font-sans">{item.description}</p>

                {item.actors && item.actors.length > 0 && (
                  <div className="flex items-center space-x-2 pt-2 text-[10px] text-[#888888]">
                    <Users className="w-3.5 h-3.5 text-[#666666]" />
                    <span className="font-bold">Atores:</span>
                    <div className="flex flex-wrap gap-1">
                      {item.actors.map((actor, aIdx) => (
                        <span key={aIdx} className="px-1.5 py-0.2 bg-[#151515] text-[#E0E0E0] border border-[#333333]">
                          {actor}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
