import React from 'react';

type State = { error: Error | null };

export class AppErrorBoundary extends React.Component<React.PropsWithChildren, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[GOITGODS] React render failure', error, info);
  }

  render() {
    if (this.state.error) {
      return (
        <main style={{ minHeight: '100vh', background: '#090909', color: '#f2f2f2', padding: '32px', fontFamily: 'monospace' }}>
          <div style={{ maxWidth: 900, margin: '0 auto', border: '1px solid #ff3e00', padding: 24, borderRadius: 12 }}>
            <h1 style={{ color: '#ff6b3d', marginTop: 0 }}>GOITGODS não conseguiu iniciar a interface</h1>
            <p>O servidor respondeu, mas o React encontrou um erro durante a inicialização.</p>
            <pre style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', background: '#111', padding: 16, borderRadius: 8 }}>
              {this.state.error.message || String(this.state.error)}
            </pre>
            <p>Administrador: verifique <code>pm2 logs goitgods --lines 100</code>, o Console do navegador e execute <code>./repair-white-screen.sh</code>.</p>
            <button onClick={() => location.reload()} style={{ padding: '10px 16px', cursor: 'pointer' }}>Recarregar</button>
          </div>
        </main>
      );
    }
    return this.props.children;
  }
}
