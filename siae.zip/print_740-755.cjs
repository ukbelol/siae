const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

for (let i = 730; i < 765; i++) console.log(i+1, lines[i]);
