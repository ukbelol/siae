#!/usr/bin/env bash
# ==============================================================================
# GOITGODS 2.3.4 + PASQUARED — INSTALADOR GERAL (DEBIAN 12)
# Domínio: https://goitgods.pasquared.space
# Instala runtime, dependências, MariaDB, Apache, PM2, build e SSL Let's Encrypt.
# ==============================================================================
set -Eeuo pipefail
IFS=$'\n\t'

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
log_info(){ echo -e "${CYAN}[INFO]${NC} $*"; }
log_ok(){ echo -e "${GREEN}[OK]${NC} $*"; }
log_warn(){ echo -e "${YELLOW}[ALERTA]${NC} $*"; }
log_error(){ echo -e "${RED}[ERRO]${NC} $*" >&2; }
die(){ log_error "$*"; exit 1; }
trap 'log_error "Falha na linha $LINENO: $BASH_COMMAND"' ERR

[[ ${EUID:-$(id -u)} -eq 0 ]] || die "Execute como root: sudo ./install-gods.sh"

DOMAIN_NAME="goitgods.pasquared.space"
WWW_DOMAIN="www.goitgods.pasquared.space"
INSTALL_DIR="${INSTALL_DIR:-/opt/goitgods}"
SYS_USER="${SYS_USER:-goitgods}"
SYS_GROUP="${SYS_GROUP:-www-data}"
APP_PORT="${APP_PORT:-3100}"
NODE_MAJOR="${NODE_MAJOR:-24}"
CERTBOT_EMAIL="${CERTBOT_EMAIL:-}"
CERTBOT_INCLUDE_WWW="${CERTBOT_INCLUDE_WWW:-auto}"
SKIP_SSL="${SKIP_SSL:-false}"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_ROOT="/var/backups/goitgods"

usage(){ cat <<USAGE
Uso: sudo ./install-gods.sh [opções]

Opções:
  --certbot-email EMAIL   E-mail válido para Let's Encrypt
  --with-www              Exige certificado também para www.$DOMAIN_NAME
  --no-www                Não inclui o alias www
  --port PORTA             Porta interna do backend (padrão: $APP_PORT)
  --skip-ssl               Instala sem solicitar certificado (diagnóstico)
  -h, --help               Exibe esta ajuda

Variáveis equivalentes:
  CERTBOT_EMAIL, CERTBOT_INCLUDE_WWW=auto|yes|no, APP_PORT, NODE_MAJOR
USAGE
}

while (($#)); do
  case "$1" in
    --certbot-email|--email) [[ $# -ge 2 ]] || die "Faltou o e-mail"; CERTBOT_EMAIL="$2"; shift 2;;
    --with-www) CERTBOT_INCLUDE_WWW=yes; shift;;
    --no-www) CERTBOT_INCLUDE_WWW=no; shift;;
    --port) [[ $# -ge 2 ]] || die "Faltou a porta"; APP_PORT="$2"; shift 2;;
    --skip-ssl) SKIP_SSL=true; shift;;
    -h|--help) usage; exit 0;;
    *) die "Argumento desconhecido: $1";;
  esac
done

[[ "$APP_PORT" =~ ^[0-9]+$ ]] && ((APP_PORT >= 1024 && APP_PORT <= 65535)) || die "APP_PORT inválida: $APP_PORT"

valid_email(){ [[ "$1" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; }
ensure_certbot_email(){
  [[ "$SKIP_SSL" == true ]] && return 0
  if valid_email "$CERTBOT_EMAIL"; then return 0; fi
  if [[ -t 0 ]]; then
    while ! valid_email "$CERTBOT_EMAIL"; do
      read -r -p "E-mail válido para Let's Encrypt: " CERTBOT_EMAIL
      valid_email "$CERTBOT_EMAIL" || log_warn "E-mail inválido."
    done
  else
    die "Informe CERTBOT_EMAIL=voce@dominio.com ou use --certbot-email."
  fi
}
resolve_domain(){ dig +short A "$1" 2>/dev/null | grep -qE '^[0-9]+\.' || dig +short AAAA "$1" 2>/dev/null | grep -q ':'; }

set_env_key(){
  local file="$1" key="$2" value="$3"
  if grep -qE "^${key}=" "$file" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    printf '%s=%s\n' "$key" "$value" >> "$file"
  fi
}
run_app(){ runuser -u "$SYS_USER" -- env HOME="$INSTALL_DIR" PATH="/usr/local/bin:/usr/bin:/bin" "$@"; }

printf '%b\n' "$CYAN"
echo "============================================================================="
echo " GOITGODS 2.3.4 + PASQUARED — INSTALAÇÃO COMPLETA DE PRODUÇÃO"
echo " Domínio: https://$DOMAIN_NAME"
echo "============================================================================="
printf '%b\n' "$NC"

export DEBIAN_FRONTEND=noninteractive
log_info "Atualizando índices APT (sem executar upgrade geral do sistema)..."
apt-get update -y

log_info "Instalando dependências do sistema compatíveis com Debian 12..."
apt-get install -y --no-install-recommends \
  ca-certificates curl wget git gnupg dirmngr apt-transport-https \
  build-essential make gcc g++ pkg-config python3 python3-venv python3-pip \
  jq unzip zip rsync openssl dnsutils iproute2 procps psmisc lsof net-tools \
  util-linux acl cron logrotate htop fail2ban ufw libapache2-mod-security2 modsecurity-crs libapache2-mod-evasive \
  apache2 certbot python3-certbot-apache \
  mariadb-server mariadb-client

# Remove apenas web server concorrente conhecido. Não remove outros aplicativos.
if systemctl is-active --quiet nginx 2>/dev/null; then
  log_warn "Nginx está ativo e conflita com Apache nas portas 80/443; desabilitando-o."
  systemctl disable --now nginx || true
fi

log_info "Habilitando Apache e módulos necessários..."
systemctl enable --now apache2
for m in proxy proxy_http ssl rewrite headers expires deflate http2; do a2enmod "$m" >/dev/null; done
apache2ctl configtest

log_info "Configurando MariaDB..."
systemctl enable --now mariadb

# Node.js 24 LTS em 2026; versões antigas (ex.: 20) são substituídas.
CURRENT_NODE_MAJOR=0
if command -v node >/dev/null 2>&1; then CURRENT_NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"; fi
if (( CURRENT_NODE_MAJOR < NODE_MAJOR )); then
  log_info "Instalando/atualizando Node.js ${NODE_MAJOR}.x LTS via NodeSource (atual: ${CURRENT_NODE_MAJOR:-nenhum})..."
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" -o /tmp/nodesource_setup.sh
  bash /tmp/nodesource_setup.sh
  apt-get install -y nodejs
  rm -f /tmp/nodesource_setup.sh
fi
command -v node >/dev/null || die "Node.js não foi instalado."
command -v npm >/dev/null || die "npm não foi instalado."
log_ok "Node $(node -v) / npm $(npm -v)"

log_info "Instalando/atualizando PM2 global..."
npm install -g pm2@latest --no-audit --no-fund
command -v pm2 >/dev/null || die "PM2 não foi instalado."

# Usuário dedicado — idempotente: não usa usermod em conta já ativa.
getent group "$SYS_GROUP" >/dev/null || groupadd -r "$SYS_GROUP"
if ! id "$SYS_USER" >/dev/null 2>&1; then
  useradd -r -g "$SYS_GROUP" -d "$INSTALL_DIR" -s /bin/bash -c "GOITGODS service" "$SYS_USER"
else
  CURRENT_GROUP="$(id -gn "$SYS_USER" 2>/dev/null || true)"
  CURRENT_HOME="$(getent passwd "$SYS_USER" | cut -d: -f6 || true)"
  [[ "$CURRENT_GROUP" == "$SYS_GROUP" ]] || log_warn "Usuário $SYS_USER já existe com grupo primário $CURRENT_GROUP; preservando-o para não interromper processos ativos."
  [[ "$CURRENT_HOME" == "$INSTALL_DIR" ]] || log_warn "Usuário $SYS_USER já existe com HOME $CURRENT_HOME; PM2 continuará usando HOME=$INSTALL_DIR explicitamente."
fi

mkdir -p "$BACKUP_ROOT" "$INSTALL_DIR" "$INSTALL_DIR/data" "$INSTALL_DIR/logs"
STAMP="$(date +%Y%m%d-%H%M%S)"
if [[ -f "$INSTALL_DIR/.env" ]]; then
  cp -a "$INSTALL_DIR/.env" "$BACKUP_ROOT/env-$STAMP"
  [[ -d "$INSTALL_DIR/data" ]] && tar -C "$INSTALL_DIR" -czf "$BACKUP_ROOT/data-$STAMP.tar.gz" data 2>/dev/null || true
  log_ok "Backup de configuração criado em $BACKUP_ROOT"
fi

# Copia código sem destruir dados/segredos/runtime da instalação existente.
if [[ "$SOURCE_DIR" != "$INSTALL_DIR" ]]; then
  log_info "Copiando código para $INSTALL_DIR preservando .env, data e logs..."
  rsync -a --delete \
    --exclude='/.env' --exclude='/data/' --exclude='/logs/' --exclude='/node_modules/' --exclude='/dist/' --exclude='/.pm2/' \
    "$SOURCE_DIR/" "$INSTALL_DIR/"
fi
mkdir -p "$INSTALL_DIR/data" "$INSTALL_DIR/logs"
chown -R "$SYS_USER:$SYS_GROUP" "$INSTALL_DIR"
chmod 750 "$INSTALL_DIR" "$INSTALL_DIR/data" "$INSTALL_DIR/logs"
find "$INSTALL_DIR" -type d -not -path "$INSTALL_DIR/data*" -not -path "$INSTALL_DIR/logs*" -exec chmod 755 {} +
find "$INSTALL_DIR" -type f -not -path "$INSTALL_DIR/.env" -not -path "$INSTALL_DIR/data/*" -exec chmod 644 {} +
chmod +x "$INSTALL_DIR/install-gods.sh" "$INSTALL_DIR/repair-white-screen.sh" "$INSTALL_DIR/migrate-domain-to-pasquared.sh" 2>/dev/null || true

# Banco: preserva senha antiga quando houver.
DB_NAME="goitgods_db"; DB_USER="goitgods"
OLD_ENV="$INSTALL_DIR/.env"
DB_PASS=""
[[ -f "$OLD_ENV" ]] && DB_PASS="$(grep '^MARIADB_PASSWORD=' "$OLD_ENV" | head -1 | cut -d= -f2- || true)"
[[ -n "$DB_PASS" ]] || DB_PASS="$(openssl rand -hex 32)"

mysql -u root <<SQL
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
ALTER USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
SQL

mysql -u root "$DB_NAME" <<'SQL'
CREATE TABLE IF NOT EXISTS goitgods_auth (
  id VARCHAR(100) PRIMARY KEY, name VARCHAR(255) NOT NULL, username VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL, password_hash VARCHAR(255) NOT NULL, role VARCHAR(50) NOT NULL,
  status VARCHAR(50) NOT NULL, api_key VARCHAR(255) NOT NULL, created_at VARCHAR(100) NOT NULL,
  is_configured BOOLEAN NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS goitgods_users (
  id VARCHAR(100) PRIMARY KEY, name VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL, status VARCHAR(50) NOT NULL, api_quota_used INT NOT NULL,
  api_quota_limit INT NOT NULL, last_active VARCHAR(100) NOT NULL, api_key VARCHAR(255) NOT NULL,
  created_at VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS goitgods_audit_logs (
  id VARCHAR(100) PRIMARY KEY, timestamp VARCHAR(100) NOT NULL, actor VARCHAR(255) NOT NULL,
  action VARCHAR(255) NOT NULL, target VARCHAR(255) NOT NULL, severity VARCHAR(50) NOT NULL,
  details TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL

# Preserva todas as chaves extras (.env) e atualiza apenas parâmetros internos.
[[ -f "$OLD_ENV" ]] || touch "$OLD_ENV"
set_env_key "$OLD_ENV" NODE_ENV production
set_env_key "$OLD_ENV" PORT "$APP_PORT"
set_env_key "$OLD_ENV" APP_URL "https://$DOMAIN_NAME"
set_env_key "$OLD_ENV" MARIADB_HOST localhost
set_env_key "$OLD_ENV" MARIADB_PORT 3306
set_env_key "$OLD_ENV" MARIADB_USER "$DB_USER"
set_env_key "$OLD_ENV" MARIADB_PASSWORD "$DB_PASS"
set_env_key "$OLD_ENV" MARIADB_DATABASE "$DB_NAME"
set_env_key "$OLD_ENV" CERTBOT_EMAIL "$CERTBOT_EMAIL"
set_env_key "$OLD_ENV" CERTBOT_INCLUDE_WWW "$CERTBOT_INCLUDE_WWW"
chown "$SYS_USER:$SYS_GROUP" "$OLD_ENV"; chmod 600 "$OLD_ENV"

# Para com segurança instâncias anteriores antes de tocar no runtime PM2.
log_info "Parando instâncias anteriores do GOITGODS, se existirem..."
systemctl stop "pm2-$SYS_USER" >/dev/null 2>&1 || true
run_app pm2 stop goitgods >/dev/null 2>&1 || true
run_app pm2 delete goitgods >/dev/null 2>&1 || true
run_app pm2 kill >/dev/null 2>&1 || true
sleep 2

# Se a porta estiver ocupada, só encerra automaticamente processos que pertençam ao GOITGODS.
PORT_PIDS="$(ss -ltnp 2>/dev/null | awk -v p=":${APP_PORT}" '$4 ~ p"$" { while (match($0,/pid=[0-9]+/)) { x=substr($0,RSTART+4,RLENGTH-4); print x; $0=substr($0,RSTART+RLENGTH) } }' | sort -u || true)"
if [[ -n "$PORT_PIDS" ]]; then
  for pid in $PORT_PIDS; do
    CMD="$(tr '\0' ' ' </proc/$pid/cmdline 2>/dev/null || true)"
    CWD="$(readlink -f /proc/$pid/cwd 2>/dev/null || true)"
    if [[ "$CMD" == *"$INSTALL_DIR"* || "$CWD" == "$INSTALL_DIR"* || "$CMD" == *"goitgods"* ]]; then
      log_warn "Encerrando instância anterior do GOITGODS na porta $APP_PORT (PID $pid)."
      kill "$pid" 2>/dev/null || true
    else
      log_error "A porta $APP_PORT pertence a processo externo (PID $pid): $CMD"
      die "Não encerrarei processo desconhecido. Libere a porta $APP_PORT ou use --port para uma porta diferente."
    fi
  done
  sleep 3
fi
if ss -ltnp 2>/dev/null | grep -qE ":${APP_PORT}[[:space:]]"; then
  ss -ltnp | grep -E ":${APP_PORT}[[:space:]]" || true
  die "A porta interna $APP_PORT continua ocupada após a limpeza segura."
fi

# Valida a integridade do fonte antes de instalar dependências/buildar.
# IMPORTANTE: /data é runtime persistente, enquanto /src/data pertence ao código-fonte.
REQUIRED_SOURCE_FILES=("src/data/godsData.ts" "src/components/GodsGrid.tsx" "src/App.tsx" "server.ts" "package.json")
for REQUIRED_FILE in "${REQUIRED_SOURCE_FILES[@]}"; do
  [[ -f "$INSTALL_DIR/$REQUIRED_FILE" ]] || die "Arquivo obrigatório ausente após cópia: $REQUIRED_FILE"
done
log_ok "Código-fonte validado; src/data/godsData.ts está presente."

log_info "Instalando dependências npm declaradas no package.json..."
cd "$INSTALL_DIR"
rm -rf node_modules dist
chown -R "$SYS_USER:$SYS_GROUP" "$INSTALL_DIR"
export npm_config_audit=false npm_config_fund=false
if [[ -f package-lock.json ]]; then
  run_app npm ci --include=dev --no-audit --no-fund
else
  run_app npm install --include=dev --no-audit --no-fund
fi

log_info "Validando TypeScript (diagnóstico; o build de produção continua sendo a barreira obrigatória)..."
if ! run_app npm run lint >"$INSTALL_DIR/logs/typescript-check.log" 2>&1; then
  log_warn "O TypeScript reportou avisos/erros. Consulte $INSTALL_DIR/logs/typescript-check.log. O build será tentado e deverá passar para a instalação continuar."
fi

log_info "Compilando frontend Vite + backend Node..."
run_app env NODE_ENV=production npm run build
[[ -s dist/index.html ]] || die "Build inválido: dist/index.html ausente."
[[ -s dist/server.cjs ]] || die "Build inválido: dist/server.cjs ausente."
find dist/assets -maxdepth 1 -type f -name '*.js' -print -quit | grep -q . || die "Build inválido: bundle JS ausente."
log_ok "Build completo validado."

# Produção não precisa de devDependencies após build; mantém para reparo/local diagnostics por padrão.
chown -R "$SYS_USER:$SYS_GROUP" "$INSTALL_DIR"

log_info "Iniciando backend pelo PM2..."
run_app pm2 start "$INSTALL_DIR/dist/server.cjs" --name goitgods --cwd "$INSTALL_DIR" --interpreter node --update-env
run_app pm2 save
# Registra PM2 no systemd para subir após reboot.
env PATH="$PATH:/usr/local/bin:/usr/bin:/bin" pm2 startup systemd -u "$SYS_USER" --hp "$INSTALL_DIR" >/tmp/goitgods-pm2-startup.log 2>&1 || {
  cat /tmp/goitgods-pm2-startup.log >&2; die "Falha ao configurar PM2 startup/systemd";
}
systemctl daemon-reload
systemctl enable "pm2-$SYS_USER" >/dev/null 2>&1 || true

sleep 2
curl -fsS "http://127.0.0.1:$APP_PORT/api/v2/health" | jq -e '.status == "ok"' >/dev/null || {
  run_app pm2 logs goitgods --lines 80 --nostream || true
  die "Backend não respondeu em /api/v2/health."
}
log_ok "Backend saudável em 127.0.0.1:$APP_PORT"

log_info "Configurando VirtualHost Apache..."
APACHE_CONF="/etc/apache2/sites-available/$DOMAIN_NAME.conf"
cat > "$APACHE_CONF" <<APACHE
<VirtualHost *:80>
    ServerName $DOMAIN_NAME
    DocumentRoot $INSTALL_DIR/dist
    ErrorLog \${APACHE_LOG_DIR}/goitgods_error.log
    CustomLog \${APACHE_LOG_DIR}/goitgods_access.log combined

    # Evita tela branca após deploy: index nunca fica preso no cache, assets hashados podem ser cacheados.
    AddType application/javascript .js .mjs
    AddType text/css .css
    <Files "index.html">
        Header always set Cache-Control "no-store, no-cache, must-revalidate, max-age=0"
        Header always set Pragma "no-cache"
        Header always set Expires "0"
    </Files>

    # Assets do Vite são arquivos reais sob o próprio DocumentRoot.
    # Não usamos Alias: isso evita interação ambígua entre Alias e mod_rewrite.

    <Directory $INSTALL_DIR/dist>
        DirectoryIndex index.html
        Options -Indexes +FollowSymLinks
        AllowOverride None
        Require all granted

        RewriteEngine On
        # NUNCA aplicar fallback SPA aos bundles/recursos estáticos.
        RewriteRule ^assets/ - [END]
        RewriteRule ^favicon\.ico$ - [END]
        # Arquivos e diretórios reais nunca entram no fallback da SPA.
        RewriteCond %{REQUEST_FILENAME} -f [OR]
        RewriteCond %{REQUEST_FILENAME} -d
        RewriteRule ^ - [END]
        # Somente rotas virtuais do React recebem index.html.
        RewriteRule ^ /index.html [END]
    </Directory>

    ProxyPreserveHost On
    ProxyPass        /api http://127.0.0.1:$APP_PORT/api retry=0 timeout=120
    ProxyPassReverse /api http://127.0.0.1:$APP_PORT/api

    <FilesMatch "\\.(js|css|png|jpg|jpeg|gif|svg|ico|woff2?)$">
        Header set Cache-Control "public, max-age=31536000, immutable"
    </FilesMatch>
</VirtualHost>
APACHE

a2ensite "$DOMAIN_NAME.conf" >/dev/null
a2dissite 000-default.conf >/dev/null 2>&1 || true
# Define FQDN global e elimina AH00558 do apache2ctl.
printf 'ServerName %s\n' "$DOMAIN_NAME" >/etc/apache2/conf-available/goitgods-servername.conf
a2enconf goitgods-servername >/dev/null 2>&1 || true
# Desabilita virtualhosts GOITGODS antigos para não disputarem ServerName.
for f in /etc/apache2/sites-enabled/goitgods.*.conf; do
  [[ -e "$f" ]] || continue
  [[ "$(basename "$f")" == "$DOMAIN_NAME.conf" ]] || a2dissite "$(basename "$f")" >/dev/null 2>&1 || true
done
apache2ctl configtest
systemctl reload apache2

INDEX_HTTP="$(curl -fsS -H "Host: $DOMAIN_NAME" -H 'Cache-Control: no-cache' http://127.0.0.1/)"
grep -q 'id="root"' <<<"$INDEX_HTTP" || die "Apache não entregou o frontend compilado."
curl -fsS -H "Host: $DOMAIN_NAME" http://127.0.0.1/api/v2/health | jq -e '.status == "ok"' >/dev/null || die "Proxy /api do Apache não respondeu."
# Valida exatamente os bundles referenciados pelo index compilado, não apenas a existência de algum .js em dist/assets.
ASSET_PATHS="$(printf '%s' "$INDEX_HTTP" | grep -oE '(src|href)="/assets/[^"]+\.(js|css)"' | sed -E 's/^(src|href)="([^"]+)"/\2/' | sort -u || true)"
[[ -n "$ASSET_PATHS" ]] || die "dist/index.html não referencia bundles /assets válidos."
while IFS= read -r asset; do
  [[ -n "$asset" ]] || continue
  HEADERS=/tmp/goitgods-asset-headers
  STATUS="$(curl -sS -D "$HEADERS" -o /tmp/goitgods-asset-check -w '%{http_code}' -H "Host: $DOMAIN_NAME" "http://127.0.0.1$asset")"
  [[ "$STATUS" == "200" ]] || die "Asset $asset retornou HTTP $STATUS pelo Apache."
  [[ -s /tmp/goitgods-asset-check ]] || die "Asset $asset foi entregue vazio."
  CONTENT_TYPE="$(awk 'BEGIN{IGNORECASE=1} /^Content-Type:/{gsub(/\r/,""); print tolower($2); exit}' "$HEADERS")"
  case "$asset" in
    *.js) [[ "$CONTENT_TYPE" == *javascript* ]] || die "Asset JS $asset recebeu Content-Type '$CONTENT_TYPE' (esperado JavaScript). Apache provavelmente devolveu index.html." ;;
    *.css) [[ "$CONTENT_TYPE" == text/css* ]] || die "Asset CSS $asset recebeu Content-Type '$CONTENT_TYPE' (esperado text/css)." ;;
  esac
done <<< "$ASSET_PATHS"
rm -f /tmp/goitgods-asset-check /tmp/goitgods-asset-headers
log_ok "Frontend + API + bundles JS/CSS via Apache HTTP validados."
SUPERADMIN_USER="roger577@ukbelol.space"; SUPERADMIN_PASSWORD="$(openssl rand -base64 30 | tr -d '\n' | tr '/+' '_-' | cut -c1-32)"
if curl -fsS -H "Host: $DOMAIN_NAME" http://127.0.0.1/api/v2/admin/setup-status | jq -e '.isSetup == false' >/dev/null; then
  curl -fsS -H "Host: $DOMAIN_NAME" -H 'Content-Type: application/json' -d "$(jq -nc --arg n 'Rogerio' --arg u "$SUPERADMIN_USER" --arg p "$SUPERADMIN_PASSWORD" --arg e "$SUPERADMIN_USER" '{fullName:$n,username:$u,password:$p,email:$e}')" http://127.0.0.1/api/v2/admin/setup-super-admin | jq -e '.success == true' >/dev/null || die "Falha ao criar Super Admin."
  umask 077; printf "Usuário: %s\nSenha inicial: %s\n" "$SUPERADMIN_USER" "$SUPERADMIN_PASSWORD" >/root/goitgods-superadmin-credentials.txt; chmod 600 /root/goitgods-superadmin-credentials.txt; SUPERADMIN_CREATED=true
else SUPERADMIN_CREATED=false; fi

log_info "Ativando firewall e camadas anti-abuso..."
# Detecta SSH sem deixar set -e/pipefail abortar a instalação.
SSH_PORT=""
SSHD_BIN="$(command -v sshd 2>/dev/null || true)"
[[ -z "$SSHD_BIN" && -x /usr/sbin/sshd ]] && SSHD_BIN=/usr/sbin/sshd
if [[ -n "$SSHD_BIN" ]]; then
  SSH_PORT="$($SSHD_BIN -T 2>/dev/null | awk '$1=="port"{print $2; exit}' || true)"
fi
if [[ -z "$SSH_PORT" && -f /etc/ssh/sshd_config ]]; then
  SSH_PORT="$(awk '/^[[:space:]]*Port[[:space:]]+[0-9]+/{print $2; exit}' /etc/ssh/sshd_config 2>/dev/null || true)"
fi
SSH_PORT="${SSH_PORT:-22}"
[[ "$SSH_PORT" =~ ^[0-9]+$ ]] || die "Porta SSH detectada é inválida: $SSH_PORT"
log_ok "Porta SSH preservada no UFW: ${SSH_PORT}/tcp"
ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
ufw allow "${SSH_PORT}/tcp" comment 'SSH' >/dev/null 2>&1 || true
ufw allow 'Apache Full' >/dev/null 2>&1 || { ufw allow 80/tcp; ufw allow 443/tcp; }
ufw --force enable >/dev/null
systemctl enable --now fail2ban >/dev/null 2>&1 || true
a2enmod security2 evasive >/dev/null 2>&1 || true
[[ -f /etc/modsecurity/modsecurity.conf-recommended && ! -f /etc/modsecurity/modsecurity.conf ]] && cp /etc/modsecurity/modsecurity.conf-recommended /etc/modsecurity/modsecurity.conf
[[ -f /etc/modsecurity/modsecurity.conf ]] && sed -i 's/^SecRuleEngine .*/SecRuleEngine DetectionOnly/' /etc/modsecurity/modsecurity.conf
apache2ctl configtest && systemctl reload apache2
log_ok "UFW, Fail2ban, ModSecurity e mod_evasive configurados."

if [[ "$SKIP_SSL" != true ]]; then
  ensure_certbot_email
  resolve_domain "$DOMAIN_NAME" || die "$DOMAIN_NAME não resolve no DNS. Crie o registro A/AAAA antes de solicitar SSL."
  INCLUDE_WWW=false
  case "${CERTBOT_INCLUDE_WWW,,}" in
    yes|true|1) resolve_domain "$WWW_DOMAIN" || die "$WWW_DOMAIN não resolve no DNS."; INCLUDE_WWW=true;;
    no|false|0) INCLUDE_WWW=false;;
    auto|'') if resolve_domain "$WWW_DOMAIN"; then INCLUDE_WWW=true; else log_warn "$WWW_DOMAIN sem DNS; certificado será somente para $DOMAIN_NAME."; fi;;
    *) die "CERTBOT_INCLUDE_WWW deve ser auto, yes ou no.";;
  esac

  CERT_ARGS=(--apache -d "$DOMAIN_NAME" --email "$CERTBOT_EMAIL" --agree-tos --no-eff-email --redirect --non-interactive --keep-until-expiring)
  if [[ "$INCLUDE_WWW" == true ]]; then
    # Adiciona ServerAlias antes do Certbot para descoberta correta do vhost.
    sed -i "/ServerName $DOMAIN_NAME/a\\    ServerAlias $WWW_DOMAIN" "$APACHE_CONF"
    apache2ctl configtest && systemctl reload apache2
    CERT_ARGS+=(-d "$WWW_DOMAIN")
  fi
  log_info "Solicitando/renovando certificado Let's Encrypt..."
  certbot "${CERT_ARGS[@]}"
  [[ -s "/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem" ]] || die "Certificado não encontrado após Certbot."
  apache2ctl configtest
  systemctl reload apache2
  systemctl enable --now certbot.timer >/dev/null 2>&1 || true

  log_info "Testando HTTPS local com o certificado real..."
  curl -fsS --resolve "$DOMAIN_NAME:443:127.0.0.1" "https://$DOMAIN_NAME/" | grep -q 'id="root"' || die "Frontend HTTPS não respondeu."
  curl -fsS --resolve "$DOMAIN_NAME:443:127.0.0.1" "https://$DOMAIN_NAME/api/v2/health" | jq -e '.status == "ok"' >/dev/null || die "API HTTPS não respondeu."
  log_ok "HTTPS + API validados."
else
  log_warn "SSL ignorado por --skip-ssl."
fi

cat > /usr/local/bin/goitgods-status <<STATUS
#!/usr/bin/env bash
set -e
printf '=== GOITGODS ===\n'
systemctl --no-pager --full status apache2 | sed -n '1,8p' || true
runuser -u $SYS_USER -- env HOME=$INSTALL_DIR pm2 status
printf '\nAPI local:\n'
curl -fsS http://127.0.0.1:$APP_PORT/api/v2/health || true
printf '\n\nApache:\n'
apache2ctl configtest
printf '\nCertificados:\n'
certbot certificates 2>/dev/null || true
STATUS
chmod 755 /usr/local/bin/goitgods-status

printf '%b\n' "$GREEN"
echo "============================================================================="
echo " GOITGODS 2.3.4 INSTALADO COM SUCESSO"
echo "============================================================================="
printf '%b\n' "$NC"
echo " URL:          https://$DOMAIN_NAME"
echo " Aplicação:    $INSTALL_DIR"
echo " Backend:      127.0.0.1:$APP_PORT (PM2/systemd)"
echo " Apache:       portas 80/443"
echo " Banco:        MariaDB/$DB_NAME"
echo " Node.js:      $(node -v)"
echo " PM2:          $(pm2 -v)"
echo " Diagnóstico:  sudo goitgods-status"
echo " Logs app:     runuser -u $SYS_USER -- env HOME=$INSTALL_DIR pm2 logs goitgods"
echo " Logs Apache:  /var/log/apache2/goitgods_error.log"
echo " Certbot:      /var/log/letsencrypt/letsencrypt.log"
echo "============================================================================="

echo "=== SEGURANÇA GOITGODS ==="; ufw status | head -8; echo "Fail2ban: $(systemctl is-active fail2ban 2>/dev/null || true)"; if [[ "${SUPERADMIN_CREATED:-false}" == true ]]; then echo "SUPER ADMIN: $SUPERADMIN_USER"; echo "SENHA INICIAL: $SUPERADMIN_PASSWORD"; echo "Cópia 0600: /root/goitgods-superadmin-credentials.txt"; fi
