import React, { useState, useEffect } from 'react';
import { Settings, CreditCard, Save, RefreshCw, Smartphone, CheckCircle, Trash2, Edit, Search } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminNFCManager() {
  const [tags, setTags] = useState<any[]>([]);
  const [isActivating, setIsActivating] = useState(false);
  const [userOptions, setUserOptions] = useState<any[]>([]);
  const [searchFilter, setSearchFilter] = useState('');
  
  // States for line-editing
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<any>({});

  useEffect(() => {
    loadTags();
    loadUsers();
  }, []);

  const loadTags = async () => {
    try {
      const res = await fetch('/api/admin/nfc');
      const data = await res.json();
      setTags(data);
    } catch(e) {
      toast.error('Erro ao listar tags NFC');
    }
  };

  const loadUsers = async () => {
    try {
      const res = await fetch('/api/admin/users');
      const data = await res.json();
      setUserOptions(data.filter((u: any) => u.role !== 'super_admin'));
    } catch(e) {
      console.error(e);
    }
  };

  const generateSerial = () => {
    // Generate 16 alphanumeric characters, 4 sequences
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 16; i++) {
      if (i > 0 && i % 4 === 0) result += '-';
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  };

  const handleActivateNfc = async () => {
    setIsActivating(true);
    // Simulate browser Web NFC flow
    if ('NDEFReader' in window) {
      try {
        const ndef = new (window as any).NDEFReader();
        toast('Aproxime a tag NFC do leitor para leitura...', { icon: '📱' });
        await ndef.scan();
        
        ndef.addEventListener("reading", async ({ message, serialNumber }: any) => {
          // 1. Guarda dados em memória ram
          const originalTagId = serialNumber || 'Desconhecido';
          toast.success(`Tag lida com sucesso! ID: ${originalTagId}`);
          
          // 2. Gera serial automaticamente
          const newSerial = generateSerial();
          const activationDateStr = new Date().toISOString();
          
          // 3. Mostra a serial e pergunta se deseja gravar
          const wantRecord = window.confirm(`Serial gerada automaticamente: ${newSerial}\n\nDeseja gravá-la na tag NFC agora?`);
          
          if (wantRecord) {
            // 4. Ativa modo de gravação e mostra mensagem
            toast('Aguardando aproximação da tag no leitor para gravação...', { icon: '🔄', duration: 4000 });
            try {
               // 5. Grava serial na tag
               await ndef.write(`Serial SIAE: ${newSerial} | ${activationDateStr}`);
               
               // 6. Grava no banco de dados imediatamente
               await fetch('/api/admin/nfc', {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify({ serial_number: newSerial, activation_date: activationDateStr })
               });
               toast.success('Serial gravada na Tag e salva no Banco de Dados com sucesso!');
               
               // 7. Refresh da página/listagem
               loadTags();
            } catch (err) {
               toast.error('Erro na gravação. Tag não detectada corretamente.');
            }
          } else {
             toast('Operação de gravação cancelada.');
          }
          setIsActivating(false);
        }, { once: true });
        
      } catch (error) {
        toast.error("Erro no leitor NFC: Verifique permissões do navegador.");
        setIsActivating(false);
      }
    } else {
       // Simulação para ambientes sem hardware nfc
       if (window.confirm("Seu navegador não suporta Web NFC. Deseja iniciar a simulação de leitura da Tag?")) {
           const originalTagId = "TEST-SIMULATION" + Math.floor(Math.random()*1000);
           toast.success(`Simulação: Tag lida! ID: ${originalTagId}`);

           const newSerial = generateSerial();
           const activationDateStr = new Date().toISOString();
           
           const wantRecord = window.confirm(`Simulação: Serial gerada automaticamente: ${newSerial}\n\nDeseja gravá-la simuladamente na tag NFC?`);
           if (wantRecord) {
              toast('Simulação: Aguardando aproximação da tag no leitor para gravação...', { icon: '🔄' });
              setTimeout(async () => {
                await fetch('/api/admin/nfc', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ serial_number: newSerial, activation_date: activationDateStr })
                });
                toast.success('Simulação: Serial gravada na Tag e salva no BD!');
                loadTags();
              }, 1500);
           } else {
              toast('Operação de gravação cancelada.');
           }
       }
       setIsActivating(false);
    }
  };

  const toggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    await fetch(`/api/admin/nfc/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    toast.success(`Status ${newStatus === 'active' ? 'ativado' : 'desativado'} com sucesso.`);
    loadTags();
  };

  const deleteTag = async (id: number) => {
    if (!window.confirm("Deseja realmente remover esta Tag?")) return;
    await fetch(`/api/admin/nfc/${id}`, { method: 'DELETE' });
    toast.success('Tag NFC removida!');
    loadTags();
  };
  
  const startEditing = (tag: any) => {
    setEditingId(tag.id);
    setEditFormData({ 
      serial_number: tag.serial_number || '', 
      user_id: tag.user_id || '' 
    });
  };

  const saveTagEdit = async (id: number) => {
    try {
      const res = await fetch(`/api/admin/nfc/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serial_number: editFormData.serial_number,
          user_id: editFormData.user_id ? Number(editFormData.user_id) : null
        })
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || 'Erro ao atualizar tag NFC');
        return;
      }
      setEditingId(null);
      toast.success('Registro de NFC atualizado com sucesso!');
      loadTags();
    } catch(err: any) {
      toast.error('Erro de conexão ao salvar: ' + err.message);
    }
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditFormData({});
  };

  const filteredTags = tags.filter((tag: any) => {
    if (!searchFilter) return true;
    const s = searchFilter.toLowerCase();
    const fullName = `${tag.first_name || ''} ${tag.last_name || ''}`.toLowerCase();
    const cpf = (tag.cpf || '').toLowerCase();
    const dob = (tag.dob || '').toLowerCase();
    const serial = (tag.serial_number || '').toLowerCase();
    return fullName.includes(s) || cpf.includes(s) || dob.includes(s) || serial.includes(s);
  });

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2"><CreditCard className="w-5 h-5 text-indigo-600"/> Gerenciador de Chaves NFC</h2>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Buscar CPF, Nome, Nasc, Serial..."
              value={searchFilter}
              onChange={e => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          <button 
            onClick={handleActivateNfc}
            disabled={isActivating}
            className={`whitespace-nowrap bg-indigo-600 text-white px-4 py-2 rounded font-medium flex items-center gap-2 hover:bg-indigo-700 ${isActivating ? 'opacity-50' : ''}`}
          >
            <Smartphone className="w-4 h-4" /> Ler e Gerar NFC
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b bg-gray-50">
              <th className="p-3 font-semibold text-gray-700">Serial Master (Tag)</th>
              <th className="p-3 font-semibold text-gray-700">Data Ativação</th>
              <th className="p-3 font-semibold text-gray-700">Atribuir Usuário</th>
              <th className="p-3 font-semibold text-gray-700">Dados do Vínculo</th>
              <th className="p-3 font-semibold text-gray-700">Status</th>
              <th className="p-3 font-semibold text-gray-700 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filteredTags.map((tag: any) => {
              const isEditing = editingId === tag.id;

              return (
                <tr key={tag.id} className="border-b hover:bg-gray-50 transition-colors">
                  <td className="p-3 font-mono text-sm text-indigo-700 font-bold">
                    {isEditing ? (
                      <input 
                        type="text"
                        value={editFormData.serial_number}
                        onChange={(e) => setEditFormData({ ...editFormData, serial_number: e.target.value })}
                        className="border p-1 text-sm rounded w-full font-mono"
                      />
                    ) : (
                      tag.serial_number
                    )}
                  </td>
                  <td className="p-3 text-sm text-gray-600">{new Date(tag.activation_date).toLocaleString()}</td>
                  <td className="p-3">
                    {isEditing ? (
                      <select 
                        className="border rounded p-1 text-sm bg-white w-full"
                        value={editFormData.user_id || ''}
                        onChange={(e) => setEditFormData({ ...editFormData, user_id: e.target.value })}
                      >
                       <option value="">-- Não Associado --</option>
                       {userOptions.map((u: any) => (
                         <option key={u.id} value={u.id}>{u.first_name} {u.last_name} ({u.cpf})</option>
                       ))}
                      </select>
                    ) : (
                      <div className="text-sm">
                        {tag.user_id ? 
                          userOptions.find((u:any) => u.id === tag.user_id)?.first_name + ' ' + userOptions.find((u:any) => u.id === tag.user_id)?.last_name 
                          : 'Não associado'
                        }
                      </div>
                    )}
                  </td>
                  <td className="p-3 text-xs text-gray-500">
                    {tag.user_id && !isEditing ? (
                      <div>
                        <p><strong>Nome:</strong> {tag.first_name} {tag.last_name}</p>
                        <p><strong>CPF:</strong> {tag.cpf}</p>
                        <p><strong>Nasc:</strong> {tag.dob}</p>
                        <p><strong>E-mail:</strong> {tag.email}</p>
                      </div>
                    ) : (
                       <span className="italic text-gray-400">-</span>
                    )}
                  </td>
                  <td className="p-3">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${tag.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {tag.status === 'active' ? 'Ativa' : 'Inativa'}
                    </span>
                  </td>
                  <td className="p-3 flex justify-end gap-2 items-center">
                    {isEditing ? (
                      <>
                        <button onClick={() => saveTagEdit(tag.id)} className="p-1 hover:bg-green-100 text-green-700 rounded" title="Salvar">
                          <Save className="w-5 h-5" />
                        </button>
                        <button onClick={cancelEditing} className="p-1 hover:bg-gray-200 text-gray-700 rounded font-bold text-sm" title="Cancelar">
                          ✕
                        </button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => startEditing(tag)} className="p-1 hover:bg-blue-50 text-blue-600 rounded" title="Editar dados">
                          <Edit className="w-5 h-5" />
                        </button>
                        <button onClick={() => toggleStatus(tag.id, tag.status)} className="p-1 hover:bg-gray-200 rounded" title={tag.status === 'active' ? 'Desativar' : 'Ativar'}>
                          <CheckCircle className={`w-5 h-5 ${tag.status === 'active' ? 'text-green-600' : 'text-gray-400'}`} />
                        </button>
                        <button onClick={() => deleteTag(tag.id)} className="p-1 hover:bg-red-50 text-red-600 rounded" title="Remover">
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              );
            })}
            {filteredTags.length === 0 && (
              <tr>
                <td colSpan={6} className="p-4 text-center text-gray-500">Nenhuma tag NFC encontrada para esta busca.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
