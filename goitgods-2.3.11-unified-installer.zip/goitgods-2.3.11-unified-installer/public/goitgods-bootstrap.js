(function () {
  'use strict';
  var started = Date.now();
  var finished = false;
  var errors = [];

  function text(v) {
    try { return String(v && (v.stack || v.message) || v || 'erro desconhecido'); }
    catch (_) { return 'erro não serializável'; }
  }

  function show(reason) {
    if (finished) return;
    var d = document.getElementById('goitgods-bootstrap-diagnostic');
    var detail = document.getElementById('goitgods-bootstrap-detail');
    if (detail) {
      detail.textContent = reason || errors.join('\n\n') ||
        'O JavaScript principal não confirmou a inicialização dentro do tempo esperado.';
    }
    if (d) d.style.display = 'block';
  }

  window.addEventListener('error', function (e) {
    errors.push('[window.error] ' + text(e.error || e.message) +
      (e.filename ? '\n' + e.filename + ':' + e.lineno + ':' + e.colno : ''));
  }, true);

  window.addEventListener('unhandledrejection', function (e) {
    errors.push('[unhandledrejection] ' + text(e.reason));
  });

  window.GOITGODS_BOOT_OK = function () {
    finished = true;
    window.__GOITGODS_BOOTSTRAPPED__ = true;
    var d = document.getElementById('goitgods-bootstrap-diagnostic');
    if (d) d.remove();
  };

  window.GOITGODS_BOOT_FAIL = function (err) {
    errors.push('[bootstrap] ' + text(err));
    show(errors.join('\n\n'));
  };

  window.addEventListener('DOMContentLoaded', function () {
    setTimeout(function () {
      if (!finished) show(errors.join('\n\n'));
    }, Math.max(0, 10000 - (Date.now() - started)));
  });
})();
