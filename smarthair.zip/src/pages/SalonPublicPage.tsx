import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Scissors, Calendar, MapPin, Clock, Users, Phone } from 'lucide-react';
import Logo from '../components/Logo';

export default function SalonPublicPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [salon, setSalon] = useState<any>(null);
  const [services, setServices] = useState<any[]>([]);
  const [selectedService, setSelectedService] = useState<any>(null);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [employeeId, setEmployeeId] = useState<number | null>(null);
  const [serviceEmployees, setServiceEmployees] = useState<any[]>([]);
  const [availableTimes, setAvailableTimes] = useState<{time: string, employee_id: number}[]>([]);
  const [availableDays, setAvailableDays] = useState<number[]>([]);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
    fetchSalonData();
  }, [id]);

  useEffect(() => {
    if (selectedService) {
      fetchServiceEmployees();
      setEmployeeId(null);
      setDate('');
      setTime('');
    } else {
      setServiceEmployees([]);
      setAvailableDays([]);
    }
  }, [selectedService]);

  useEffect(() => {
    if (selectedService && employeeId) {
      fetchAvailableDays();
      setDate('');
      setTime('');
    } else {
      setAvailableDays([]);
    }
  }, [selectedService, employeeId]);

  useEffect(() => {
    if (date && selectedService && employeeId) {
      // Validate if date is an available day
      const dayOfWeek = new Date(`${date}T00:00:00`).getDay();
      if (availableDays.length > 0 && !availableDays.includes(dayOfWeek)) {
        showToast('Este profissional não atende neste dia da semana para este serviço.', 'error');
        setAvailableTimes([]);
        return;
      }
      fetchAvailableTimes();
    } else {
      setAvailableTimes([]);
      setTime('');
    }
  }, [date, selectedService, employeeId, availableDays]);

  const fetchServiceEmployees = async () => {
    try {
      const res = await fetch(`/api/salons/${id}/services/${selectedService.id}/employees`);
      if (res.ok) {
        const data = await res.json();
        setServiceEmployees(data);
      }
    } catch (error) {
      console.error('Error fetching service employees', error);
    }
  };

  const fetchAvailableDays = async () => {
    try {
      const res = await fetch(`/api/salons/${id}/available-days?service_id=${selectedService.id}&employee_id=${employeeId}`);
      if (res.ok) {
        const days = await res.json();
        setAvailableDays(days);
      }
    } catch (error) {
      console.error('Error fetching available days', error);
    }
  };

  const fetchAvailableTimes = async () => {
    try {
      const res = await fetch(`/api/salons/${id}/available-times?date=${date}&service_id=${selectedService.id}&employee_id=${employeeId}`);
      if (res.ok) {
        const times = await res.json();
        setAvailableTimes(times);
        setTime('');
      }
    } catch (error) {
      console.error('Error fetching available times', error);
    }
  };

  const fetchSalonData = async () => {
    // In a real app, we'd fetch salon details by ID. For now we fetch all and filter.
    const res = await fetch('/api/salons');
    const salons = await res.json();
    const currentSalon = salons.find((s: any) => s.id === Number(id));
    setSalon(currentSalon);

    const srvRes = await fetch(`/api/salons/${id}/services`);
    const allServices = await srvRes.json();
    setServices(allServices.filter((s: any) => s.active === 1));
  };

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      showToast('Você precisa estar logado para agendar.', 'error');
      setTimeout(() => navigate('/login/client'), 2000);
      return;
    }

    if (!selectedService || !date || !time || !employeeId) {
      showToast('Preencha todos os campos.', 'error');
      return;
    }

    if (!agreedToTerms) {
      showToast('Você deve concordar com os termos de agendamento.', 'error');
      return;
    }

    // Calculate 20% deposit (15% salon + 5% platform)
    const total = selectedService.price;
    const deposit = total * 0.20;
    const pending = total - deposit;

    const start_time = `${date}T${time}:00`;
    
    // Calculate end_time
    const [hours, minutes] = time.split(':').map(Number);
    const end_date = new Date(`${date}T${time}:00`);
    end_date.setMinutes(end_date.getMinutes() + selectedService.duration);
    const end_time = `${date}T${end_date.getHours().toString().padStart(2, '0')}:${end_date.getMinutes().toString().padStart(2, '0')}:00`;
    
    // In a real app, we would redirect to Mercado Pago checkout here.
    // For this prototype, we just save the appointment.
    
    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: user.id,
        salon_id: id,
        service_id: selectedService.id,
        employee_id: employeeId,
        start_time,
        end_time,
        paid_amount: deposit,
        pending_amount: pending
      })
    });

    if (res.ok) {
      const { appointmentId } = await res.json();
      
      // Redirect to the transparent checkout page
      window.location.href = `/checkout/${appointmentId}`;
    } else {
      showToast('Erro ao agendar.', 'error');
    }
  };

  const getDayName = (dayIndex: number) => {
    const days = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
    return days[dayIndex];
  };

  if (!salon) return <div className="p-8 text-center">Carregando...</div>;

  return (
    <div className="min-h-screen bg-slate-50">
      {toast && (
        <div className={`fixed top-4 right-4 px-6 py-3 rounded-xl shadow-lg font-medium z-50 transition-all ${
          toast.type === 'success' ? 'bg-cyan-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.message}
        </div>
      )}
      {/* Hero Section */}
      <div className="h-64 bg-slate-800 relative">
        {salon.bg_url ? (
          <img src={salon.bg_url} alt="Capa" className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
        ) : (
          <div className="w-full h-full bg-teal-900/80 flex items-center justify-center">
            <Scissors className="w-16 h-16 text-white/20" />
          </div>
        )}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          {salon.logo_url && (
            <img src={salon.logo_url} alt="Logo" className="h-24 w-24 object-contain mb-4 rounded-full bg-white/10 backdrop-blur-sm p-2" referrerPolicy="no-referrer" />
          )}
          <h1 className="text-4xl font-bold mb-2">{salon.name}</h1>
          <p className="text-lg text-slate-200">{salon.slogan || 'Especialistas em beleza e bem-estar'}</p>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid md:grid-cols-3 gap-8">
        {/* Main Content Area */}
        <div className="md:col-span-2 space-y-10">
          
          {/* About Section */}
          {(salon.about_text || salon.mission_text) && (
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
              {salon.about_text && (
                <div className="mb-8 last:mb-0">
                  <h2 className="text-2xl font-bold text-slate-900 mb-4">Sobre o Estabelecimento</h2>
                  <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">{salon.about_text}</p>
                </div>
              )}
              {salon.mission_text && (
                <div className="mb-8 last:mb-0">
                  <h2 className="text-2xl font-bold text-slate-900 mb-4">Nossa Missão</h2>
                  <p className="text-slate-600 leading-relaxed whitespace-pre-wrap italic">"{salon.mission_text}"</p>
                </div>
              )}
            </div>
          )}

          {/* Services List */}
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Nossos Serviços</h2>
            {Object.entries(services.reduce((acc: Record<string, any[]>, srv: any) => {
              const cat = srv.category || 'Geral';
              if (!acc[cat]) acc[cat] = [];
              acc[cat].push(srv);
              return acc;
            }, {} as Record<string, any[]>)).map(([category, categoryServices]: [string, any[]]) => (
              <div key={category} className="mb-8">
                <h3 className="text-xl font-bold text-slate-800 mb-4 border-b border-slate-200 pb-2">{category}</h3>
                <div className="space-y-4">
                  {categoryServices.map(srv => (
                    <div 
                      key={srv.id} 
                      className={`bg-white p-6 rounded-2xl shadow-sm border cursor-pointer transition-all ${selectedService?.id === srv.id ? 'border-cyan-500 ring-2 ring-cyan-500/20' : 'border-slate-200 hover:border-cyan-300'}`}
                      onClick={() => setSelectedService(srv)}
                    >
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-1">
                          <h4 className="font-bold text-lg text-slate-900">{srv.name}</h4>
                          <p className="text-sm text-slate-500 mt-1">{srv.description || 'Sem descrição'}</p>
                          <div className="flex items-center gap-4 mt-4 text-sm text-slate-600">
                            <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {srv.duration} min</span>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <div className="text-xl font-bold text-cyan-700">
                            R$ {srv.price.toFixed(2)}
                          </div>
                          {srv.photo_url && (
                            <img src={srv.photo_url} alt={srv.name} className="w-20 h-20 object-cover rounded-xl border border-slate-100 shadow-sm" referrerPolicy="no-referrer" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            {services.length === 0 && (
              <div className="text-slate-500 text-center py-8">Nenhum serviço cadastrado.</div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Address Info */}
          {(salon.street || salon.city || salon.phone) && (
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Localização & Contato</h2>
              <div className="text-slate-600 space-y-3 text-sm">
                <div>
                  {salon.street && <p>{salon.street}{salon.number ? `, ${salon.number}` : ''}</p>}
                  {salon.neighborhood && <p>{salon.neighborhood}</p>}
                  {(salon.city || salon.state) && <p>{salon.city}{salon.city && salon.state ? ' - ' : ''}{salon.state}</p>}
                  {salon.country && <p>{salon.country}</p>}
                </div>
                {salon.phone && (
                   <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                     <Phone className="w-4 h-4 text-cyan-600" />
                     <span className="font-medium text-slate-900">{salon.phone}</span>
                   </div>
                )}
              </div>
            </div>
          )}

          {/* Booking Form */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 sticky top-6">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Agendar Horário</h2>
            <form onSubmit={handleBooking} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Serviço Selecionado</label>
                <div className="w-full border border-slate-300 rounded-lg px-3 py-2 bg-slate-50 text-slate-600">
                  {selectedService ? selectedService.name : 'Selecione um serviço ao lado'}
                </div>
              </div>
              
              {selectedService && (
                <>
                  <div className="border-t border-slate-200 pt-4">
                    <label className="block text-sm font-medium text-slate-700 mb-3">Escolha o Profissional</label>
                    <div className="space-y-3">
                      {serviceEmployees.map(emp => (
                        <label key={emp.id} className={`flex items-center gap-4 p-3 rounded-xl border cursor-pointer transition-all ${employeeId === emp.id ? 'border-cyan-500 bg-cyan-50' : 'border-slate-200 hover:border-cyan-200'}`}>
                          <input 
                            type="radio" 
                            name="employee" 
                            checked={employeeId === emp.id} 
                            onChange={() => setEmployeeId(emp.id)}
                            className="w-4 h-4 text-cyan-600 border-slate-300 focus:ring-cyan-500"
                          />
                          <div className="relative group/photo">
                            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-200">
                              {emp.photo_url ? (
                                <img src={emp.photo_url} alt={emp.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              ) : (
                                <Users className="w-6 h-6 text-slate-400" />
                              )}
                            </div>
                            
                            {/* Zoom Hover Card */}
                            <div className="absolute right-full mr-4 top-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white shadow-2xl rounded-3xl z-50 opacity-0 group-hover/photo:opacity-100 transition-all duration-300 pointer-events-none border border-slate-200 overflow-hidden flex flex-col scale-90 group-hover/photo:scale-100 origin-right">
                              <div className="h-[380px] w-full bg-slate-100 flex items-center justify-center overflow-hidden">
                                {emp.photo_url ? (
                                  <img src={emp.photo_url} alt={emp.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                ) : (
                                  <Users className="w-24 h-24 text-slate-300" />
                                )}
                              </div>
                              <div className="p-8 bg-white flex-1 flex flex-col justify-center">
                                <h3 className="text-3xl font-bold text-slate-900 mb-2">{emp.name} {emp.surname}</h3>
                                <p className="text-slate-500 font-medium mb-3">Dias de Atendimento:</p>
                                <div className="flex flex-wrap gap-2">
                                  {emp.workingDays.sort((a: number, b: number) => a - b).map((d: number) => (
                                    <span key={d} className="px-3 py-1.5 bg-cyan-50 text-cyan-700 text-sm font-bold rounded-lg border border-cyan-100 uppercase">
                                      {getDayName(d)}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="flex-1">
                            <p className="font-bold text-slate-900 text-sm">{emp.name} {emp.surname}</p>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {emp.workingDays.sort((a: number, b: number) => a - b).map((d: number) => (
                                <span key={d} className="text-[9px] font-bold uppercase text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                                  {getDayName(d).split('-')[0]}
                                </span>
                              ))}
                            </div>
                          </div>
                        </label>
                      ))}
                      {serviceEmployees.length === 0 && (
                        <p className="text-sm text-slate-500 italic">Nenhum profissional disponível para este serviço.</p>
                      )}
                    </div>
                  </div>

                  {employeeId && (
                    <>
                      <div className="bg-cyan-50 p-3 rounded-xl border border-cyan-100 mt-4">
                        <p className="text-xs font-bold text-teal-800 uppercase tracking-wider mb-2">Dias de Atendimento do Profissional:</p>
                        <div className="flex flex-wrap gap-1">
                          {availableDays.length > 0 ? (
                            availableDays.sort((a, b) => a - b).map(d => (
                              <span key={d} className="px-2 py-1 bg-white text-cyan-700 text-[10px] font-bold rounded-md border border-cyan-200 uppercase">
                                {getDayName(d).split('-')[0]}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-slate-500 italic">Nenhum dia disponível configurado.</span>
                          )}
                        </div>
                      </div>

                      <div className="mt-4">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Data</label>
                        <input 
                          type="date" 
                          required 
                          value={date} 
                          onChange={e => setDate(e.target.value)} 
                          min={new Date().toISOString().split('T')[0]} 
                          className={`w-full border rounded-lg px-3 py-2 focus:ring-cyan-500 focus:border-cyan-500 ${
                            date && availableDays.length > 0 && !availableDays.includes(new Date(`${date}T00:00:00`).getDay()) 
                            ? 'border-red-500 bg-red-50' : 'border-slate-300'
                          }`} 
                        />
                        {date && availableDays.length > 0 && !availableDays.includes(new Date(`${date}T00:00:00`).getDay()) && (
                          <p className="text-xs text-red-600 mt-1 font-medium flex items-center gap-1">
                            <Calendar className="w-3 h-3" /> Este profissional não atende neste dia.
                          </p>
                        )}
                      </div>
                      
                      {date && (
                        <div className="mt-4">
                          <label className="block text-sm font-medium text-slate-700 mb-1">Horário Disponível</label>
                          {availableTimes.length > 0 ? (
                            <div className="grid grid-cols-3 gap-2">
                              {availableTimes.map((slot, idx) => (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => {
                                    setTime(slot.time);
                                  }}
                                  className={`py-2 px-1 text-sm rounded-lg border transition-colors ${
                                    time === slot.time 
                                      ? 'bg-cyan-600 text-white border-cyan-600' 
                                      : 'bg-white text-slate-700 border-slate-300 hover:border-cyan-500'
                                  }`}
                                >
                                  {slot.time}
                                </button>
                              ))}
                            </div>
                          ) : (
                            <div className="text-sm text-slate-500 p-4 bg-slate-100 rounded-xl text-center border border-dashed border-slate-300">
                              <Clock className="w-5 h-5 mx-auto mb-2 opacity-20" />
                              Nenhum horário disponível para esta data.
                            </div>
                          )}
                        </div>
                      )}

                      <div className="mt-6 pt-4 border-t border-slate-200">
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-slate-500">Valor Total</span>
                          <span className="font-medium">R$ {selectedService.price.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-sm mb-4">
                          <span className="text-slate-500">Sinal (20% online)</span>
                          <span className="font-bold text-cyan-700">R$ {(selectedService.price * 0.20).toFixed(2)}</span>
                        </div>

                        <div className="mb-4 p-3 bg-slate-50 rounded-xl border border-slate-200">
                          <label className="flex items-start gap-3 cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={agreedToTerms} 
                              onChange={e => setAgreedToTerms(e.target.checked)}
                              className="mt-1 w-4 h-4 text-cyan-600 border-slate-300 rounded focus:ring-cyan-500"
                            />
                            <span className="text-xs text-slate-600 leading-tight">
                              Concordo em pagar o sinal de 20%. Entendo que o agendamento expira em <b>7 minutos</b> se não pago, e que o sinal <b>não é reembolsável</b> para cancelamentos com menos de 24h de antecedência.
                            </span>
                          </label>
                        </div>

                        <button 
                          type="submit" 
                          disabled={!time || !date || !agreedToTerms || (availableDays.length > 0 && !availableDays.includes(new Date(`${date}T00:00:00`).getDay()))}
                          className="w-full bg-teal-900 text-white rounded-xl px-4 py-3 font-medium hover:bg-teal-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Pagar Sinal e Agendar
                        </button>
                        <p className="text-xs text-slate-400 text-center mt-3">
                          O restante (R$ {(selectedService.price * 0.80).toFixed(2)}) será pago no local.
                        </p>
                      </div>
                    </>
                  )}
                </>
              )}
            </form>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
          <div className="flex items-center gap-2 text-slate-400 mb-4">
            <Logo className="w-6 h-6 grayscale opacity-50" variant="dark" />
            <span className="text-sm font-medium">Powered by Hair Smart Mall</span>
          </div>
          <p className="text-xs text-slate-400 mb-4">© 2026 Hair Smart Mall. Todos os direitos reservados.</p>
          <button 
            type="button"
            onClick={() => {
              const userData = localStorage.getItem('user');
              if (userData) {
                try {
                  const parsedUser = JSON.parse(userData);
                  if (parsedUser.role === 'superadmin') {
                    navigate('/dashboard/admin');
                    return;
                  }
                } catch (e) {}
              }
              navigate('/login/superadmin');
            }}
            className="text-xs font-semibold text-slate-500 hover:text-cyan-600 transition-colors bg-slate-50 hover:bg-slate-100 px-4 py-2 rounded-xl border border-slate-200 flex items-center gap-2"
          >
            🔐 Área Restrita
          </button>
        </div>
      </footer>
    </div>
  );
}
