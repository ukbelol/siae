
import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  Search, 
  BarChart3, 
  Users, 
  Terminal, 
  Globe, 
  Zap, 
  Cpu,
  ShieldCheck,
  Send,
  Loader2,
  ExternalLink,
  ArrowLeft,
  Activity,
  Server,
  Code2,
  Lock,
  ChevronDown,
  Sparkles,
  RefreshCw,
  MessageSquare
} from 'lucide-react';
import { AppSection, Message, Language } from './types';
import { askAboutProject } from './geminiService';
import { translations } from './translations';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.DASHBOARD);
  const [lang, setLang] = useState<Language>('en');
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const t = translations[lang];

  useEffect(() => {
    // Reset welcome message on language change if no chat started
    if (messages.length <= 1) {
      setMessages([{ role: 'model', text: t.investigation.welcome }]);
    }
  }, [lang]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (typeof textToSend === 'string' ? textToSend : inputValue).trim();
    if (!text) return;

    const userMsg = { role: 'user' as const, text };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    const response = await askAboutProject(text, lang);
    setMessages(prev => [...prev, { role: 'model', text: response }]);
    setIsTyping(false);
  };

  const handleResetChat = () => {
    setMessages([{ role: 'model', text: t.investigation.welcome }]);
    setInputValue('');
    setIsTyping(false);
  };

  const renderSection = () => {
    switch (activeSection) {
      case AppSection.DASHBOARD:
        return <DashboardView onNavigate={setActiveSection} t={t} />;
      case AppSection.NODES_DETAIL:
        return <NodesDetailView onBack={() => setActiveSection(AppSection.DASHBOARD)} t={t} />;
      case AppSection.USERS_DETAIL:
        return <UsersDetailView onBack={() => setActiveSection(AppSection.DASHBOARD)} t={t} />;
      case AppSection.UPTIME_DETAIL:
        return <UptimeDetailView onBack={() => setActiveSection(AppSection.DASHBOARD)} t={t} />;
      case AppSection.COMMITS_DETAIL:
        return <CommitsDetailView onBack={() => setActiveSection(AppSection.DASHBOARD)} t={t} />;
      case AppSection.INVESTIGATION:
        return (
          <InvestigationView 
            messages={messages} 
            isTyping={isTyping} 
            inputValue={inputValue} 
            setInputValue={setInputValue} 
            onSendMessage={handleSendMessage}
            onResetChat={handleResetChat}
            t={t} 
          />
        );
      case AppSection.ANALYTICS:
        return <AnalyticsView t={t} />;
      case AppSection.COMMUNITY:
        return <CommunityView />;
      default:
        return <DashboardView onNavigate={setActiveSection} t={t} />;
    }
  };

  const getSectionTitle = () => {
    switch (activeSection) {
      case AppSection.DASHBOARD: return t.common.overview;
      case AppSection.NODES_DETAIL: return t.sections.nodes;
      case AppSection.USERS_DETAIL: return t.sections.users;
      case AppSection.UPTIME_DETAIL: return t.sections.uptime;
      case AppSection.COMMITS_DETAIL: return t.sections.commits;
      case AppSection.INVESTIGATION: return t.sections.investigation;
      case AppSection.ANALYTICS: return t.sections.analytics;
      case AppSection.COMMUNITY: return t.sections.community;
      default: return t.sections.dashboard;
    }
  };

  const languages = [
    { code: 'en', label: 'English' },
    { code: 'fr', label: 'Français' },
    { code: 'es', label: 'Español' },
    { code: 'pt-br', label: 'Português (BR)' }
  ];

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 glass border-r border-slate-800 flex flex-col z-20">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-emerald-500/20 p-2 rounded-lg border border-emerald-500/50">
              <Cpu className="text-emerald-400 w-6 h-6" />
            </div>
            <h1 className="font-bold text-xl tracking-tight gradient-text cursor-pointer" onClick={() => setActiveSection(AppSection.DASHBOARD)}>{t.appName}</h1>
          </div>
          
          <nav className="space-y-2">
            <SidebarItem 
              icon={<LayoutDashboard size={20} />} 
              label={t.sections.dashboard} 
              active={activeSection === AppSection.DASHBOARD || [AppSection.NODES_DETAIL, AppSection.USERS_DETAIL, AppSection.UPTIME_DETAIL, AppSection.COMMITS_DETAIL].includes(activeSection)}
              onClick={() => setActiveSection(AppSection.DASHBOARD)}
            />
            <SidebarItem 
              icon={<Search size={20} className="text-emerald-400" />} 
              label={t.sections.investigation} 
              badge="AI"
              active={activeSection === AppSection.INVESTIGATION}
              onClick={() => setActiveSection(AppSection.INVESTIGATION)}
            />
            <SidebarItem 
              icon={<BarChart3 size={20} />} 
              label={t.sections.analytics} 
              active={activeSection === AppSection.ANALYTICS}
              onClick={() => setActiveSection(AppSection.ANALYTICS)}
            />
            <SidebarItem 
              icon={<Users size={20} />} 
              label={t.sections.community} 
              active={activeSection === AppSection.COMMUNITY}
              onClick={() => setActiveSection(AppSection.COMMUNITY)}
            />
          </nav>
        </div>

        <div className="mt-auto p-6 space-y-4">
          <div className="relative">
            <button 
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="w-full flex items-center justify-between gap-2 p-3 bg-slate-900/50 hover:bg-slate-800/50 border border-slate-800 rounded-xl text-sm transition-colors"
            >
              <div className="flex items-center gap-2">
                <Globe size={16} className="text-blue-400" />
                <span className="font-medium">{languages.find(l => l.code === lang)?.label}</span>
              </div>
              <ChevronDown size={14} className={`text-slate-500 transition-transform ${showLangMenu ? 'rotate-180' : ''}`} />
            </button>
            
            {showLangMenu && (
              <div className="absolute bottom-full left-0 w-full mb-2 glass border border-slate-800 rounded-xl overflow-hidden shadow-2xl animate-in fade-in slide-in-from-bottom-2 duration-200">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code as Language);
                      setShowLangMenu(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-xs hover:bg-slate-800 transition-colors ${lang === l.code ? 'text-emerald-400 bg-emerald-500/5' : 'text-slate-400'}`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
            <p className="text-xs text-slate-500 uppercase font-semibold mb-2">{t.status.label}</p>
            <div className="flex items-center gap-2 text-sm text-emerald-400">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              {t.status.operational}
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto relative p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* Header */}
          <header className="flex justify-between items-start">
            <div className="flex items-center gap-4">
              {[AppSection.NODES_DETAIL, AppSection.USERS_DETAIL, AppSection.UPTIME_DETAIL, AppSection.COMMITS_DETAIL].includes(activeSection) && (
                <button onClick={() => setActiveSection(AppSection.DASHBOARD)} className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white">
                  <ArrowLeft size={20} />
                </button>
              )}
              <div>
                <h2 className="text-3xl font-bold mb-1 tracking-tight">
                  {getSectionTitle()}
                </h2>
                <p className="text-slate-400 text-sm">Monitoring FreeFlow OS 577's global footprint.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <button className="bg-slate-900 hover:bg-slate-800 border border-slate-700 px-4 py-2 rounded-lg text-sm flex items-center gap-2 transition-colors">
                <Globe size={16} /> {t.common.cdn}
              </button>
              <button className="bg-emerald-600 hover:bg-emerald-500 px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-emerald-900/20">
                <Zap size={16} /> {t.common.deploy}
              </button>
            </div>
          </header>

          {renderSection()}

        </div>
      </main>
    </div>
  );
};

// --- View Components ---

const DashboardView: React.FC<{ onNavigate: (section: AppSection) => void, t: any }> = ({ onNavigate, t }) => (
  <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard 
        label={t.common.nodes} 
        value="1,284" 
        trend="+12%" 
        icon={<Cpu className="text-blue-400" />} 
        onClick={() => onNavigate(AppSection.NODES_DETAIL)}
      />
      <StatCard 
        label={t.common.activeUsers} 
        value="84.2k" 
        trend="+5.4%" 
        icon={<Users className="text-emerald-400" />} 
        onClick={() => onNavigate(AppSection.USERS_DETAIL)}
      />
      <StatCard 
        label={t.common.uptime} 
        value="99.99%" 
        trend={t.common.stable} 
        icon={<ShieldCheck className="text-purple-400" />} 
        onClick={() => onNavigate(AppSection.UPTIME_DETAIL)}
      />
      <StatCard 
        label={t.common.commits} 
        value="12,401" 
        trend="+82" 
        icon={<Terminal className="text-amber-400" />} 
        onClick={() => onNavigate(AppSection.COMMITS_DETAIL)}
      />
    </div>
    
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 glass rounded-2xl p-6">
        <h3 className="text-lg font-semibold mb-4">Traffic Heatmap</h3>
        <div className="h-64 bg-slate-900/50 rounded-xl flex items-center justify-center relative overflow-hidden group">
          <img src="https://picsum.photos/800/400?grayscale" alt="Map" className="absolute inset-0 object-cover opacity-20 group-hover:scale-105 transition-transform duration-700" />
          <div className="relative z-10 flex flex-col items-center">
            <Globe className="w-12 h-12 text-slate-700 mb-2" />
            <p className="text-slate-500 text-sm">Visualizing global data flow in real-time</p>
          </div>
        </div>
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="text-lg font-semibold mb-4">Core Components</h3>
        <div className="space-y-4">
          <ComponentBar label="Kernel Engine" percent={92} color="bg-blue-500" />
          <ComponentBar label="Memory Manager" percent={78} color="bg-emerald-500" />
          <ComponentBar label="I/O Scheduler" percent={85} color="bg-purple-500" />
          <ComponentBar label="Network Stack" percent={64} color="bg-amber-500" />
        </div>
      </div>
    </div>
  </div>
);

const NodesDetailView: React.FC<{ onBack: () => void, t: any }> = ({ onBack, t }) => (
  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="glass p-6 rounded-2xl border border-slate-800">
        <h4 className="text-slate-400 text-sm mb-2">{t.nodes.regions}</h4>
        <div className="space-y-3">
          <RegionStat name="North America" count={452} color="bg-blue-400" />
          <RegionStat name="Europe" count={381} color="bg-emerald-400" />
          <RegionStat name="Asia Pacific" count={298} color="bg-amber-400" />
          <RegionStat name="Others" count={153} color="bg-purple-400" />
        </div>
      </div>
      <div className="lg:col-span-2 glass p-6 rounded-2xl border border-slate-800">
        <h4 className="text-slate-400 text-sm mb-4">{t.nodes.distribution}</h4>
        <div className="h-48 flex items-end gap-2 px-2">
          {[40, 65, 55, 80, 70, 95, 100, 85, 90, 110, 120, 130].map((h, i) => (
            <div key={i} className="flex-1 bg-blue-500/20 hover:bg-blue-500/40 transition-colors rounded-t-sm relative group" style={{ height: `${h}%` }}>
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-[10px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                Vol: {h * 10}
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-between mt-4 text-[10px] text-slate-500 uppercase tracking-widest px-2">
          <span>Jan</span><span>Apr</span><span>Jul</span><span>Oct</span><span>Dec</span>
        </div>
      </div>
    </div>
    <div className="glass rounded-2xl overflow-hidden border border-slate-800">
       <div className="p-4 border-b border-slate-800 bg-slate-900/20">
         <h4 className="font-semibold text-sm">{t.nodes.registry}</h4>
       </div>
       <table className="w-full text-sm text-left">
         <thead className="bg-slate-900/50 text-slate-500 uppercase text-[10px] font-bold">
           <tr>
             <th className="px-6 py-3">{t.nodes.id}</th>
             <th className="px-6 py-3">{t.nodes.provider}</th>
             <th className="px-6 py-3">{t.nodes.region}</th>
             <th className="px-6 py-3">{t.nodes.latency}</th>
             <th className="px-6 py-3">{t.nodes.status}</th>
           </tr>
         </thead>
         <tbody className="divide-y divide-slate-800">
           <NodeRow id="ND-8821" provider="AWS" region="us-east-1" latency="12ms" status="online" />
           <NodeRow id="ND-4920" provider="GCP" region="europe-west3" latency="24ms" status="online" />
           <NodeRow id="ND-1104" provider="Azure" region="asia-south1" latency="8ms" status="online" />
           <NodeRow id="ND-2295" provider="DigitalOcean" region="fra1" latency="45ms" status="warning" />
         </tbody>
       </table>
    </div>
  </div>
);

const UsersDetailView: React.FC<{ onBack: () => void, t: any }> = ({ onBack, t }) => (
  <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard label={t.users.monthly} value="84,210" trend="+5.2%" icon={<Users className="text-emerald-400" />} />
      <StatCard label={t.users.signups} value="2,401" trend="+18%" icon={<Activity className="text-blue-400" />} />
      <StatCard label={t.users.churn} value="0.4%" trend="-2%" icon={<ArrowLeft className="text-red-400" />} />
      <StatCard label={t.users.nps} value="78" trend="High" icon={<Zap className="text-amber-400" />} />
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
       <div className="glass p-6 rounded-2xl">
         <h4 className="font-semibold mb-4">{t.users.breakdown}</h4>
         <div className="space-y-6">
           <ComponentBar label="Enterprise" percent={24} color="bg-blue-500" />
           <ComponentBar label="Open Source Developers" percent={58} color="bg-emerald-500" />
           <ComponentBar label="Academic/Research" percent={12} color="bg-purple-500" />
           <ComponentBar label="Hobbyists" percent={6} color="bg-slate-500" />
         </div>
       </div>
       <div className="glass p-6 rounded-2xl flex flex-col items-center justify-center text-center">
         <Users size={48} className="text-emerald-500/20 mb-4" />
         <h4 className="text-lg font-semibold">{t.users.growth}</h4>
         <p className="text-slate-400 text-sm mt-2 max-w-xs">{t.users.growthDesc}</p>
       </div>
    </div>
  </div>
);

const UptimeDetailView: React.FC<{ onBack: () => void, t: any }> = ({ onBack, t }) => (
  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
    <div className="glass p-8 rounded-2xl text-center border border-slate-800 bg-gradient-to-b from-slate-900/50 to-transparent">
       <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-500/20">
         <ShieldCheck size={40} className="text-emerald-400" />
       </div>
       <h3 className="text-4xl font-bold mb-2">99.998%</h3>
       <p className="text-slate-400">Total System Uptime (Last 30 Days)</p>
       <div className="flex justify-center gap-1 mt-8">
         {Array.from({length: 40}).map((_, i) => (
           <div key={i} className={`h-8 w-1.5 rounded-full ${i === 28 ? 'bg-amber-500/50' : 'bg-emerald-500/50'}`} title={`Day ${i+1}: Operational`} />
         ))}
       </div>
    </div>
  </div>
);

const CommitsDetailView: React.FC<{ onBack: () => void, t: any }> = ({ onBack, t }) => (
  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="glass p-6 rounded-2xl flex flex-col items-center">
        <Code2 size={32} className="text-amber-400 mb-2" />
        <span className="text-2xl font-bold">12,401</span>
        <span className="text-xs text-slate-500 uppercase font-bold">{t.common.commits}</span>
      </div>
      <div className="glass p-6 rounded-2xl flex flex-col items-center">
        <Users size={32} className="text-blue-400 mb-2" />
        <span className="text-2xl font-bold">184</span>
        <span className="text-xs text-slate-500 uppercase font-bold">Contributors</span>
      </div>
      <div className="glass p-6 rounded-2xl flex flex-col items-center">
        <Zap size={32} className="text-emerald-400 mb-2" />
        <span className="text-2xl font-bold">1.2m</span>
        <span className="text-xs text-slate-500 uppercase font-bold">Lines of Code</span>
      </div>
    </div>
  </div>
);

const InvestigationView: React.FC<{ 
  messages: Message[], 
  isTyping: boolean, 
  inputValue: string, 
  setInputValue: (v: string) => void, 
  onSendMessage: (text?: string) => void, 
  onResetChat: () => void,
  t: any 
}> = ({ messages, isTyping, inputValue, setInputValue, onSendMessage, onResetChat, t }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const suggestedPrompts = [
    t.investigation.prompt1 || 'Why did Google feature FreeFlow OS 577 in their developer showcase?',
    t.investigation.prompt2 || 'What architectural innovations make our OS kernel unique?',
    t.investigation.prompt3 || 'How does our benchmark performance compare with modern microkernels?'
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="lg:col-span-2 space-y-4">
        {/* Terminal Card */}
        <div className="glass rounded-2xl h-[560px] flex flex-col border border-slate-800 shadow-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
            <span className="text-sm font-medium text-slate-300 flex items-center gap-2">
              <Terminal size={16} className="text-emerald-400" /> {t.investigation.terminal}
            </span>
            <div className="flex items-center gap-3">
              <button 
                onClick={onResetChat}
                title="Reset session"
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 px-2 py-1 rounded-md hover:bg-slate-800/80 transition-colors"
              >
                <RefreshCw size={12} />
                <span>Reset</span>
              </button>
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/40 border border-red-500/30" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/40 border border-yellow-500/30" />
                <div className="w-3 h-3 rounded-full bg-green-500/40 border border-green-500/30" />
              </div>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl shadow-sm ${
                  m.role === 'user' 
                    ? 'bg-emerald-600 text-white rounded-br-none' 
                    : 'bg-slate-900/90 text-slate-200 rounded-bl-none border border-slate-800'
                }`}>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-slate-900/90 p-4 rounded-2xl rounded-bl-none border border-slate-800 flex items-center gap-3">
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                  <span className="text-sm text-slate-300 font-mono">{t.investigation.processing}</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Prompt input */}
          <div className="p-4 border-t border-slate-800 bg-slate-900/30">
            <div className="relative flex items-center">
              <input 
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    onSendMessage();
                  }
                }}
                placeholder={t.investigation.placeholder}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition-all pr-12 text-slate-100 placeholder:text-slate-500"
              />
              <button 
                onClick={() => onSendMessage()}
                disabled={!inputValue.trim() || isTyping}
                className="absolute right-2 p-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:hover:bg-emerald-600 rounded-lg transition-colors text-white"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>

        {/* Suggested Quick Inquiries */}
        <div className="glass p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase text-slate-400">
            <Sparkles size={14} className="text-emerald-400" />
            <span>{t.investigation.promptsTitle || 'Suggested Inquiries'}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestedPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => onSendMessage(prompt)}
                disabled={isTyping}
                className="text-left text-xs bg-slate-900/60 hover:bg-slate-800/80 hover:text-emerald-300 border border-slate-800 hover:border-emerald-500/30 text-slate-300 px-3 py-2 rounded-xl transition-all disabled:opacity-50 flex items-center gap-2"
              >
                <MessageSquare size={12} className="text-emerald-400 flex-shrink-0" />
                <span>{prompt}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Side evidence cards */}
      <div className="space-y-6">
        <div className="glass p-6 rounded-2xl border border-slate-800">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <ShieldCheck className="text-emerald-400" /> {t.investigation.evidence}
          </h3>
          <div className="space-y-4">
            <EvidenceCard title="Google I/O 2024" subtitle="Keynote Showcase" tags={['Kernel', 'Distributed']} />
            <EvidenceCard title="Google Cloud Next" subtitle="Infrastructure Spotlight" tags={['Cloud', 'IPC']} />
            <EvidenceCard title="Android Open Source" subtitle="Architecture Review" tags={['Microkernel', 'OS']} />
          </div>
        </div>
        
        <div className="glass p-6 rounded-2xl border border-slate-800 bg-gradient-to-br from-blue-600/10 to-emerald-600/10">
          <h3 className="font-semibold mb-2">{t.investigation.impact}</h3>
          <div className="text-4xl font-bold text-emerald-400 mb-4 tracking-tighter">98.4</div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full w-[98%] shadow-[0_0_12px_rgba(16,185,129,0.5)]" />
          </div>
          <p className="text-xs text-slate-400 mt-2">{t.investigation.impactDesc}</p>
        </div>
      </div>
    </div>
  );
};

const AnalyticsView: React.FC<{ t: any }> = ({ t }) => (
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="glass rounded-2xl p-6 h-[400px] flex flex-col justify-center items-center">
      <BarChart3 size={48} className="text-slate-800 mb-4" />
      <p className="text-slate-400 font-medium tracking-tight">{t.common.loading}</p>
    </div>
    <div className="glass rounded-2xl p-6 h-[400px] flex flex-col justify-center items-center">
      <Zap size={48} className="text-slate-800 mb-4" />
      <p className="text-slate-400 font-medium tracking-tight">{t.common.loading}</p>
    </div>
  </div>
);

const CommunityView = () => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    {[1,2,3,4,5,6].map(i => (
      <div key={i} className="glass p-6 rounded-2xl border border-slate-800 hover:border-emerald-500/50 transition-all hover:-translate-y-1 group">
        <img src={`https://picsum.photos/seed/${i + 10}/40/40`} className="w-12 h-12 rounded-full mb-4 border-2 border-slate-700 group-hover:border-emerald-500 transition-colors" />
        <h4 className="font-semibold text-lg">Contributor #{i}00</h4>
        <div className="flex gap-2">
          <span className="text-[10px] uppercase font-bold px-2 py-1 bg-slate-800 rounded border border-slate-700">Lead</span>
        </div>
      </div>
    ))}
  </div>
);

// --- UI Helper Components ---

const SidebarItem: React.FC<{ 
  icon: React.ReactNode, 
  label: string, 
  active: boolean, 
  badge?: string,
  onClick: () => void 
}> = ({ icon, label, active, badge, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group ${
      active 
        ? 'bg-emerald-600/15 text-emerald-400 border border-emerald-500/30 shadow-sm shadow-emerald-950/40 font-semibold' 
        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50'
    }`}
  >
    <div className="flex items-center gap-3">
      {icon}
      <span className="font-medium whitespace-nowrap overflow-hidden text-ellipsis">{label}</span>
    </div>
    {badge && (
      <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono uppercase tracking-wider ${
        active ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400 group-hover:text-slate-200'
      }`}>
        {badge}
      </span>
    )}
  </button>
);

const StatCard: React.FC<{ label: string, value: string, trend: string, icon: React.ReactNode, onClick?: () => void }> = ({ label, value, trend, icon, onClick }) => (
  <div 
    onClick={onClick}
    className={`glass p-6 rounded-2xl border border-slate-800 transition-all duration-300 group ${onClick ? 'cursor-pointer hover:border-emerald-500/30 hover:bg-slate-900/40 hover:-translate-y-1 active:scale-95' : ''}`}
  >
    <div className="flex justify-between items-start mb-4">
      <div className={`p-2 bg-slate-900 rounded-lg group-hover:scale-110 transition-transform ${onClick ? 'group-hover:bg-slate-800' : ''}`}>{icon}</div>
      <span className={`text-xs font-bold px-2 py-1 rounded-full ${
        trend.startsWith('+') ? 'bg-emerald-500/10 text-emerald-400' : 
        ['Stable', 'Estable', 'Stable', 'Estável'].includes(trend) ? 'bg-blue-500/10 text-blue-400' : 'bg-slate-800 text-slate-400'
      }`}>
        {trend}
      </span>
    </div>
    <p className="text-slate-400 text-sm mb-1">{label}</p>
    <div className="flex items-end justify-between">
      <h3 className="text-2xl font-bold tracking-tight">{value}</h3>
      {onClick && <ArrowLeft size={16} className="rotate-180 text-slate-600 group-hover:text-emerald-400 transition-colors" />}
    </div>
  </div>
);

const RegionStat: React.FC<{ name: string, count: number, color: string }> = ({ name, count, color }) => (
  <div className="flex items-center justify-between group">
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${color}`} />
      <span className="text-sm text-slate-300">{name}</span>
    </div>
    <span className="text-xs font-mono text-slate-500">{count} nodes</span>
  </div>
);

const NodeRow: React.FC<{ id: string, provider: string, region: string, latency: string, status: string }> = ({ id, provider, region, latency, status }) => (
  <tr className="hover:bg-slate-900/30 transition-colors">
    <td className="px-6 py-4 font-mono text-xs text-blue-400">{id}</td>
    <td className="px-6 py-4">{provider}</td>
    <td className="px-6 py-4 text-slate-400">{region}</td>
    <td className="px-6 py-4 font-mono text-xs">{latency}</td>
    <td className="px-6 py-4">
      <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
        status === 'online' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
      }`}>
        <div className={`w-1.5 h-1.5 rounded-full ${status === 'online' ? 'bg-emerald-400' : 'bg-amber-400'} animate-pulse`} />
        {status}
      </span>
    </td>
  </tr>
);

const EvidenceCard: React.FC<{ title: string, subtitle: string, tags: string[] }> = ({ title, subtitle, tags }) => (
  <div className="p-4 bg-slate-900/40 rounded-xl border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group hover:-translate-x-1">
    <div className="flex justify-between items-start mb-1">
      <h4 className="font-medium group-hover:text-emerald-400 transition-colors">{title}</h4>
      <ExternalLink size={14} className="text-slate-500 group-hover:text-slate-300 transition-colors" />
    </div>
    <p className="text-xs text-slate-400 mb-3">{subtitle}</p>
    <div className="flex gap-2">
      {tags.map(t => (
        <span key={t} className="text-[9px] px-2 py-0.5 bg-slate-800 rounded-md text-slate-300 font-mono border border-slate-700/50">
          {t}
        </span>
      ))}
    </div>
  </div>
);

const ComponentBar: React.FC<{ label: string, percent: number, color: string }> = ({ label, percent, color }) => (
  <div className="space-y-1.5">
    <div className="flex justify-between text-xs">
      <span className="text-slate-400 font-medium">{label}</span>
      <span className="text-slate-200 font-mono">{percent}%</span>
    </div>
    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
      <div className={`${color} h-full transition-all duration-1000 shadow-[0_0_8px_rgba(255,255,255,0.1)]`} style={{ width: `${percent}%` }} />
    </div>
  </div>
);

export default App;
