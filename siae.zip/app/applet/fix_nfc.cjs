const fs = require('fs');
let file = 'src/pages/NfcReader.tsx';
let t = fs.readFileSync(file, 'utf8');

t = t.replace(
  "const [error, setError] = useState('');",
  "const [error, setError] = useState('');\n  const [currentTreatmentPlan, setCurrentTreatmentPlan] = useState<any>(null);"
);

t = t.replace(
  ".then(data => setWorkerActive(data));",
  ".then(data => { setWorkerActive(data); if (data && data.assisted_id) { fetch(`/api/assisted/${data.assisted_id}/treatment-plan`).then(r => r.json()).then(plan => setCurrentTreatmentPlan(plan)); } });"
);

let beforeUI = `                      <p className="text-gray-300">Ficha N°: <span className="text-white font-bold">{workerActive.ticket_number}</span></p>
                    </div>`;
let afterUI = `                      <p className="text-gray-300">Ficha N°: <span className="text-white font-bold">{workerActive.ticket_number}</span></p>
                    </div>
                    {currentTreatmentPlan && currentTreatmentPlan.treatments && (
                       <div className="mt-4 bg-gray-800 p-4 rounded-xl border border-gray-700">
                          <h3 className="font-bold text-white mb-2 text-sm">{currentTreatmentPlan.title}</h3>
                          <table className="w-full text-left text-xs">
                            <thead>
                              <tr className="text-gray-400 border-b border-gray-700">
                                <th className="pb-2">Tipo</th>
                                <th className="pb-2 text-center">Progresso</th>
                              </tr>
                            </thead>
                            <tbody>
                              {currentTreatmentPlan.treatments.map((t: any, i:number) => {
                                const pend = Math.max(0, t.totalSessions - t.completedSessions);
                                return (
                                <tr key={i} className="border-b border-gray-700">
                                  <td className="py-2 text-gray-200">{t.typeName}</td>
                                  <td className="py-2 text-center text-emerald-400">{t.completedSessions} / {t.totalSessions}</td>
                                </tr>
                                )
                              })}
                            </tbody>
                          </table>
                       </div>
                    )}`;

t = t.replace(beforeUI, afterUI);
fs.writeFileSync(file, t);
console.log('NfcReader Updated');
