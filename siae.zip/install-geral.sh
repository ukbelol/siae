#!/bin/bash
# ==============================================================================
# Script de Instalação Geral Unificado - SIAE (SIAE Meet Autônomo e Integrado)
# ==============================================================================
# Sistema Autônomo de Videoconferência e Atendimento Espírita baseados em WebRTC.
# Recursos Integrados:
# - Painel Super Admin Unificado com edição e alteração de NFCs integradas à segurança do banco.
# - Monitor de Senhas em Tela Única 16:9 via Tabela Matricial de agrupamento dinâmico com
#   salas de atendimento individuais, exibindo senha chamada, nome e sala na coluna
#   da assistência, seguido pelas próximas 7 senhas em fila.
# - Sala de Videoconferência com efeito espelho e cartões integrados (foto, cidade, telefone).
# - Módulo NFC Inteligente no terminal com de-duplicação de cache (5s) impedindo disparos
#   múltiplos na aproximação, e validação rígida de apenas uma tag ativa por CPF/usuário.
#
# DOMÍNIOS QUE DEVEM SER APONTADOS NO SEU DNS (Tipo A e/ou AAAA - IPv6 agora é ativado automaticamente):
# 1. app.siae.space           -> IP da sua VPS (Principal: SIAE) - Use registro tipo A (IPv4) e/ou AAAA (IPv6)
# ==============================================================================

set -e

# Cores para Saída Elegante
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

echo -e "${CYAN}=====================================================================${NC}"
echo -e "${CYAN}        SIAE MEET AUTÔNOMO: INSTALADOR E CONFIGURADOR COESO V3       ${NC}"
echo -e "${CYAN}=====================================================================${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}ERRO: Por favor, execute este script como root (sudo).${NC}"
  exit 1
fi

DOMAIN="app.siae.space"
EMAIL="rogermei577@gmail.com"
APP_DIR="/var/www/siae"

# Parâmetros customizáveis do Banco de Dados e API do Google Gemini para VPS
DB_HOST="localhost"
DB_USER="siae_user"
DB_PASSWORD="siae_password"
DB_NAME="siae_db"
GEMINI_API_KEY="" # Chave opcional do Google Gemini para inteligência artificial se desejar habilitar resumos/sugestões

# ==============================================================================
# ETAPA 1: COMPLETAR DESINSTALAÇÃO DOS SISTEMAS ANTERIORES E CONFIGURAÇÃO FIREWALL
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 1 - LIMPEZA & FIREWALL] Removendo sistemas legados (Openfire/Jitsi/OpenMeetings)...${NC}"

# Pausando e expurgando serviços antigos
systemctl stop openfire 2>/dev/null || true
systemctl disable openfire 2>/dev/null || true
systemctl stop jitsi-videobridge2 2>/dev/null || true
systemctl stop jicofo 2>/dev/null || true
systemctl stop prosody 2>/dev/null || true
systemctl stop openmeetings 2>/dev/null || true
docker stop kms 2>/dev/null || true
docker rm kms 2>/dev/null || true

# Expurgando totalmente pacotes antigos ddo sistema
DEBIAN_FRONTEND=noninteractive apt-get purge -y openfire jitsi-meet jitsi-meet-web jitsi-meet-web-config jitsi-meet-prosody jicofo prosody || true
apt-get autoremove -y || true

# Limpando diretórios residuais dos antigos sistemas de videoconferência para assegurar a coesão do sistema
rm -rf /etc/openfire /var/lib/openfire /var/log/openfire /usr/share/openfire || true
rm -rf /etc/jitsi /var/log/jitsi /etc/prosody /var/lib/prosody || true
rm -rf /opt/openmeetings /opt/mirotalk-sfu || true

# Configura regras estritas de firewall: abre somente portas Web Seguras 80/443 e TURN/STUN para WebRTC
if command -v ufw >/dev/null; then
    echo -e "${YELLOW}-> Ativando portas seguras no firewall UFW...${NC}"
    ufw allow 80/tcp || true
    ufw allow 443/tcp || true
    # Limpando portas legadas do Jitsi/Openfire para evitar frestas de segurança na VPS
    ufw delete allow 7070/tcp 2>/dev/null || true
    ufw delete allow 7443/tcp 2>/dev/null || true
    ufw delete allow 9090/tcp 2>/dev/null || true
    ufw delete allow 9091/tcp 2>/dev/null || true
    ufw delete allow 5222/tcp 2>/dev/null || true
    ufw delete allow 5223/tcp 2>/dev/null || true
    ufw delete allow 5080/tcp 2>/dev/null || true
    ufw reload || true
fi

# Removendo conflitos de porta do Nginx
systemctl stop nginx 2>/dev/null || true
systemctl disable nginx 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get purge -y nginx nginx-common || true

# ==============================================================================
# ETAPA 1.5: CONFIGURAÇÃO E ATIVAÇÃO DE IPV6 EXTERNO NA VPS
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 1.5 - IPV6 CONFIG] Configurando e Ativando IPv6 Externo na VPS...${NC}"

# 1. Habilitar IPv6 no Kernel via Sysctl
echo -e "${YELLOW}-> Ativando processamento IPv6 no Kernel...${NC}"
cat <<EOF > /etc/sysctl.d/99-ipv6-siae.conf
net.ipv6.conf.all.disable_ipv6 = 0
net.ipv6.conf.default.disable_ipv6 = 0
net.ipv6.conf.lo.disable_ipv6 = 0
net.ipv6.conf.all.accept_ra = 2
net.ipv6.conf.default.accept_ra = 2
EOF
sysctl -p /etc/sysctl.d/99-ipv6-siae.conf || true

# 2. Detectar interface de rede principal
IP_INTERFACE=$(ip -4 route show | grep default | awk '{print $5}' | head -n 1)
if [ -z "$IP_INTERFACE" ]; then
    IP_INTERFACE=$(ip link show | grep -E '^[0-9]' | awk -F: '{print $2}' | tr -d ' ' | grep -v 'lo' | head -n 1)
fi

echo -e "${YELLOW}-> Interface de rede principal detectada: ${IP_INTERFACE}${NC}"

# 3. Forçar ativação de IPv6 para a interface de rede principal
if [ -n "$IP_INTERFACE" ]; then
    echo -e "${YELLOW}-> Solicitando autoconfiguração IPv6 (SLAAC) e DHCPv6 para ${IP_INTERFACE}...${NC}"
    ip link set dev $IP_INTERFACE up || true
    
    # Se dhclient estiver disponível, tentar solicitar IPv6 sem bloquear o script de instalação
    if command -v dhclient >/dev/null; then
        echo -e "${YELLOW}-> Solicitando concessão IPv6 de forma não-bloqueante...${NC}"
        if command -v timeout >/dev/null; then
            timeout 10 dhclient -6 -1 -v $IP_INTERFACE >/dev/null 2>&1 || true
        else
            dhclient -6 -nw $IP_INTERFACE >/dev/null 2>&1 || true
        fi
    fi

    # Configuração de interface no estilo Debian tradicional se /etc/network/interfaces existir
    if [ -f "/etc/network/interfaces" ]; then
        if ! grep -q "inet6" /etc/network/interfaces; then
            echo -e "${YELLOW}-> Atualizando /etc/network/interfaces para auto-configurar IPv6...${NC}"
            cat <<EOF >> /etc/network/interfaces

# Configuração Automática de IPv6 inserida pelo SIAE Meet
iface ${IP_INTERFACE} inet6 auto
EOF
            systemctl restart networking || true
        fi
    fi

    # Configuração de Netplan se detectada (comum em Ubuntu)
    if command -v netplan >/dev/null && [ -d "/etc/netplan" ]; then
        echo -e "${YELLOW}-> Netplan detectado. Ajustando arquivos yaml para ativar IPv6...${NC}"
        for netplan_file in /etc/netplan/*.yaml; do
            if [ -f "$netplan_file" ]; then
                if ! grep -q "dhcp6:" "$netplan_file"; then
                    sed -i "s/dhcp4: true/dhcp4: true\n      dhcp6: true\n      accept-ra: true/g" "$netplan_file" || true
                fi
            fi
        done
        netplan apply || true
    fi
fi

# 4. Ajustar regras de Firewall UFW se UFW estiver ativo para permitir conexões IPv6
if command -v ufw >/dev/null; then
    echo -e "${YELLOW}-> Garantindo que o firewall UFW permite tráfego IPv6...${NC}"
    if [ -f "/etc/default/ufw" ]; then
        sed -i 's/IPV6=no/IPV6=yes/g' /etc/default/ufw || true
    fi
    ufw allow proto tcp from any to any port 80 || true
    ufw allow proto tcp from any to any port 443 || true
    ufw reload || true
fi

# 5. Validar se o IPv6 externo está ativo
IPV6_EXTERNO=$(ip -6 addr show dev "$IP_INTERFACE" | grep -v "fe80" | grep "global" | awk '{print $2}' | cut -d'/' -f1 | head -n 1)
if [ -z "$IPV6_EXTERNO" ]; then
    echo -e "${YELLOW}! Não foi detectado IPv6 global automático na interface ${IP_INTERFACE}.${NC}"
    echo -e "${YELLOW}Tentando forçar a habilitação de IPv6 na interface via ip command...${NC}"
    ip -6 addr add ::1/128 dev lo 2>/dev/null || true
    sysctl -w net.ipv6.conf."$IP_INTERFACE".accept_ra=2 || true
    sysctl -w net.ipv6.conf."$IP_INTERFACE".autoconf=1 || true
    
    sleep 3
    IPV6_EXTERNO=$(ip -6 addr show dev "$IP_INTERFACE" | grep -v "fe80" | grep "global" | awk '{print $2}' | cut -d'/' -f1 | head -n 1)
fi

if [ -n "$IPV6_EXTERNO" ]; then
    echo -e "${GREEN}✓ IPv6 Externo Ativo com Sucesso: ${IPV6_EXTERNO}${NC}"
    
    echo -e "\n${CYAN}[PERGUNTA] Configuração de DNS para IPv6:${NC}"
    read -p "Você já apontou o domínio $DOMAIN para o IPv6 $IPV6_EXTERNO na entrada AAAA do seu DNS? (s/n): " RES_AAAA
    if [[ "$RES_AAAA" =~ ^[sS] ]]; then
        echo -e "${GREEN}✓ Confirmado! Continuando com a instalação...${NC}"
    else
        echo -e "${YELLOW}[!] Aguardando apontamento do IPv6...${NC}"
        echo -e "${YELLOW}Por favor, acesse o painel do seu domínio e crie uma entrada AAAA para ${DOMAIN} apontando para o IPv6: ${IPV6_EXTERNO}${NC}"
        read -p "Após criar a entrada AAAA, pressione [ENTER] para continuar a instalação..."
    fi
else
    echo -e "${YELLOW}Aviso: IPv6 externo não pôde ser ativado automaticamente.${NC}"
    echo -e "${YELLOW}Se o seu provedor de VPS exige configuração estática de IPv6, configure-o em seu painel e reinicie o script.${NC}"
fi

# ==============================================================================
# ETAPA 2: INSTALAÇÃO DO APACHE, NODE.JS E DEPENDÊNCIAS
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 2 - DEPENDÊNCIAS] Instalando Apache Web Server, utilitários e Openssl...${NC}"

apt-get update
apt-get install -y mariadb-server apache2 certbot python3-certbot-apache build-essential git psmisc net-tools curl wget unzip openssl

# Habilitando os módulos necessários do Apache para Proxy reverso WebRTC e WebSocket
a2enmod proxy || true
a2enmod proxy_http || true
a2enmod proxy_wstunnel || true
a2enmod rewrite || true
a2enmod ssl || true
a2enmod headers || true

systemctl unmask apache2 || true
systemctl enable apache2 || true
systemctl start apache2 || true

# ==============================================================================
# ETAPA 3: SOLICITAÇÃO DOS CERTIFICADOS SSL VÁLIDOS (LET'S ENCRYPT)
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 3 - CERTIFICADOS SSL] Gerando Certificado SSL Let's Encrypt Válido...${NC}"

# Garantir que portas estejam livres de outros servidores como Nginx
echo -e "${YELLOW}-> Parando possíveis conflitos com Nginx...${NC}"
systemctl stop nginx 2>/dev/null || true
systemctl disable nginx 2>/dev/null || true
killall -9 nginx 2>/dev/null || true

# Criação de um Virtual Host básico de porta 80 para validação HTTP do Let's Encrypt
echo -e "${YELLOW}-> Criando Virtual Host temporário para validação do domínio...${NC}"
mkdir -p /var/www/html
cat <<EOF > /etc/apache2/sites-available/siae.conf
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    DocumentRoot /var/www/html
</VirtualHost>
EOF

# Desativar sites padrão e ativar temporariamente o siae.conf
a2dissite 000-default.conf || true
a2dissite default-ssl.conf || true
a2ensite siae.conf || true

# Reiniciar Apache para carregar a configuração da porta 80
echo -e "${YELLOW}-> Reiniciando Apache para validação HTTP do Let's Encrypt...${NC}"
systemctl restart apache2 || true

echo -e "${YELLOW}-> Solicitando certificado Let's Encrypt para o domínio ${DOMAIN}...${NC}"
SSL_DIR_MAIN=""

# Tentamos obter via plugin do Apache primeiro (extremamente confiável quando a porta 80 está rodando)
if certbot certonly --apache -d ${DOMAIN} --non-interactive --agree-tos -m ${EMAIL} --keep-until-expiring; then
    echo -e "${GREEN}Sucesso! Certificado Let's Encrypt obtido via plugin Apache.${NC}"
    SSL_DIR_MAIN="${DOMAIN}"
else
    echo -e "${YELLOW}-> Falha na validação via Apache. Parando o Apache e tentando standalone...${NC}"
    systemctl stop apache2 || true
    if command -v fuser >/dev/null; then
        fuser -k 80/tcp 2>/dev/null || true
        fuser -k 443/tcp 2>/dev/null || true
    fi
    
    # Se houver IPv6 ativo, permitimos que o certbot escute em todas as interfaces. Caso contrário, limitamos ao IPv4.
    if [ -n "$IPV6_EXTERNO" ]; then
        CERTBOT_BIND_OPTS=""
    else
        CERTBOT_BIND_OPTS="--http-01-address 0.0.0.0"
    fi
    
    if certbot certonly --standalone $CERTBOT_BIND_OPTS -d ${DOMAIN} --non-interactive --agree-tos -m ${EMAIL} --keep-until-expiring; then
        echo -e "${GREEN}Sucesso! Certificado Let's Encrypt obtido via standalone.${NC}"
        SSL_DIR_MAIN="${DOMAIN}"
    else
        echo -e "${RED}ERRO CRÍTICO: Não foi possível obter o certificado SSL Let's Encrypt para ${DOMAIN}.${NC}"
        echo -e "${RED}Certifique-se de que o domínio está corretamente apontado para o IP desta VPS e tente novamente.${NC}"
        exit 1
    fi
    systemctl start apache2 || true
fi

# ==============================================================================
# ETAPA 4: INICIALIZAÇÃO DA APLICAÇÃO SIAE COM O NOVO SISTEMA AUTÔNOMO MEET
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 4 - BACKEND & FRONTEND] Preparando o Servidor de Sinalização e Frontend...${NC}"

# 4.1 Iniciar MariaDB
systemctl start mariadb || true
systemctl enable mariadb || true

# Criação das Tabelas do banco SIAE com parâmetros customizáveis
echo -e "${YELLOW}-> Configurando o Banco de Dados MariaDB (${DB_NAME})...${NC}"
mysql -uroot -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8 COLLATE utf8_general_ci;"
mysql -uroot -e "GRANT ALL ON ${DB_NAME}.* TO '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';"
mysql -uroot -e "FLUSH PRIVILEGES;"

# 4.2 Configurando Node.js v22
echo -e "${YELLOW}-> Instalando/Atualizando para Node.js v22 e npm mais recente...${NC}"
apt-get install -y curl gnupg || true
rm -f /etc/apt/sources.list.d/nodesource.list || true
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

# Confirmar versões instaladas
echo -e "${GREEN}Node.js versão: $(node -v)${NC}"
echo -e "${GREEN}npm versão: $(npm -v)${NC}"

# 4.3 Movendo arquivos e compilando frontend
mkdir -p ${APP_DIR}
cp -r ./* ${APP_DIR}/ 2>/dev/null || true
cp -r ./.[!.]* ${APP_DIR}/ 2>/dev/null || true
cd ${APP_DIR}

# Criação do arquivo .env configurado automaticamente para o ambiente de produção da VPS
echo -e "${YELLOW}-> Criando o arquivo de variáveis de ambiente (.env) na VPS...${NC}"
cat <<EOF > .env
PORT=3000
NODE_ENV=production
DB_HOST=${DB_HOST}
DB_USER=${DB_USER}
DB_PASSWORD=${DB_PASSWORD}
DB_NAME=${DB_NAME}
APP_URL=https://${DOMAIN}
GEMINI_API_KEY=${GEMINI_API_KEY}
EOF

echo -e "${YELLOW}-> Instalando dependências npm...${NC}"
rm -rf node_modules dist
npm install

echo -e "${YELLOW}-> Compilando Frontend e empacotando servidor...${NC}"
npm run build

# 4.4 Inicialização de Processos com o PM2
echo -e "${YELLOW}-> Ativando o processo Node em background via PM2...${NC}"
npm install -g pm2 tsx || true
pm2 delete siae 2>/dev/null || true

# Inicializa usando o bundle compilado em dist/server.cjs
pm2 start dist/server.cjs --name "siae" --max-memory-restart 1G
pm2 startup systemd -u root --hp /root || true
pm2 save

# Pasta de Uploads de arquivos das salas de conferência
mkdir -p ${APP_DIR}/uploads
chown -R www-data:www-data ${APP_DIR} || true
chmod -R 775 ${APP_DIR}/uploads || true

# ==============================================================================
# ETAPA 5: CONFIGURAÇÃO DO VIRTUAL HOST PROXY NO APACHE
# ==============================================================================
echo -e "\n${MAGENTA}[ETAPA 5 - PROXY APACHE] Aplicando Configuração do Host do Apache...${NC}"

# Verificar se o certificado do Let's Encrypt de fato existe e é válido
if [ -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" ] && [ -f "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" ]; then
    APACHE_SSL_CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
    APACHE_SSL_KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
    echo -e "${GREEN}-> Utilizando certificado SSL real e válido do Let's Encrypt obtido para ${DOMAIN}${NC}"
else
    echo -e "${RED}ERRO CRÍTICO: Certificado Let's Encrypt não encontrado em /etc/letsencrypt/live/${DOMAIN}/.${NC}"
    echo -e "${RED}A instalação foi interrompida pois a geração de certificado real é obrigatória.${NC}"
    exit 1
fi

cat <<EOF > /etc/apache2/sites-available/siae.conf
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    Redirect permanent / https://${DOMAIN}/
</VirtualHost>

<VirtualHost *:443>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}

    SSLEngine on
    SSLCertificateFile ${APACHE_SSL_CERT}
    SSLCertificateKeyFile ${APACHE_SSL_KEY}

    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/
    
    # Suporte a WebSockets para tráfego WebRTC veloz no sinalizador autônomo
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule ^/(.*) ws://127.0.0.1:3000/\$1 [P,L]
</VirtualHost>
EOF

# Garantir a limpeza de links padrão do Apache para evitar colisões
rm -f /etc/apache2/sites-enabled/000-default.conf || true
rm -f /etc/apache2/sites-enabled/default-ssl.conf || true

# Ativar virtual hosts no Apache
a2ensite siae.conf || true

echo -e "${YELLOW}-> Testando sintaxe das alterações do Apache e reiniciando...${NC}"
apache2ctl configtest
systemctl restart apache2 || true

echo -e "\n${GREEN}=====================================================================${NC}"
echo -e "${GREEN}           PARABÉNS! SISTEMA DE VIDEOCONFERÊNCIA CRIPTOGRAFADO ATIVO  ${NC}"
echo -e "${GREEN}=====================================================================${NC}"
echo -e "${CYAN}Acesso ao SIAE Geral & Meet:   https://${DOMAIN}${NC}"
echo -e "${CYAN}Status do Processo Node (SIAE):${NC}"
pm2 status siae || true
echo -e "====================================================================="
