const bcrypt = require('bcryptjs');
[ "Ass@Siae-123", "Tra@Siae-123", "Rep@Siae-123" ].forEach(p => {
  console.log(p + " : " + bcrypt.hashSync(p, 10));
});
