import React, { useState, useEffect } from 'react';
import { Camera, Mic, Volume2, ShieldCheck, Check, AlertCircle, X, Sparkles } from 'lucide-react';
import type { DevicePermissionsState } from '../types.ts';

interface DevicePermissionsModalProps {
  onPermissionsUpdated?: (state: DevicePermissionsState) => void;
}

const STORAGE_KEY = 'chamasso_equipment_permissions';

export const DevicePermissionsModal: React.FC<DevicePermissionsModalProps> = ({ onPermissionsUpdated }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [cameraGranted, setCameraGranted] = useState(true);
  const [micGranted, setMicGranted] = useState(true);
  const [rememberForever, setRememberForever] = useState(true);
  const [isRequesting, setIsRequesting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    // Verifica se já foi tomada uma decisão anteriormente no primeiro acesso
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed: DevicePermissionsState = JSON.parse(saved);
        if (parsed.granted) {
          setIsOpen(false);
          if (onPermissionsUpdated) onPermissionsUpdated(parsed);
          return;
        }
      }
      // Primeiro acesso: abre modal de autorização dos recursos do equipamento
      setIsOpen(true);
    } catch {
      setIsOpen(true);
    }
  }, [onPermissionsUpdated]);

  const handleGrantPermissions = async () => {
    setIsRequesting(true);
    setErrorMessage(null);

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // Solicita autorização de câmera e microfone do equipamento local
        const constraints: MediaStreamConstraints = {
          video: cameraGranted,
          audio: micGranted,
        };

        try {
          const stream = await navigator.mediaDevices.getUserMedia(constraints);
          // Fecha as faixas imediatamente após obter a permissão
          stream.getTracks().forEach((track) => track.stop());
        } catch (mediaErr: any) {
          console.warn('Aviso ao acessar dispositivos (pode ser restrição de sandbox ou hardware):', mediaErr);
          // Mesmo se o navegador em iframe restringir hardware real, registramos a concessão do usuário
        }
      }

      const decision: DevicePermissionsState = {
        granted: true,
        date: new Date().toISOString(),
        camera: cameraGranted,
        microphone: micGranted,
        speaker: true,
      };

      if (rememberForever) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(decision));
      }

      if (onPermissionsUpdated) onPermissionsUpdated(decision);
      setIsOpen(false);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Não foi possível acessar a câmera ou microfone.');
    } finally {
      setIsRequesting(false);
    }
  };

  const handleDismissForNow = () => {
    const decision: DevicePermissionsState = {
      granted: false,
      date: new Date().toISOString(),
      camera: false,
      microphone: false,
      speaker: true,
    };
    if (rememberForever) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(decision));
    }
    setIsOpen(false);
    if (onPermissionsUpdated) onPermissionsUpdated(decision);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl border-2 border-[#22D3EE]/50 bg-[#0F172A] p-6 sm:p-8 shadow-[0_0_50px_rgba(34,211,238,0.25)] text-[#E2E8F0]">
        <button
          onClick={handleDismissForNow}
          className="absolute right-4 top-4 rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
          title="Fechar"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Cabeçalho */}
        <div className="flex items-center gap-4 mb-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#22D3EE] to-[#F472B6] text-black shadow-lg shadow-[#22D3EE]/30 shrink-0">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#22D3EE]">
              Primeiro Acesso ao Chamasso Live Chat
            </span>
            <h2 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight">
              Autorização de Recursos do Equipamento
            </h2>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
          Para garantir a melhor experiência em chamadas de vídeo ao vivo, lives de câmera e bate-papo com áudio, o{' '}
          <strong className="text-[#22D3EE]">chamasso live chat</strong> precisa da sua autorização para acessar os recursos locais do seu equipamento. Sua decisão será guardada posteriormente para os próximos acessos.
        </p>

        {/* Lista de Recursos Solicitados */}
        <div className="space-y-3 mb-6">
          <label className="flex items-center justify-between rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-3.5 cursor-pointer hover:border-[#22D3EE]/40 transition">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#22D3EE]/10 text-[#22D3EE]">
                <Camera className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">Câmera de Vídeo</p>
                <p className="text-[11px] text-slate-400">
                  Transmissão ao vivo estilo live, videoconferência e apresentação
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={cameraGranted}
              onChange={(e) => setCameraGranted(e.target.checked)}
              className="h-5 w-5 rounded border-[#1E293B] text-[#22D3EE] focus:ring-[#22D3EE] bg-[#1E293B]"
            />
          </label>

          <label className="flex items-center justify-between rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-3.5 cursor-pointer hover:border-[#22D3EE]/40 transition">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F472B6]/10 text-[#F472B6]">
                <Mic className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">Microfone & Áudio</p>
                <p className="text-[11px] text-slate-400">
                  Comunicação por voz nas salas e envio de áudios MP3/WAV
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={micGranted}
              onChange={(e) => setMicGranted(e.target.checked)}
              className="h-5 w-5 rounded border-[#1E293B] text-[#F472B6] focus:ring-[#F472B6] bg-[#1E293B]"
            />
          </label>

          <div className="flex items-center gap-3 rounded-2xl border border-[#1E293B] bg-[#0A0C10]/60 p-3 text-[11px] text-slate-400">
            <Volume2 className="h-4 w-4 text-[#22D3EE] shrink-0" />
            <span>
              Alto-falantes e sons da sala: ativados automaticamente para reprodução de áudio e plugins de vídeo.
            </span>
          </div>
        </div>

        {/* Checkbox de memorização */}
        <div className="mb-6 flex items-center gap-2 text-xs text-slate-300">
          <input
            type="checkbox"
            id="rememberPermission"
            checked={rememberForever}
            onChange={(e) => setRememberForever(e.target.checked)}
            className="h-4 w-4 rounded border-[#1E293B] text-[#22D3EE] focus:ring-[#22D3EE] bg-[#1E293B]"
          />
          <label htmlFor="rememberPermission" className="cursor-pointer select-none">
            Guardar minha decisão permanentemente para este equipamento
          </label>
        </div>

        {errorMessage && (
          <div className="mb-4 flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-950/40 p-3 text-xs text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Botões de Ação */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleDismissForNow}
            className="flex-1 rounded-xl border border-[#1E293B] bg-[#1E293B] py-3 text-xs font-bold text-slate-300 hover:bg-[#334155] hover:text-white transition"
          >
            Depois / Apenas Chat
          </button>
          <button
            onClick={handleGrantPermissions}
            disabled={isRequesting}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-3 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
          >
            <Sparkles className="h-4 w-4 text-black" />
            <span>{isRequesting ? 'Concedendo...' : 'Autorizar Recursos'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
