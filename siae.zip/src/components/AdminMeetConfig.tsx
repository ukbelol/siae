import React, { useState, useEffect } from 'react';
import { 
  Video, 
  ShieldAlert, 
  Check, 
  RefreshCw, 
  Trash2, 
  Calendar, 
  Clock, 
  Sparkles, 
  Building2, 
  ExternalLink,
  Lock,
  Compass,
  FileText
} from 'lucide-react';
import { toast } from 'react-hot-toast';

export default function AdminMeetConfig() {
  const [conferences, setConferences] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalRooms: 0,
    activePeers: 0,
    signalSystem: 'Ativo (SIAE Signaling Server)'
  });

  const loadConferences = async () => {
    setLoading(true);
    try {
      // In SIAE, we can query all conferences through a general endpoint or list by houses.
      // Let's list general house details and load conferences
      const housesRes = await fetch('/api/admin/houses');
      const houses = await housesRes.json();
      
      let allConferences: any[] = [];
      if (Array.isArray(houses)) {
        for (const house of houses) {
          const confRes = await fetch(`/api/houses/${house.id}/conferences`);
          const confs = await confRes.json();
          if (Array.isArray(confs)) {
            const mapped = confs.map((c: any) => ({
              ...c,
              houseName: house.name,
              houseId: house.id
            }));
            allConferences = [...allConferences, ...mapped];
          }
        }
      }
      
      // Sort by date/time desc
      allConferences.sort((a, b) => {
        const datetimeA = new Date(`${a.scheduled_date}T${a.scheduled_time || '00:00'}`);
        const datetimeB = new Date(`${b.scheduled_date}T${b.scheduled_time || '00:00'}`);
        return datetimeB.getTime() - datetimeA.getTime();
      });

      setConferences(allConferences);
      
      // Update statistics
      setStats({
        totalRooms: allConferences.length,
        activePeers: allConferences.reduce((acc, current) => acc + (current.participants?.length || 0), 0),
        signalSystem: 'Ativo e Operacional (Porta: 3000)'
      });
    } catch (err: any) {
      console.error('Error loading super admin conferences info:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConferences();
  }, []);

  const handleDeleteConference = async (houseId: string, id: number) => {
    if (!window.confirm('Tem certeza que deseja remover esta sala de videoconferência permanentemente?')) {
      return;
    }

    try {
      const res = await fetch(`/api/houses/${houseId}/conferences/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        toast.success('Sala de videoconferência excluída com sucesso!');
        loadConferences();
      } else {
        const data = await res.json();
        throw new Error(data.error || 'Erro ao deletar');
      }
    } catch (err: any) {
      toast.error('Erro ao deletar: ' + err.message);
    }
  };

  return (
    <div className="space-y-6" id="superadmin-meet-dashboard">
      
      {/* 1. HERO HEADER */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100 shrink-0">
            <Video className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-gray-800">Serviço de Videoconferência Autônomo (SIAE Meet)</h3>
            <p className="text-xs text-gray-500 max-w-xl">
              Central do Super Admin para controle, monitoramento e visualização de salas virtuais de atendimento do espiritismo do SIAE, totalmente autônoma e integrada.
            </p>
          </div>
        </div>

        <button 
          onClick={loadConferences} 
          disabled={loading}
          className="px-4 py-2 border rounded-xl hover:bg-gray-50 text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 self-end md:self-auto select-none"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Sincronizar Monitoramento
        </button>
      </div>

      {/* 2. STATS CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Total Rooms */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 flex flex-col justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 p-8 bg-indigo-50 rounded-full text-indigo-400 group-hover:scale-110 transition-transform duration-300" />
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-400">Total de Salas Virtuais</span>
            <p className="text-3xl font-extrabold text-indigo-950 mt-1">{stats.totalRooms}</p>
          </div>
          <p className="text-xs text-gray-500 mt-3 pt-2 border-t z-10">Cadastradas pelas Casas Espíritas</p>
        </div>

        {/* Signaling Engine Status */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 flex flex-col justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 p-8 bg-green-50 rounded-full text-green-400 group-hover:scale-110 transition-transform duration-300" />
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-400">Servidor de Sinalização (WebRTC)</span>
            <p className="text-md font-bold text-green-600 mt-2 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              SIAE Signaling Engine
            </p>
          </div>
          <p className="text-xs text-gray-500 mt-3 pt-2 border-t z-10">Porta Interna Segura: <code className="font-mono bg-gray-50 px-1 rounded">3000 (Proxy Ativo)</code></p>
        </div>

        {/* Infrastructure Footprint */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 flex flex-col justify-between shadow-sm relative overflow-hidden group">
          <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 p-8 bg-violet-50 rounded-full text-violet-400 group-hover:scale-110 transition-transform duration-300" />
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-400">Status de Migração Coesa</span>
            <p className="text-md font-extrabold text-violet-950 mt-2">Zero Dependências Externas</p>
          </div>
          <p className="text-xs text-gray-500 mt-3 pt-2 border-t z-10">Serviço de sinalização autônomo e unificado</p>
        </div>

      </div>

      {/* 3. TECHNICAL DOCUMENTATION OVERVIEW */}
      <div className="bg-indigo-950/5 border border-indigo-950/20 rounded-2xl p-6 text-indigo-950">
        <div className="flex gap-3">
          <ShieldAlert className="w-5 h-5 shrink-0 text-indigo-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-black">Por que o SIAE Meet agora é a escolha definitiva?</h4>
            <p className="text-xs text-indigo-800 leading-relaxed mt-1">
              O sistema é <strong>100% integrado ao back-end Node.js do SIAE</strong>, operando de forma autônoma sobre WebRTC puro em qualquer navegador moderno. Esse sistema de sinalização elimina qualquer dependência de servidores adicionais de videoconferência de terceiros, garantindo máxima performance e zero consumo de recursos extras da VPS.
            </p>
            <div className="mt-3 flex flex-wrap gap-4 text-[11px] font-bold text-indigo-900 border-t border-indigo-950/10 pt-3">
              <span className="flex items-center gap-1">✔ Compartilhamento de arquivos nativo</span>
              <span className="flex items-center gap-1">✔ Compartilhamento de tela em tempo real</span>
              <span className="flex items-center gap-1">✔ Chat instantâneo de texto</span>
              <span className="flex items-center gap-1">✔ Sinais acústicos baseados em oscilador web</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. CONFERENCES LISTING */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50 select-none">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-gray-400" />
            <h4 className="text-xs font-black uppercase tracking-wider text-gray-500">Salas de Videoconferência registradas no ecossistema</h4>
          </div>
          <span className="text-[10px] font-bold bg-indigo-50 border border-indigo-100 text-indigo-700 px-2.5 py-1 rounded-lg">
            {conferences.length} {conferences.length === 1 ? 'Sala Encontrada' : 'Salas Encontradas'}
          </span>
        </div>

        <div className="divide-y divide-gray-100 overflow-x-auto">
          {loading ? (
            <div className="p-12 text-center text-gray-500 flex flex-col items-center justify-center gap-2">
              <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">Buscando conferências ativas...</p>
            </div>
          ) : conferences.length === 0 ? (
            <div className="p-12 text-center text-gray-500 flex flex-col items-center justify-center gap-3">
              <Video className="w-12 h-12 text-gray-300 opacity-40 animate-pulse" />
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Nenhuma sala de videoconferência registrada</p>
              <p className="text-xs text-gray-400 max-w-sm">No momento as Casas Espíritas não criaram salas virtuais de atendimento grupal ou palestras.</p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse min-w-[700px]">
              <thead>
                <tr className="bg-gray-50/75 border-b text-gray-400 font-extrabold text-[10px] tracking-wider uppercase select-none">
                  <th className="py-3 px-5">Casa Espírita</th>
                  <th className="py-3 px-5">Título / Objetivo</th>
                  <th className="py-3 px-3">Código Único</th>
                  <th className="py-3 px-3">Agenda planejada</th>
                  <th className="py-3 px-3">Membros</th>
                  <th className="py-3 px-5 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="text-xs divide-y divide-gray-100">
                {conferences.map((conf) => (
                  <tr key={conf.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="py-4 px-5">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center mb-0.5 shrink-0 border border-indigo-100 font-bold text-xs select-none">
                          {conf.houseName?.charAt(0) || 'C'}
                        </div>
                        <div className="truncate max-w-[150px]">
                          <p className="font-bold text-gray-800 line-clamp-1">{conf.houseName}</p>
                          <p className="text-[9px] text-gray-400">ID da Casa: #{conf.house_id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-5">
                      <div className="max-w-[200px]">
                        <p className="font-bold text-gray-800 truncate" title={conf.title}>{conf.title}</p>
                        {conf.description && <p className="text-[10px] text-gray-400 truncate mt-0.5" title={conf.description}>{conf.description}</p>}
                      </div>
                    </td>
                    <td className="py-4 px-3 font-mono font-bold text-indigo-750 text-xs">
                      {conf.room_name}
                    </td>
                    <td className="py-4 px-3 text-gray-500">
                      <div className="flex flex-col gap-0.5">
                        <span className="flex items-center gap-1 text-[11px] font-semibold text-gray-700">
                          <Calendar className="w-3.5 h-3.5 text-gray-400" />
                          {conf.scheduled_date ? new Date(`${conf.scheduled_date}T00:00:00`).toLocaleDateString('pt-BR') : 'Sem data'}
                        </span>
                        <span className="flex items-center gap-1 text-[10px]">
                          <Clock className="w-3.5 h-3.5 text-gray-400" />
                          {conf.scheduled_time || 'Sem horário'}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-3">
                      <span className="px-2 py-0.5 bg-gray-100 border text-gray-600 font-bold rounded-lg text-[10px]">
                        {conf.participants?.length || 0} cadastrados
                      </span>
                    </td>
                    <td className="py-4 px-5 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => {
                            const link = `/room/${conf.room_name}`;
                            window.open(link, '_blank');
                          }}
                          className="px-2.5 py-1.5 bg-gray-50 hover:bg-indigo-50 hover:text-indigo-600 text-gray-600 rounded-lg font-bold border border-gray-200 hover:border-indigo-200 transition-all flex items-center gap-1"
                          title="Entrar como observador administrativo"
                        >
                          <ExternalLink className="w-3.5 h-3.5" /> Entrar
                        </button>
                        <button
                          onClick={() => handleDeleteConference(conf.houseId, conf.id)}
                          className="p-1.5 bg-amber-50 hover:bg-rose-50 border border-amber-100 hover:border-rose-100 text-amber-600 hover:text-rose-600 rounded-lg transition-colors"
                          title="Remover conferência"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
      
    </div>
  );
}
