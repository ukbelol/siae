# GOITGODS 2.3.15

- Bootstrap do navegador isolado e versionado para evitar cache antigo.
- `main.tsx` usa importações dinâmicas para capturar falhas de avaliação de App/dependências.
- Remove o loader estático que podia permanecer indefinidamente.
- Mostra no navegador o erro JavaScript real se o React não puder montar.
- Instalador e reparador validam também o bootstrap JS, além dos bundles Vite.
- Mantém as correções acumuladas de PM2, porta 3100, Apache, assets, SSL, UFW/SSH e reinstalação idempotente.
