#!/bin/bash

# ==============================================================================
# S.I.A.E - Gerenciador do Sistema
# ==============================================================================

SERVICE_NAME="siae"
APP_DIR="/var/www/siae"

show_menu() {
    clear
    echo "=========================================================="
    echo "       S.I.A.E - Painel de Gerenciamento do Servidor      "
    echo "=========================================================="
    echo "1. Iniciar o sistema"
    echo "2. Parar o sistema"
    echo "3. Reiniciar o sistema"
    echo "4. Verificar status do sistema"
    echo "5. Ver logs da aplicação (Tempo Real)"
    echo "6. Ver logs de erro do Apache"
    echo "7. Atualizar dependências (npm install)"
    echo "8. Recompilar a aplicação (npm run build)"
    echo "9. Renovar Certificado SSL"
    echo "0. Sair"
    echo "=========================================================="
    echo -n "Escolha uma opção: "
}

while true; do
    show_menu
    read option

    case $option in
        1)
            echo "Iniciando o serviço S.I.A.E..."
            sudo systemctl start $SERVICE_NAME
            sudo systemctl enable $SERVICE_NAME
            echo "Serviço iniciado."
            read -p "Pressione Enter para continuar..."
            ;;
        2)
            echo "Parando o serviço S.I.A.E..."
            sudo systemctl stop $SERVICE_NAME
            echo "Serviço parado."
            read -p "Pressione Enter para continuar..."
            ;;
        3)
            echo "Reiniciando o serviço S.I.A.E..."
            sudo systemctl restart $SERVICE_NAME
            echo "Serviço reiniciado."
            read -p "Pressione Enter para continuar..."
            ;;
        4)
            echo "Status do serviço S.I.A.E:"
            sudo systemctl status $SERVICE_NAME --no-pager
            read -p "Pressione Enter para continuar..."
            ;;
        5)
            echo "Exibindo logs da aplicação (Pressione CTRL+C para sair)..."
            sudo journalctl -u $SERVICE_NAME -f
            ;;
        6)
            echo "Exibindo logs de erro do Apache (Pressione CTRL+C para sair)..."
            sudo tail -f /var/log/apache2/siae_ssl_error.log
            ;;
        7)
            echo "Atualizando dependências do Node.js..."
            cd $APP_DIR
            sudo -u www-data npm install
            echo "Dependências atualizadas."
            read -p "Pressione Enter para continuar..."
            ;;
        8)
            echo "Recompilando a aplicação..."
            cd $APP_DIR
            sudo -u www-data npm run build
            echo "Aplicação recompilada. Reiniciando o serviço..."
            sudo systemctl restart $SERVICE_NAME
            read -p "Pressione Enter para continuar..."
            ;;
        9)
            echo "Renovando certificado SSL..."
            sudo certbot renew
            sudo systemctl reload apache2
            read -p "Pressione Enter para continuar..."
            ;;
        0)
            echo "Saindo..."
            exit 0
            ;;
        *)
            echo "Opção inválida!"
            read -p "Pressione Enter para continuar..."
            ;;
    esac
done
