const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

// Line 140:     const houses = (await db.query(query).all(...params);
lines[139] = "    const houses = (await db.query(query, params))[0];";

// Line 151:       .run(req.params.houseId, workerId, 'pending');
// Wait, looking at lines before 151
for (let i=148; i<=152; i++) {
  if (lines[i].includes('INSERT IGNORE INTO house_workers')) {
    lines[i] = "    await db.query('INSERT IGNORE INTO house_workers (house_id, worker_id, status) VALUES (?, ?, ?)', [req.params.houseId, workerId, 'pending']);";
    lines[i+1] = ""; // remove the `.run`
  }
}

// Line 1009:       const activeAttendance = db.prepare('SELECT * FROM attendances WHERE worker_id = ? AND house_id = ? AND status = \'in_progress\'', [user.id, houseId]))[0][0] as any;
lines[1008] = "      const activeAttendance = (await db.query('SELECT * FROM attendances WHERE worker_id = ? AND house_id = ? AND status = \\\'in_progress\\\'', [user.id, houseId]))[0][0] as any;";

// Line 1013:         db.prepare('UPDATE attendances SET status = !!completed!!, end_time = CURRENT_TIMESTAMP WHERE id = ?'.replace(/!!/g, "'"), [activeAttendance.id]))[0];
lines[1012] = "        await db.query('UPDATE attendances SET status = \\'completed\\', end_time = CURRENT_TIMESTAMP WHERE id = ?', [activeAttendance.id]);";

// Line 1201:           await conn.query(insertParticipantCmd, [Number(info.insertId]), userId);
lines[1200] = "          await conn.query(insertParticipantCmd, [Number(info.insertId), userId]);";


fs.writeFileSync('src/api/index.ts', lines.join('\n'));
