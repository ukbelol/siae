const fs = require('fs');
let text = fs.readFileSync('install-all.sh', 'utf8');

// Revert nvm to n manager globally
text = text.replace(/echo "Instalando NVM e Node\.js\.\.\."[\s\S]*?npm install -g npm@latest/g, `echo "Instalando gerenciador 'N' para Node.js global..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
npm install -g n
n 22.2.0
npm install -g npm@latest
`);

text = text.replace(/Environment=PATH=\$NVM_DIR\/versions\/node\/\$\(nvm version\)\/bin:\$PATH/g, `Environment=PATH=/usr/local/bin:/usr/bin:$PATH`);
text = text.replace(/ExecStart=\/bin\/bash -c 'source \$HOME\/\.nvm\/nvm\.sh && npm run start'/g, `ExecStart=/usr/local/bin/npm run start`);

text = text.replace(/user: process.env.DB_USER/g, "user: process.env.DB_USER");

fs.writeFileSync('install-all.sh', text);
