import React from 'react';
import { 
  Sparkles, 
  Search, 
  BookOpen, 
  Crown, 
  Network, 
  Cpu, 
  Lock, 
  ShieldCheck, 
  UserCheck, 
  LogOut 
} from 'lucide-react';
import { SuperAdminUser } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  adminUser: SuperAdminUser | null;
  onOpenLoginModal: () => void;
  onLogoutAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  adminUser,
  onOpenLoginModal,
  onLogoutAdmin,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#050505] border-b border-zinc-800 text-zinc-100 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Branding */}
          <div 
            onClick={() => setActiveTab('search')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-9 h-9 bg-yellow-400 rounded-sm flex items-center justify-center text-black font-black font-display text-lg shadow-md group-hover:bg-yellow-300 transition-colors">
              G
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-display font-black text-xl sm:text-2xl tracking-tighter uppercase italic text-white">
                  GOIT<span className="text-yellow-400">GODS</span>
                </span>
                <span className="text-[10px] font-mono font-black bg-zinc-800 text-yellow-400 px-2 py-0.5 border border-zinc-700 uppercase tracking-widest">
                  2.0
                </span>
              </div>
              <p className="text-[9px] text-zinc-500 font-black tracking-[0.2em] uppercase">
                PASQUARED-OS // Cognitive Kernel PCK
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-3 text-xs font-bold tracking-widest uppercase">
            <button
              id="nav-btn-search"
              onClick={() => setActiveTab('search')}
              className={`flex items-center space-x-2 px-3.5 py-2 border transition-colors ${
                activeTab === 'search'
                  ? 'bg-zinc-800 text-white border-yellow-400 font-black'
                  : 'text-zinc-400 hover:text-white border-transparent hover:border-zinc-800'
              }`}
            >
              <Search className="w-3.5 h-3.5 text-yellow-400" />
              <span>System</span>
            </button>

            <button
              id="nav-btn-ebook"
              onClick={() => setActiveTab('ebook')}
              className={`flex items-center space-x-2 px-3.5 py-2 border transition-colors ${
                activeTab === 'ebook'
                  ? 'bg-zinc-800 text-white border-yellow-400 font-black'
                  : 'text-zinc-400 hover:text-white border-transparent hover:border-zinc-800'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-yellow-400" />
              <span>E-Book Vault</span>
            </button>

            <button
              id="nav-btn-evolution"
              onClick={() => setActiveTab('evolution')}
              className={`flex items-center space-x-2 px-3.5 py-2 border transition-colors ${
                activeTab === 'evolution'
                  ? 'bg-zinc-800 text-white border-yellow-400 font-black'
                  : 'text-zinc-400 hover:text-white border-transparent hover:border-zinc-800'
              }`}
            >
              <Cpu className="w-3.5 h-3.5 text-yellow-400" />
              <span>Evolution</span>
            </button>
          </nav>

          {/* Super Admin Status & Auth Button */}
          <div className="flex items-center space-x-4">
            <div className="hidden lg:flex items-center space-x-3 text-right">
              <div>
                <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest leading-none">STATUS</p>
                <p className="text-xs font-mono text-emerald-500 font-bold uppercase tracking-tighter">Active_Pulse</p>
              </div>
            </div>

            {adminUser && adminUser.isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <button
                  id="nav-btn-admin-panel"
                  onClick={() => setActiveTab('admin')}
                  className={`flex items-center space-x-2 px-3 py-1.5 border text-xs font-mono font-bold transition-all ${
                    activeTab === 'admin'
                      ? 'bg-yellow-400 text-black border-yellow-400'
                      : 'bg-zinc-900 text-emerald-400 border-zinc-700 hover:border-emerald-500'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span className="hidden sm:inline">SUPER ADMIN</span>
                </button>
                <button
                  id="btn-logout"
                  onClick={onLogoutAdmin}
                  title="Sair da Conta Super Admin"
                  className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-zinc-800 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                id="btn-open-super-admin-login"
                onClick={onOpenLoginModal}
                className="flex items-center space-x-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white px-3.5 py-2 border border-zinc-700 text-xs font-black uppercase tracking-widest transition-colors"
              >
                <Lock className="w-3.5 h-3.5 text-yellow-400" />
                <span>Admin</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden overflow-x-auto py-2 space-x-2 border-t border-zinc-800 no-scrollbar text-xs font-bold uppercase tracking-widest">
          <button
            onClick={() => setActiveTab('search')}
            className={`px-3 py-1.5 border whitespace-nowrap ${
              activeTab === 'search' ? 'bg-yellow-400 text-black border-yellow-400' : 'text-zinc-400 border-zinc-800'
            }`}
          >
            System
          </button>
          <button
            onClick={() => setActiveTab('ebook')}
            className={`px-3 py-1.5 border whitespace-nowrap ${
              activeTab === 'ebook' ? 'bg-yellow-400 text-black border-yellow-400' : 'text-zinc-400 border-zinc-800'
            }`}
          >
            E-Book
          </button>
          <button
            onClick={() => setActiveTab('evolution')}
            className={`px-3 py-1.5 border whitespace-nowrap ${
              activeTab === 'evolution' ? 'bg-yellow-400 text-black border-yellow-400' : 'text-zinc-400 border-zinc-800'
            }`}
          >
            Evolution
          </button>
          {adminUser && adminUser.isAuthenticated && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-1.5 border whitespace-nowrap ${
                activeTab === 'admin' ? 'bg-yellow-400 text-black border-yellow-400' : 'text-zinc-400 border-zinc-800'
              }`}
            >
              Admin
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
