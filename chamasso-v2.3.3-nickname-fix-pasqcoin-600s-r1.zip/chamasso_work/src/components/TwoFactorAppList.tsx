import React, { useState, useEffect } from 'react';
import { Smartphone, Shield, Check, ExternalLink, Key, Clock, Sparkles, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';

export interface AuthenticatorAppInfo {
  id: string;
  name: string;
  developer: string;
  badge: string;
  badgeColor: string;
  platforms: string[];
  features: string[];
  iconBg: string;
  iconText: string;
  playStoreUrl?: string;
  appStoreUrl?: string;
  webUrl?: string;
  description: string;
}

export const POPULAR_2FA_APPS: AuthenticatorAppInfo[] = [
  {
    id: 'google-authenticator',
    name: 'Google Authenticator',
    developer: 'Google LLC',
    badge: 'Mais Popular',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    platforms: ['Android', 'iOS'],
    features: ['Sincronização com Conta Google', 'Simples e Direto', 'Offline'],
    iconBg: 'bg-gradient-to-tr from-blue-500 via-red-500 to-amber-500',
    iconText: 'G',
    playStoreUrl: 'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2',
    appStoreUrl: 'https://apps.apple.com/app/google-authenticator/id388497605',
    description: 'O aplicativo padrão mais usado no mundo. Suporta backup automático e leitura instantânea por QR Code.',
  },
  {
    id: 'microsoft-authenticator',
    name: 'Microsoft Authenticator',
    developer: 'Microsoft Corporation',
    badge: 'Empresarial & Nuvem',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    platforms: ['Android', 'iOS'],
    features: ['Backup em Nuvem Seguro', 'Biometria FaceID/Digital', 'Alta Estabilidade'],
    iconBg: 'bg-gradient-to-tr from-cyan-600 to-blue-700',
    iconText: 'M',
    playStoreUrl: 'https://play.google.com/store/apps/details?id=com.azure.authenticator',
    appStoreUrl: 'https://apps.apple.com/app/microsoft-authenticator/id983156458',
    description: 'Excelente para quem utiliza o ecossistema Microsoft com backup criptografado de contas.',
  },
  {
    id: '2fas-authenticator',
    name: '2FAS Authenticator',
    developer: 'Two Factor Authentication Service',
    badge: 'Recomendado / Open Source',
    badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    platforms: ['Android', 'iOS', 'Extensão Navegador'],
    features: ['100% Código Aberto', 'Sem Coleta de Dados', 'Backup Criptografado (Google Drive / iCloud)'],
    iconBg: 'bg-gradient-to-tr from-rose-500 to-red-600',
    iconText: '2F',
    playStoreUrl: 'https://play.google.com/store/apps/details?id=com.twofasapp',
    appStoreUrl: 'https://apps.apple.com/app/2fas-auth/id1217793794',
    webUrl: 'https://2fas.com',
    description: 'Altamente elogiado pela comunidade de cibersegurança. Seguro, privado e com integração via navegador.',
  },
  {
    id: 'twilio-authy',
    name: 'Twilio Authy',
    developer: 'Twilio Inc.',
    badge: 'Multi-Dispositivo',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    platforms: ['Android', 'iOS', 'Desktop (Mac/PC)'],
    features: ['Sincronização Multidispositivo', 'Senha Mestra de Proteção', 'Recuperação por Telefone'],
    iconBg: 'bg-gradient-to-tr from-red-600 to-amber-600',
    iconText: 'A',
    playStoreUrl: 'https://play.google.com/store/apps/details?id=com.authy.authy',
    appStoreUrl: 'https://apps.apple.com/app/twilio-authy/id494168017',
    webUrl: 'https://authy.com',
    description: 'Permite sincronizar os mesmos códigos 2FA entre celular, tablet e computador.',
  },
  {
    id: 'bitwarden-passwords',
    name: 'Bitwarden / 1Password / Proton Pass',
    developer: 'Gerenciadores de Senha TOTP',
    badge: 'Tudo-em-Um',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    platforms: ['Android', 'iOS', 'Windows', 'Mac', 'Linux', 'Web'],
    features: ['Preenchimento Automático', 'Cofre Criptografado Ponta-a-Ponta', 'Auto-Preenchimento nos Sites'],
    iconBg: 'bg-gradient-to-tr from-purple-600 to-indigo-700',
    iconText: '🛡️',
    webUrl: 'https://bitwarden.com',
    description: 'Gerenciadores com gerador TOTP embutido que preenchem o código 2FA com 1 clique.',
  },
  {
    id: 'aegis-authenticator',
    name: 'Aegis Authenticator',
    developer: 'Aegis Open Source',
    badge: 'Foco em Privacidade (Android)',
    badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
    platforms: ['Android'],
    features: ['Código Aberto Total', 'Criptografia Local AES-256', 'Bloqueio Biométrico'],
    iconBg: 'bg-gradient-to-tr from-teal-600 to-emerald-700',
    iconText: 'Ae',
    playStoreUrl: 'https://play.google.com/store/apps/details?id=com.beemdevelopment.aegis',
    description: 'Opção open-source favorita de usuários Android com exportação e controle total de chaves.',
  },
];

interface TwoFactorAppListProps {
  compact?: boolean;
  selectedAppId?: string;
  onSelectApp?: (app: AuthenticatorAppInfo) => void;
}

export const TwoFactorAppList: React.FC<TwoFactorAppListProps> = ({
  compact = false,
  selectedAppId,
  onSelectApp,
}) => {
  const [expandedApp, setExpandedApp] = useState<string | null>(selectedAppId || 'google-authenticator');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(30);

  // Calcula os segundos restantes do ciclo TOTP de 30 segundos
  useEffect(() => {
    const updateCountdown = () => {
      const nowSeconds = Math.floor(Date.now() / 1000);
      const remaining = 30 - (nowSeconds % 30);
      setSecondsRemaining(remaining);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-3">
      {/* Timer de Ciclo TOTP */}
      <div className="flex items-center justify-between rounded-xl border border-[#1E293B] bg-[#0A0C10]/90 px-3 py-2 text-xs">
        <div className="flex items-center gap-2 text-slate-300">
          <Clock className="h-4 w-4 text-[#22D3EE] animate-pulse" />
          <span>Protocolo TOTP (RFC 6238):</span>
          <span className="text-[11px] text-slate-400">Códigos de 6 dígitos</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-16 sm:w-24 bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-[#22D3EE] to-[#F472B6] h-full transition-all duration-1000"
              style={{ width: `${(secondsRemaining / 30) * 100}%` }}
            />
          </div>
          <span className="font-mono text-xs font-bold text-[#22D3EE] tabular-nums">
            {secondsRemaining}s
          </span>
        </div>
      </div>

      {/* Título de aplicativos suportados */}
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
          <Smartphone className="h-3.5 w-3.5 text-[#22D3EE]" />
          <span>Principais Aplicativos de 2FA Compatíveis</span>
        </span>
        <span className="text-[10px] text-slate-400">Padrão Universal TOTP</span>
      </div>

      {/* Grid de Apps */}
      <div className={`grid ${compact ? 'grid-cols-2 sm:grid-cols-3' : 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3'} gap-2`}>
        {POPULAR_2FA_APPS.map((app) => {
          const isSelected = selectedAppId === app.id;
          const isExpanded = expandedApp === app.id;

          return (
            <div
              key={app.id}
              onClick={() => {
                setExpandedApp(isExpanded ? null : app.id);
                if (onSelectApp) onSelectApp(app);
              }}
              className={`cursor-pointer rounded-2xl border p-2.5 transition-all relative overflow-hidden ${
                isSelected || isExpanded
                  ? 'border-[#22D3EE] bg-[#22D3EE]/10 shadow-[0_0_15px_rgba(34,211,238,0.15)]'
                  : 'border-[#1E293B] bg-[#0A0C10]/80 hover:border-slate-600 hover:bg-[#0F172A]'
              }`}
            >
              <div className="flex items-start gap-2">
                <div
                  className={`h-8 w-8 rounded-xl ${app.iconBg} flex items-center justify-center font-bold text-white shadow-sm shrink-0 text-xs`}
                >
                  {app.iconText}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="text-xs font-bold text-white truncate">{app.name}</h4>
                    {isSelected && <CheckCircle2 className="h-3.5 w-3.5 text-[#22D3EE] shrink-0" />}
                  </div>
                  <p className="text-[10px] text-slate-400 truncate">{app.developer}</p>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between gap-1">
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold border ${app.badgeColor}`}>
                  {app.badge}
                </span>
                <span className="text-[9px] text-slate-400">
                  {app.platforms.join(' • ')}
                </span>
              </div>

              {/* Informações expandidas se clicado */}
              {isExpanded && !compact && (
                <div className="mt-2.5 pt-2.5 border-t border-[#1E293B] text-[11px] text-slate-300 space-y-1.5">
                  <p className="text-[10px] text-slate-300 leading-tight">{app.description}</p>
                  <div className="space-y-0.5">
                    {app.features.map((feat, i) => (
                      <div key={i} className="flex items-center gap-1 text-[10px] text-cyan-200">
                        <Check className="h-3 w-3 text-emerald-400 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
