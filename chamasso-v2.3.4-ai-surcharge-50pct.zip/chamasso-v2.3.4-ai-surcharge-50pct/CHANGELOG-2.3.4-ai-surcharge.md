# Chamasso v2.3.4 — Sobretaxa de conversa com IA

- Usuário comum + usuário comum: tarifa PASQcoin normal (multiplicador 1,0).
- Usuário comum + conta oficial AI/PASQUARED: sobretaxa de 50% (multiplicador 1,5). Exemplo: 2 PASQcoin passam a consumir 3 PASQcoin.
- Usuário VIP + AI/PASQUARED: consumo zero.
- Conta `account_type = AI`: nunca é debitada.
- A identificação da IA é validada no backend pelos participantes da sala; o cliente não pode autodeclarar o tipo de conta para alterar a cobrança.
- Adicionada migração SQL para `users.account_type`, com padrão `USER`.
