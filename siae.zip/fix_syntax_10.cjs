const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

lines[1141] = "    for (const conf of conferences) {";
lines[1144] = "    }";

fs.writeFileSync('src/api/index.ts', lines.join('\n'));

let b = fs.readFileSync('src/lib/backup.ts', 'utf8');
b = b.replace(/function runBackup\(\) \{/g, "async function runBackup() {");
fs.writeFileSync('src/lib/backup.ts', b);
