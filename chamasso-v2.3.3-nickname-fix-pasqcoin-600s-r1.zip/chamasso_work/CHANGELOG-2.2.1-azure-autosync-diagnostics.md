# Chamasso 2.2.1 — Azure AutoSync + Diagnostics

- Log explícito de sucesso/falha do upload automático para Azure Blob.
- Debounce de 2,5 s após persistência local e upload somente de arquivos alterados durante a execução.
- Restauração Azure registra `AZURE RESTORE ✓` e inicializa hashes dos arquivos restaurados.
- Novo `npm run diagnose:recovery`: valida LOCAL BACKUP, AZURE UPLOAD, AZURE RESTORE e conta snapshots reais na nuvem.
- Backups temporários do Supabase passam a usar `/var/lib/chamasso/cloud-backups`, evitando caminhos antigos dependentes do diretório de execução.
- Mantém Managed Identity; nenhum segredo Azure é gravado no código.
