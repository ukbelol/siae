import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { ManagedIdentityCredential } from '@azure/identity';
import { BlobServiceClient } from '@azure/storage-blob';

const account = process.env.AZURE_STORAGE_ACCOUNT_NAME || 'chamasso';
const containerName = process.env.AZURE_STORAGE_CONTAINER || 'container-chamasso';
const endpoint = process.env.AZURE_STORAGE_ENDPOINT || `https://${account}.blob.core.windows.net`;
const backupDir = process.env.CHAMASSO_PROFILE_BACKUP_DIR || '/var/lib/chamasso/profile-backups';
const prefix = (process.env.AZURE_STORAGE_PREFIX || 'recovery/users').replace(/^\/+|\/+$/g, '');
const fail = (label, e) => { console.error(`${label} ✗ ${e?.message || e}`); process.exitCode = 1; };

try {
  const local = fs.existsSync(backupDir) ? fs.readdirSync(backupDir, { withFileTypes: true }).filter(x => x.isDirectory() && fs.existsSync(path.join(backupDir, x.name, 'profile-image.json'))) : [];
  if (!local.length) throw new Error(`nenhum profile-image.json encontrado em ${backupDir}`);
  console.log(`LOCAL BACKUP ✓ ${local.length} perfil(is) em ${backupDir}`);
} catch (e) { fail('LOCAL BACKUP', e); }

let blob;
try {
  const service = new BlobServiceClient(endpoint, new ManagedIdentityCredential());
  const container = service.getContainerClient(containerName);
  await container.getProperties();
  const name = `recovery/diagnostics/diag-${Date.now()}.txt`;
  blob = container.getBlockBlobClient(name);
  const payload = `Chamasso recovery diagnostic ${new Date().toISOString()}`;
  await blob.upload(payload, Buffer.byteLength(payload));
  const got = (await blob.downloadToBuffer()).toString();
  if (got !== payload) throw new Error('conteúdo lido diverge do conteúdo enviado');
  console.log(`AZURE UPLOAD ✓ ${containerName}/${name}`);
  const tmp = path.join(os.tmpdir(), `chamasso-restore-${Date.now()}.txt`);
  await blob.downloadToFile(tmp);
  if (!fs.existsSync(tmp) || fs.readFileSync(tmp, 'utf8') !== payload) throw new Error('arquivo restaurado não confere');
  console.log(`AZURE RESTORE ✓ leitura e restauração validadas em ${tmp}`);
  fs.unlinkSync(tmp);
  await blob.delete();

  let profiles = 0;
  for await (const item of container.listBlobsFlat({ prefix: `${prefix}/` })) if (item.name.endsWith('/profile-image.json')) profiles++;
  console.log(`CLOUD PROFILES ✓ ${profiles} profile-image.json encontrado(s) em ${prefix}/`);
} catch (e) { fail('AZURE', e); try { await blob?.deleteIfExists(); } catch {} }
