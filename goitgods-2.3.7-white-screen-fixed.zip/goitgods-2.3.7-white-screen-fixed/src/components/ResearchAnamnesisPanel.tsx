import React, { useState } from 'react';
import { BookOpenCheck, BrainCircuit, ChevronDown, ChevronUp, Database, FlaskConical, Send } from 'lucide-react';
import type { AcademicLevel, DynamicAnamnesisQuestion, DynamicAnamnesisSession, ResearchAnamnesisResult } from '../types';

const LEVELS: {value: AcademicLevel; label: string}[] = [
  { value: 'FUNDAMENTAL_I', label: 'Ensino Fundamental I' }, { value: 'FUNDAMENTAL_II', label: 'Ensino Fundamental II' },
  { value: 'MEDIO', label: 'Ensino Médio' }, { value: 'TECNICO', label: 'Ensino Técnico' }, { value: 'GRADUACAO', label: 'Graduação' },
  { value: 'POS_GRADUACAO', label: 'Pós-graduação' }, { value: 'MESTRADO', label: 'Mestrado' }, { value: 'DOUTORADO', label: 'Doutorado' }, { value: 'OUTRO', label: 'Outro' },
];

export function ResearchAnamnesisPanel({ onTopicReady }: { onTopicReady?: (topic: string) => void }) {
  const [open, setOpen] = useState(true);
  const [subjectArea, setSubjectArea] = useState('');
  const [academicLevel, setAcademicLevel] = useState<AcademicLevel>('MEDIO');
  const [schoolYear, setSchoolYear] = useState('');
  const [session, setSession] = useState<DynamicAnamnesisSession | null>(null);
  const [question, setQuestion] = useState<DynamicAnamnesisQuestion | null>(null);
  const [answer, setAnswer] = useState('');
  const [history, setHistory] = useState<{q: string; a: string; stage: string}[]>([]);
  const [result, setResult] = useState<ResearchAnamnesisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const inputClass = 'w-full bg-[#090909] border border-[#2b2b2b] px-3 py-2.5 text-sm text-white focus:outline-none focus:border-[#00FF41]';
  const labelClass = 'text-[11px] uppercase font-black tracking-wider text-[#bdbdbd]';

  const start = async () => {
    setLoading(true); setError(''); setResult(null); setHistory([]);
    try {
      const r = await fetch('/api/v3/anamnesis/dynamic/start', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({subjectArea,academicLevel,schoolYear}) });
      const data = await r.json(); if (!data.success) throw new Error(data.error || 'Falha ao iniciar');
      setSession(data.session); setQuestion(data.nextQuestion); setAnswer('');
    } catch (e:any) { setError(e.message || 'Erro ao iniciar anamnese'); } finally { setLoading(false); }
  };

  const send = async () => {
    if (!session || !question) return;
    setLoading(true); setError('');
    try {
      const r = await fetch('/api/v3/anamnesis/dynamic/answer', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({sessionId:session.sessionId,questionId:question.id,answer}) });
      const data = await r.json(); if (!data.success) throw new Error(data.error || 'Falha ao processar resposta');
      setHistory(h => [...h, { q: question.question, a: answer || '(sem resposta)', stage: question.stage }]);
      setSession(data.session); setQuestion(data.nextQuestion || null); setAnswer('');
      if (data.result) {
        setResult(data.result);
        onTopicReady?.(data.result.protocol.topic);
      }
    } catch (e:any) { setError(e.message || 'Erro na anamnese'); } finally { setLoading(false); }
  };

  const research:any = result?.research;
  const sources:any[] = research?.sources || [];
  const diagnostics:any[] = research?.providerDiagnostics || [];

  return <section className="bg-[#0F0F0F] border border-[#222] border-l-4 border-l-[#00FF41] font-mono">
    <button onClick={()=>setOpen(!open)} className="w-full px-5 py-4 flex items-center justify-between text-left">
      <div className="flex items-center gap-3"><BrainCircuit className="w-5 h-5 text-[#00FF41]"/><div><h2 className="text-white font-black uppercase">Anamnese Investigativa Dinâmica</h2><p className="text-[11px] text-[#777] mt-1">Cada resposta determina a próxima pergunta; depois PASQUARED + GOITGODS pesquisam e avaliam as premissas em fontes acadêmicas reais.</p></div></div>
      {open ? <ChevronUp className="text-[#777]"/> : <ChevronDown className="text-[#777]"/>}
    </button>
    {open && <div className="p-5 border-t border-[#222] space-y-5">
      {!session && <>
        <div className="grid md:grid-cols-3 gap-4">
          <label className="space-y-1.5"><span className={labelClass}>Matéria / área *</span><input className={inputClass} value={subjectArea} onChange={e=>setSubjectArea(e.target.value)} placeholder="Medicina, Direito, Matemática, Psicologia..."/></label>
          <label className="space-y-1.5"><span className={labelClass}>Nível *</span><select className={inputClass} value={academicLevel} onChange={e=>setAcademicLevel(e.target.value as AcademicLevel)}>{LEVELS.map(x=><option key={x.value} value={x.value}>{x.label}</option>)}</select></label>
          <label className="space-y-1.5"><span className={labelClass}>Ano / série / semestre</span><input className={inputClass} value={schoolYear} onChange={e=>setSchoolYear(e.target.value)} placeholder="Ex.: 9º ano, 4º semestre"/></label>
        </div>
        <button onClick={start} disabled={loading || !subjectArea.trim()} className="bg-[#00FF41] text-black font-black uppercase px-5 py-3 text-xs flex items-center gap-2 disabled:opacity-50"><FlaskConical className="w-4 h-4"/>{loading?'Iniciando...':'Iniciar anamnese dinâmica'}</button>
      </>}

      {session && <div className="space-y-4">
        <div className="flex flex-wrap gap-2 text-[10px] uppercase"><span className="border border-[#333] px-2 py-1 text-[#bbb]">Área: {session.subjectArea}</span><span className="border border-[#333] px-2 py-1 text-[#bbb]">Domínio: {session.detectedDomain}</span><span className="border border-[#333] px-2 py-1 text-[#bbb]">Nível: {session.academicLevel}</span></div>
        {history.length>0 && <div className="max-h-64 overflow-auto space-y-2">{history.map((h,i)=><div key={i} className="border-l-2 border-[#333] pl-3"><p className="text-[10px] text-[#777] uppercase">{h.stage}</p><p className="text-xs text-[#bbb]">{h.q}</p><p className="text-sm text-white mt-1">{h.a}</p></div>)}</div>}
        {question && <div className="border border-[#2c2c2c] bg-[#090909] p-4 space-y-3">
          <div><p className="text-[10px] text-[#00FF41] font-black uppercase">{question.stage}</p><p className="text-white mt-1">{question.question}</p>{question.help&&<p className="text-[11px] text-[#777] mt-1">{question.help}</p>}</div>
          {question.kind==='select' ? <select className={inputClass} value={answer} onChange={e=>setAnswer(e.target.value)}><option value="">Selecione...</option>{(question.options||[]).map(o=><option key={o}>{o}</option>)}</select> : question.kind==='textarea' ? <textarea className={inputClass} rows={4} value={answer} onChange={e=>setAnswer(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&e.ctrlKey) send();}} placeholder={question.required?'Resposta obrigatória':'Opcional — pode enviar em branco'}/> : <input className={inputClass} value={answer} onChange={e=>setAnswer(e.target.value)}/>} 
          <button onClick={send} disabled={loading || (question.required&&!answer.trim())} className="bg-[#00FF41] text-black font-black uppercase px-4 py-2.5 text-xs flex items-center gap-2 disabled:opacity-50"><Send className="w-4 h-4"/>{loading?'Processando...':'Responder e continuar'}</button>
        </div>}
      </div>}

      {error && <div className="border border-red-800 bg-red-950/30 text-red-300 p-3 text-xs">{error}</div>}

      {result && <div className="border border-[#333] bg-[#090909] p-4 space-y-5">
        <div className="flex items-center justify-between gap-3"><div className="flex items-center gap-2"><BookOpenCheck className="w-5 h-5 text-[#00FF41]"/><h3 className="text-white font-black uppercase">Pesquisa estruturada e triangulada</h3></div><span className="text-xs text-[#00FF41]">Prontidão: {(result.readiness.score*100).toFixed(0)}%</span></div>
        <div className="grid md:grid-cols-3 gap-3 text-xs"><div><p className="text-[#777] uppercase">Domínio detectado</p><p className="text-white mt-1">{research?.detectedKnowledgeDomain || 'GENERAL'}</p></div><div><p className="text-[#777] uppercase">Fontes recuperadas</p><p className="text-white mt-1">{sources.length}</p></div><div><p className="text-[#777] uppercase">Claims no ledger</p><p className="text-white mt-1">{research?.ledger?.totalClaims || 0}</p></div></div>
        <div><div className="flex items-center gap-2 mb-2"><Database className="w-4 h-4 text-[#00FF41]"/><p className="text-[#777] uppercase text-xs">Conectores acadêmicos</p></div><div className="flex flex-wrap gap-2">{diagnostics.map((d:any)=><span key={d.provider} className={`text-[10px] border px-2 py-1 ${d.success?'border-[#246b34] text-[#8bff9f]':'border-[#6b2a24] text-[#ff9b8b]'}`}>{d.provider}: {d.success?`${d.resultCount} resultados`:'indisponível'}</span>)}</div></div>
        {sources.length>0 && <div><p className="text-[#777] uppercase text-xs mb-2">Fontes reais melhor ranqueadas</p><div className="space-y-2">{sources.slice(0,8).map((s:any)=><div key={s.source_id} className="border border-[#222] p-3"><p className="text-white text-xs">{s.title}</p><p className="text-[10px] text-[#777] mt-1">{s.source_type} · {s.publisher} · {s.publication_date || 'data não informada'} · relevância {(s.relevance_score*100).toFixed(0)}%</p>{s.url&&<a href={s.url} target="_blank" rel="noreferrer" className="text-[10px] text-[#00FF41] break-all">{s.url}</a>}</div>)}</div></div>}
        {result.premiseEvaluations.length>0 && <div><p className="text-[#777] uppercase text-xs mb-2">Avaliação PASQUARED + GOITGODS das premissas</p><div className="space-y-2">{result.premiseEvaluations.map(p=><div key={p.premiseId} className="border border-[#222] p-3"><div className="flex justify-between gap-3"><span className="text-white text-xs">{p.premise}</span><b className="text-[#FF8A00] text-[10px]">{p.verdict}</b></div><p className="text-[#777] mt-1 text-[10px]">Confiança: {(p.confidence*100).toFixed(0)}% · claims relacionados: {p.supportingClaimIds.length}</p></div>)}</div></div>}
        {['MEDICINE','RADIOLOGY'].includes(research?.detectedKnowledgeDomain) && <div className="border border-amber-900/60 bg-amber-950/20 p-3 text-[11px] text-amber-200">Uso acadêmico: evidências médicas/radiológicas recuperadas pelo sistema não substituem diagnóstico, laudo, prescrição ou decisão clínica profissional.</div>}
        {research?.detectedKnowledgeDomain==='LAW' && <div className="border border-amber-900/60 bg-amber-950/20 p-3 text-[11px] text-amber-200">Uso acadêmico: literatura jurídica não confirma, por si só, a vigência de uma norma ou jurisprudência. Para parecer jurídico, a camada jurisdicional oficial deve ser consultada e a data de vigência verificada.</div>}
      </div>}
    </div>}
  </section>;
}
