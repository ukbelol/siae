// --- STORE & MERCADOPAGO CONFIG ---
const fs = require('fs');
let file = 'src/api/index.ts';
let t = fs.readFileSync(file, 'utf8');

const routes = `
router.get('/config/mercadopago', async (req, res) => {
  try {
    const config = (await db.query('SELECT * FROM mercadopago_config LIMIT 1'))[0][0];
    res.json(config || null);
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.post('/config/mercadopago', async (req, res) => {
  try {
    const { access_token, public_key, client_id, client_secret, redirect_url } = req.body;
    const existing = (await db.query('SELECT * FROM mercadopago_config LIMIT 1'))[0][0];
    if (existing) {
      await db.query('UPDATE mercadopago_config SET access_token = ?, public_key = ?, client_id = ?, client_secret = ?, redirect_url = ? WHERE id = ?', 
        [access_token, public_key, client_id, client_secret, redirect_url, existing.id]);
    } else {
      await db.query('INSERT INTO mercadopago_config (access_token, public_key, client_id, client_secret, redirect_url) VALUES (?, ?, ?, ?, ?)',
        [access_token, public_key, client_id, client_secret, redirect_url]);
    }
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.get('/products', async (req, res) => {
  try {
    const products = (await db.query("SELECT * FROM products"))[0];
    res.json(products);
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.post('/products', async (req, res) => {
  try {
    const { name, description, price, stock, image_url, status } = req.body;
    await db.query('INSERT INTO products (name, description, price, stock, image_url, status) VALUES (?, ?, ?, ?, ?, ?)', 
      [name, description, price, stock, image_url, status || 'active']);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.put('/products/:id', async (req, res) => {
  try {
    const { name, description, price, stock, image_url, status } = req.body;
    await db.query('UPDATE products SET name=?, description=?, price=?, stock=?, image_url=?, status=? WHERE id=?', 
      [name, description, price, stock, image_url, status, req.params.id]);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.delete('/products/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM products WHERE id=?', [req.params.id]);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});

router.post('/store/buy', async (req, res) => {
  try {
    const { userId, houseId, productId, quantity } = req.body;
    const product = (await db.query('SELECT * FROM products WHERE id = ?', [productId]))[0][0];
    if (!product || product.stock < quantity) {
      return res.status(400).json({error: 'Produto indisponível ou estoque insuficiente'});
    }
    const totalAmount = product.price * quantity;
    
    // Config MP
    const config = (await db.query('SELECT * FROM mercadopago_config LIMIT 1'))[0][0];
    
    let qr_code = '';
    let qr_code_base64 = '';
    let payment_id = '';
    
    if (config && config.access_token) {
      // Create PIX transaction in MP
      const idempotencyKey = Math.random().toString(36).substring(7);
      const mpres = await fetch('https://api.mercadopago.com/v1/payments', {
        method: 'POST',
        headers: {
          'Authorization': \`Bearer \${config.access_token}\`,
          'Content-Type': 'application/json',
          'X-Idempotency-Key': idempotencyKey
        },
        body: JSON.stringify({
          transaction_amount: Number(totalAmount),
          description: \`Pedido de \${quantity}x \${product.name}\`,
          payment_method_id: 'pix',
          payer: {
             email: 'comprador@siae.space' // mock or get user email
          }
        })
      });
      const data = await mpres.json();
      if (data.point_of_interaction?.transaction_data) {
        qr_code = data.point_of_interaction.transaction_data.qr_code;
        qr_code_base64 = data.point_of_interaction.transaction_data.qr_code_base64;
        payment_id = data.id.toString();
      }
    } else {
       // Mock for development if not configured
       qr_code = '00020126...mockpix...00000000';
       qr_code_base64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAMSURBVBhXY3jh4AMAA1sBydZ7Y/kAAAAASUVORK5CYII=';
       payment_id = 'mock_' + Math.random().toString(36).substring(7);
    }
    
    // Decrement stock
    await db.query('UPDATE products SET stock = stock - ? WHERE id = ?', [quantity, productId]);
    
    // Insert order
    const orderRaw = await db.query('INSERT INTO orders (user_id, house_id, product_id, quantity, total_amount, status, payment_id, qr_code, qr_code_base64) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
       [userId, houseId || null, productId, quantity, totalAmount, 'pending', payment_id, qr_code, qr_code_base64]);
       
    res.json({
       success: true,
       orderId: orderRaw[0].insertId || 1,
       qr_code,
       qr_code_base64,
       totalAmount
    });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});
`;

t = t.replace("export default router;", routes + "\nexport default router;");
fs.writeFileSync(file, t);
console.log('Routes added');
