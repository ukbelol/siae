#!/bin/bash

# Este script atualiza as referências do ícone genérico para a imagem real do chaveiro NFC
# nos componentes da loja já implantados na VPS.
# Execute este script a partir da pasta raiz do projeto na sua VPS.

echo "=========================================================="
echo " Atualizando imagem do chaveiro NFC no sistema SIAE..."
echo "=========================================================="

APP_DIR="/var/www/siae"

if [ ! -d "$APP_DIR/src/components" ]; then
    echo "⚠️  Não foi possível encontrar a pasta src/components em $APP_DIR."
    echo "Deseja usar a pasta atual como raiz do projeto? (S/n)"
    read -r resp
    if [ "$resp" != "n" ] && [ "$resp" != "N" ]; then
        APP_DIR=$(pwd)
    else
        exit 1
    fi
fi

cd "$APP_DIR" || exit 1

echo "Modificando src/components/StoreAd.tsx ..."
sed -i 's|<ShoppingCart className="w-16 h-16 text-indigo-400" />|<img src="/chaveiro-siae.png" alt="Chaveiro NFC SIAE" className="w-full h-full object-contain rounded-full bg-white drop-shadow-md p-1" />|g' src/components/StoreAd.tsx

echo "Modificando src/pages/Store.tsx ..."
sed -i 's|<ShoppingCart className="w-24 h-24 text-gray-400" />|<img src="/chaveiro-siae.png" alt="Chaveiro NFC SIAE" className="max-w-full h-auto object-contain drop-shadow-md rounded-lg" />|g' src/pages/Store.tsx

echo "=========================================================="
echo " Recompilando frontend para aplicar as alterações..."
echo "=========================================================="
npm run build

echo "=========================================================="
echo " Reiniciando serviço do Node (PM2)..."
echo "=========================================================="
pm2 reload process.json || pm2 restart all || systemctl restart siae || echo "Serviço não reiniciado pelo pm2/systemctl. Favor reiniciar se necessário."

echo "=========================================================="
echo " ✅ Operação concluída com sucesso! Acesse a loja para verificar."
echo "=========================================================="
