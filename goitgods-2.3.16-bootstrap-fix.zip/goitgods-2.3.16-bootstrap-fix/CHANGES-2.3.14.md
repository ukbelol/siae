# GOITGODS 2.3.15 — Unified HTTPS Asset Fix

## Correção principal
- Corrige definitivamente a divergência entre os VirtualHosts HTTP (:80) e HTTPS (:443).
- O instalador e o `repair-white-screen.sh` agora regravam explicitamente o VirtualHost SSL do GOITGODS após o Certbot, usando o mesmo `DocumentRoot`, regras SPA, MIME types e exclusão de `/assets/` do fallback.
- Impede que chunks Vite carregados por HTTPS recebam `index.html` (`Content-Type: text/html`) no lugar de JavaScript.
- Mantém `/api` em reverse proxy para 127.0.0.1:3100 também no VirtualHost SSL.

## Acumulado
Inclui as correções de usuário goitgods existente, PM2, porta 3100, rsync de src/data, ServerName global, UFW/SSH, validação HTTP/HTTPS, bootstrap de runtime e preservação de dados/configurações.
