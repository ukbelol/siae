# GOITGODS 2.3.16 — Bootstrap deployment fix

- Corrige inconsistência da 2.3.15: `index.html` solicitava `goitgods-bootstrap-2.3.15.js`, mas o pacote continha apenas `goitgods-bootstrap-2.3.14.js`.
- Bootstrap agora é publicado como `public/goitgods-bootstrap-2.3.16.js` e referenciado pelo `index.html`.
- Instalador e reparador não dependem mais de um nome de bootstrap codificado: extraem do `index.html` compilado o arquivo efetivamente referenciado e validam esse caminho.
- Mantém as correções acumuladas de Apache HTTP/HTTPS, assets Vite, PM2, porta 3100, usuário goitgods, UFW/SSH e Admin Shield.
