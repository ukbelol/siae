#!/bin/bash
echo "Resetando as credenciais do admin e reiniciando o servidor..."
node -e "
import('node:fs').then(fs => {
  const file = 'src/lib/db.ts';
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/'2149090577@Roger'/g, \"'21490905@Siae-roger-577'\");
  fs.writeFileSync(file, content);
  console.log('Arquivo editado, recarregando dev server para rodar o initDb()...');
  console.log('Credenciais atualizadas no script inicializador. Ao reiniciar o servidor a senha e o email admin@siae.space serão reconfigurados no BD.');
});
"
