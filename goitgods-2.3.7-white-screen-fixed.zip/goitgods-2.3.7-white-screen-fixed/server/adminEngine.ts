import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import mysql from 'mysql2/promise';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  AdminUser,
  SystemSettings,
  ModerationItem,
  AdminSystemStats,
  AuditLog,
  UserRole,
  UserStatus,
  ModerationStatus,
} from '../src/types';

interface StoredSuperAdmin {
  id: string;
  name: string;
  username: string;
  passwordHash: string;
  email: string;
  role: 'SUPER_ADMIN';
  status: 'ACTIVE';
  apiQuotaUsed: number;
  apiQuotaLimit: number;
  apiKey: string;
  createdAt: string;
  isConfigured: boolean;
}

class AdminEngine {
  private dataDir = path.join(process.cwd(), 'data');
  private dbPath = path.join(process.cwd(), 'data', 'system_auth.json');
  private settingsPath = path.join(process.cwd(), 'data', 'system_settings.json');
  private usersPath = path.join(process.cwd(), 'data', 'system_users.json');
  private moderationPath = path.join(process.cwd(), 'data', 'system_moderation.json');
  private logsPath = path.join(process.cwd(), 'data', 'system_logs.json');

  private superAdminData: StoredSuperAdmin | null = null;
  private supabase: SupabaseClient | null = null;
  private pool: mysql.Pool | null = null;
  private isMariaDBActive = false;

  private users: AdminUser[] = [];

  private settings: SystemSettings = {
    kgsThreshold: 0.65,
    epistemicStrictness: 0.85,
    aresAttackRigor: 'HIGH',
    hadesAutoQuarantine: true,
    maxConcurrentGods: 12,
    geminiModel: 'gemini-2.5-flash',
    maintenanceMode: false,
    mvedWeights: {
      evidence: 0.3,
      logic: 0.25,
      relevance: 0.2,
      risk: 0.15,
      consensus: 0.1,
    },
    blockedDomains: ['unverified-blog-fake.xyz', 'sensational-news-hub.net', 'spam-history-generator.io'],
    rateLimitPerMin: 120,
    microsoftFoundryApiKey: '',
    microsoftFoundryEndpoint: 'https://models.inference.ai.azure.com',
    microsoftFoundryDeployment: 'gpt-4o',
    microsoftFoundryModel: 'gpt-4o',
    pasquaredAgentModel: 'gpt-4o',
    goitgodsAgentModel: 'gpt-4o',
  };

  private moderationItems: ModerationItem[] = [];

  private auditLogs: AuditLog[] = [];

  private startTime = Date.now();
  private arbitrationsCounter = 1248;

  constructor() {
    this.initSupabase();
    // First boot must remain unconfigured until the owner creates the Super Admin.
    this.initDatabaseAndLoad();
  }

  private initSupabase() {
    const supabaseUrl = process.env.SUPABASE_URL || '';
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || '';
    if (supabaseUrl) {
      try {
        this.supabase = createClient(supabaseUrl, supabaseAnonKey);
        console.log(`[SUPABASE] Inicializado com sucesso para o projeto 'goitgods-2.0' (${supabaseUrl})`);
      } catch (err) {
        console.error('[SUPABASE] Erro ao inicializar cliente:', err);
      }
    }
  }

  private checkOneTimeReset() { /* deprecated: never reset administrator credentials automatically */ }

  private async initDatabaseAndLoad() {
    // 1. Initialize MariaDB
    const host = process.env.MARIADB_HOST || 'localhost';
    const port = parseInt(process.env.MARIADB_PORT || '3306', 10);
    const user = process.env.MARIADB_USER || 'goitgods';
    const password = process.env.MARIADB_PASSWORD || '';
    const database = process.env.MARIADB_DATABASE || 'goitgods_db';

    try {
      this.pool = mysql.createPool({
        host,
        port,
        user,
        password,
        database,
        waitForConnections: true,
        connectionLimit: 15,
        queueLimit: 0,
      });

      // Test connection
      const conn = await this.pool.getConnection();
      console.log(`[MARIADB] Conectado ao banco de dados '${database}' com sucesso.`);
      conn.release();

      await this.ensureMariaDBTables();
      this.isMariaDBActive = true;
      console.log(`[MARIADB] Tabelas e esquemas validados para o PASQUARED-OS.`);
    } catch (err: any) {
      console.warn(`[MARIADB FALLBACK] Não foi possível conectar ao MariaDB. Usando persistência JSON local:`, err.message);
      this.isMariaDBActive = false;
    }

    // 2. Load system data (From MariaDB if active, otherwise Local JSON Files)
    await this.loadAllSystemData();
  }

  private async ensureMariaDBTables() {
    if (!this.pool) return;

    const queries = [
      `CREATE TABLE IF NOT EXISTS goitgods_auth (
        id VARCHAR(100) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        username VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        api_key VARCHAR(255) NOT NULL,
        created_at VARCHAR(100) NOT NULL,
        is_configured BOOLEAN NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

      `CREATE TABLE IF NOT EXISTS goitgods_settings (
        id VARCHAR(50) PRIMARY KEY,
        settings_json LONGTEXT NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

      `CREATE TABLE IF NOT EXISTS goitgods_users (
        id VARCHAR(100) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        api_quota_used INT NOT NULL,
        api_quota_limit INT NOT NULL,
        last_active VARCHAR(100) NOT NULL,
        api_key VARCHAR(255) NOT NULL,
        created_at VARCHAR(100) NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

      `CREATE TABLE IF NOT EXISTS goitgods_moderation (
        id VARCHAR(100) PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        confidence_score DOUBLE NOT NULL,
        flag_reason TEXT,
        status VARCHAR(50) NOT NULL,
        submitted_by VARCHAR(100) NOT NULL,
        created_at VARCHAR(100) NOT NULL,
        metadata_json LONGTEXT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

      `CREATE TABLE IF NOT EXISTS goitgods_audit_logs (
        id VARCHAR(100) PRIMARY KEY,
        timestamp VARCHAR(100) NOT NULL,
        actor VARCHAR(255) NOT NULL,
        action VARCHAR(255) NOT NULL,
        target VARCHAR(255) NOT NULL,
        severity VARCHAR(50) NOT NULL,
        details TEXT NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`
    ];

    for (const q of queries) {
      await this.pool.query(q);
    }
  }

  private async loadAllSystemData() {
    try {
      if (this.isMariaDBActive && this.pool) {
        // Load Super Admin
        const [authRows]: any = await this.pool.query('SELECT * FROM goitgods_auth LIMIT 1');
        if (authRows.length > 0) {
          const row = authRows[0];
          this.superAdminData = {
            id: row.id,
            name: row.name,
            username: row.username,
            email: row.email,
            passwordHash: row.password_hash,
            role: row.role as any,
            status: row.status as any,
            apiQuotaUsed: 0,
            apiQuotaLimit: 1000000,
            apiKey: row.api_key,
            createdAt: row.created_at,
            isConfigured: !!row.is_configured,
          };
        } else {
          // If empty in MariaDB, try load from Local file and migrate
          await this.loadSuperAdminFromFile();
          if (this.superAdminData) {
            await this.saveSuperAdminToMariaDB(this.superAdminData);
          }
        }

        // Load Settings
        const [settingsRows]: any = await this.pool.query("SELECT settings_json FROM goitgods_settings WHERE id = 'global'");
        if (settingsRows.length > 0) {
          this.settings = JSON.parse(settingsRows[0].settings_json);
        } else {
          // Try load from file or save defaults
          await this.loadSettingsFromFile();
          await this.pool.query(
            "INSERT INTO goitgods_settings (id, settings_json) VALUES ('global', ?) ON CONFLICT (id) DO UPDATE SET settings_json = ?",
            [JSON.stringify(this.settings), JSON.stringify(this.settings)]
          ).catch(async () => {
            // Standard MySQL/MariaDB syntax fallback without ON CONFLICT
            await this.pool?.query(
              "INSERT INTO goitgods_settings (id, settings_json) VALUES ('global', ?) ON DUPLICATE KEY UPDATE settings_json = ?",
              [JSON.stringify(this.settings), JSON.stringify(this.settings)]
            );
          });
        }

        // Load Users
        const [userRows]: any = await this.pool.query('SELECT * FROM goitgods_users');
        if (userRows.length > 0) {
          this.users = userRows.map((row: any) => ({
            id: row.id,
            name: row.name,
            email: row.email,
            role: row.role,
            status: row.status,
            apiQuotaUsed: row.api_quota_used,
            apiQuotaLimit: row.api_quota_limit,
            lastActive: row.last_active,
            apiKey: row.api_key,
            createdAt: row.created_at,
          }));
        } else {
          // Migrate standard users
          await this.loadUsersFromFile();
          for (const u of this.users) {
            await this.saveUserToMariaDB(u);
          }
        }

        // Load Moderation Items
        const [modRows]: any = await this.pool.query('SELECT * FROM goitgods_moderation');
        if (modRows.length > 0) {
          this.moderationItems = modRows.map((row: any) => ({
            id: row.id,
            type: row.type,
            title: row.title,
            description: row.description,
            confidenceScore: row.confidence_score,
            flagReason: row.flag_reason,
            status: row.status,
            submittedBy: row.submitted_by,
            createdAt: row.created_at,
            metadata: row.metadata_json ? JSON.parse(row.metadata_json) : {},
          }));
        } else {
          await this.loadModerationFromFile();
          for (const m of this.moderationItems) {
            await this.saveModerationToMariaDB(m);
          }
        }

        // Load Audit Logs
        const [logRows]: any = await this.pool.query('SELECT * FROM goitgods_audit_logs ORDER BY timestamp DESC LIMIT 100');
        if (logRows.length > 0) {
          this.auditLogs = logRows.map((row: any) => ({
            id: row.id,
            timestamp: row.timestamp,
            actor: row.actor,
            action: row.action,
            target: row.target,
            severity: row.severity,
            details: row.details,
          }));
        } else {
          await this.loadLogsFromFile();
          for (const l of this.auditLogs) {
            await this.saveLogToMariaDB(l);
          }
        }

      } else {
        // Falling back entirely to Filesystem JSON
        await this.loadSuperAdminFromFile();
        await this.loadSettingsFromFile();
        await this.loadUsersFromFile();
        await this.loadModerationFromFile();
        await this.loadLogsFromFile();
      }

      // SECURITY: do not create default credentials. First boot remains unconfigured.

      // Sync master super admin to users memory array
      if (this.superAdminData && this.superAdminData.isConfigured) {
        const superUserObj: AdminUser = {
          id: this.superAdminData.id,
          name: this.superAdminData.name,
          email: this.superAdminData.email,
          role: 'SUPER_ADMIN',
          status: 'ACTIVE',
          apiQuotaUsed: 0,
          apiQuotaLimit: 1000000,
          lastActive: 'Agora mesmo',
          apiKey: this.superAdminData.apiKey,
          createdAt: this.superAdminData.createdAt,
        };
        this.users = [superUserObj, ...this.users.filter(u => u.role !== 'SUPER_ADMIN')];
      }
    } catch (err) {
      console.error('Erro no fluxo principal de carregamento de dados do sistema:', err);
    }
  }

  // Backup loading helpers
  private async loadSuperAdminFromFile() {
    if (fs.existsSync(this.dbPath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(this.dbPath, 'utf-8'));
        if (parsed && parsed.isConfigured) this.superAdminData = parsed;
      } catch {}
    }
  }

  private async loadSettingsFromFile() {
    if (fs.existsSync(this.settingsPath)) {
      try {
        this.settings = JSON.parse(fs.readFileSync(this.settingsPath, 'utf-8'));
      } catch {}
    }
  }

  private async loadUsersFromFile() {
    if (fs.existsSync(this.usersPath)) {
      try {
        this.users = JSON.parse(fs.readFileSync(this.usersPath, 'utf-8'));
      } catch {}
    }
  }

  private async loadModerationFromFile() {
    if (fs.existsSync(this.moderationPath)) {
      try {
        this.moderationItems = JSON.parse(fs.readFileSync(this.moderationPath, 'utf-8'));
      } catch {}
    }
  }

  private async loadLogsFromFile() {
    if (fs.existsSync(this.logsPath)) {
      try {
        this.auditLogs = JSON.parse(fs.readFileSync(this.logsPath, 'utf-8'));
      } catch {}
    }
  }

  // MariaDB direct saving adapters
  private async saveSuperAdminToMariaDB(admin: StoredSuperAdmin) {
    if (!this.pool) return;
    await this.pool.query(
      `INSERT INTO goitgods_auth (id, name, username, email, password_hash, role, status, api_key, created_at, is_configured)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE name=?, username=?, email=?, password_hash=?, role=?, status=?, api_key=?, is_configured=?`,
      [
        admin.id, admin.name, admin.username, admin.email, admin.passwordHash, admin.role, admin.status, admin.apiKey, admin.createdAt, admin.isConfigured,
        admin.name, admin.username, admin.email, admin.passwordHash, admin.role, admin.status, admin.apiKey, admin.isConfigured
      ]
    );
  }

  private async saveUserToMariaDB(user: AdminUser) {
    if (!this.pool) return;
    await this.pool.query(
      `INSERT INTO goitgods_users (id, name, email, role, status, api_quota_used, api_quota_limit, last_active, api_key, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE name=?, email=?, role=?, status=?, api_quota_used=?, api_quota_limit=?, last_active=?, api_key=?`,
      [
        user.id, user.name, user.email, user.role, user.status, user.apiQuotaUsed, user.apiQuotaLimit, user.lastActive, user.apiKey, user.createdAt,
        user.name, user.email, user.role, user.status, user.apiQuotaUsed, user.apiQuotaLimit, user.lastActive, user.apiKey
      ]
    );
  }

  private async saveModerationToMariaDB(item: ModerationItem) {
    if (!this.pool) return;
    await this.pool.query(
      `INSERT INTO goitgods_moderation (id, type, title, description, confidence_score, flag_reason, status, submitted_by, created_at, metadata_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE status=?, confidence_score=?`,
      [
        item.id, item.type, item.title, item.description, item.confidenceScore, item.flagReason, item.status, item.submittedBy, item.createdAt, JSON.stringify(item.metadata || {}),
        item.status, item.confidenceScore
      ]
    );
  }

  private async saveLogToMariaDB(log: AuditLog) {
    if (!this.pool) return;
    await this.pool.query(
      `INSERT INTO goitgods_audit_logs (id, timestamp, actor, action, target, severity, details)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE actor=?, action=?, details=?`,
      [
        log.id, log.timestamp, log.actor, log.action, log.target, log.severity, log.details,
        log.actor, log.action, log.details
      ]
    );
  }

  private hashPassword(password: string): string {
    if (password.length < 12) throw new Error('A senha do Super Admin deve possuir pelo menos 12 caracteres.');
    const salt = crypto.randomBytes(16).toString('hex');
    const derived = crypto.scryptSync(password, salt, 64).toString('hex');
    return `scrypt$${salt}$${derived}`;
  }

  private verifyPassword(password: string, stored: string): boolean {
    try {
      if (!stored.startsWith('scrypt$')) return false;
      const [, salt, expectedHex] = stored.split('$');
      const actual = crypto.scryptSync(password, salt, 64);
      const expected = Buffer.from(expectedHex, 'hex');
      return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
    } catch { return false; }
  }

  public verifyAdminToken(token: string | undefined): boolean {
    if (!token || !this.superAdminData?.isConfigured) return false;
    const a = Buffer.from(token);
    const b = Buffer.from(this.superAdminData.apiKey);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }

  public isSuperAdminSetup(): boolean {
    return !!(this.superAdminData && this.superAdminData.isConfigured);
  }

  public getSuperAdminSummary() {
    if (!this.superAdminData) return null;
    return {
      id: this.superAdminData.id,
      name: this.superAdminData.name,
      username: this.superAdminData.username,
      email: this.superAdminData.email,
      createdAt: this.superAdminData.createdAt,
    };
  }

  public setupSuperAdmin(payload: { fullName: string; username: string; passwordHash: string; email: string }) {
    if (!payload.fullName || !payload.username || !payload.passwordHash || !payload.email) {
      throw new Error('Todos os campos (Nome Completo, Usuário, Senha e E-mail) são obrigatórios.');
    }

    const newSuperAdmin: StoredSuperAdmin = {
      id: 'usr_super_admin',
      name: payload.fullName.trim(),
      username: payload.username.trim(),
      passwordHash: this.hashPassword(payload.passwordHash),
      email: payload.email.trim(),
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      apiQuotaUsed: 0,
      apiQuotaLimit: 1000000,
      apiKey: `pasq_live_super_${crypto.randomBytes(24).toString('hex')}`,
      createdAt: new Date().toISOString(),
      isConfigured: true,
    };

    // Save locally
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
    fs.writeFileSync(this.dbPath, JSON.stringify(newSuperAdmin, null, 2), 'utf-8');
    this.superAdminData = newSuperAdmin;

    // Save to MariaDB
    if (this.isMariaDBActive) {
      this.saveSuperAdminToMariaDB(newSuperAdmin).catch(err => {
        console.error('Falha ao sincronizar Super Admin no MariaDB:', err);
      });
    }

    // Update memory user list
    const superUserObj: AdminUser = {
      id: newSuperAdmin.id,
      name: newSuperAdmin.name,
      email: newSuperAdmin.email,
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      apiQuotaUsed: 0,
      apiQuotaLimit: 1000000,
      lastActive: 'Agora mesmo',
      apiKey: newSuperAdmin.apiKey,
      createdAt: newSuperAdmin.createdAt,
    };
    this.users = [superUserObj, ...this.users.filter(u => u.role !== 'SUPER_ADMIN')];

    // Audit logs
    this.addAuditLog({
      actor: `${newSuperAdmin.name} (SUPER_ADMIN)`,
      action: 'CADASTRO_INICIAL_SUPER_ADMIN',
      target: 'GOITGODS 2.1 Engine',
      severity: 'SECURITY',
      details: 'Super Admin mestre registrado com sucesso no banco de dados persistente.',
    });

    // Sincroniza Supabase
    this.syncToSupabase();

    return {
      user: superUserObj,
      token: newSuperAdmin.apiKey,
    };
  }

  public authenticate(usernameInput: string, passwordInput: string): { success: boolean; user?: AdminUser; token?: string; error?: string } {
    if (!this.superAdminData) {
      return { success: false, error: 'O sistema ainda não possui Super Admin cadastrado.' };
    }

    const cleanUser = usernameInput.trim();
    if (
      (cleanUser === this.superAdminData.username || cleanUser === this.superAdminData.email) &&
      this.verifyPassword(passwordInput, this.superAdminData.passwordHash)
    ) {
      const user = this.users.find(u => u.role === 'SUPER_ADMIN') || {
        id: this.superAdminData.id,
        name: this.superAdminData.name,
        email: this.superAdminData.email,
        role: 'SUPER_ADMIN' as const,
        status: 'ACTIVE' as const,
        apiQuotaUsed: 0,
        apiQuotaLimit: 1000000,
        lastActive: 'Agora mesmo',
        apiKey: this.superAdminData.apiKey,
        createdAt: this.superAdminData.createdAt,
      };

      this.addAuditLog({
        actor: `${user.name} (SUPER_ADMIN)`,
        action: 'SUPER_ADMIN_LOGIN',
        target: 'Painel Admin',
        severity: 'INFO',
        details: 'Autenticação realizada com sucesso.',
      });

      return {
        success: true,
        user,
        token: user.apiKey,
      };
    }

    return { success: false, error: 'Credenciais incorretas (Usuário ou Senha inválidos).' };
  }

  public getSystemStats(): AdminSystemStats {
    const uptimeSeconds = Math.floor((Date.now() - this.startTime) / 1000) + 432000;
    const activeUsersCount = this.users.filter(u => u.status === 'ACTIVE').length;

    const now = new Date();
    const latencyHistory = Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(now.getTime() - (6 - i) * 10 * 60 * 1000);
      const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      return {
        time: timeStr,
        latencyMs: Math.floor(180 + Math.sin(i + Date.now() / 10000) * 45 + Math.random() * 20),
        arbitrations: Math.floor(15 + Math.random() * 25),
      };
    });

    const roleDistribution: Record<UserRole, number> = {
      SUPER_ADMIN: this.users.filter(u => u.role === 'SUPER_ADMIN').length,
      GOD_OPERATOR: this.users.filter(u => u.role === 'GOD_OPERATOR').length,
      EVIDENCE_AUDITOR: this.users.filter(u => u.role === 'EVIDENCE_AUDITOR').length,
      STANDARD_USER: this.users.filter(u => u.role === 'STANDARD_USER').length,
    };

    return {
      uptimeSeconds,
      cpuLoadPercent: parseFloat((18.4 + Math.sin(Date.now() / 5000) * 5.2).toFixed(1)),
      memoryUsedMB: 1420 + Math.floor(Math.sin(Date.now() / 8000) * 120),
      totalMemoryMB: 8192,
      totalArbitrations: this.arbitrationsCounter,
      avgHcsScore: 0.912,
      avgLatencyMs: 214,
      activeGodAgents: 12,
      totalKnowledgeObjects: 14850,
      generatedEbooksCount: 38,
      apiCallsTotal: this.users.reduce((acc, u) => acc + u.apiQuotaUsed, 0),
      geminiTokensUsed: 4289000,
      latencyHistory,
      roleDistribution,
    };
  }

  public getUsers(): AdminUser[] {
    return this.users;
  }

  public createUser(userData: Omit<AdminUser, 'id' | 'apiKey' | 'createdAt' | 'apiQuotaUsed' | 'lastActive'>): AdminUser {
    const newUser: AdminUser = {
      id: `usr_${Math.floor(100 + Math.random() * 900)}`,
      name: userData.name,
      email: userData.email,
      role: userData.role,
      status: userData.status || 'ACTIVE',
      apiQuotaUsed: 0,
      apiQuotaLimit: userData.apiQuotaLimit || 10000,
      lastActive: 'Nunca',
      apiKey: `pasq_${userData.role.toLowerCase()}_${crypto.randomBytes(12).toString('hex')}`,
      createdAt: new Date().toISOString(),
    };

    this.users.unshift(newUser);

    // Save locally
    fs.writeFileSync(this.usersPath, JSON.stringify(this.users, null, 2), 'utf-8');

    // Save to MariaDB
    if (this.isMariaDBActive) {
      this.saveUserToMariaDB(newUser).catch(err => {
        console.error('Erro ao salvar usuário no MariaDB:', err);
      });
    }

    this.addAuditLog({
      actor: 'SUPER_ADMIN',
      action: 'CREATE_USER',
      target: `${newUser.name} (${newUser.id})`,
      severity: 'INFO',
      details: `Novo usuário criado com a função ${newUser.role} e limite de cota ${newUser.apiQuotaLimit}.`,
    });

    return newUser;
  }

  public updateUser(id: string, updates: Partial<AdminUser>): AdminUser | null {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) return null;

    const oldUser = this.users[idx];
    const updatedUser: AdminUser = { ...oldUser, ...updates };
    this.users[idx] = updatedUser;

    // Save locally
    fs.writeFileSync(this.usersPath, JSON.stringify(this.users, null, 2), 'utf-8');

    // Save to MariaDB
    if (this.isMariaDBActive) {
      this.saveUserToMariaDB(updatedUser).catch(err => {
        console.error('Erro ao atualizar usuário no MariaDB:', err);
      });
    }

    this.addAuditLog({
      actor: 'SUPER_ADMIN',
      action: 'UPDATE_USER',
      target: `${updatedUser.name} (${updatedUser.id})`,
      severity: 'INFO',
      details: `Atualização de usuário: Status=${updatedUser.status}, Função=${updatedUser.role}, Cota=${updatedUser.apiQuotaLimit}.`,
    });

    return updatedUser;
  }

  public deleteUser(id: string): boolean {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) return false;

    const deleted = this.users.splice(idx, 1)[0];

    // Save locally
    fs.writeFileSync(this.usersPath, JSON.stringify(this.users, null, 2), 'utf-8');

    // Delete in MariaDB
    if (this.isMariaDBActive && this.pool) {
      this.pool.query('DELETE FROM goitgods_users WHERE id = ?', [id]).catch(err => {
        console.error('Erro ao deletar usuário do MariaDB:', err);
      });
    }

    this.addAuditLog({
      actor: 'SUPER_ADMIN',
      action: 'DELETE_USER',
      target: `${deleted.name} (${deleted.id})`,
      severity: 'SECURITY',
      details: `Usuário removido permanentemente do sistema.`,
    });

    return true;
  }

  public generateUserToken(id: string): string | null {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) return null;

    const user = this.users[idx];
    const newKey = `pasq_${user.role.toLowerCase()}_${crypto.randomBytes(12).toString('hex')}`;
    this.users[idx].apiKey = newKey;

    // Save locally
    fs.writeFileSync(this.usersPath, JSON.stringify(this.users, null, 2), 'utf-8');

    // Save to MariaDB
    if (this.isMariaDBActive) {
      this.saveUserToMariaDB(this.users[idx]).catch(err => {
        console.error('Erro ao salvar token de usuário no MariaDB:', err);
      });
    }

    this.addAuditLog({
      actor: 'SUPER_ADMIN',
      action: 'ROTATE_API_TOKEN',
      target: `${user.name} (${user.id})`,
      severity: 'SECURITY',
      details: `Nova chave de API gerada com sucesso.`,
    });

    return newKey;
  }

  public getSettings(): SystemSettings {
    return this.settings;
  }

  public updateSettings(newSettings: Partial<SystemSettings>): SystemSettings {
    this.settings = { ...this.settings, ...newSettings };

    // Save locally
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
    fs.writeFileSync(this.settingsPath, JSON.stringify(this.settings, null, 2), 'utf-8');

    // Save to MariaDB
    if (this.isMariaDBActive && this.pool) {
      this.pool.query(
        "INSERT INTO goitgods_settings (id, settings_json) VALUES ('global', ?) ON DUPLICATE KEY UPDATE settings_json = ?",
        [JSON.stringify(this.settings), JSON.stringify(this.settings)]
      ).catch(err => {
        console.error('Erro ao salvar configurações no MariaDB:', err);
      });
    }

    this.addAuditLog({
      actor: 'SUPER_ADMIN',
      action: 'UPDATE_SYSTEM_SETTINGS',
      target: 'PASQUARED-OS Core Configuration',
      severity: 'WARN',
      details: `Configurações globais atualizadas. KGS=${this.settings.kgsThreshold}, ARES=${this.settings.aresAttackRigor}, Modelo=${this.settings.geminiModel}.`,
    });

    return this.settings;
  }

  public getModerationItems(): ModerationItem[] {
    return this.moderationItems;
  }

  public resolveModeration(id: string, action: 'APPROVE' | 'REJECT' | 'QUARANTINE'): ModerationItem | null {
    const idx = this.moderationItems.findIndex(m => m.id === id);
    if (idx === -1) return null;

    const item = this.moderationItems[idx];
    const newStatus: ModerationStatus = action === 'APPROVE' ? 'APPROVED' : action === 'REJECT' ? 'REJECTED' : 'QUARANTINED';
    item.status = newStatus;

    // Save locally
    fs.writeFileSync(this.moderationPath, JSON.stringify(this.moderationItems, null, 2), 'utf-8');

    // Save to MariaDB
    if (this.isMariaDBActive) {
      this.saveModerationToMariaDB(item).catch(err => {
        console.error('Erro ao atualizar moderação no MariaDB:', err);
      });
    }

    this.addAuditLog({
      actor: 'EVIDENCE_AUDITOR',
      action: `MODERATION_${action}`,
      target: `${item.title} (${item.id})`,
      severity: action === 'REJECT' ? 'WARN' : 'INFO',
      details: `Item de moderação classificado como ${newStatus}.`,
    });

    return item;
  }

  public addBlockedDomain(domain: string): string[] {
    const clean = domain.trim().toLowerCase();
    if (clean && !this.settings.blockedDomains.includes(clean)) {
      this.settings.blockedDomains.push(clean);
      this.updateSettings(this.settings);
      this.addAuditLog({
        actor: 'SUPER_ADMIN',
        action: 'BLOCK_DOMAIN',
        target: clean,
        severity: 'SECURITY',
        details: `Domínio adicionado à lista de bloqueio de fontes e ingestão.`,
      });
    }
    return this.settings.blockedDomains;
  }

  public removeBlockedDomain(domain: string): string[] {
    this.settings.blockedDomains = this.settings.blockedDomains.filter(d => d !== domain);
    this.updateSettings(this.settings);
    this.addAuditLog({
      actor: 'SUPER_ADMIN',
      action: 'UNBLOCK_DOMAIN',
      target: domain,
      severity: 'INFO',
      details: `Domínio removido da lista de bloqueio.`,
    });
    return this.settings.blockedDomains;
  }

  public getAuditLogs(): AuditLog[] {
    return this.auditLogs;
  }

  private addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>) {
    const newLog: AuditLog = {
      id: `log_${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      ...log,
    };
    this.auditLogs.unshift(newLog);
    if (this.auditLogs.length > 100) {
      this.auditLogs.pop();
    }

    // Save locally
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
    fs.writeFileSync(this.logsPath, JSON.stringify(this.auditLogs, null, 2), 'utf-8');

    // Save to MariaDB
    if (this.isMariaDBActive) {
      this.saveLogToMariaDB(newLog).catch(err => {
        console.error('Erro ao salvar log de auditoria no MariaDB:', err);
      });
    }
  }

  public async syncToSupabase() {
    if (!this.supabase) return;
    try {
      if (this.superAdminData) {
        const { error } = await this.supabase
          .from('goitgods_auth')
          .upsert({
            id: this.superAdminData.id,
            name: this.superAdminData.name,
            username: this.superAdminData.username,
            email: this.superAdminData.email,
            password_hash: this.superAdminData.passwordHash,
            role: this.superAdminData.role,
            status: this.superAdminData.status,
            api_key: this.superAdminData.apiKey,
            created_at: this.superAdminData.createdAt,
            is_configured: this.superAdminData.isConfigured
          }, { onConflict: 'id' });

        if (error) {
          console.warn('[SUPABASE SYNC WARNING]', error.message);
        } else {
          console.log('[SUPABASE SYNC] Super Admin sincronizado.');
        }
      }
    } catch (err: any) {
      console.warn('[SUPABASE SYNC ERROR]', err.message || err);
    }
  }
}

export const adminEngine = new AdminEngine();
