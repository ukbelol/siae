# Chamasso 2.0 — Security/WebRTC consolidation

- WebRTC P2P real na sala clássica.
- STUN/TURN configurável.
- Sessões seguras em cookie HttpOnly.
- Autorização central de Super Admin.
- WebSocket autenticado por sessão.
- scrypt para senhas e migração de hash legado.
- Remoção de credenciais embutidas no projeto.
- Persistência de histórico de mensagens por sala.
- Redis/Coturn adicionados ao instalador Debian 12.
- PM2 ajustado para uma instância enquanto o realtime estiver baseado em memória local.
- Correção da compra rápida de Pasqcoin.
