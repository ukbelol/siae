const fs = require('fs');
let file = 'src/api/index.ts';
let t = fs.readFileSync(file, 'utf8');

let before1 = "const completed = (await db.query(`\n      SELECT type FROM attendances \n      WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?\n    `, [houseId, assistedId, today])[0] as any[]).map((r: any) => r.type);";
let after1 = "const completed = ((await db.query(`\n      SELECT type FROM attendances \n      WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?\n    `, [houseId, assistedId, today]))[0] as any[]).map((r: any) => r.type);";

let before2 = "const completed = (await db.query(`\n        SELECT type FROM attendances \n        WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?\n      `, [attendance.house_id, attendance.assisted_id, today])[0] as any[]).map((r: any) => r.type);";
let after2 = "const completed = ((await db.query(`\n        SELECT type FROM attendances \n        WHERE house_id = ? AND assisted_id = ? AND status = 'completed' AND DATE(created_at) = ?\n      `, [attendance.house_id, attendance.assisted_id, today]))[0] as any[]).map((r: any) => r.type);";

if (t.includes(before1)) {
    t = t.replace(before1, after1);
} else {
    // try fallback
    t = t.replace("`, [houseId, assistedId, today])[0]", "`, [houseId, assistedId, today]))[0]");
    t = t.replace("const completed = (await db.query(`\n      SELECT", "const completed = ((await db.query(`\n      SELECT");
}

if (t.includes(before2)) {
    t = t.replace(before2, after2);
} else {
    // try fallback
    t = t.replace("`, [attendance.house_id, attendance.assisted_id, today])[0]", "`, [attendance.house_id, attendance.assisted_id, today]))[0]");
    t = t.replace("const completed = (await db.query(`\n        SELECT", "const completed = ((await db.query(`\n        SELECT");
}

fs.writeFileSync(file, t);
console.log("Replaced");
