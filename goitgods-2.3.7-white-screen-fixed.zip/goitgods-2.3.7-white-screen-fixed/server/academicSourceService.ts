import { createHash } from 'node:crypto';
import type { AcademicProviderDiagnostic, KnowledgeDomainId, SourceProvider } from '../src/types';

type SearchContext = {
  query: string;
  domain: KnowledgeDomainId;
  limit?: number;
};

type ProviderResult = { sources: SourceProvider[]; diagnostic: AcademicProviderDiagnostic };

const DOMAIN_KEYWORDS: Record<KnowledgeDomainId, string[]> = {
  MEDICINE: ['medicina','médico','medico','clínica','clinica','doença','doenca','tratamento','diagnóstico','diagnostico','saúde','saude','cardio','oncologia','neurologia','cirurgia','farmacologia'],
  LAW: ['direito','jurídico','juridico','lei','legislação','legislacao','constituição','constituicao','jurisprudência','jurisprudencia','tribunal','contrato','crime','civil','penal'],
  PSYCHOLOGY: ['psicologia','psicológico','psicologico','cognição','cognicao','comportamento','psicometria','terapia','emocional'],
  PSYCHOANALYSIS: ['psicanálise','psicanalise','freud','lacan','inconsciente','transferência','transferencia','pulsão','pulsao'],
  RADIOLOGY: ['radiologia','radiografia','tomografia','ressonância','ressonancia','ultrassom','imagem médica','imagem medica','dicom','raio-x'],
  EXACT_SCIENCES: ['matemática','matematica','física','fisica','química','quimica','estatística','estatistica','álgebra','algebra','cálculo','calculo'],
  BIOLOGICAL_SCIENCES: ['biologia','genética','genetica','ecologia','zoologia','botânica','botanica','microbiologia','bioquímica','bioquimica','evolução','evolucao'],
  ENGINEERING_TECHNOLOGY: ['engenharia','computação','computacao','informática','informatica','software','inteligência artificial','inteligencia artificial','eletrônica','eletronica','mecânica','mecanica'],
  HUMANITIES: ['história','historia','filosofia','sociologia','antropologia','literatura','linguística','linguistica','geografia'],
  EDUCATION: ['educação','educacao','pedagogia','ensino','aprendizagem','currículo','curriculo','didática','didatica'],
  ECONOMICS: ['economia','finanças','financas','mercado','contabilidade','administração','administracao','gestão','gestao'],
  GENERAL: [],
};

export class AcademicSourceService {
  public detectDomain(subjectArea: string, topic = ''): KnowledgeDomainId {
    const text = `${subjectArea} ${topic}`.toLowerCase();
    let best: KnowledgeDomainId = 'GENERAL';
    let bestScore = 0;
    for (const [domain, words] of Object.entries(DOMAIN_KEYWORDS) as [KnowledgeDomainId, string[]][]) {
      const score = words.reduce((n, w) => n + (text.includes(w) ? 1 : 0), 0);
      if (score > bestScore) { best = domain; bestScore = score; }
    }
    return best;
  }

  public async search(context: SearchContext): Promise<{ sources: SourceProvider[]; diagnostics: AcademicProviderDiagnostic[] }> {
    const providers: Promise<ProviderResult>[] = [
      this.searchCrossref(context),
      this.searchOpenAlex(context),
    ];

    if (['MEDICINE','RADIOLOGY','BIOLOGICAL_SCIENCES','PSYCHOLOGY','PSYCHOANALYSIS'].includes(context.domain)) {
      providers.push(this.searchEuropePMC(context), this.searchPubMed(context));
    }

    const settled = await Promise.all(providers);
    const merged = this.dedupe(settled.flatMap(r => r.sources));
    const ranked = merged
      .sort((a,b) => this.rank(b) - this.rank(a))
      .slice(0, Math.max(5, Math.min(context.limit || 20, 50)));
    return { sources: ranked, diagnostics: settled.map(r => r.diagnostic) };
  }

  private async searchCrossref({ query, limit = 12 }: SearchContext): Promise<ProviderResult> {
    const mailto = process.env.CROSSREF_MAILTO || process.env.RESEARCH_CONTACT_EMAIL || '';
    const url = new URL('https://api.crossref.org/works');
    url.searchParams.set('query.bibliographic', query);
    url.searchParams.set('rows', String(Math.min(limit, 20)));
    url.searchParams.set('select', 'DOI,title,author,publisher,published,URL,type,abstract,container-title,is-referenced-by-count');
    if (mailto) url.searchParams.set('mailto', mailto);
    try {
      const json = await this.fetchJson(url.toString());
      const items = json?.message?.items || [];
      const sources: SourceProvider[] = items.map((item: any, i: number) => {
        const doi = typeof item.DOI === 'string' ? item.DOI : '';
        const title = this.first(item.title) || 'Sem título';
        const publicationDate = this.crossrefDate(item.published);
        const publisher = item.publisher || this.first(item['container-title']) || 'Crossref member';
        return this.source({
          provider: 'crossref', providerId: doi || `item-${i}`, title,
          authors: (item.author || []).map((a: any) => [a.given,a.family].filter(Boolean).join(' ')).filter(Boolean),
          publisher, publicationDate,
          url: item.URL || (doi ? `https://doi.org/${doi}` : ''),
          authority: 0.88, query,
          metadata: { doi, type: item.type || '', citations: item['is-referenced-by-count'] || 0, abstract: this.stripTags(item.abstract || '') },
        });
      });
      return this.ok('Crossref', sources);
    } catch (e: any) { return this.fail('Crossref', e); }
  }

  private async searchOpenAlex({ query, limit = 12 }: SearchContext): Promise<ProviderResult> {
    const url = new URL('https://api.openalex.org/works');
    url.searchParams.set('search', query);
    url.searchParams.set('per-page', String(Math.min(limit, 20)));
    const key = process.env.OPENALEX_API_KEY;
    const mailto = process.env.OPENALEX_MAILTO || process.env.RESEARCH_CONTACT_EMAIL;
    if (key) url.searchParams.set('api_key', key);
    if (mailto) url.searchParams.set('mailto', mailto);
    try {
      const json = await this.fetchJson(url.toString());
      const sources: SourceProvider[] = (json?.results || []).map((item: any, i: number) => {
        const doiUrl = item.doi || '';
        const doi = doiUrl.replace(/^https?:\/\/(dx\.)?doi\.org\//, '');
        const location = item.primary_location || {};
        return this.source({
          provider: 'openalex', providerId: item.id || doi || `item-${i}`, title: item.display_name || item.title || 'Sem título',
          authors: (item.authorships || []).map((a: any) => a.author?.display_name).filter(Boolean),
          publisher: location.source?.display_name || item.host_venue?.display_name || 'OpenAlex source',
          publicationDate: item.publication_date || (item.publication_year ? `${item.publication_year}-01-01` : ''),
          url: doiUrl || item.id || '', authority: 0.90, query,
          metadata: { openalex_id: item.id || '', doi, cited_by_count: item.cited_by_count || 0, type: item.type || '', is_oa: item.open_access?.is_oa ?? null },
        });
      });
      return this.ok('OpenAlex', sources);
    } catch (e: any) { return this.fail('OpenAlex', e); }
  }

  private async searchEuropePMC({ query, limit = 10 }: SearchContext): Promise<ProviderResult> {
    const url = new URL('https://www.ebi.ac.uk/europepmc/webservices/rest/search');
    url.searchParams.set('query', query);
    url.searchParams.set('format', 'json');
    url.searchParams.set('pageSize', String(Math.min(limit, 20)));
    url.searchParams.set('resultType', 'core');
    try {
      const json = await this.fetchJson(url.toString());
      const sources: SourceProvider[] = (json?.resultList?.result || []).map((item: any, i: number) => {
        const doi = item.doi || '';
        const pmid = item.pmid || '';
        return this.source({
          provider: 'europepmc', providerId: item.id || pmid || doi || `item-${i}`, title: item.title || 'Sem título',
          authors: (item.authorList?.author || []).map((a: any) => a.fullName || [a.firstName,a.lastName].filter(Boolean).join(' ')).filter(Boolean),
          publisher: item.journalInfo?.journal?.title || item.journalTitle || 'Europe PMC indexed source',
          publicationDate: item.firstPublicationDate || item.dateOfPublication || (item.pubYear ? `${item.pubYear}-01-01` : ''),
          url: doi ? `https://doi.org/${doi}` : (pmid ? `https://pubmed.ncbi.nlm.nih.gov/${pmid}/` : ''), authority: 0.94, query,
          metadata: { doi, pmid, pmcid: item.pmcid || '', cited_by_count: Number(item.citedByCount || 0), abstract: item.abstractText || '', publication_type: item.pubType || '' },
        });
      });
      return this.ok('Europe PMC', sources);
    } catch (e: any) { return this.fail('Europe PMC', e); }
  }

  private async searchPubMed({ query, limit = 10 }: SearchContext): Promise<ProviderResult> {
    const base = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
    const search = new URL(`${base}esearch.fcgi`);
    search.searchParams.set('db', 'pubmed'); search.searchParams.set('term', query); search.searchParams.set('retmode', 'json');
    search.searchParams.set('retmax', String(Math.min(limit, 20)));
    if (process.env.NCBI_API_KEY) search.searchParams.set('api_key', process.env.NCBI_API_KEY);
    if (process.env.NCBI_TOOL) search.searchParams.set('tool', process.env.NCBI_TOOL);
    if (process.env.RESEARCH_CONTACT_EMAIL) search.searchParams.set('email', process.env.RESEARCH_CONTACT_EMAIL);
    try {
      const found = await this.fetchJson(search.toString());
      const ids: string[] = found?.esearchresult?.idlist || [];
      if (!ids.length) return this.ok('PubMed/NCBI', []);
      const summary = new URL(`${base}esummary.fcgi`);
      summary.searchParams.set('db', 'pubmed'); summary.searchParams.set('id', ids.join(',')); summary.searchParams.set('retmode', 'json');
      if (process.env.NCBI_API_KEY) summary.searchParams.set('api_key', process.env.NCBI_API_KEY);
      const json = await this.fetchJson(summary.toString());
      const sources: SourceProvider[] = ids.map((id, i) => {
        const item = json?.result?.[id] || {};
        const doi = (item.articleids || []).find((x: any) => x.idtype === 'doi')?.value || '';
        return this.source({
          provider: 'pubmed', providerId: id, title: item.title || 'Sem título',
          authors: (item.authors || []).map((a: any) => a.name).filter(Boolean), publisher: item.fulljournalname || item.source || 'PubMed indexed journal',
          publicationDate: this.normalizeDate(item.pubdate || ''), url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`, authority: 0.96, query,
          metadata: { pmid: id, doi, publication_types: item.pubtype || [] },
        });
      });
      return this.ok('PubMed/NCBI', sources);
    } catch (e: any) { return this.fail('PubMed/NCBI', e); }
  }

  private source(v: { provider: string; providerId: string; title: string; authors: string[]; publisher: string; publicationDate: string; url: string; authority: number; query: string; metadata: Record<string, any> }): SourceProvider {
    const publicationDate = this.normalizeDate(v.publicationDate);
    const relevance = this.relevance(v.query, `${v.title} ${v.metadata.abstract || ''}`);
    const recency = this.recency(publicationDate);
    const sourceType = v.provider === 'europepmc' ? 'europepmc' : v.provider as any;
    const id = `${v.provider}_${this.hash(v.providerId || v.title).slice(0,16)}`;
    const verifiedUrl = /^https:\/\//i.test(v.url) ? v.url : '';
    return {
      source_id: id, title: v.title.trim(), authors: v.authors.slice(0,20), publisher: v.publisher || v.provider,
      publication_date: publicationDate, url: verifiedUrl, source_type: sourceType,
      authority_score: v.authority, independence_score: 0.88, recency_score: recency, relevance_score: relevance,
      citation_metadata: { provider: v.provider, ...v.metadata }, retrieved_at: new Date().toISOString(),
      content_hash: this.hash(JSON.stringify([v.providerId,v.title,v.publisher,publicationDate])), verification_status: verifiedUrl ? 'VERIFIED' : 'UNVERIFIED',
    };
  }

  private dedupe(items: SourceProvider[]): SourceProvider[] {
    const seen = new Set<string>(); const out: SourceProvider[] = [];
    for (const s of items) {
      const doi = String(s.citation_metadata?.doi || '').toLowerCase();
      const key = doi || `${s.title.toLowerCase().replace(/\W+/g,' ').trim()}|${s.publication_date.slice(0,4)}`;
      if (!key || seen.has(key)) continue; seen.add(key); out.push(s);
    }
    const publishers = new Map<string, number>();
    out.forEach(s => publishers.set(s.publisher.toLowerCase(), (publishers.get(s.publisher.toLowerCase()) || 0) + 1));
    out.forEach(s => { const count = publishers.get(s.publisher.toLowerCase()) || 1; s.independence_score = Number(Math.max(0.55, 0.96 - (count - 1) * 0.08).toFixed(3)); });
    return out;
  }

  private rank(s: SourceProvider) { return s.relevance_score * .38 + s.authority_score * .27 + s.independence_score * .2 + s.recency_score * .15; }
  private relevance(q: string, text: string) { const a=this.tokens(q), b=new Set(this.tokens(text)); if(!a.length) return .5; return Number(Math.min(1, .2 + .8*(a.filter(x=>b.has(x)).length/a.length)).toFixed(3)); }
  private recency(date: string) { const y=Number(date.slice(0,4)); if(!y) return .6; const age=Math.max(0,new Date().getUTCFullYear()-y); return Number(Math.max(.45, 1-age*.035).toFixed(3)); }
  private tokens(s:string){return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9 ]/g,' ').split(/\s+/).filter(x=>x.length>2).slice(0,80)}
  private first(v:any){return Array.isArray(v)?String(v[0]||''):String(v||'')}
  private stripTags(v:string){return String(v||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim()}
  private normalizeDate(v:string){ const m=String(v||'').match(/(19|20)\d{2}(?:[-\/]\d{1,2})?(?:[-\/]\d{1,2})?/); if(!m) return ''; const parts=m[0].replace(/\//g,'-').split('-'); return `${parts[0]}-${String(parts[1]||'01').padStart(2,'0')}-${String(parts[2]||'01').padStart(2,'0')}`; }
  private crossrefDate(v:any){ const p=v?.['date-parts']?.[0]; return p?.[0] ? `${p[0]}-${String(p[1]||1).padStart(2,'0')}-${String(p[2]||1).padStart(2,'0')}` : ''; }
  private hash(v:string){return createHash('sha256').update(v).digest('hex')}
  private ok(provider:string,sources:SourceProvider[]):ProviderResult{return {sources,diagnostic:{provider,enabled:true,success:true,resultCount:sources.length,message:sources.length?'Consulta concluída':'Nenhum resultado'}}}
  private fail(provider:string,e:any):ProviderResult{return {sources:[],diagnostic:{provider,enabled:true,success:false,resultCount:0,message:String(e?.message||e).slice(0,220)}}}
  private async fetchJson(url:string){ const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(), Number(process.env.RESEARCH_HTTP_TIMEOUT_MS||10000)); try { const r=await fetch(url,{signal:controller.signal,headers:{'Accept':'application/json','User-Agent':`PASQUARED-GOITGODS/3.1 (${process.env.RESEARCH_CONTACT_EMAIL||'research'})`}}); if(!r.ok) throw new Error(`HTTP ${r.status} ${r.statusText}`); return await r.json(); } finally { clearTimeout(timer); } }
}

export const academicSourceService = new AcademicSourceService();
