(function(){
  'use strict';
  window.__GOITGODS_BOOTSTRAPPED__ = false;
  window.__GOITGODS_BOOT_ERRORS__ = [];
  function esc(v){ return String(v == null ? '' : v); }
  function root(){ return document.getElementById('root'); }
  function paint(title, detail){
    var r=root(); if(!r) return;
    r.innerHTML='<div style="min-height:100vh;background:#0A0A0A;color:#E0E0E0;display:flex;align-items:center;justify-content:center;font-family:monospace;padding:24px;box-sizing:border-box"><div style="width:min(760px,100%);border:1px solid #333;padding:28px"><div style="color:#FF3E00;font-weight:800;letter-spacing:.12em">GOITGODS 2.3.14</div><h2 style="font-size:18px">'+esc(title)+'</h2><pre style="white-space:pre-wrap;overflow-wrap:anywhere;color:#aaa">'+esc(detail||'')+'</pre></div></div>';
  }
  window.GOITGODS_BOOT_STAGE=function(stage){ paint('Inicializando interface…', stage); };
  window.GOITGODS_BOOT_OK=function(){ window.__GOITGODS_BOOTSTRAPPED__=true; };
  window.GOITGODS_BOOT_FAIL=function(err){
    var msg=err && (err.stack||err.message) || String(err||'erro desconhecido');
    window.__GOITGODS_BOOT_ERRORS__.push(msg);
    paint('Falha real ao iniciar a interface', msg+'\n\nEnvie esta mensagem ao administrador.');
  };
  window.addEventListener('error',function(e){ if(!window.__GOITGODS_BOOTSTRAPPED__) window.GOITGODS_BOOT_FAIL(e.error||e.message); },true);
  window.addEventListener('unhandledrejection',function(e){ if(!window.__GOITGODS_BOOTSTRAPPED__) window.GOITGODS_BOOT_FAIL(e.reason); });
  document.addEventListener('DOMContentLoaded',function(){
    if(!window.__GOITGODS_BOOTSTRAPPED__) paint('Inicializando interface…','Carregando módulo principal…');
    setTimeout(function(){ if(!window.__GOITGODS_BOOTSTRAPPED__ && window.__GOITGODS_BOOT_ERRORS__.length===0) paint('O módulo principal não confirmou a inicialização','Verifique se o bundle JavaScript principal foi executado.'); },15000);
  });
})();
