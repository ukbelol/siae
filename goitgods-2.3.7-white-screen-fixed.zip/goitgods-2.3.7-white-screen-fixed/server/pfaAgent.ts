import { FormulationState, FormulationMode, EbookDNA, CognitiveVector } from '../src/types';

export class PFAFormulationAgent {
  public createInitialState(
    query: string,
    mode: FormulationMode = 'EXPRESS',
    customAnswers: Record<string, string> = {}
  ): FormulationState {
    const isPersonalized = mode === 'PERSONALIZED';
    const isExpert = mode === 'EXPERT';

    // Calculate initial uncertainty I and FCS
    // Standard answers inferred from query
    const answers: Record<string, string> = {
      topic: query || 'História e Tecnologia Global',
      intent: customAnswers.intent || 'Pesquisa aprofundada e documentação',
      audience: customAnswers.audience || 'Público geral e leitores entusiastas',
      objective: customAnswers.objective || 'Compreender origem, desenvolvimento, causas e consequências',
      depth: customAnswers.depth || 'profundo',
      style: customAnswers.style || 'narrativo',
      tone: customAnswers.tone || 'analitico',
      length: customAnswers.length || 'medio',
      language: customAnswers.language || 'Português',
      ...customAnswers,
    };

    // Number of parameters provided vs total required parameters
    const keysCount = Object.keys(answers).length;
    const totalRequired = 15;
    const rawCompleteness = Math.min(1.0, keysCount / totalRequired);

    // FCS = 1 - (I / Imax)
    const completenessScore = isExpert ? 1.0 : (isPersonalized ? 0.65 : 0.95);

    const ebookDNA: EbookDNA = {
      topic: answers.topic,
      intent: answers.intent,
      audience: answers.audience,
      objective: answers.objective,
      language: answers.language || 'Português',
      depth: (answers.depth as any) || 'profundo',
      style: (answers.style as any) || 'narrativo',
      tone: (answers.tone as any) || 'analitico',
      length: (answers.length as any) || 'medio',
      chapterCount: parseInt(answers.chapterCount || '8', 10),
      technicality: parseFloat(answers.technicality || '0.7'),
      historicalDepth: parseFloat(answers.historicalDepth || '0.85'),
      criticalDepth: parseFloat(answers.criticalDepth || '0.75'),
      narrativeLevel: parseFloat(answers.narrativeLevel || '0.8'),
      creativityLevel: parseFloat(answers.creativityLevel || '0.6'),
      fictionLevel: parseFloat(answers.fictionLevel || '0.0'), // Default 0 fiction
      evidenceLevel: parseFloat(answers.evidenceLevel || '0.9'),
      citationLevel: parseFloat(answers.citationLevel || '0.85'),
      visualDensity: parseFloat(answers.visualDensity || '0.5'),
      sourcePolicy: 'verified_only',
      riskTolerance: 'low',
      outputFormat: (answers.outputFormat as any) || 'EPUB',
    };

    // Formula 3.5: Cognitive Vector P = [D, T, A, N, C, H, R, F, V, S]
    const cognitiveVector: CognitiveVector = {
      depth: ebookDNA.depth === 'exaustivo' ? 0.95 : (ebookDNA.depth === 'profundo' ? 0.8 : 0.5),
      technicality: ebookDNA.technicality,
      academicLevel: ebookDNA.citationLevel,
      narrativeLevel: ebookDNA.narrativeLevel,
      criticalDepth: ebookDNA.criticalDepth,
      historicalDepth: ebookDNA.historicalDepth,
      referenceRigor: ebookDNA.evidenceLevel,
      fictionFreedom: ebookDNA.fictionLevel,
      visualDensity: ebookDNA.visualDensity,
      simplicity: 1.0 - ebookDNA.technicality,
    };

    return {
      id: `pfa_${Date.now()}`,
      mode,
      completenessScore,
      ebookDNA,
      cognitiveVector,
      questionsAsked: [
        'Qual o público-alvo principal do e-book?',
        'Qual a profundidade desejada (intermediário, profundo, exaustivo)?',
        'Deseja focar na perspectiva histórica, técnica ou analítica?',
      ],
      userAnswers: answers,
      isComplete: completenessScore >= 0.8,
    };
  }
}

export const pfaAgent = new PFAFormulationAgent();
