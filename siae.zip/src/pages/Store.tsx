import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, ArrowLeft, Loader2, CheckCircle2 } from 'lucide-react';

export default function Store() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [myHouses, setMyHouses] = useState<any[]>([]);
  const [selectedHouse, setSelectedHouse] = useState<any>(null);

  const [quantities, setQuantities] = useState<Record<number, number>>({});
  const [processing, setProcessing] = useState(false);
  const [orderCode, setOrderCode] = useState<any>(null);

  useEffect(() => {
    const userStr = localStorage.getItem('siae_user');
    if (!userStr) {
      navigate('/login');
      return;
    }
    const parsedUser = JSON.parse(userStr);
    setUser(parsedUser);

    fetch('/api/products')
      .then(r => r.json())
      .then(data => {
        setProducts(data.filter((p: any) => p.status === 'active'));
        const initQ: Record<number, number> = {};
        data.forEach((p: any) => initQ[p.id] = 1);
        setQuantities(initQ);
        setLoading(false);
      });
      
    fetch(`/api/users/${parsedUser.id}/houses`)
      .then(r => r.json())
      .then((data: any[]) => {
        setMyHouses(data);
        if (data && data.length > 0) {
           setSelectedHouse(data[0].id);
        }
      });
  }, [navigate]);

  const handleCheckout = async (productId: number) => {
    if (!selectedHouse) {
      alert("Selecione sua Casa Espírita para retirar o pedido.");
      return;
    }
    try {
      setProcessing(true);
      const res = await fetch('/api/store/buy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user.id,
          houseId: selectedHouse,
          productId,
          quantity: quantities[productId] || 1
        })
      });
      
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        setProcessing(false);
      } else {
        setProcessing(false);
        setOrderCode(data);
      }
    } catch(e) {
      console.error(e);
      alert('Erro ao processar pedido');
      setProcessing(false);
    }
  };

  if (loading) return <div className="p-8 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto" /></div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white shadow relative z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button onClick={() => navigate('/dashboard')} className="text-gray-600 hover:text-indigo-600">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-indigo-700 flex items-center gap-2">
              <ShoppingCart className="w-6 h-6" />
              Loja S.I.A.E
            </h1>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {orderCode ? (
          <div className="bg-white p-8 rounded-xl shadow-md border border-gray-100 max-w-2xl mx-auto text-center">
             <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
             <h2 className="text-2xl font-bold text-gray-900 mb-2">Pedido Realizado com Sucesso!</h2>
             <p className="text-gray-600 mb-6">
                Escaneie o QR Code abaixo ou utilize o Pix Copia e Cola para realizar o pagamento.
             </p>
             <div className="bg-gray-50 p-6 rounded-lg mb-6 border border-gray-200">
                <p className="text-sm text-gray-500 mb-2">Valor Total</p>
                <p className="text-3xl font-black text-indigo-600 mb-6">R$ {Number(orderCode.totalAmount).toFixed(2)}</p>
                
                {orderCode.qr_code_base64 && (
                  <div className="flex justify-center mb-6">
                    <img src={`data:image/png;base64,${orderCode.qr_code_base64}`} alt="QR Code Pix" className="w-48 h-48 border bg-white p-2" />
                  </div>
                )}
                
                <div className="text-left">
                  <p className="text-xs text-gray-500 mb-1 font-bold">Pix Copia e Cola:</p>
                  <textarea readOnly className="w-full text-xs text-gray-700 bg-white border border-gray-300 p-2 rounded-lg h-24" value={orderCode.qr_code}></textarea>
                </div>
             </div>
             <p className="text-gray-600">
                <span className="font-bold">Retirada:</span> Lembre-se de retirar seu Chaveiro NFC na Casa Espírita selecionada após a compensação do pagamento.
             </p>
             <button onClick={() => navigate('/dashboard')} className="mt-8 bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg w-full">Voltar ao Painel</button>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto space-y-6">
            
            {products.length === 0 ? (
              <div className="bg-white p-8 rounded-xl shadow-md text-center">
                <p className="text-gray-500">Nenhum produto disponível no momento.</p>
              </div>
            ) : (
              products.map(p => (
                <div key={p.id} className="bg-white p-6 justify-between rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6">
                   <div className="md:w-1/4 flex justify-center items-center bg-gray-50 rounded-lg p-4">
                     {p.image_url ? (
                       <img src={p.image_url} alt={p.name} className="max-w-full h-auto rounded-lg" />
                     ) : (
                       <img src="/chaveiro-siae.png" alt="Chaveiro NFC SIAE" className="max-w-full h-auto object-contain drop-shadow-md rounded-lg" />
                     )}
                   </div>
                   <div className="md:w-3/4 flex flex-col justify-between">
                     <div>
                       <h3 className="text-xl font-bold text-gray-900 mb-2">{p.name}</h3>
                       <p className="text-gray-600 mb-4">{p.description}</p>
                       <p className="text-2xl font-black text-indigo-700 mb-4">R$ {Number(p.price).toFixed(2)}</p>
                     </div>
                     
                     <div className="border-t border-gray-100 pt-4 flex flex-col md:flex-row gap-4 items-end">
                        <div className="w-full md:w-1/2">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Local de Retirada (Sua Casa Espírita)</label>
                          <select 
                            value={selectedHouse || ''} 
                            onChange={(e) => setSelectedHouse(Number(e.target.value))}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500"
                          >
                            <option value="">Selecione...</option>
                            {myHouses.map(h => (
                               <option key={h.id} value={h.id}>{h.name}</option>
                            ))}
                          </select>
                        </div>
                        <div className="flex items-center gap-4 w-full md:w-auto">
                          <div className="w-24">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Qtde.</label>
                            <input 
                              type="number" 
                              min="1" 
                              max={Math.min(p.stock, 10)}
                              value={quantities[p.id] || 1}
                              onChange={(e) => setQuantities({...quantities, [p.id]: Math.min(Number(e.target.value), 10)})}
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg text-center" 
                            />
                          </div>
                          <button 
                            disabled={processing || p.stock < 1}
                            onClick={() => handleCheckout(p.id)}
                            className="flex-1 md:flex-none mt-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-lg transition-colors flex justify-center items-center h-[42px]"
                          >
                            {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Finalizar Compra'}
                          </button>
                        </div>
                     </div>
                   </div>
                </div>
              ))
            )}
            
          </div>
        )}
      </main>
    </div>
  );
}
