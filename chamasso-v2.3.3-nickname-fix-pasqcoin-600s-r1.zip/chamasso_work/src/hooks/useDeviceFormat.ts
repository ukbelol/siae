import { useState, useEffect } from 'react';
import type { ScreenFormatInfo, DeviceType, DeviceOrientation } from '../types.ts';

export function useDeviceFormat(): ScreenFormatInfo {
  const [formatInfo, setFormatInfo] = useState<ScreenFormatInfo>(() => detectDeviceFormat());

  useEffect(() => {
    const handleResize = () => {
      setFormatInfo(detectDeviceFormat());
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  return formatInfo;
}

function detectDeviceFormat(): ScreenFormatInfo {
  if (typeof window === 'undefined') {
    return {
      deviceType: 'desktop',
      orientation: 'landscape',
      is16to9: true,
      width: 1920,
      height: 1080,
      aspectRatio: 16 / 9,
      label: 'Computador / Notebook • 16:9 Widescreen',
    };
  }

  const width = window.innerWidth;
  const height = window.innerHeight;
  const aspectRatio = width / (height || 1);
  const userAgent = navigator.userAgent.toLowerCase();

  // Detecção do tipo de dispositivo
  const isMobileUA = /android|iphone|ipod|blackberry|iemobile|opera mini/i.test(userAgent);
  const isTabletUA = /ipad|tablet|(android(?!.*mobile))/i.test(userAgent);
  const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

  let deviceType: DeviceType = 'desktop';

  if (isTabletUA || (hasTouch && width >= 600 && width <= 1024 && Math.min(width, height) >= 600)) {
    deviceType = 'tablet';
  } else if (isMobileUA || (hasTouch && (width < 768 || height < 600))) {
    deviceType = 'mobile';
  } else {
    deviceType = 'desktop';
  }

  const orientation: DeviceOrientation = width >= height ? 'landscape' : 'portrait';

  // "se estiver usando pc ou notebook o site deverá carregar com formato 16:9 e se estiver usando celular na horizontal tambem deverá ser formato 16:9, mas o sistema deverá identificar se está sendo executado em computador tablet ou celular, para que a exibição do site se ajuste automaticamente"
  const is16to9 = deviceType === 'desktop' || (deviceType === 'mobile' && orientation === 'landscape');

  let label = '';
  if (deviceType === 'desktop') {
    label = 'Computador / Notebook • Formato 16:9 Widescreen';
  } else if (deviceType === 'mobile') {
    if (orientation === 'landscape') {
      label = 'Celular Horizontal • Formato 16:9 Widescreen';
    } else {
      label = 'Celular Vertical • Ajuste Automático Mobile';
    }
  } else {
    label = 'Tablet • Ajuste Automático Multi-Toque';
  }

  return {
    deviceType,
    orientation,
    is16to9,
    width,
    height,
    aspectRatio,
    label,
  };
}
