import { superAdminRegistry, type FoundryAgentConfig } from './superAdminRegistry';

export interface FoundryCreateResult {
  name: string;
  id?: string;
  version: string;
  active?: boolean;
  raw?: any;
}

class FoundryAgentService {
  private async getAccessToken() {
    const cfg = superAdminRegistry.getFoundryRuntimeConfig();
    if (!cfg.tenantId || !cfg.clientId || !cfg.clientSecret) {
      throw new Error('Configure Tenant ID, Client ID e Client Secret do Microsoft Entra ID no Super Admin.');
    }
    const body = new URLSearchParams({
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
      grant_type: 'client_credentials',
      scope: 'https://ai.azure.com/.default',
    });
    const r = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(cfg.tenantId)}/oauth2/v2.0/token`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body,
      signal: AbortSignal.timeout(15000),
    });
    const j:any = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) throw new Error(`Falha ao autenticar no Microsoft Entra ID: ${j.error_description || j.error || `HTTP ${r.status}`}`);
    return j.access_token as string;
  }

  private endpoint(agent: FoundryAgentConfig) {
    const cfg = superAdminRegistry.getFoundryRuntimeConfig();
    const endpoint = (agent.projectEndpoint || cfg.defaultProjectEndpoint || '').replace(/\/$/, '');
    if (!endpoint) throw new Error('Configure o Foundry Project Endpoint.');
    return endpoint;
  }

  private validName(input: string) {
    const normalized = input.toLowerCase().trim().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 63);
    if (!normalized) throw new Error('Nome de agente inválido.');
    return normalized;
  }

  async testConnection() {
    const token = await this.getAccessToken();
    const cfg = superAdminRegistry.getFoundryRuntimeConfig();
    const endpoint = (cfg.defaultProjectEndpoint || '').replace(/\/$/, '');
    if (!endpoint) throw new Error('Configure o Foundry Project Endpoint.');
    const r = await fetch(`${endpoint}/agents?api-version=v1`, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
    const text = await r.text();
    if (!r.ok) throw new Error(`Foundry respondeu HTTP ${r.status}: ${text.slice(0, 400)}`);
    return { ok: true, message: 'Autenticação e acesso ao projeto Foundry confirmados.' };
  }

  async createPromptAgent(localId: string, activate = true): Promise<FoundryCreateResult> {
    const agent = superAdminRegistry.getAgentRuntime(localId);
    if (!agent) throw new Error('Agente local não encontrado.');
    if (agent.agentType !== 'PROMPT_AGENT') throw new Error('Criação automática nesta versão suporta Prompt Agent. Hosted Agent exige pacote/container e fluxo de deployment próprio.');
    const cfg = superAdminRegistry.getFoundryRuntimeConfig();
    const modelDeployment = agent.modelDeployment || cfg.defaultModelDeployment;
    if (!modelDeployment) throw new Error(`Defina o deployment/modelo para ${agent.label} ou um deployment padrão.`);
    const token = await this.getAccessToken();
    const endpoint = this.endpoint(agent);
    const name = this.validName(agent.agentName || `pasquared-${agent.role.toLowerCase().replace(/_/g,'-')}`);
    const r = await fetch(`${endpoint}/agents?api-version=v1`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        name,
        definition: { kind: 'prompt', model: modelDeployment, instructions: agent.instructions || `Você é o agente ${agent.label} do PASQUARED/GOITGODS.` },
      }),
      signal: AbortSignal.timeout(30000),
    });
    const j:any = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`Falha ao criar agente ${agent.label}: ${j?.error?.message || j?.message || `HTTP ${r.status}`}`);
    const version = String(j.version ?? j.latest_version ?? j?.versions?.latest?.version ?? '1');
    const id = j.id || j.agent_id;
    superAdminRegistry.markAgentProvisioned(localId, { agentName: name, agentId: id, remoteVersion: version, remoteStatus: 'CREATED' });
    if (activate) await this.activateAgent(localId, version);
    return { name, id, version, active: activate, raw: j };
  }

  async activateAgent(localId: string, version?: string) {
    const agent = superAdminRegistry.getAgentRuntime(localId);
    if (!agent) throw new Error('Agente local não encontrado.');
    const name = agent.agentName;
    const selected = version || agent.remoteVersion;
    if (!name || !selected) throw new Error('Agente ainda não possui nome/versão no Foundry.');
    const token = await this.getAccessToken();
    const endpoint = this.endpoint(agent);
    const r = await fetch(`${endpoint}/agents/${encodeURIComponent(name)}?api-version=v1`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/merge-patch+json', Accept: 'application/json' },
      body: JSON.stringify({ agent_endpoint: { version_selector: { version_selection_rules: [{ type: 'FixedRatio', agent_version: String(selected), traffic_percentage: 100 }] } } }),
      signal: AbortSignal.timeout(20000),
    });
    const j:any = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`Falha ao ativar ${agent.label}: ${j?.error?.message || j?.message || `HTTP ${r.status}`}`);
    superAdminRegistry.markAgentProvisioned(localId, { remoteVersion: String(selected), remoteStatus: 'ACTIVE', lastPublishedAt: new Date().toISOString() });
    return { ok: true, name, version: String(selected), status: 'ACTIVE' };
  }

  async createStandardArchitecture() {
    const results:any[] = [];
    for (const a of superAdminRegistry.getAllAgentRuntime().filter(x => x.enabled && x.agentType === 'PROMPT_AGENT')) {
      try { results.push({ id: a.id, label: a.label, success: true, result: await this.createPromptAgent(a.id, true) }); }
      catch (e:any) { results.push({ id: a.id, label: a.label, success: false, error: e.message }); }
    }
    return results;
  }
}

export const foundryAgentService = new FoundryAgentService();
