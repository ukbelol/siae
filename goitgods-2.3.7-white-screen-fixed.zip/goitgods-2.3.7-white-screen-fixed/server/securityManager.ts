import { execFileSync } from 'child_process';
const run=(cmd:string,args:string[]=[])=>{try{return {ok:true,output:execFileSync(cmd,args,{encoding:'utf8',timeout:8000}).trim()}}catch(e:any){return {ok:false,output:String(e?.stdout||e?.stderr||e?.message||'erro').trim()}}};
const port=(v:any)=>{const n=Number(v);return Number.isInteger(n)&&n>0&&n<65536?n:null};
export const securityManager={
 status(){const u=run('ufw',['status','verbose']),f=run('systemctl',['is-active','fail2ban']),m=run('apache2ctl',['-M']),j=run('fail2ban-client',['status']);return {ufw:{active:/Status:\s+active/i.test(u.output),details:u.output},fail2ban:{active:f.output==='active',details:j.output||f.output},modSecurity:{active:/security2_module/i.test(m.output)},modEvasive:{active:/evasive20_module/i.test(m.output)},protections:{ddos:'UFW + mod_evasive + rate limiting',bruteForce:'Fail2ban + bloqueio de login',webAttacks:'ModSecurity/OWASP CRS',phishing:'CSP/HSTS + bloqueio de domínios; firewall isoladamente não detecta phishing'}}},
 setFirewallEnabled(enabled:boolean){const r=run('ufw',enabled?['--force','enable']:['disable']);if(!r.ok)throw Error(r.output);return this.status()},
 addPort(v:any,p='tcp'){const n=port(v),proto=String(p).toLowerCase();if(!n||!['tcp','udp'].includes(proto))throw Error('Porta/protocolo inválido');const r=run('ufw',['allow',`${n}/${proto}`]);if(!r.ok)throw Error(r.output);return this.status()},
 deletePort(v:any,p='tcp'){const n=port(v),proto=String(p).toLowerCase();if(!n||!['tcp','udp'].includes(proto))throw Error('Porta/protocolo inválido');const r=run('ufw',['--force','delete','allow',`${n}/${proto}`]);if(!r.ok)throw Error(r.output);return this.status()}
};
