const fs = require('fs');

function fixMySQLAPI(file) {
  let content = fs.readFileSync(file, 'utf8');

  // Convert db.prepare( X ).get( Y ) to (await db.query( X, [ Y ] ))[0][0]
  // In `mysql2/promise`, db.query(sql, params) returns [results, fields]
  // We need to carefully replace the patterns.

  // Restore anything we made "await db.prepare(" back to "db.prepare("
  content = content.replace(/await \(await db\.prepare\((.*?)\)\)\.(get|all|run)\((.*?)\)/gs, "db.prepare($1).$2($3)");
  content = content.replace(/await \(await db\.prepare\((.*?)\)\)\.(get|all|run)\(\)/gs, "db.prepare($1).$2()");
  content = content.replace(/await db\.prepare\(/g, "db.prepare(");
  content = content.replace(/await stmt\./g, "stmt.");
  
  // Now we have the original `db.prepare(X).get(Y)`, `db.prepare(X).run()`, etc., but with async routers.
  
  // Replace .get(Y)
  content = content.replace(/db\.prepare\(([\s\S]*?)\)\.get\(([\s\S]*?)\)/g, "(await db.query($1, [$2]))[0][0]");
  // Replace .get()
  content = content.replace(/db\.prepare\(([\s\S]*?)\)\.get\(\)/g, "(await db.query($1))[0][0]");

  // Replace .all(Y)
  content = content.replace(/db\.prepare\(([\s\S]*?)\)\.all\(([\s\S]*?)\)/g, "(await db.query($1, [$2]))[0]");
  // Replace .all()
  content = content.replace(/db\.prepare\(([\s\S]*?)\)\.all\(\)/g, "(await db.query($1))[0]");

  // Replace .run(Y)
  content = content.replace(/db\.prepare\(([\s\S]*?)\)\.run\(([\s\S]*?)\)/g, "(await db.query($1, [$2]))[0]");
  // Replace .run()
  content = content.replace(/db\.prepare\(([\s\S]*?)\)\.run\(\)/g, "(await db.query($1))[0]");

  // For unchained:
  // const stmt = db.prepare(X);
  // stmt.run(Y);
  content = content.replace(/const stmt = db\.prepare\(([\s\S]*?)\);/g, "const stmtCommand = $1;");
  content = content.replace(/stmt\.run\(([\s\S]*?)\)/g, "(await db.query(stmtCommand, [$1]))[0]");
  content = content.replace(/stmt\.get\(([\s\S]*?)\)/g, "(await db.query(stmtCommand, [$1]))[0][0]");
  content = content.replace(/stmt\.all\(([\s\S]*?)\)/g, "(await db.query(stmtCommand, [$1]))[0]");
  content = content.replace(/stmt\.run\(\)/g, "(await db.query(stmtCommand))[0]");
  content = content.replace(/stmt\.get\(\)/g, "(await db.query(stmtCommand))[0][0]");
  content = content.replace(/stmt\.all\(\)/g, "(await db.query(stmtCommand))[0]");

  content = content.replace(/info\.lastInsertRowid/g, "info.insertId");
  
  // Transactions
  // const insertParticipant = db.prepare(...)
  content = content.replace(/const insertParticipant = db\.prepare\(([\s\S]*?)\);/g, "const insertParticipantCmd = $1;");
  content = content.replace(/insertParticipant\.run\(([\s\S]*?)\)/g, "await conn.query(insertParticipantCmd, [$1])"); // Assuming conn

  content = content.replace(/const insert = db\.prepare\(([\s\S]*?)\);/g, "const insertCmd = $1;");
  content = content.replace(/insert\.run\(([\s\S]*?)\)/g, "await conn.query(insertCmd, [$1])"); // Assuming conn

  fs.writeFileSync(file, content);
}

['src/api/index.ts', 'src/api/admin.ts', 'src/lib/backup.ts'].forEach(f => fs.existsSync(f) && fixMySQLAPI(f));

console.log('Fixed');
