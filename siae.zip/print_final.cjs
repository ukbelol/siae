const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

for (let i = 710; i < 718; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 755; i < 765; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 848; i < 856; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 880; i < 895; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 997; i < 1005; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 1025; i < 1035; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 1058; i < 1064; i++) console.log(i+1, lines[i]);
console.log('---');
for (let i = 1100; i < 1110; i++) console.log(i+1, lines[i]);

