import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Heart, Users, Activity, ShieldCheck, ArrowRight, Server, Database, Lock, CheckCircle } from 'lucide-react';

const slides = [
  {
    id: 1,
    title: '',
    description: '',
    image: '/libertadores2026.png',
    duration: 60000, // 60 segundos para exibição da imagem da libertadores
  },
  {
    id: 2,
    title: '',
    description: '',
    image: '/logo.png',
    duration: 10000,
  },
  {
    id: 3,
    title: 'Sistema Integrado de Assistência Espírita',
    description: 'Conectando Casas Espíritas, Trabalhadores e Assistidos em uma plataforma única, segura e eficiente.',
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=1920',
    duration: 10000,
  },
  {
    id: 4,
    title: 'Gestão Completa para Casas Espíritas',
    description: 'Administre trabalhadores, acompanhe assistidos e organize filas de atendimento com tecnologia NFC.',
    image: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80&w=1920',
    duration: 10000,
  },
  {
    id: 5,
    title: 'Acolhimento e Triagem Humanizada',
    description: 'Acompanhamento detalhado do histórico de tratamentos, garantindo que cada assistido receba a atenção necessária.',
    image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&q=80&w=1920',
    duration: 10000,
  },
  {
    id: 6,
    title: 'Adquira Seu Chaveiro NFC de Acesso Rápido',
    description: 'Faça check-in nas filas de atendimento instantaneamente sem precisar do celular.',
    image: '/chaveiro-siae.png',
    link: '/comprar-chaveiro',
    duration: 10000,
  }
];

export default function LandingPage() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const currentDuration = slides[currentSlide]?.duration || 10000;
    const timer = setTimeout(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, currentDuration);
    return () => clearTimeout(timer);
  }, [currentSlide]);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed w-full top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="SIAE Logo" className="w-10 h-10 object-contain" onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling?.classList.remove('hidden'); }} />
            <Heart className="w-8 h-8 text-indigo-600 hidden" />
            <span className="font-bold text-xl tracking-tight text-gray-900">siae.space</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/terminal" className="text-sm font-medium text-gray-600 hover:text-indigo-600 hidden sm:block">Acesso de Terminais</Link>
            <Link to="/login" className="text-sm font-medium text-gray-600 hover:text-gray-900">Entrar</Link>
            <Link to="/register" className="text-sm font-medium bg-indigo-600 text-white px-4 py-2 rounded-full hover:bg-indigo-700 transition-colors">
              Cadastre-se
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Carousel */}
      <section className="relative h-screen pt-16 overflow-hidden bg-gray-900">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
          >
            {slides[currentSlide].id === 6 ? (
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-950 via-slate-950 to-blue-950 flex items-center justify-center z-20 px-4 sm:px-6 lg:px-8">
                <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl"></div>
                <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl"></div>
                
                <div className="max-w-6xl w-full grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center">
                  <div className="col-span-12 md:col-span-5 flex justify-center md:justify-end">
                    <motion.div 
                      initial={{ scale: 0.8, opacity: 0, y: 20 }}
                      animate={{ scale: 1, opacity: 1, y: 0 }}
                      transition={{ delay: 0.3, duration: 0.6 }}
                      className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 flex items-center justify-center"
                    >
                      <div className="absolute inset-4 bg-gradient-to-tr from-indigo-500 to-emerald-500 rounded-full blur-2xl opacity-30 animate-pulse"></div>
                      
                      <div className="relative bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 shadow-2xl flex items-center justify-center w-4/5 h-4/5 hover:scale-105 transition-transform duration-500">
                        <img 
                          src="/chaveiro-siae.png" 
                          alt="Chaveiro NFC SIAE"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain drop-shadow-[0_15px_30px_rgba(99,102,241,0.5)]"
                        />
                        <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white text-[10px] font-black px-3 py-1 rounded-full border border-emerald-400 shadow-md">
                          NFC ACTIVE
                        </div>
                      </div>
                    </motion.div>
                  </div>
                  
                  <div className="col-span-12 md:col-span-7 text-center md:text-left space-y-6">
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.3 }}
                      className="space-y-3"
                    >
                      <span className="text-emerald-400 font-extrabold tracking-widest text-xs uppercase bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20 inline-block">
                        Tecnologia a Serviço da Caridade
                      </span>
                      <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight">
                        {slides[currentSlide].title}
                      </h1>
                    </motion.div>
                    
                    <motion.p
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5 }}
                      className="text-lg text-indigo-100 max-w-2xl leading-relaxed"
                    >
                      {slides[currentSlide].description}
                    </motion.p>
                    
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.7 }}
                      className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start pt-2"
                    >
                      <Link 
                        to="/comprar-chaveiro" 
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3.5 rounded-full font-bold tracking-wide transition-all shadow-xl shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2"
                      >
                        Comprar Chaveiro <ArrowRight className="w-5 h-5" />
                      </Link>
                    </motion.div>
                  </div>
                </div>
              </div>
            ) : (
              <>
                {slides[currentSlide].image !== '/logo.png' && slides[currentSlide].image !== '/libertadores2026.png' && (
                  <div className="absolute inset-0 bg-black/50 z-10" />
                )}
                {slides[currentSlide].image === '/logo.png' || slides[currentSlide].image === '/libertadores2026.png' ? (
                  <div className="absolute inset-0 z-0 flex items-center justify-center bg-white p-4 md:p-12 lg:p-16">
                    <img
                      src={slides[currentSlide].image}
                      alt={slides[currentSlide].title || 'Slide'}
                      className="w-full h-full object-contain"
                    />
                  </div>
                ) : (
                  <img
                    src={slides[currentSlide].image}
                    alt={slides[currentSlide].title || 'Slide'}
                    className="w-full h-full object-cover"
                  />
                )}
                {slides[currentSlide].title && (
                  <div className="absolute inset-0 z-20 flex items-center justify-center text-center px-4">
                    <div className="max-w-3xl">
                      <motion.h1 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.3 }}
                        className="text-4xl md:text-6xl font-bold text-white mb-6"
                      >
                        {slides[currentSlide].title}
                      </motion.h1>
                      <motion.p 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.5 }}
                        className="text-xl text-gray-200 mb-8"
                      >
                        {slides[currentSlide].description}
                      </motion.p>
                      <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.7 }}
                        className="flex flex-col sm:flex-row gap-4 justify-center"
                      >
                        {slides[currentSlide].link ? (
                          <Link to={slides[currentSlide].link} className="bg-indigo-600 text-white px-8 py-3 rounded-full font-medium hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2">
                            Comprar Chaveiro <ArrowRight className="w-5 h-5" />
                          </Link>
                        ) : (
                          <Link to="/register" className="bg-white text-gray-900 px-8 py-3 rounded-full font-medium hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
                            Começar Agora <ArrowRight className="w-5 h-5" />
                          </Link>
                        )}
                      </motion.div>
                    </div>
                  </div>
                )}
              </>
            )}
          </motion.div>
        </AnimatePresence>
        
        {/* Carousel Indicators */}
        <div className="absolute bottom-8 left-0 right-0 z-30 flex justify-center gap-2">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`w-3 h-3 rounded-full transition-colors \${idx === currentSlide ? 'bg-white' : 'bg-white/50'}`}
            />
          ))}
        </div>
      </section>

      {/* Marketing Keychain */}
      <section className="py-24 bg-gradient-to-r from-indigo-50 to-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-indigo-100 flex flex-col md:flex-row items-center gap-12">
              <div className="w-full md:w-1/2 flex justify-center">
                  <div className="relative group">
                    <div className="absolute -inset-1 bg-gradient-to-r from-indigo-600 to-emerald-600 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                    <img src="/chaveiro-siae.png" alt="Chaveiro SIAE NFC" className="relative w-72 h-auto object-cover rounded-2xl shadow-xl transform group-hover:scale-105 transition-transform duration-300" />
                  </div>
              </div>
              <div className="w-full md:w-1/2 space-y-6 text-left">
                  <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900">Sua Chave de Acesso Rápido</h2>
                  <p className="text-lg text-gray-600">
                      Agilize sua entrada com nosso <strong>Chaveiro Tag NFC Oficial</strong>. Basta encostar no terminal da Casa Espírita para fazer check-in nas filas de atendimento instantaneamente.
                  </p>
                  <ul className="space-y-3">
                      <li className="flex items-center gap-3 text-gray-700">
                          <CheckCircle className="w-5 h-5 text-emerald-500" /> Dispensa o uso do celular no momento do check-in
                      </li>
                      <li className="flex items-center gap-3 text-gray-700">
                          <CheckCircle className="w-5 h-5 text-emerald-500" /> Entrada prioritária em filas configuradas
                      </li>
                      <li className="flex items-center gap-3 text-gray-700">
                          <CheckCircle className="w-5 h-5 text-emerald-500" /> Design elegante e durável
                      </li>
                  </ul>
                  <div className="pt-4 flex flex-col sm:flex-row gap-4">
                     <Link to="/comprar-chaveiro" className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 shadow-lg shadow-indigo-600/30 transition-all">
                       Adquirir Agora
                     </Link>
                  </div>
              </div>
            </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Funcionalidades do Sistema</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">Uma plataforma completa para atender as necessidades de todos os envolvidos no trabalho de assistência espiritual.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600 mb-6">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Casas Espíritas</h3>
              <p className="text-gray-600">Gestão completa de trabalhadores, assistidos, cursos e serviços. Painel de controle para acompanhamento de filas e atendimentos.</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 mb-6">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Trabalhadores</h3>
              <p className="text-gray-600">Check-in via NFC, acesso ao histórico de assistidos, registro de tratamentos e organização de disponibilidade.</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 mb-6">
                <Activity className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Assistidos</h3>
              <p className="text-gray-600">Localização de casas próximas, solicitação de triagem, acompanhamento de tratamento e check-in em filas digitais.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-24 bg-white border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Tecnologia e Infraestrutura</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">O S.I.A.E foi projetado para ser robusto, seguro e fácil de implantar.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
             <div className="flex flex-col items-center text-center">
              <Server className="w-12 h-12 text-gray-400 mb-4" />
              <h4 className="text-lg font-bold text-gray-900">Debian 12 & Apache2</h4>
              <p className="text-sm text-gray-500 mt-2">Compatibilidade total com servidores Linux Debian 12, utilizando Apache2 como proxy reverso com Virtual Hosts padronizados.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <Lock className="w-12 h-12 text-gray-400 mb-4" />
              <h4 className="text-lg font-bold text-gray-900">SSL/TLS Automático</h4>
              <p className="text-sm text-gray-500 mt-2">Segurança garantida com criptografia ponta a ponta e certificados SSL/TLS renovados automaticamente.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <Database className="w-12 h-12 text-gray-400 mb-4" />
              <h4 className="text-lg font-bold text-gray-900">MariaDB Persistente</h4>
              <p className="text-sm text-gray-500 mt-2">Banco de dados MariaDB com schema flexível, garantindo segurança e integridade de dados para ambientes de alta performance.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 text-gray-400 py-12 text-center text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
          <div className="max-w-3xl text-center mb-8 space-y-4">
            <div>
              <h5 className="text-gray-300 font-semibold mb-2">Sobre o Autor</h5>
              <p className="text-gray-500">Rogério Gomes dos Santos, nascido em 05 de maio de 1977 na cidade de Osasco, São Paulo, Brasil. Graduado em Bacharelado em Sistemas de Informação pela instituição Unifieo - Osasco em 2010.</p>
            </div>
            <div>
              <h5 className="text-gray-300 font-semibold mb-2">Dedicatória</h5>
              <p className="text-gray-500 italic">Dedico esta obra primeiramente ao Deus criador, e a todos os anjos e santos, e também aos meus pais: Minha Mãe Terezinha Gomes Pereira, e ao meu pai, Antônio Manoel dos Santos.</p>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-4">
            <div className="flex gap-4 mb-2">
              <Link to="/termos" className="text-gray-400 hover:text-white transition-colors">
                Termos de Compromisso
              </Link>
              <span className="text-gray-700">|</span>
              <Link to="/privacidade" className="text-gray-400 hover:text-white transition-colors">
                Política de Privacidade
              </Link>
            </div>
            <p className="mb-4 text-gray-600 border-t border-gray-800 pt-4 px-12">&copy; {new Date().getFullYear()} S.I.A.E - Sistema Integrado de Assistência Espírita.</p>
            <Link to="/loginsupersu" className="text-gray-600 hover:text-white text-xs font-medium px-4 py-2 flex items-center gap-2 border border-gray-800 rounded-md hover:bg-gray-800 transition-colors mt-2">
              <Lock className="w-3 h-3" />
              Área Restrita
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
