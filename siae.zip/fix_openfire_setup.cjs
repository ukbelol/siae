const fs = require('fs');

let s = fs.readFileSync('install-geral.sh', 'utf8');

const setupOpenfireXML = `
echo "Automatizando o Setup do Openfire..."
cat > /etc/openfire/openfire.xml << 'XML_EOF'
<?xml version="1.0" encoding="UTF-8"?>
<jive>
  <adminConsole>
    <port>9090</port>
    <securePort>9091</securePort>
  </adminConsole>
  <locale>pt_BR</locale>
  <connectionProvider>
    <className>org.jivesoftware.database.DefaultConnectionProvider</className>
  </connectionProvider>
  <database>
    <defaultProvider>
      <driver>com.mysql.cj.jdbc.Driver</driver>
      <serverURL>jdbc:mysql://localhost:3306/openfire?rewriteBatchedStatements=true&amp;characterEncoding=UTF-8&amp;characterSetResults=UTF-8&amp;serverTimezone=UTC</serverURL>
      <username>openfire_user</username>
      <password>openfire_password</password>
      <minConnections>5</minConnections>
      <maxConnections>25</maxConnections>
      <connectionTimeout>1.0</connectionTimeout>
    </defaultProvider>
  </database>
  <setup>true</setup>
</jive>
XML_EOF

# Inicializa as tabelas do banco
mysql -uopenfire_user -popenfire_password openfire < /usr/share/openfire/resources/database/openfire_mysql.sql || true

# Configura o dominio e senha admin
mysql -uopenfire_user -popenfire_password openfire << 'SQL_EOF'
INSERT IGNORE INTO ofProperty (name, propValue) VALUES ('xmpp.domain', '\\$\\{DOMAIN\\}');
INSERT IGNORE INTO ofProperty (name, propValue) VALUES ('setup', 'true');
INSERT IGNORE INTO ofUser (username, plainPassword, name, email, creationDate, modificationDate) VALUES ('admin', 'siaeadmin123', 'Administrator', 'admin@\\$\\{DOMAIN\\}', '0', '0');
SQL_EOF

chown openfire:openfire /etc/openfire/openfire.xml
`;

// Insert the setup sequence before "systemctl restart openfire"
s = s.replace('systemctl restart openfire || true', setupOpenfireXML + '\n\nsystemctl restart openfire || true');

fs.writeFileSync('install-geral.sh', s);
