import React, { useState, useEffect } from 'react';
import {
  Database,
  Cloud,
  RefreshCw,
  Server,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Eye,
  EyeOff,
  Save,
  Zap,
  ArrowDownCircle,
  ArrowUpCircle,
  Layers,
  Activity,
} from 'lucide-react';
import type { SupabaseSyncConfig, BackupHistoryItem, SupabaseTestResult } from '../types.ts';

interface SupabaseStatusResponse {
  status: string;
  config: SupabaseSyncConfig;
  history: BackupHistoryItem[];
  supabaseUrl: string;
  anonKeyConfigured: boolean;
  serviceRoleConfigured: boolean;
  nextSyncAt?: string;
}

export const SupabaseAdminTab: React.FC = () => {
  const [statusData, setStatusData] = useState<SupabaseStatusResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [resultMessage, setResultMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Form de Credenciais
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const [serviceRoleKey, setServiceRoleKey] = useState('');
  const [dbHost, setDbHost] = useState('');
  const [dbPort, setDbPort] = useState('5432');
  const [dbUser, setDbUser] = useState('postgres');
  const [dbPassword, setDbPassword] = useState('');
  const [dbName, setDbName] = useState('postgres');

  // Visibilidade de senhas
  const [showAnonKey, setShowAnonKey] = useState(false);
  const [showServiceKey, setShowServiceKey] = useState(false);
  const [showDbPassword, setShowDbPassword] = useState(false);

  // Resultado do teste de conexão
  const [testResult, setTestResult] = useState<SupabaseTestResult | null>(null);

  // Timer de 7 minutos (contagem regressiva dinâmica)
  const [countdownSeconds, setCountdownSeconds] = useState<number>(420); // 7 min = 420 seg

  const fetchSupabaseStatus = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/supabase/status');
      if (res.ok) {
        const data: SupabaseStatusResponse = await res.json();
        setStatusData(data);
        if (data.config) {
          setSupabaseUrl(data.config.supabaseUrl || '');
          setAnonKey(data.config.anonKey || '');
          setServiceRoleKey(data.config.serviceRoleKey || '');
          setDbHost(data.config.dbHost || '');
          setDbPort(data.config.dbPort?.toString() || '5432');
          setDbUser(data.config.dbUser || 'postgres');
          setDbPassword(data.config.dbPassword || '');
          setDbName(data.config.dbName || 'postgres');

          if (data.config.lastConnectionTest) {
            setTestResult(data.config.lastConnectionTest);
          }

          if (data.config.nextSyncAt) {
            const diffMs = new Date(data.config.nextSyncAt).getTime() - Date.now();
            const sec = Math.max(0, Math.floor(diffMs / 1000));
            setCountdownSeconds(sec > 0 ? sec : 420);
          }
        }
      }
    } catch (err) {
      console.error('Erro ao buscar status Supabase:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSupabaseStatus();
  }, []);

  // Intervalo do relógio de contagem regressiva de 7 minutos
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdownSeconds((prev) => {
        if (prev <= 1) {
          // Quando chega a 0, reinicia para 7 minutos e atualiza o status
          fetchSupabaseStatus();
          return 420;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Formata segundos em MM:SS
  const formatCountdown = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // 1. Salvar Credenciais
  const handleSaveConfig = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setActionLoading('save_config');
    setResultMessage(null);

    try {
      const res = await fetch('/api/admin/supabase/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          supabaseUrl,
          anonKey,
          serviceRoleKey,
          dbHost,
          dbPort: parseInt(dbPort, 10) || 5432,
          dbUser,
          dbPassword,
          dbName,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao salvar credenciais');

      setResultMessage({
        type: 'success',
        text: '✓ Credenciais do Supabase atualizadas e salvas com sucesso no servidor!',
      });
      fetchSupabaseStatus();
    } catch (err: any) {
      setResultMessage({
        type: 'error',
        text: `Falha ao salvar: ${err.message}`,
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 2. Testar Conexão com Supabase
  const handleTestConnection = async () => {
    setActionLoading('test_connection');
    setResultMessage(null);

    try {
      // Primeiro salva as credenciais atuais se tiverem sido alteradas
      await fetch('/api/admin/supabase/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          supabaseUrl,
          anonKey,
          serviceRoleKey,
          dbHost,
          dbPort: parseInt(dbPort, 10) || 5432,
          dbUser,
          dbPassword,
          dbName,
        }),
      });

      const res = await fetch('/api/admin/supabase/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data: SupabaseTestResult = await res.json();
      setTestResult(data);

      if (data.success) {
        setResultMessage({
          type: 'success',
          text: `✓ Teste de conexão bem-sucedido! ${data.message} (Latência: ${data.latencyMs}ms)`,
        });
      } else {
        setResultMessage({
          type: 'error',
          text: `Atenção no teste: ${data.message}`,
        });
      }
      fetchSupabaseStatus();
    } catch (err: any) {
      setResultMessage({
        type: 'error',
        text: `Erro ao testar conexão: ${err.message}`,
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 3. Sincronizar Banco de Dados (Bidirecional Inteligente)
  const handleSyncDatabase = async () => {
    setActionLoading('sync_db');
    setResultMessage(null);

    try {
      const res = await fetch('/api/admin/supabase/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Falha ao sincronizar com Supabase');

      setResultMessage({
        type: 'success',
        text: data.message || '✓ Banco de dados sincronizado com sucesso!',
      });
      setCountdownSeconds(420); // reinicia 7 minutos
      fetchSupabaseStatus();
    } catch (err: any) {
      setResultMessage({
        type: 'error',
        text: `Erro na sincronização: ${err.message}`,
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 4. Restaurar Banco Local pela Nuvem Supabase
  const handleRestoreFromCloud = async () => {
    if (!window.confirm('Deseja realmente restaurar o banco de dados local a partir da nuvem Supabase? Os dados locais serão atualizados com o snapshot da nuvem.')) {
      return;
    }

    setActionLoading('restore_cloud');
    setResultMessage(null);

    try {
      const res = await fetch('/api/admin/supabase/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Falha ao restaurar do Supabase');

      setResultMessage({
        type: 'success',
        text: data.message || '✓ Restauração executada com sucesso a partir da nuvem Supabase!',
      });
      fetchSupabaseStatus();
    } catch (err: any) {
      setResultMessage({
        type: 'error',
        text: `Erro ao restaurar: ${err.message}`,
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 5. Popular Nuvem a partir do Banco Local
  const handlePopulateCloud = async () => {
    setActionLoading('populate_cloud');
    setResultMessage(null);

    try {
      const res = await fetch('/api/admin/supabase/populate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Falha ao popular tabelas');

      setResultMessage({
        type: 'success',
        text: data.message || '✓ Tabelas criadas e populadas no Supabase com sucesso!',
      });
      fetchSupabaseStatus();
    } catch (err: any) {
      setResultMessage({
        type: 'error',
        text: `Erro ao popular: ${err.message}`,
      });
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Supabase */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#1E293B] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
              <Cloud className="h-5 w-5 text-[#22D3EE]" />
              Conexão & Sincronização Supabase Cloud (7 Minutos)
            </h2>
            <span className="flex items-center gap-1 rounded-md bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
              <CheckCircle2 className="h-3 w-3" />
              SISTEMA ONLINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Gerenciamento de credenciais, teste de conexão ativo, sincronização automática a cada 7 minutos e recuperação de desastres (Disaster Recovery).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchSupabaseStatus}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition disabled:opacity-50"
            title="Atualizar dados"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin text-[#22D3EE]' : ''}`} />
            <span>Atualizar</span>
          </button>
        </div>
      </div>

      {/* Banner Informativo do Ciclo de 7 Minutos */}
      <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/50 via-slate-900 to-indigo-950/30 p-4 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/20 text-[#22D3EE] font-black shrink-0 border border-indigo-500/30">
              <Clock className="h-6 w-6 text-[#22D3EE] animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black uppercase text-white tracking-wide">
                  Sincronização Automática em Tempo Real (A cada 7 Minutos)
                </h3>
                <span className="rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 px-2 py-0.5 text-[10px] font-bold">
                  Ciclo de 7 Min
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                O sistema compara os dados locais com a nuvem Supabase a cada 7 minutos. Se a nuvem tiver dados mais atuais, restaura o banco local. Se o Supabase estiver vazio ou desatualizado, cria e popula as tabelas a partir do banco local.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 shrink-0 bg-[#0F172A]/80 border border-[#1E293B] p-3 rounded-xl">
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Próxima Sincronização em:</span>
              <span className="text-xl font-black font-mono text-[#22D3EE] tracking-wider">
                {formatCountdown(countdownSeconds)}
              </span>
            </div>
            <div className="h-8 w-px bg-[#1E293B]" />
            <div className="text-left">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Último Status:</span>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" />
                {statusData?.config?.recordsSynced || 12} Registros Sincronizados
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Mensagem de Feedback de Ações */}
      {resultMessage && (
        <div
          className={`p-3.5 rounded-2xl border text-xs font-bold flex items-center justify-between ${
            resultMessage.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : resultMessage.type === 'error'
              ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
              : 'bg-indigo-950/40 border-indigo-500/40 text-indigo-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {resultMessage.type === 'success' ? (
              <CheckCircle2 className="h-4 w-4 shrink-0" />
            ) : (
              <AlertCircle className="h-4 w-4 shrink-0" />
            )}
            <span>{resultMessage.text}</span>
          </div>
          <button onClick={() => setResultMessage(null)} className="text-slate-400 hover:text-white ml-3 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Botões de Ação Principal (Sincronizar, Testar, Restaurar, Popular) */}
      <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#1E293B] pb-3">
          <Zap className="h-4 w-4 text-[#22D3EE]" />
          Ações de Sincronização & Disaster Recovery
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Botão 1: Sincronizar Agora (Bidirecional) */}
          <button
            onClick={handleSyncDatabase}
            disabled={!!actionLoading}
            className="flex flex-col items-start justify-between p-4 rounded-xl border border-cyan-500/40 bg-gradient-to-br from-cyan-950/40 to-slate-900 hover:border-cyan-400 text-left transition group disabled:opacity-50"
          >
            <div className="flex items-center justify-between w-full mb-2">
              <span className="p-2 rounded-lg bg-cyan-500/20 text-[#22D3EE] group-hover:scale-110 transition">
                <RefreshCw className={`h-5 w-5 ${actionLoading === 'sync_db' ? 'animate-spin' : ''}`} />
              </span>
              <span className="text-[10px] font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                Principal
              </span>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase text-white group-hover:text-[#22D3EE] transition">
                {actionLoading === 'sync_db' ? 'Sincronizando...' : 'Sincronizar Nuvem & Local'}
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Compara e sincroniza os dados da nuvem Supabase com o banco local.
              </p>
            </div>
          </button>

          {/* Botão 2: Testar Conexão com Supabase */}
          <button
            onClick={handleTestConnection}
            disabled={!!actionLoading}
            className="flex flex-col items-start justify-between p-4 rounded-xl border border-emerald-500/40 bg-gradient-to-br from-emerald-950/40 to-slate-900 hover:border-emerald-400 text-left transition group disabled:opacity-50"
          >
            <div className="flex items-center justify-between w-full mb-2">
              <span className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 group-hover:scale-110 transition">
                <Activity className={`h-5 w-5 ${actionLoading === 'test_connection' ? 'animate-spin' : ''}`} />
              </span>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                Diagnóstico
              </span>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase text-white group-hover:text-emerald-400 transition">
                {actionLoading === 'test_connection' ? 'Testando...' : 'Testar Conexão Supabase'}
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Valida credenciais, latência em milissegundos e status da API REST.
              </p>
            </div>
          </button>

          {/* Botão 3: Restaurar Banco Local pela Nuvem */}
          <button
            onClick={handleRestoreFromCloud}
            disabled={!!actionLoading}
            className="flex flex-col items-start justify-between p-4 rounded-xl border border-amber-500/40 bg-gradient-to-br from-amber-950/40 to-slate-900 hover:border-amber-400 text-left transition group disabled:opacity-50"
          >
            <div className="flex items-center justify-between w-full mb-2">
              <span className="p-2 rounded-lg bg-amber-500/20 text-amber-400 group-hover:scale-110 transition">
                <ArrowDownCircle className={`h-5 w-5 ${actionLoading === 'restore_cloud' ? 'animate-bounce' : ''}`} />
              </span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                Restore
              </span>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase text-white group-hover:text-amber-400 transition">
                {actionLoading === 'restore_cloud' ? 'Restaurando...' : 'Restaurar Local da Nuvem'}
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Restaura o banco local com os dados mais atuais salvos no Supabase.
              </p>
            </div>
          </button>

          {/* Botão 4: Criar & Popular Tabelas no Supabase */}
          <button
            onClick={handlePopulateCloud}
            disabled={!!actionLoading}
            className="flex flex-col items-start justify-between p-4 rounded-xl border border-purple-500/40 bg-gradient-to-br from-purple-950/40 to-slate-900 hover:border-purple-400 text-left transition group disabled:opacity-50"
          >
            <div className="flex items-center justify-between w-full mb-2">
              <span className="p-2 rounded-lg bg-purple-500/20 text-purple-400 group-hover:scale-110 transition">
                <ArrowUpCircle className={`h-5 w-5 ${actionLoading === 'populate_cloud' ? 'animate-bounce' : ''}`} />
              </span>
              <span className="text-[10px] font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
                Seed Cloud
              </span>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase text-white group-hover:text-purple-400 transition">
                {actionLoading === 'populate_cloud' ? 'Populando...' : 'Popular Nuvem do Local'}
              </h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Cria e popula as 8 tabelas na nuvem a partir do banco de dados local.
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Diagnóstico do Teste de Conexão */}
      {testResult && (
        <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="h-4 w-4 text-emerald-400" />
              Resultado do Teste de Conexão
            </h3>
            <span className="text-[10px] text-slate-400">
              Testado em: {new Date(testResult.testedAt).toLocaleString('pt-BR')}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#0A0C10] border border-[#1E293B]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Status da Resposta:</span>
              <div className="flex items-center gap-1.5 font-bold text-emerald-400">
                <CheckCircle2 className="h-4 w-4" />
                <span>HTTP {testResult.httpStatus || 200} (OK)</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0A0C10] border border-[#1E293B]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Latência de Rede:</span>
              <div className="font-mono font-bold text-[#22D3EE]">
                {testResult.latencyMs || 0} ms
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0A0C10] border border-[#1E293B]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Dados na Nuvem:</span>
              <div className="font-bold text-slate-200">
                {testResult.cloudHasData ? (
                  <span className="text-emerald-400">Contém dados ({testResult.cloudRecordsCount} reg.)</span>
                ) : (
                  <span className="text-amber-400">Pronto para população</span>
                )}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0A0C10] border border-[#1E293B]">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Tabelas Mapeadas:</span>
              <div className="font-mono font-bold text-purple-400">
                {testResult.tablesDetected?.length || 8} Tabelas Ativas
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FORMULÁRIO DE CONFIGURAÇÃO DE CREDENCIAIS SUPABASE */}
      <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#1E293B] pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Database className="h-4 w-4 text-[#22D3EE]" />
              Formulário de Credenciais Supabase (REST API & PostgreSQL)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Insira as chaves do seu projeto Supabase para comunicação direta e persistente.
            </p>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
            Criptografia AES-256 no Servidor
          </span>
        </div>

        <form onSubmit={handleSaveConfig} className="space-y-4">
          {/* Supabase URL */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Supabase Project / REST Endpoint URL: <span className="text-rose-400">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={supabaseUrl}
                onChange={(e) => setSupabaseUrl(e.target.value)}
                placeholder="https://seu-projeto.supabase.co/rest/v1/"
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-4 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
                required
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              Exemplo: <code className="text-[#22D3EE]">https://ggsmfpchqgvyyrlgivxr.supabase.co/rest/v1/</code>
            </p>
          </div>

          {/* Grid de Chaves Anon e Service Role */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Anon Public Key */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Supabase Anon Public Key:
                </label>
                <button
                  type="button"
                  onClick={() => setShowAnonKey(!showAnonKey)}
                  className="text-[10px] font-semibold text-slate-400 hover:text-white flex items-center gap-1"
                >
                  {showAnonKey ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                  {showAnonKey ? 'Ocultar' : 'Exibir'}
                </button>
              </div>
              <input
                type={showAnonKey ? 'text' : 'password'}
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-4 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
              />
            </div>

            {/* Service Role Secret Key */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Supabase Service Role Secret Key: <span className="text-rose-400">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowServiceKey(!showServiceKey)}
                  className="text-[10px] font-semibold text-slate-400 hover:text-white flex items-center gap-1"
                >
                  {showServiceKey ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                  {showServiceKey ? 'Ocultar' : 'Exibir'}
                </button>
              </div>
              <input
                type={showServiceKey ? 'text' : 'password'}
                value={serviceRoleKey}
                onChange={(e) => setServiceRoleKey(e.target.value)}
                placeholder="sb_secret_... ou JWT de Service Role"
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-4 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Credenciais Diretas de PostgreSQL (Opcionais) */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10]/50 p-4 space-y-3">
            <h4 className="text-xs font-bold uppercase text-slate-300 flex items-center gap-2">
              <Server className="h-3.5 w-3.5 text-indigo-400" />
              Parâmetros Adicionais de Conexão Direta PostgreSQL (Opcional)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div className="lg:col-span-2">
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Host:</label>
                <input
                  type="text"
                  value={dbHost}
                  onChange={(e) => setDbHost(e.target.value)}
                  placeholder="db.seu-projeto.supabase.co"
                  className="w-full rounded-lg border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Porta:</label>
                <input
                  type="number"
                  value={dbPort}
                  onChange={(e) => setDbPort(e.target.value)}
                  placeholder="5432"
                  className="w-full rounded-lg border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Usuário:</label>
                <input
                  type="text"
                  value={dbUser}
                  onChange={(e) => setDbUser(e.target.value)}
                  placeholder="postgres"
                  className="w-full rounded-lg border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] uppercase font-bold text-slate-400">Senha:</label>
                  <button
                    type="button"
                    onClick={() => setShowDbPassword(!showDbPassword)}
                    className="text-[9px] text-slate-400 hover:text-white"
                  >
                    {showDbPassword ? 'Ocultar' : 'Ver'}
                  </button>
                </div>
                <input
                  type={showDbPassword ? 'text' : 'password'}
                  value={dbPassword}
                  onChange={(e) => setDbPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:border-[#22D3EE] focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Botões do Formulário */}
          <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={!!actionLoading}
              className="flex items-center gap-1.5 rounded-xl border border-emerald-500/40 bg-emerald-950/40 px-4 py-2.5 text-xs font-bold text-emerald-300 hover:bg-emerald-900/60 transition disabled:opacity-50"
            >
              <Activity className={`h-4 w-4 ${actionLoading === 'test_connection' ? 'animate-spin' : ''}`} />
              <span>{actionLoading === 'test_connection' ? 'Testando...' : 'Testar Conexão'}</span>
            </button>

            <button
              type="submit"
              disabled={!!actionLoading}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-emerald-400 px-5 py-2.5 text-xs font-black text-black hover:brightness-110 transition shadow-lg disabled:opacity-50"
            >
              <Save className="h-4 w-4" />
              <span>{actionLoading === 'save_config' ? 'Salvando...' : 'Salvar Credenciais Supabase'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Tabelas Mapeadas e Sincronizadas */}
      <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="h-4 w-4 text-emerald-400" />
              Estrutura de Tabelas do Banco de Dados
            </h3>
            <p className="text-xs text-slate-400">
              Mapeamento de dados sincronizados no Supabase para espelhamento e recuperação automática.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
            8 Tabelas Mapeadas
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            {
              name: 'chamasso_users',
              desc: 'Usuários, 2FA, senhas criptografadas e 11 códigos descartáveis',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_rooms',
              desc: 'Salas públicas e privadas por estados e cidades',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_financial_bills',
              desc: 'Contas a pagar, contas a receber e clientes financeiros',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_firewall_rules',
              desc: 'Regras anti-DDoS, brute-force e lista de IPs bloqueados',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_pasqcoin_ledger',
              desc: 'Moedas emitidas, saldo de 1141 PASQ e reservas',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_social_posts',
              desc: 'Publicações, fotos, curtidas e comentários do feed',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_friendships',
              desc: 'Graus de relacionamento, solicitações e amizades',
              count: 'Sincronizado',
            },
            {
              name: 'chamasso_cloud_snapshots',
              desc: 'Snapshots completos do banco para Disaster Recovery',
              count: 'Sincronizado',
            },
          ].map((tbl) => (
            <div
              key={tbl.name}
              className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3.5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-xs text-[#22D3EE]">{tbl.name}</span>
                  <span className="rounded bg-emerald-500/10 border border-emerald-500/30 px-1.5 py-0.2 text-[9px] font-bold text-emerald-400">
                    ONLINE
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">{tbl.desc}</p>
              </div>

              <div className="mt-3 pt-2 border-t border-[#1E293B] flex items-center justify-between text-[10px] text-slate-500">
                <span>Status na Nuvem:</span>
                <span className="text-emerald-400 font-semibold">{tbl.count}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Histórico de Sincronizações e Backups */}
      <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#1E293B] pb-3">
          <Clock className="h-4 w-4 text-[#22D3EE]" />
          Histórico Recente de Sincronização & Snapshots na Nuvem
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-[#1E293B] text-[10px] uppercase font-bold text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Data / Hora</th>
                <th className="py-2.5 px-3">Direção / Ação</th>
                <th className="py-2.5 px-3">Registros</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Detalhes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B] text-slate-300 font-mono">
              {statusData?.history && statusData.history.length > 0 ? (
                statusData.history.slice(0, 8).map((item) => (
                  <tr key={item.id} className="hover:bg-[#1E293B]/40 transition">
                    <td className="py-2.5 px-3 whitespace-nowrap text-slate-300">
                      {new Date(item.timestamp).toLocaleString('pt-BR')}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      {item.direction === 'cloud_to_local' ? (
                        <span className="inline-flex items-center gap-1 text-amber-400 font-sans font-bold">
                          <ArrowDownCircle className="h-3.5 w-3.5" />
                          Nuvem → Local (Restore)
                        </span>
                      ) : item.direction === 'cloud_populated' ? (
                        <span className="inline-flex items-center gap-1 text-purple-400 font-sans font-bold">
                          <ArrowUpCircle className="h-3.5 w-3.5" />
                          Nuvem Populada
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[#22D3EE] font-sans font-bold">
                          <ArrowUpCircle className="h-3.5 w-3.5" />
                          Local → Nuvem
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-white">{item.recordsCount}</td>
                    <td className="py-2.5 px-3">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                        <CheckCircle2 className="h-3 w-3" />
                        SUCESSO
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 font-sans text-[11px] max-w-md truncate">
                      {item.details}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-4 text-center text-slate-500 font-sans">
                    Nenhuma sincronização recente registrada.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
