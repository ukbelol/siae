#!/usr/bin/env bash
# ==============================================================================
# GOITGODS 2.0 & PASQUARED-OS -- INSTALADOR GERAL DO SISTEMA ("install-gods.sh")
# ==============================================================================
# Domínio Alvo: gogo.pasquared.space
# E-mail de Segurança SSL: rogermei577@gmail.com
# Sistema Operacional Suportado: Linux Debian 12 (Bookworm) / Ubuntu 22.04+ LTS
# ==============================================================================

set -e

# Cores para saída no terminal
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

DOMAIN="gogo.pasquared.space"
EMAIL="rogermei577@gmail.com"
APP_DIR="$(pwd)"
WEBROOT_DIR="/var/www/certbot"

echo -e "${CYAN}"
echo "================================================================================"
echo "          GOITGODS 2.0 & PASQUARED-OS -- GENERAL SYSTEM INSTALLER               "
echo "================================================================================"
echo "  Domínio Registrado : ${DOMAIN}"
echo "  E-mail Segurança SSL: ${EMAIL}"
echo "  Ambiente Alvo      : Linux Debian 12 / Ubuntu Server LTS"
echo "================================================================================"
echo -e "${NC}"

# 1. Verificação de privilégios de ROOT
if [ "$EUID" -ne 0 ]; then
  echo -e "${YELLOW}[!] AVISO: Executando sem permissão root direta. Recomendado: sudo bash install-gods.sh${NC}"
fi

# 2. Atualização dos repositórios APT do Debian 12
echo -e "${BLUE}[1/8] Atualizando lista de pacotes APT do Debian 12...${NC}"
if command -v apt-get &> /dev/null; then
  apt-get update -y || echo -e "${YELLOW}[!] Alerta no apt update, continuando...${NC}"
fi

# 3. Instalação de dependências essenciais e pacotes ACME / Certbot / Apache
echo -e "${BLUE}[2/8] Instalando utilitários de sistema, ferramentas de rede e compilação...${NC}"
DEPS="curl wget git build-essential ca-certificates gnupg lsb-release jq ufw openssl apache2 certbot python3-certbot-apache python3-certbot-nginx nginx psmisc lsof socat"
if command -v apt-get &> /dev/null; then
  apt-get install -y $DEPS || echo -e "${YELLOW}[!] Alguns pacotes foram instalados com avisos.${NC}"
fi

# 4. Instalação do ambiente Node.js LTS (v20+) e Ferramentas Globais
echo -e "${BLUE}[3/8] Verificando e Instalando ambiente Node.js 20+ LTS...${NC}"
if ! command -v node &> /dev/null; then
  echo -e "${CYAN}Instalando Node.js v20 LTS via Nodesource...${NC}"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo -e "${GREEN}Node.js versão: $(node -v)${NC}"
echo -e "${GREEN}NPM versão    : $(npm -v)${NC}"

echo -e "${CYAN}Instalando gerenciadores globais tsx, esbuild e pm2...${NC}"
npm install -g tsx esbuild pm2 speakeasy qrcode --quiet || true

# 5. Abertura e liberação de todas as portas de rede necessárias (80, 443, 3000)
echo -e "${BLUE}[4/8] Liberando portas 80, 443 e 3000 no Firewall (UFW / iptables)...${NC}"
if command -v ufw &> /dev/null; then
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true
  ufw allow 3000/tcp || true
  ufw reload || true
fi
if command -v iptables &> /dev/null; then
  iptables -I INPUT -p tcp --dport 80 -j ACCEPT || true
  iptables -I INPUT -p tcp --dport 443 -j ACCEPT || true
  iptables -I INPUT -p tcp --dport 3000 -j ACCEPT || true
fi

# 6. Instalação das dependências locais do projeto e compilação em CJS (dist/server.cjs)
echo -e "${BLUE}[5/8] Instalando pacotes do projeto (package.json) e gerando build de produção...${NC}"
if [ -f "package.json" ]; then
  npm install
  npm run build || echo -e "${YELLOW}[!] Build inicial gerado com aviso.${NC}"
fi

# 7. Verificação e liberação preventiva de portas 80/443 (Garante bind limpo para ACME / Certbot)
echo -e "${BLUE}[6/8] Verificando e desocupando portas 80 e 443 para validação ACME SSL...${NC}"

# Parar temporariamente Apache e Nginx para desocupar a porta 80/443
systemctl stop apache2 nginx 2>/dev/null || service apache2 stop 2>/dev/null || service nginx stop 2>/dev/null || true

# Encerrar qualquer processo que esteja ocupando as portas 80 ou 443
if command -v fuser &> /dev/null; then
  fuser -k 80/tcp 443/tcp 2>/dev/null || true
elif command -v lsof &> /dev/null; then
  PID80=$(lsof -t -i:80 2>/dev/null || true)
  PID443=$(lsof -t -i:443 2>/dev/null || true)
  if [ -n "$PID80" ]; then kill -9 $PID80 2>/dev/null || true; fi
  if [ -n "$PID443" ]; then kill -9 $PID443 2>/dev/null || true; fi
fi

sleep 1

# Prepare webroot directory for ACME HTTP-01 challenges
mkdir -p "${WEBROOT_DIR}/.well-known/acme-challenge"
chmod -R 755 "${WEBROOT_DIR}"

# 8. Emissão do Certificado SSL Válido e Confiável por Autoridade Certificadora Pública (CA)
echo -e "${BLUE}[7/8] Solicitando Certificado SSL Válido e Confiável (Let's Encrypt / ZeroSSL)...${NC}"

CERT_DIR="/etc/letsencrypt/live/${DOMAIN}"
mkdir -p "${CERT_DIR}"

SUCCESS_SSL=false

# MÉTODOS DE OBTENÇÃO DE CERTIFICADO RECONHECIDO NAVEGADOR (PÚBLICO CA)
if command -v certbot &> /dev/null; then
  echo -e "${CYAN}[Tentativa 1/3] Certbot Standalone com ACME HTTP-01 Let's Encrypt CA...${NC}"
  if certbot certonly --standalone --non-interactive --agree-tos --email "${EMAIL}" -d "${DOMAIN}" -d "www.${DOMAIN}" --preferred-challenges http; then
    echo -e "${GREEN}[✓] CERTIFICADO SSL PÚBLICO (Let's Encrypt) GERADO COM SUCESSO PARA ${DOMAIN}!${NC}"
    SUCCESS_SSL=true
  elif certbot certonly --standalone --non-interactive --agree-tos --email "${EMAIL}" -d "${DOMAIN}" --preferred-challenges http; then
    echo -e "${GREEN}[✓] CERTIFICADO SSL PÚBLICO (Let's Encrypt) GERADO COM SUCESSO PARA ${DOMAIN}!${NC}"
    SUCCESS_SSL=true
  fi

  # Tentativa 2: Webroot Challenge
  if [ "$SUCCESS_SSL" = false ]; then
    echo -e "${CYAN}[Tentativa 2/3] Certbot Webroot Challenge via ${WEBROOT_DIR}...${NC}"
    if certbot certonly --webroot -w "${WEBROOT_DIR}" --non-interactive --agree-tos --email "${EMAIL}" -d "${DOMAIN}" -d "www.${DOMAIN}"; then
      echo -e "${GREEN}[✓] CERTIFICADO SSL PÚBLICO (Let's Encrypt Webroot) GERADO COM SUCESSO!${NC}"
      SUCCESS_SSL=true
    fi
  fi
fi

# Tentativa 3: acme.sh com ZeroSSL / Let's Encrypt CA
if [ "$SUCCESS_SSL" = false ]; then
  echo -e "${CYAN}[Tentativa 3/3] Instalando e utilizando acme.sh (ZeroSSL / Let's Encrypt CA Oficial)...${NC}"
  if [ ! -d "$HOME/.acme.sh" ]; then
    curl -fsSL https://get.acme.sh | sh -s email="${EMAIL}" || true
  fi
  
  if [ -f "$HOME/.acme.sh/acme.sh" ]; then
    "$HOME/.acme.sh/acme.sh" --set-default-ca --server letsencrypt
    if "$HOME/.acme.sh/acme.sh" --issue -d "${DOMAIN}" --standalone --httpport 80; then
      echo -e "${GREEN}[✓] CERTIFICADO SSL PÚBLICO GERADO VIA ACME.SH!${NC}"
      "$HOME/.acme.sh/acme.sh" --install-cert -d "${DOMAIN}" \
        --key-file "${CERT_DIR}/privkey.pem" \
        --fullchain-file "${CERT_DIR}/fullchain.pem"
      SUCCESS_SSL=true
    fi
  fi
fi

# Caso o DNS 'gogo.pasquared.space' ainda não esteja apontado ao IP público da máquina durante o script:
if [ "$SUCCESS_SSL" = false ]; then
  echo -e "${RED}[!] ATENÇÃO: A validação remota ACME não concluiu porque o DNS de '${DOMAIN}' ainda precisa propagar ao IP do servidor.${NC}"
  echo -e "${YELLOW}[i] Gerando arquivos de certificado para subida do Apache2...${NC}"
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout "${CERT_DIR}/privkey.pem" \
    -out "${CERT_DIR}/fullchain.pem" \
    -subj "/CN=${DOMAIN}/O=PASQUARED-OS/OU=Security/emailAddress=${EMAIL}" \
    -addext "subjectAltName=DNS:${DOMAIN},DNS:www.${DOMAIN}"
fi

# 9. Configuração de Permissões de Leitura, Escrita, Grupos e Usuários
echo -e "${BLUE}[8/8] Aplicando permissões de leitura, escrita e grupos (chmod / chown)...${NC}"

# Ajusta propriedade e permissões no diretório do aplicativo
chmod -R 775 "${APP_DIR}"
chown -R root:root "${APP_DIR}" 2>/dev/null || true

# Permissões do Certificado SSL e diretórios do Let's Encrypt
chmod -R 755 /etc/letsencrypt/live/ 2>/dev/null || true
chmod -R 755 /etc/letsencrypt/archive/ 2>/dev/null || true
if [ -f "${CERT_DIR}/fullchain.pem" ]; then
  chmod 644 "${CERT_DIR}/fullchain.pem" 2>/dev/null || true
fi
if [ -f "${CERT_DIR}/privkey.pem" ]; then
  chmod 640 "${CERT_DIR}/privkey.pem" 2>/dev/null || true
fi

# Adiciona o usuário do servidor web (www-data) ao grupo root caso exista
if id "www-data" &>/dev/null; then
  usermod -aG root www-data 2>/dev/null || true
  chown -R www-data:www-data "${APP_DIR}/dist" 2>/dev/null || true
fi

# 10. Configuração do Servidor Web Apache2 - Manter EXCLUSIVAMENTE este sistema ativo como primário
echo -e "${BLUE}Configurando Apache2 VirtualHost com Proxy Reverso e limpando apontamentos secundários...${NC}"

APACHE_CONF="/etc/apache2/sites-available/gogo.pasquared.space.conf"

if [ -d "/etc/apache2/sites-available" ]; then
  # Ativa todos os módulos do Apache necessários para SSL, Proxy e WebSockets
  a2enmod ssl proxy proxy_http proxy_wstunnel headers rewrite &> /dev/null || true

  # Cria arquivo de VirtualHost exclusivo
  cat <<EOF > "${APACHE_CONF}"
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    ServerAdmin ${EMAIL}

    # Desvio para validações ACME HTTP-01 do Certbot
    Alias /.well-known/acme-challenge/ ${WEBROOT_DIR}/.well-known/acme-challenge/
    <Directory ${WEBROOT_DIR}/.well-known/acme-challenge/>
        Options None
        AllowOverride None
        Require all granted
    </Directory>

    Redirect permanent / https://${DOMAIN}/
</VirtualHost>

<VirtualHost *:443>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    ServerAdmin ${EMAIL}

    SSLEngine on
    SSLCertificateFile ${CERT_DIR}/fullchain.pem
    SSLCertificateKeyFile ${CERT_DIR}/privkey.pem

    ProxyPreserveHost On
    ProxyVia On
    ProxyRequests Off

    # Suporte a WebSockets se necessário
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*)           ws://127.0.0.1:3000/\$1 [P,L]

    # Redireciona requisições ao backend Node (retry=0 evita erro 503 por indisponibilidade temporária de worker)
    ProxyPass / http://127.0.0.1:3000/ retry=0 timeout=120
    ProxyPassReverse / http://127.0.0.1:3000/

    Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"

    ErrorLog \${APACHE_LOG_DIR}/pasquared_error.log
    CustomLog \${APACHE_LOG_DIR}/pasquared_access.log combined
</VirtualHost>
EOF

  # Desativa todos os outros VirtualHosts presentes em sites-enabled para manter este como ÚNICO primário
  if [ -d "/etc/apache2/sites-enabled" ]; then
    echo -e "${CYAN}Desativando VirtualHosts concorrentes em /etc/apache2/sites-enabled/...${NC}"
    for site in /etc/apache2/sites-enabled/*; do
      if [ -e "$site" ]; then
        sitenam=$(basename "$site")
        if [ "$sitenam" != "gogo.pasquared.space.conf" ]; then
          a2dissite "$sitenam" &> /dev/null || rm -f "$site" || true
        fi
      fi
    done
  fi

  # Habilita unicamente a configuração primária do PASQUARED-OS
  a2ensite gogo.pasquared.space.conf &> /dev/null || true
  systemctl restart apache2 &> /dev/null || service apache2 restart &> /dev/null || echo -e "${YELLOW}[!] Apache2 configurado.${NC}"
fi

# 11. Configuração e Inicialização do Serviço Systemd pasquared-os
SERVICE_FILE="/etc/systemd/system/pasquared-os.service"

if [ -d "/etc/systemd/system" ]; then
  cat <<EOF > "${SERVICE_FILE}"
[Unit]
Description=GOITGODS 2.0 & PASQUARED-OS Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${APP_DIR}
ExecStart=$(which node) ${APP_DIR}/dist/server.cjs
Restart=always
RestartSec=3
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload &> /dev/null || true
  systemctl enable pasquared-os.service &> /dev/null || true
  systemctl restart pasquared-os.service &> /dev/null || true
  echo -e "${GREEN}Serviço systemd pasquared-os configurado e iniciado.${NC}"
fi

# Ativa cron de renovação automática do SSL para impedir expiração
if command -v crontab &> /dev/null; then
  (crontab -l 2>/dev/null | grep -v "certbot renew"; echo "0 3 * * * certbot renew --quiet --post-hook 'systemctl reload apache2'") | crontab - || true
fi

echo -e "${GREEN}"
echo "================================================================================"
echo "          INSTALAÇÃO E REGISTRO SSL DO PASQUARED-OS CONCLUÍDOS!               "
echo "================================================================================"
echo "  Domínio Configurado : https://${DOMAIN}"
echo "  E-mail de Segurança  : ${EMAIL}"
echo "  Diretório SSL CA    : ${CERT_DIR}/"
echo "  VirtualHost Ativo   : gogo.pasquared.space.conf (ÚNICO PRIMÁRIO)"
echo "  Porta Interna Node  : http://127.0.0.1:3000 (Sem Erro 503)"
echo "================================================================================"
echo -e "${NC}"
