/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Store from './pages/Store';
import QueuePanel from './pages/QueuePanel';
import TerminalLogin from './pages/TerminalLogin';
import TerminalSelect from './pages/TerminalSelect';
import NfcReader from './pages/NfcReader';
import NewReport from './pages/NewReport';
import VideoRoom from './pages/VideoRoom';
import SuperAdmin from './pages/SuperAdmin';
import SuperAdminLogin from './pages/SuperAdminLogin';
import SSEListener from './components/SSEListener';

import RegisterHouse from './pages/RegisterHouse';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Checkout from './pages/Checkout';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
        <Toaster position="top-right" />
        <SSEListener />
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/register-house" element={<RegisterHouse />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/store" element={<Store />} />
          <Route path="/comprar-chaveiro" element={<Navigate to="/checkout?ref=propaganda" replace />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/room/:roomName" element={<VideoRoom />} />
          <Route path="/queue/:houseId" element={<QueuePanel />} />
          <Route path="/terminal" element={<TerminalLogin />} />
          <Route path="/terminal/select" element={<TerminalSelect />} />
          <Route path="/terminal/nfc/:houseId" element={<NfcReader />} />
          <Route path="/report/:houseId" element={<NewReport />} />
          <Route path="/loginsupersu" element={<SuperAdminLogin />} />
          <Route path="/super-admin-panel" element={<SuperAdmin />} />
          <Route path="/termos" element={<Terms />} />
          <Route path="/privacidade" element={<Privacy />} />
        </Routes>
      </div>
    </Router>
  );
}
