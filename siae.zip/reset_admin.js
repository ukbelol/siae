import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const host = process.env.DB_HOST || '127.0.0.1';
const user = process.env.DB_USER || 'siae_user';
const password = process.env.DB_PASSWORD || 'siae_pass';
const database = process.env.DB_NAME || 'siae_db';
const port = parseInt(process.env.DB_PORT || '3306', 10);

console.log(`Connecting to database at ${host}:${port}...`);

const db = mysql.createPool({
  host,
  user,
  password,
  database,
  port,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

async function resetSuperAdmin() {
  try {
    const adminEmail = 'admin@siae.space';
    const adminPassword = '21490905@Siae-roger-577';
    
    console.log(`Hashing password for ${adminEmail}...`);
    const hashedPassword = await bcrypt.hash(adminPassword, 10);
    
    console.log('Checking if superadmin already exists (by role)...');
    const [rows] = await db.query('SELECT * FROM users WHERE role = ?', ['super_admin']);
    const existingAdmins = rows;
    
    if (existingAdmins.length > 0) {
      console.log(`Found ${existingAdmins.length} existing super_admin(s). Updating the first one to the new email and password.`);
      await db.query(`
        UPDATE users 
        SET email = ?, password = ?, role = 'super_admin'
        WHERE id = ?
      `, [adminEmail, hashedPassword, existingAdmins[0].id]);
      console.log('Credentials updated.');
    } else {
      console.log('No super_admin found. Inserting a new one.');
      // See if email might already exist as different role
      const [emailRows] = await db.query('SELECT * FROM users WHERE email = ?', [adminEmail]);
      const emailMatch = emailRows;
      if (emailMatch.length > 0) {
          console.log('User with this email exists but is not super_admin. Updating role and password.');
          await db.query(`
            UPDATE users 
            SET role = 'super_admin', password = ?
            WHERE id = ?
           `, [hashedPassword, emailMatch[0].id]);
      } else {
         await db.query(`
            INSERT INTO users (first_name, last_name, email, password, role) 
            VALUES ('Super', 'Admin', ?, ?, 'super_admin')
          `, [adminEmail, hashedPassword]);
      }
      
      console.log('New super admin created.');
    }
    
    console.log('Super admin credentials successfully reset.');
    process.exit(0);
  } catch (error) {
    console.error('Error resetting super admin:', error);
    process.exit(1);
  }
}

resetSuperAdmin();
