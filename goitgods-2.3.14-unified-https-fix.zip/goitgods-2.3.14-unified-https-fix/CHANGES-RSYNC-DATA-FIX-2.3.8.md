# GOITGODS 2.3.8

Corrige o rsync: `--exclude='data/'` também excluía `src/data/`. Agora somente `/data/` da raiz é preservado/excluído, e `src/data/godsData.ts` é validado antes do build.
