const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

for (let i = 227; i <= 229; i++) {
  if (lines[i].includes(".all(")) {
    lines[i] = "      ];";
    // wait I need to see what 227-229 are!
  }
}

// Just regex replace
let t = lines.join('\n');
t = t.replace(/await db\.query\(`\n        SELECT \*\n        FROM assistance_requests\n        WHERE house_id = \? AND assisted_id = \? AND status IN \('analyzed', 'in_treatment'\)\n        ORDER BY id DESC\n      `\)\n      \.all\(req\.params\.houseId, req\.params\.assistedId\);/g, 
"      (await db.query(`\n        SELECT *\n        FROM assistance_requests\n        WHERE house_id = ? AND assisted_id = ? AND status IN ('analyzed', 'in_treatment')\n        ORDER BY id DESC\n      `, [req.params.houseId, req.params.assistedId]))[0];");

t = t.replace(/db\.prepare\('UPDATE assistance_requests/g, "await db.query('UPDATE assistance_requests");

t = t.replace(/attendanceInfo\.insertId/g, "(attendanceInfo as any).insertId");

t = t.replace(/router\.get\('\/houses\/:houseId\/conferences', \(req, res\) => \{/g, "router.get('/houses/:houseId/conferences', async (req, res) => {");

fs.writeFileSync('src/api/index.ts', t);

let b = fs.readFileSync('src/lib/backup.ts', 'utf8');
b = b.replace(/export function runManualBackup/g, "export async function runManualBackup");
fs.writeFileSync('src/lib/backup.ts', b);
