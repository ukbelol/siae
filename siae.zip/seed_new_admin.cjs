
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./siae.db');
db.serialize(() => {
  db.get("SELECT id FROM users WHERE email = 'ukbelol@gmail.com'", (err, row) => {
    if (!row) {
      db.run("INSERT INTO users (role, email, password, first_name, last_name, cpf, dob) VALUES ('super_admin', 'ukbelol@gmail.com', '2149090577&Roger-577', 'Master', 'Admin', '00000000001', '1990-01-01')");
      console.log('User ukbelol@gmail.com seeded');
    } else {
      console.log('User already exists, updating password');
      db.run("UPDATE users SET password = '2149090577&Roger-577', role = 'super_admin' WHERE email = 'ukbelol@gmail.com'");
    }
  });
});
