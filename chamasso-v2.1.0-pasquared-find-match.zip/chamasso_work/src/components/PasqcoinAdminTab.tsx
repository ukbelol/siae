import React, { useState } from 'react';
import {
  Coins,
  Zap,
  RefreshCw,
  PlusCircle,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  ArrowRight,
  UserCheck,
  TrendingUp,
  Shield,
  Layers,
  History,
  Check,
  Info,
} from 'lucide-react';
import type {
  PasqcoinSettings,
  PasqcoinMintBatch,
  PasqcoinTransaction,
  User,
} from '../types.ts';

interface PasqcoinAdminTabProps {
  settings: PasqcoinSettings;
  batches: PasqcoinMintBatch[];
  transactions: PasqcoinTransaction[];
  users: User[];
  onRefresh: () => void;
}

export const PasqcoinAdminTab: React.FC<PasqcoinAdminTabProps> = ({
  settings,
  batches,
  transactions,
  users,
  onRefresh,
}) => {
  // Local form state
  const [formData, setFormData] = useState<PasqcoinSettings>({ ...settings });
  const [customMintAmount, setCustomMintAmount] = useState<number>(1141);
  const [customMintNotes, setCustomMintNotes] = useState<string>('');
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [creditAmount, setCreditAmount] = useState<number>(100);
  const [creditNotes, setCreditNotes] = useState<string>('Bonificação concedida pelo Super Admin');

  // Loading & notification states
  const [savingSettings, setSavingSettings] = useState(false);
  const [minting, setMinting] = useState(false);
  const [crediting, setCrediting] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Sync state if settings prop updates
  React.useEffect(() => {
    setFormData({ ...settings });
  }, [settings]);

  const showNotification = (msg: string, isError = false) => {
    if (isError) {
      setActionError(msg);
      setTimeout(() => setActionError(null), 5000);
    } else {
      setActionSuccess(msg);
      setTimeout(() => setActionSuccess(null), 5000);
    }
  };

  // Salva configurações da Pasqcoin de forma persistente
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      const payload = {
        enabled: Boolean(formData.enabled),
        secondsPerCoin: Number(formData.secondsPerCoin) || 60,
        pricePerCoin: Number(formData.pricePerCoin) || 0.01,
        batchSize: Number(formData.batchSize) || 1141,
        autoReplenishThresholdPercent: Number(formData.autoReplenishThresholdPercent) || 20,
        autoReplenishEnabled: Boolean(formData.autoReplenishEnabled),
        expirationDays: Number(formData.expirationDays) || 30,
      };

      const res = await fetch('/api/admin/pasqcoin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao salvar configurações da Pasqcoin.');
      }

      const data = await res.json();
      setFormData(data.settings);
      showNotification('Configurações da Pasqcoin salvas e persistidas no PostgreSQL com sucesso!');
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Erro ao gravar parâmetros da Pasqcoin.', true);
    } finally {
      setSavingSettings(false);
    }
  };

  // Gera lote de Pasqcoins (1.141 moedas ou valor personalizado)
  const handleMintBatch = async (amountToMint = 1141, notes?: string) => {
    setMinting(true);
    try {
      const res = await fetch('/api/admin/pasqcoin/mint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: amountToMint,
          notes: notes || `Lote gerado pelo Super Admin (${amountToMint} Pasqcoins).`,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao gerar lote de Pasqcoins.');
      }

      const data = await res.json();
      showNotification(`Sucesso! Novo lote de ${amountToMint} Pasqcoins gerado e adicionado ao estoque disponível.`);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Erro ao gerar lote de Pasqcoins.', true);
    } finally {
      setMinting(false);
    }
  };

  // Credita moedas na carteira de um usuário selecionado
  const handleCreditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) {
      showNotification('Selecione um usuário para creditar Pasqcoins.', true);
      return;
    }
    if (creditAmount <= 0) {
      showNotification('A quantidade de Pasqcoins deve ser maior que zero.', true);
      return;
    }

    setCrediting(true);
    try {
      const res = await fetch('/api/admin/pasqcoin/credit-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: selectedUserId,
          amountCoins: creditAmount,
          notes: creditNotes,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao creditar moedas.');
      }

      showNotification(`Sucesso! ${creditAmount} Pasqcoins creditadas na conta do usuário selecionado.`);
      setSelectedUserId('');
      setCreditAmount(100);
      onRefresh();
    } catch (err: any) {
      showNotification(err.message || 'Erro ao conceder moedas.', true);
    } finally {
      setCrediting(false);
    }
  };

  // Cálculos de estoque e gatilho de 20%
  const reserve = settings.availableReserve ?? 1141;
  const standardBatch = settings.batchSize || 1141;
  const replenishThreshold = Math.ceil(standardBatch * ((settings.autoReplenishThresholdPercent || 20) / 100));
  const isNearReplenish = reserve <= replenishThreshold;
  const reservePercent = standardBatch > 0 ? Math.min(100, Math.round((reserve / standardBatch) * 100)) : 100;

  return (
    <div className="space-y-6">
      {/* Toast Alert Notifications */}
      {actionSuccess && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-950/40 p-4 text-xs font-bold text-emerald-300 shadow-lg backdrop-blur">
          <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {actionError && (
        <div className="flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-950/40 p-4 text-xs font-bold text-rose-300 shadow-lg backdrop-blur">
          <AlertTriangle className="h-5 w-5 shrink-0 text-rose-400" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Main Header / Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-[#1E293B] bg-gradient-to-br from-[#0F172A] via-[#111827] to-[#0A0C10] p-6 shadow-2xl">
        <div className="absolute -right-12 -top-12 h-52 w-52 rounded-full bg-gradient-to-br from-[#22D3EE]/10 to-[#F472B6]/10 blur-2xl" />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#22D3EE] to-[#F472B6] p-0.5 shadow-lg shadow-[#22D3EE]/20">
                <div className="flex h-full w-full items-center justify-center rounded-[14px] bg-[#0A0C10]">
                  <Coins className="h-6 w-6 text-[#22D3EE]" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-black text-white tracking-wide">
                    Moeda Virtual Pasqcoin (PASQ)
                  </h2>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      settings.enabled
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                    }`}
                  >
                    {settings.enabled ? 'Ativa' : 'Pausada'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Moeda virtual que equivale a tempo de conexão e desbloqueio completo das funcionalidades do chat (áudio, vídeo, texto e microfone).
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onRefresh()}
              className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2 text-xs font-bold text-slate-300 hover:bg-[#1E293B] hover:text-white transition"
              title="Atualizar dados do servidor"
            >
              <RefreshCw className="h-4 w-4" />
              <span>Atualizar</span>
            </button>

            <button
              onClick={() => handleMintBatch(1141)}
              disabled={minting}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2.5 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
            >
              <Zap className="h-4 w-4 fill-black" />
              <span>{minting ? 'Gerando Lote...' : 'Gerar 1.141 Pasqcoin Agora'}</span>
            </button>
          </div>
        </div>

        {/* 20% Replenish Alert Strip */}
        <div className="mt-5 pt-4 border-t border-[#1E293B]/70 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <div
              className={`h-2.5 w-2.5 rounded-full ${
                isNearReplenish ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'
              }`}
            />
            <span className="text-slate-300">
              Regra de Reposição Automática:{' '}
              <strong className="text-white">
                Gera 1.141 moedas automaticamente ao restar 20% do lote (≤ {replenishThreshold} PASQ).
              </strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-[11px]">
              Gatilho de reposição:{' '}
              <span className="text-[#22D3EE] font-mono font-bold">{settings.autoReplenishThresholdPercent}%</span>
            </span>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                settings.autoReplenishEnabled
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {settings.autoReplenishEnabled ? 'Gatilho Ativo' : 'Gatilho Inativo'}
            </span>
          </div>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Estoque Disponível */}
        <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4 flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Estoque Disponível</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#22D3EE]/10 text-[#22D3EE]">
              <Coins className="h-4 w-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-black font-mono text-[#22D3EE]">
              {reserve.toLocaleString('pt-BR')} <span className="text-xs text-slate-400 font-sans">PASQ</span>
            </div>
            <div className="mt-1.5 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isNearReplenish ? 'bg-amber-400' : 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6]'
                }`}
                style={{ width: `${reservePercent}%` }}
              />
            </div>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>Pronto para compra</span>
            <span className="font-mono text-slate-300 font-bold">{reservePercent}% do lote</span>
          </div>
        </div>

        {/* Card 2: Valor em Tempo / Desbloqueio */}
        <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Tempo de Conexão</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#F472B6]/10 text-[#F472B6]">
              <Clock className="h-4 w-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-black font-mono text-white">
              {settings.secondsPerCoin}{' '}
              <span className="text-xs text-slate-400 font-sans">segundos / 1 PASQ</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Equivale a <strong className="text-white">{(settings.secondsPerCoin / 60).toFixed(1)} minuto(s)</strong> de chat por moeda.
            </p>
          </div>
          <div className="text-[11px] text-[#22D3EE] font-semibold flex items-center gap-1">
            <Sparkles className="h-3 w-3" /> Desbloqueia áudio, vídeo e texto
          </div>
        </div>

        {/* Card 3: Lote Automático & Gatilho 20% */}
        <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Lote & Reposição</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400">
              <RefreshCw className="h-4 w-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-black font-mono text-emerald-400">
              +{standardBatch}{' '}
              <span className="text-xs text-slate-400 font-sans">moedas/lote</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Gatilho automático: quando sobrar <strong className="text-amber-400">{settings.autoReplenishThresholdPercent}%</strong> (≤ {replenishThreshold} moedas).
            </p>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>Status do lote:</span>
            <span className={isNearReplenish ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
              {isNearReplenish ? 'Gatilho 20% atingido' : 'Abastecido'}
            </span>
          </div>
        </div>

        {/* Card 4: Preço & Circulação */}
        <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Preço e Circulação</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-400">
              <TrendingUp className="h-4 w-4" />
            </span>
          </div>
          <div className="my-2">
            <div className="text-2xl font-black font-mono text-white">
              R$ {Number(settings.pricePerCoin || 0.01).toFixed(2).replace('.', ',')}
              <span className="text-xs text-slate-400 font-sans"> / moeda</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Total emitido: <strong className="text-white">{Number(settings.totalMinted || 1141).toLocaleString('pt-BR')} PASQ</strong>
            </p>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>Nas carteiras dos usuários:</span>
            <span className="font-mono text-[#F472B6] font-bold">
              {Number(settings.circulatingInWallets || 0).toLocaleString('pt-BR')} PASQ
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Settings Form & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form de Configurações */}
        <div className="lg:col-span-7 rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-5">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#1E293B]">
            <Layers className="h-5 w-5 text-[#22D3EE]" />
            <div>
              <h3 className="text-sm font-bold text-white">
                Parâmetros e Regras de Emissão da Pasqcoin
              </h3>
              <p className="text-[11px] text-slate-400">
                Ajuste os valores de tempo, preço e regras de geração automática de moedas
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4">
            {/* Toggle de Ativação Geral da Pasqcoin */}
            <div className="rounded-xl border border-[#1E293B] bg-[#0F172A]/40 p-3.5 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">
                  Moeda Virtual Pasqcoin Ativada
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Permite aos usuários comprar moedas e utilizá-las para tempo e desbloqueio nas salas.
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={formData.enabled}
                  onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#22D3EE]"></div>
              </label>
            </div>

            {/* Toggle Reposição Automática de 20% */}
            <div className="rounded-xl border border-[#1E293B] bg-[#0F172A]/40 p-3.5 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">
                  Gatilho Automático de Reabastecimento (20%)
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Gera automaticamente mais 1.141 moedas assim que o estoque disponível atingir ≤ 20%.
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0">
                <input
                  type="checkbox"
                  checked={formData.autoReplenishEnabled}
                  onChange={(e) =>
                    setFormData({ ...formData, autoReplenishEnabled: e.target.checked })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#F472B6]"></div>
              </label>
            </div>

            {/* Grid 2 Inputs: Segundos por moeda e Preço por moeda */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">
                    Segundos que vale cada Pasqcoin:
                  </label>
                  <span className="text-[11px] font-mono text-[#22D3EE] font-bold">
                    {formData.secondsPerCoin} seg
                  </span>
                </div>
                <div className="relative">
                  <Clock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.secondsPerCoin}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        secondsPerCoin: parseInt(e.target.value, 10) || 60,
                      })
                    }
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                    placeholder="60"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Padrão: 60 segundos (1 minuto) de áudio, vídeo e chat liberado por cada moeda.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">
                    Preço de Compra (Reais):
                  </label>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">
                    R$ {Number(formData.pricePerCoin || 0.01).toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs text-slate-400 font-bold">R$</span>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.pricePerCoin}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        pricePerCoin: parseFloat(e.target.value) || 0.01,
                      })
                    }
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                    placeholder="0.01"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Custo pago pelo usuário para comprar 1 Pasqcoin com saldo ou PIX.
                </p>
              </div>
            </div>

            {/* Grid 2 Inputs: Tamanho do Lote e Percentual do Gatilho */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">
                    Tamanho do Lote Padrão:
                  </label>
                  <span className="text-[11px] font-mono text-white font-bold">
                    {formData.batchSize} PASQ
                  </span>
                </div>
                <div className="relative">
                  <Coins className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="number"
                    min="100"
                    step="1"
                    value={formData.batchSize}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        batchSize: parseInt(e.target.value, 10) || 1141,
                      })
                    }
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                    placeholder="1141"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Quantidade oficial estipulada pelo sistema: <strong className="text-white">1.141 Pasqcoins</strong>.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">
                    Gatilho de Reposição (%):
                  </label>
                  <span className="text-[11px] font-mono text-amber-400 font-bold">
                    {formData.autoReplenishThresholdPercent}% (restar ≤ {Math.ceil(formData.batchSize * (formData.autoReplenishThresholdPercent / 100))})
                  </span>
                </div>
                <div className="relative">
                  <TrendingUp className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="number"
                    min="5"
                    max="50"
                    step="1"
                    value={formData.autoReplenishThresholdPercent}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        autoReplenishThresholdPercent: parseInt(e.target.value, 10) || 20,
                      })
                    }
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                    placeholder="20"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Regra estipulada: gera novo lote assim que sobrar apenas <strong className="text-amber-300">20%</strong> da reserva.
                </p>
              </div>
            </div>

            {/* Input Livre para Dias de Validade da Pasqcoin */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-300">
                  Validade dos Pasqcoins (em dias):
                </label>
                <span className="text-[11px] font-mono text-[#F472B6] font-bold">
                  {formData.expirationDays || 30} dias
                </span>
              </div>
              <div className="relative">
                <Clock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={formData.expirationDays ?? 30}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      expirationDays: parseInt(e.target.value, 10) || 30,
                    })
                  }
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                  placeholder="30"
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                Campo livre: estipule a quantidade exata de dias de validade que os Pasqcoins terão antes de expirar após a aquisição ou concessão.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end">
              <button
                type="submit"
                disabled={savingSettings}
                className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2.5 text-xs font-black text-black hover:brightness-110 active:scale-98 transition disabled:opacity-50"
              >
                {savingSettings ? 'Salvando no Banco...' : 'Salvar Alterações da Pasqcoin'}
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Bonificar Usuário / Ação Manual */}
        <div className="lg:col-span-5 space-y-6">
          {/* Card: Bonificar ou Creditar Usuário */}
          <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-5">
            <div className="flex items-center gap-2 mb-3 pb-3 border-b border-[#1E293B]">
              <UserCheck className="h-5 w-5 text-[#F472B6]" />
              <div>
                <h3 className="text-sm font-bold text-white">Creditar Pasqcoins para Usuário</h3>
                <p className="text-[11px] text-slate-400">
                  Bonifique ou adicione tempo de chat diretamente na carteira de um usuário
                </p>
              </div>
            </div>

            <form onSubmit={handleCreditUser} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Selecione o Usuário:
                </label>
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                >
                  <option value="">Selecione um usuário cadastrado...</option>
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} {u.lastName || ''} ({u.googleEmail}) - Saldo: {u.pasqcoins || 0} PASQ
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300">
                    Quantidade de Pasqcoins:
                  </label>
                  <span className="text-[11px] font-mono text-[#F472B6] font-bold">
                    {creditAmount} PASQ = {Math.round((creditAmount * settings.secondsPerCoin) / 60)} min
                  </span>
                </div>
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={creditAmount}
                  onChange={(e) => setCreditAmount(parseInt(e.target.value, 10) || 10)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                  placeholder="100"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Motivo / Observação:
                </label>
                <input
                  type="text"
                  value={creditNotes}
                  onChange={(e) => setCreditNotes(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  placeholder="Ex: Bonificação promocional de chat"
                />
              </div>

              <button
                type="submit"
                disabled={crediting || !selectedUserId}
                className="w-full rounded-xl bg-gradient-to-r from-[#F472B6] to-[#22D3EE] py-2.5 text-xs font-black text-black hover:brightness-110 active:scale-98 transition disabled:opacity-50"
              >
                {crediting ? 'Creditando...' : 'Confirmar Crédito de Pasqcoins'}
              </button>
            </form>
          </div>

          {/* Card: Emissão Manual de Lote Customizado */}
          <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-5">
            <div className="flex items-center gap-2 mb-3 pb-3 border-b border-[#1E293B]">
              <PlusCircle className="h-5 w-5 text-emerald-400" />
              <div>
                <h3 className="text-sm font-bold text-white">Emissão Manual de Lote</h3>
                <p className="text-[11px] text-slate-400">
                  Gere um lote com quantidade específica para a reserva
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={customMintAmount}
                  onChange={(e) => setCustomMintAmount(parseInt(e.target.value, 10) || 1141)}
                  className="w-32 rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs font-mono text-white focus:border-emerald-400 focus:outline-none"
                  placeholder="1141"
                />
                <button
                  onClick={() => handleMintBatch(customMintAmount, customMintNotes)}
                  disabled={minting}
                  className="flex-1 rounded-xl bg-emerald-500 hover:bg-emerald-400 py-2 text-xs font-black text-black transition active:scale-98 disabled:opacity-50"
                >
                  {minting ? 'Emitindo...' : `Emitir +${customMintAmount} Pasqcoins`}
                </button>
              </div>
              <input
                type="text"
                value={customMintNotes}
                onChange={(e) => setCustomMintNotes(e.target.value)}
                placeholder="Observação da emissão (opcional)"
                className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-1.5 text-xs text-slate-300 focus:border-emerald-400 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Histórico de Lotes Gerados (Batches) */}
      <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-5">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#1E293B]">
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-[#22D3EE]" />
            <div>
              <h3 className="text-sm font-bold text-white">Histórico de Lotes Emitidos (Mineração/Geração)</h3>
              <p className="text-[11px] text-slate-400">
                Registro auditável de cada lote gerado automaticamente ou pelo administrador
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Total de lotes: <strong className="text-white">{batches.length}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1E293B] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                <th className="py-2.5 px-3">Lote #</th>
                <th className="py-2.5 px-3">Quantidade</th>
                <th className="py-2.5 px-3">Gatilho da Emissão</th>
                <th className="py-2.5 px-3">Estoque Antes / Depois</th>
                <th className="py-2.5 px-3">Data e Hora</th>
                <th className="py-2.5 px-3">Observações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]/40 font-mono">
              {batches.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-500 font-sans">
                    Nenhum lote registrado ainda.
                  </td>
                </tr>
              ) : (
                batches.map((b) => (
                  <tr key={b.id} className="hover:bg-[#111827]/40 transition">
                    <td className="py-3 px-3 font-bold text-white">
                      #{b.batchNumber || 1}
                    </td>
                    <td className="py-3 px-3 font-bold text-emerald-400">
                      +{b.amount.toLocaleString('pt-BR')} PASQ
                    </td>
                    <td className="py-3 px-3 font-sans">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          b.trigger === 'auto_replenish_20'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : b.trigger === 'initial'
                            ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                            : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        }`}
                      >
                        {b.trigger === 'auto_replenish_20' && '⚡ Reposição 20% (Automática)'}
                        {b.trigger === 'initial' && '🚀 Emissão Inicial'}
                        {b.trigger === 'manual_admin' && '👤 Manual Super Admin'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-300">
                      {b.reserveBefore} → <strong className="text-[#22D3EE]">{b.reserveAfter}</strong>
                    </td>
                    <td className="py-3 px-3 text-slate-400 font-sans text-[11px]">
                      {new Date(b.timestamp).toLocaleString('pt-BR')}
                    </td>
                    <td className="py-3 px-3 text-slate-400 font-sans text-[11px] max-w-xs truncate">
                      {b.notes || '-'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Histórico de Compras e Transações de Pasqcoins */}
      <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-5">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#1E293B]">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-[#F472B6]" />
            <div>
              <h3 className="text-sm font-bold text-white">Transações e Vendas de Pasqcoin</h3>
              <p className="text-[11px] text-slate-400">
                Histórico de aquisição de moedas virtuais por usuários da plataforma
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Total de transações: <strong className="text-white">{transactions.length}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1E293B] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                <th className="py-2.5 px-3">ID</th>
                <th className="py-2.5 px-3">Usuário</th>
                <th className="py-2.5 px-3">Moedas Adquiridas</th>
                <th className="py-2.5 px-3">Tempo Liberado</th>
                <th className="py-2.5 px-3">Valor Pago</th>
                <th className="py-2.5 px-3">Método</th>
                <th className="py-2.5 px-3">Data</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]/40 font-mono">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-500 font-sans">
                    Nenhuma compra de Pasqcoin registrada ainda.
                  </td>
                </tr>
              ) : (
                transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#111827]/40 transition">
                    <td className="py-3 px-3 text-slate-400 text-[11px]">
                      {tx.id.substring(0, 14)}...
                    </td>
                    <td className="py-3 px-3 font-sans">
                      <span className="font-bold text-white block">{tx.userName}</span>
                      <span className="text-[10px] text-slate-400">{tx.userEmail}</span>
                    </td>
                    <td className="py-3 px-3 font-bold text-[#22D3EE]">
                      +{tx.amountCoins} PASQ
                    </td>
                    <td className="py-3 px-3 text-slate-300 font-sans">
                      {Math.round((tx.chatDurationSeconds || tx.amountCoins * 60) / 60)} minutos
                    </td>
                    <td className="py-3 px-3 font-bold text-emerald-400">
                      R$ {Number(tx.pricePaid || 0).toFixed(2).replace('.', ',')}
                    </td>
                    <td className="py-3 px-3 font-sans">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 uppercase font-bold">
                        {tx.paymentMethod === 'balance' ? 'Saldo R$' : tx.paymentMethod?.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 font-sans text-[11px]">
                      {new Date(tx.timestamp).toLocaleString('pt-BR')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
