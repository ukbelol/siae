const fs = require('fs');
let file = 'src/api/index.ts';
let t = fs.readFileSync(file, 'utf8');

const newRoute = `
router.get('/assisted/:assistedId/treatment-plan', async (req, res) => {
  try {
    const assistedId = req.params.assistedId;
    const request = (await db.query(\`SELECT * FROM assistance_requests WHERE assisted_id = ? AND status = 'in_treatment' ORDER BY created_at DESC LIMIT 1\`, [assistedId]))[0][0] as any;
    if (!request || !request.target_treatments) {
      return res.json(null);
    }
    const user = (await db.query('SELECT first_name, last_name FROM users WHERE id = ?', [assistedId]))[0][0] as any;
    const initials = (user.first_name[0] + (user.last_name || '').charAt(0)).toUpperCase();
    const dt = new Date(request.created_at);
    // adjust for local
    dt.setHours(dt.getHours() - 3);
    const title = 'Tratamento ' + initials + ' - ' + dt.toLocaleString('pt-BR');
    
    let plan = [];
    const targetTreatments = JSON.parse(request.target_treatments);
    for (const tt of targetTreatments) {
      if (!tt.typeId) continue;
      const typeInfo = (await db.query('SELECT name FROM assistance_types WHERE id = ?', [tt.typeId]))[0][0] as any;
      if (!typeInfo) continue;
      
      const atts = (await db.query(\`
        SELECT a.created_at, w.first_name, w.last_name 
        FROM attendances a
        LEFT JOIN users w ON a.worker_id = w.id
        WHERE a.assistance_request_id = ? AND a.type = ? AND a.status = 'completed'
        ORDER BY a.created_at ASC
      \`, [request.id, typeInfo.name]))[0] as any[];
      
      plan.push({
        typeId: tt.typeId,
        typeName: typeInfo.name,
        totalSessions: tt.sessions || 1,
        completedSessions: atts.length,
        history: atts.map((a: any) => ({
          date: new Date(a.created_at).toLocaleString('pt-BR'),
          worker: a.first_name ? a.first_name + ' ' + (a.last_name || '') : 'Sem T.'
        }))
      });
    }
    
    res.json({ title, treatments: plan, requestId: request.id });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
`;

if (!t.includes('/assisted/:assistedId/treatment-plan')) {
  t = t.replace("router.get('/queue/stats', async (req, res) => {", newRoute + "\nrouter.get('/queue/stats', async (req, res) => {");
}

fs.writeFileSync(file, t);
console.log("Added Plan API");
