import React, { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  Users,
  Video,
  Server,
  ShieldCheck,
  Terminal,
  Trash2,
  Edit2,
  PlusCircle,
  Ban,
  CheckCircle2,
  RefreshCw,
  Copy,
  Check,
  Download,
  AlertTriangle,
  KeyRound,
  LogOut,
  Globe,
  ExternalLink,
  Heart,
  Sparkles,
  Layers,
  Database,
  CreditCard,
  DollarSign,
  Clock,
  Zap,
  ArrowRight,
  Eye,
  EyeOff,
  Coins,
  ShieldAlert,
  Cloud,
} from 'lucide-react';
import { formatCPF, isValidCPF, cleanCPF } from '../utils/cpf.ts';
import type {
  Room,
  User,
  AuditLog,
  RelationshipLevel,
  ChamassoTariffSettings,
  MercadoPagoSettings,
  RechargeTransaction,
  PasqcoinSettings,
  PasqcoinMintBatch,
  PasqcoinTransaction,
} from '../types.ts';
import { PasqcoinAdminTab } from './PasqcoinAdminTab.tsx';
import { FinancialAdminTab } from './FinancialAdminTab.tsx';
import { FirewallAdminTab } from './FirewallAdminTab.tsx';
import { SupabaseAdminTab } from './SupabaseAdminTab.tsx';

interface AdminDashboardProps {
  onClose: () => void;
  onRefreshData?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose, onRefreshData }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loading, setLoading] = useState(false);

  // Active Tab
  const [activeTab, setActiveTab] = useState<
    'users' | 'rooms' | 'relationships' | 'tariffs' | 'financial' | 'firewall' | 'supabase' | 'pasqcoin' | 'server' | 'database' | 'installer' | 'logs'
  >('users');

  // Modal para confirmação e download de 11 códigos provisórios resetados
  const [resetCodesModalData, setResetCodesModalData] = useState<{
    user: any;
    codes: string[];
    email: string;
    fileName: string;
    txtContent: string;
  } | null>(null);

  // Data
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [adminRooms, setAdminRooms] = useState<Room[]>([]);
  const [systemStats, setSystemStats] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [securityNotifications, setSecurityNotifications] = useState<any[]>([]);
  const [relationshipLevels, setRelationshipLevels] = useState<RelationshipLevel[]>([]);

  // Tarifas Chamasso & Mercado Pago API state
  const [tariffSettings, setTariffSettings] = useState<ChamassoTariffSettings>({
    billingEnabled: true,
    unlockFeeEnabled: true,
    ratePerMinute: 0.01,
    minRechargeAmount: 5.0,
    rechargeValidityDays: 30,
  });
  const [mercadoPagoSettings, setMercadoPagoSettings] = useState<MercadoPagoSettings>({
    publicKey: '',
    accessToken: '',
    webhookUrl: 'https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=test',
    redirectUrl: 'https://chamasso.pasquared.space/app?payment=success&environment=test',
    sandboxMode: true,
    environment: 'test',
  });
  const [rechargeTransactions, setRechargeTransactions] = useState<RechargeTransaction[]>([]);
  const [savingTariffs, setSavingTariffs] = useState(false);
  const [savingMp, setSavingMp] = useState(false);
  const [testingMp, setTestingMp] = useState(false);
  const [testMpResult, setTestMpResult] = useState<{ success: boolean; message: string; seller?: any } | null>(null);
  const [tariffSavedSuccess, setTariffSavedSuccess] = useState(false);
  const [mpSavedSuccess, setMpSavedSuccess] = useState(false);
  const [showSecretKey, setShowSecretKey] = useState(false);

  // Moeda Virtual Pasqcoin state
  const [pasqcoinSettings, setPasqcoinSettings] = useState<PasqcoinSettings>({
    enabled: true,
    name: 'pasqcoin',
    symbol: 'PASQ',
    secondsPerCoin: 60,
    pricePerCoin: 0.01,
    batchSize: 1141,
    autoReplenishThresholdPercent: 20,
    totalMinted: 1141,
    availableReserve: 1141,
    circulatingInWallets: 0,
    autoReplenishEnabled: true,
    updatedAt: new Date().toISOString(),
  });
  const [pasqcoinBatches, setPasqcoinBatches] = useState<PasqcoinMintBatch[]>([]);
  const [pasqcoinTransactions, setPasqcoinTransactions] = useState<PasqcoinTransaction[]>([]);

  // Database & Persistent SGBD state
  const [dbStatus, setDbStatus] = useState<any>(null);
  const [dbSettings, setDbSettings] = useState<Record<string, any>>({});
  const [sqlScript, setSqlScript] = useState<string>('');
  const [copiedSql, setCopiedSql] = useState(false);
  const [saveSettingSuccess, setSaveSettingSuccess] = useState<string | null>(null);
  const [settingEditValues, setSettingEditValues] = useState<Record<string, string>>({});

  // Modals inside Admin
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [showCreateRoomModal, setShowCreateRoomModal] = useState(false);
  const [showCreateLevelModal, setShowCreateLevelModal] = useState(false);
  const [editingLevel, setEditingLevel] = useState<RelationshipLevel | null>(null);
  const [editingUser, setEditingUser] = useState<any | null>(null);

  // Relationship Level Form State
  const [levelName, setLevelName] = useState('');
  const [levelDesc, setLevelDesc] = useState('');
  const [levelIcon, setLevelIcon] = useState('✨');
  const [levelColor, setLevelColor] = useState('#22D3EE');

  // New User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserLastName, setNewUserLastName] = useState('');
  const [newUserBirthDate, setNewUserBirthDate] = useState('');
  const [newUserCpf, setNewUserCpf] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');

  // New Room Form State
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomDesc, setNewRoomDesc] = useState('');
  const [newRoomCat, setNewRoomCat] = useState<'paquera' | 'amizade' | 'romance' | 'musica'>('paquera');
  const [newRoomType, setNewRoomType] = useState<'public' | 'private'>('public');

  // Copied feedback
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedVhost, setCopiedVhost] = useState(false);

  const fetchAdminData = async () => {
    try {
      const [usersRes, roomsRes, statsRes, logsRes, relRes, dbStatusRes, settingsRes, sqlRes, tariffRes, mpRes, txRes, pasqRes, batchesRes, pasqTxRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/rooms'),
        fetch('/api/admin/stats'),
        fetch('/api/admin/logs'),
        fetch('/api/relationship-levels'),
        fetch('/api/admin/db-status'),
        fetch('/api/admin/settings'),
        fetch('/api/admin/schema-sql'),
        fetch('/api/tariffs/settings'),
        fetch('/api/admin/mercadopago/settings'),
        fetch('/api/admin/transactions'),
        fetch('/api/pasqcoin/settings'),
        fetch('/api/admin/pasqcoin/batches'),
        fetch('/api/admin/pasqcoin/transactions'),
      ]);

      if (usersRes.ok) setAdminUsers(await usersRes.json());
      if (roomsRes.ok) setAdminRooms(await roomsRes.json());
      if (statsRes.ok) setSystemStats(await statsRes.json());
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setAuditLogs(logsData.auditLogs || []);
        setSecurityNotifications(logsData.securityNotifications || []);
      }
      if (relRes.ok) {
        setRelationshipLevels(await relRes.json());
      }
      if (dbStatusRes.ok) {
        setDbStatus(await dbStatusRes.json());
      }
      if (settingsRes.ok) {
        const st = await settingsRes.json();
        setDbSettings(st);
        const mapVals: Record<string, string> = {};
        for (const k in st) {
          mapVals[k] = JSON.stringify(st[k].value, null, 2);
        }
        setSettingEditValues(mapVals);
      }
      if (sqlRes.ok) {
        setSqlScript(await sqlRes.text());
      }
      if (tariffRes.ok) {
        setTariffSettings(await tariffRes.json());
      }
      if (mpRes.ok) {
        setMercadoPagoSettings(await mpRes.json());
      }
      if (txRes.ok) {
        setRechargeTransactions(await txRes.json());
      }
      if (pasqRes && pasqRes.ok) {
        setPasqcoinSettings(await pasqRes.json());
      }
      if (batchesRes && batchesRes.ok) {
        setPasqcoinBatches(await batchesRes.json());
      }
      if (pasqTxRes && pasqTxRes.ok) {
        setPasqcoinTransactions(await pasqTxRes.json());
      }
    } catch (err) {
      console.error('Erro ao carregar dados do admin:', err);
    }
  };

  const handleSaveTariffSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingTariffs(true);
    try {
      const payload = {
        billingEnabled: Boolean(tariffSettings.billingEnabled),
        unlockFeeEnabled: Boolean(tariffSettings.unlockFeeEnabled),
        ratePerMinute: Number(tariffSettings.ratePerMinute) >= 0 ? Number(tariffSettings.ratePerMinute) : 0.01,
        minRechargeAmount: Number(tariffSettings.minRechargeAmount) >= 1 ? Number(tariffSettings.minRechargeAmount) : 5.0,
        rechargeValidityDays: Number(tariffSettings.rechargeValidityDays) >= 1 ? Number(tariffSettings.rechargeValidityDays) : 30,
      };
      const res = await fetch('/api/admin/tariffs/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao salvar tarifas.');
      }
      const data = await res.json();
      setTariffSettings(data.settings);
      setTariffSavedSuccess(true);
      setTimeout(() => setTariffSavedSuccess(false), 4000);
      fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao salvar tarifas');
    } finally {
      setSavingTariffs(false);
    }
  };

  const handleMercadoPagoEnvironmentChange = async (sandboxMode: boolean) => {
    const environment = sandboxMode ? 'test' : 'production';
    setTestMpResult(null);
    setMpSavedSuccess(false);
    try {
      const selectRes = await fetch('/api/admin/mercadopago/environment', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ environment }),
      });
      if (!selectRes.ok) throw new Error('Falha ao ativar o ambiente selecionado.');

      const res = await fetch(`/api/admin/mercadopago/settings?environment=${environment}`);
      if (!res.ok) throw new Error('Falha ao carregar credenciais do ambiente selecionado.');
      const settings = await res.json();
      setMercadoPagoSettings({ ...settings, sandboxMode, environment });
      setShowSecretKey(false);
    } catch (err: any) {
      alert(err.message || 'Erro ao alternar ambiente Mercado Pago');
    }
  };

  const handleSaveMercadoPagoSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingMp(true);
    try {
      const environment = mercadoPagoSettings.sandboxMode ? 'test' : 'production';
      const res = await fetch('/api/admin/mercadopago/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...mercadoPagoSettings, environment }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao salvar configurações Mercado Pago.');
      }
      const data = await res.json();
      setMercadoPagoSettings(data.settings);
      setMpSavedSuccess(true);
      setTimeout(() => setMpSavedSuccess(false), 3000);
      fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao salvar credenciais Mercado Pago');
    } finally {
      setSavingMp(false);
    }
  };

  const handleTestMercadoPago = async () => {
    setTestingMp(true);
    setTestMpResult(null);
    try {
      const res = await fetch('/api/admin/mercadopago/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accessToken: mercadoPagoSettings.accessToken,
          environment: mercadoPagoSettings.sandboxMode ? 'test' : 'production',
        }),
      });
      const data = await res.json();
      setTestMpResult(data);
    } catch (err: any) {
      setTestMpResult({ success: false, message: `Falha ao testar conexão: ${err.message}` });
    } finally {
      setTestingMp(false);
    }
  };

  const handleSaveSetting = async (key: string) => {
    try {
      const parsedVal = JSON.parse(settingEditValues[key]);
      const res = await fetch(`/api/admin/settings/${key}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value: parsedVal }),
      });
      if (!res.ok) throw new Error('Erro ao salvar configuração no banco de dados.');
      setSaveSettingSuccess(key);
      setTimeout(() => setSaveSettingSuccess(null), 3000);
      fetchAdminData();
    } catch (err: any) {
      alert('Certifique-se de que a configuração é um JSON válido: ' + err.message);
    }
  };

  const handleDownloadSql = () => {
    if (!sqlScript) return;
    const blob = new Blob([sqlScript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'db_chamasso.sql';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchAdminData();
    }
  }, [isAuthenticated]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user: usernameInput.trim(),
          password: passwordInput.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Credenciais de Administrador inválidas.');
      }

      setIsAuthenticated(true);
    } catch (err: any) {
      setLoginError(err.message || 'Falha ao autenticar.');
    } finally {
      setLoading(false);
    }
  };

  // Admin User Actions
  const handleToggleBlockUser = async (user: any) => {
    const willBlock = !user.isBlocked;
    const reason = willBlock ? prompt('Motivo do bloqueio:') || 'Bloqueado pelo Super Admin' : '';

    try {
      await fetch(`/api/admin/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          isBlocked: willBlock,
          blockReason: reason,
        }),
      });
      fetchAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleResetCodes = async (userId: string) => {
    if (!confirm('Deseja resetar e gerar novos 11 códigos descartáveis para este usuário? Os códigos serão enviados por e-mail com anexo .txt e baixados automaticamente.')) return;

    try {
      const res = await fetch(`/api/admin/users/${userId}/reset-disposable-codes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Falha ao resetar códigos');

      fetchAdminData();
      setResetCodesModalData({
        user: data.user,
        codes: data.codes,
        email: data.email,
        fileName: data.fileName,
        txtContent: data.txtContent,
      });

      // Dispara download automático do arquivo .txt com os 11 códigos
      if (data.txtContent && data.fileName) {
        const blob = new Blob([data.txtContent], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = data.fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }
    } catch (err: any) {
      alert(err.message || 'Erro ao resetar 11 códigos.');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Tem certeza que deseja excluir este usuário permanentemente?')) return;

    try {
      await fetch(`/api/admin/users/${userId}`, { method: 'DELETE' });
      fetchAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = cleanCPF(newUserCpf);
    if (!isValidCPF(clean)) {
      alert('CPF inválido segundo a regra oficial da Receita Federal.');
      return;
    }

    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newUserName.trim(),
          lastName: newUserLastName.trim(),
          birthDate: newUserBirthDate,
          cpf: clean,
          googleEmail: newUserEmail.trim(),
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error);
      }

      setShowCreateUserModal(false);
      setNewUserName('');
      setNewUserLastName('');
      setNewUserBirthDate('');
      setNewUserCpf('');
      setNewUserEmail('');
      fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao criar usuário.');
    }
  };

  // Admin Room Actions
  const handleDeleteRoom = async (roomId: string) => {
    if (!confirm('Tem certeza que deseja encerrar e excluir esta sala?')) return;

    try {
      await fetch(`/api/rooms/${roomId}`, { method: 'DELETE' });
      fetchAdminData();
      onRefreshData?.();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newRoomName.trim(),
          description: newRoomDesc.trim(),
          category: newRoomCat,
          type: newRoomType,
          creatorId: 'admin_super',
          creatorName: 'Super Admin',
          creatorEmail: 'roger577@ukbelol.space',
        }),
      });

      if (!res.ok) throw new Error('Erro ao criar sala.');

      setShowCreateRoomModal(false);
      setNewRoomName('');
      setNewRoomDesc('');
      fetchAdminData();
      onRefreshData?.();
    } catch (err: any) {
      alert(err.message || 'Erro ao criar sala.');
    }
  };

  // Relationship Levels Handlers
  const handleSaveRelationshipLevel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!levelName.trim() || !levelDesc.trim()) return;

    try {
      const url = editingLevel
        ? `/api/relationship-levels/${editingLevel.id}`
        : '/api/relationship-levels';
      const method = editingLevel ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: levelName.trim(),
          description: levelDesc.trim(),
          icon: levelIcon,
          color: levelColor,
        }),
      });

      if (!res.ok) throw new Error('Erro ao salvar nível de relacionamento.');

      setShowCreateLevelModal(false);
      setEditingLevel(null);
      setLevelName('');
      setLevelDesc('');
      setLevelIcon('✨');
      setLevelColor('#22D3EE');
      fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao salvar nível de relacionamento.');
    }
  };

  const handleDeleteRelationshipLevel = async (id: string, name: string) => {
    if (!confirm(`Tem certeza que deseja excluir o nível "${name}"?`)) return;

    try {
      const res = await fetch(`/api/relationship-levels/${id}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Erro ao excluir nível.');
      fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao excluir.');
    }
  };

  const handleResetRelationshipLevels = async () => {
    if (!confirm('Deseja restaurar todos os 6 níveis de relacionamento padrão do sistema chamasso?')) return;

    try {
      const res = await fetch('/api/relationship-levels/reset-defaults', {
        method: 'POST',
      });
      if (!res.ok) throw new Error('Erro ao restaurar padrões.');
      fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Erro ao restaurar níveis.');
    }
  };

  // ==============================================================================
  // VIEW: SUPER ADMIN LOGIN GATE
  // ==============================================================================
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/85 backdrop-blur-md">
        <div className="relative w-full max-w-md rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 sm:p-8 shadow-2xl text-[#E2E8F0]">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 rounded-lg p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
          >
            ✕
          </button>

          <div className="text-center mb-6">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onClose();
              }}
              title="Voltar para a página inicial"
              className="mx-auto block relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_20px_rgba(34,211,238,0.4)] mb-3 bg-[#0A0C10] cursor-pointer hover:scale-105 active:scale-95 transition-transform"
            >
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </a>
            <h2 className="text-xl font-black tracking-tight text-white uppercase italic">Área Restrita do Super Admin</h2>
            <p className="text-xs text-[#22D3EE] font-mono mt-1">chamasso live chat • Painel de Controle</p>
            <div className="mt-2 text-center">
              <button
                type="button"
                onClick={() => {
                  setUsernameInput('roger577@ukbelol.space');
                  setPasswordInput('');
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#22D3EE]/30 bg-[#22D3EE]/10 px-2.5 py-1 text-[11px] font-mono text-[#22D3EE] hover:bg-[#22D3EE]/20 transition"
              >
                <KeyRound className="h-3 w-3" />
                <span>Preencher credenciais Super Admin</span>
              </button>
            </div>
          </div>

          {loginError && (
            <div className="mb-4 flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
              <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Usuário Super Admin:
              </label>
              <input
                type="text"
                required
                autoFocus
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value)}
                placeholder="roger577@ukbelol.space"
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs font-mono text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Senha de Acesso:</label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••••••••••••"
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs font-mono text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-3 text-xs font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition disabled:opacity-50"
            >
              {loading ? (
                'Verificando Credenciais...'
              ) : (
                <>
                  <Lock className="h-4 w-4" />
                  <span>Acessar Painel do Super Admin</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ==============================================================================
  // VIEW: SUPER ADMIN MAIN DASHBOARD
  // ==============================================================================
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0A0C10] text-[#E2E8F0] overflow-y-auto">
      {/* Top Admin Header */}
      <header className="sticky top-0 z-40 border-b border-[#1E293B] bg-[#0F172A]/90 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onClose();
              }}
              title="Voltar para a página inicial"
              className="relative w-10 h-10 rounded-xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_12px_rgba(34,211,238,0.35)] shrink-0 bg-[#0A0C10] block cursor-pointer hover:scale-105 active:scale-95 transition-transform"
            >
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </a>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">
                  Painel de Controle Super Admin
                </h1>
                <span className="rounded bg-[#22D3EE]/20 border border-[#22D3EE]/40 px-1.5 py-0.2 text-[9px] font-bold text-[#22D3EE]">
                  SUPERUSER
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Logado como: <span className="text-[#22D3EE] font-mono">roger577@ukbelol.space</span> • Domínio: chamasso.pasquared.space
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAuthenticated(false)}
              className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-1.5 text-xs text-slate-300 hover:bg-[#334155] hover:text-white transition"
              title="Sair do Super Admin"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Desconectar Admin</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500 transition"
            >
              Fechar Painel
            </button>
          </div>
        </div>
      </header>

      {/* Admin Navigation Tabs */}
      <div className="border-b border-[#1E293B] bg-[#0F172A]/50 px-4">
        <div className="mx-auto flex max-w-7xl gap-1 sm:gap-2 overflow-x-auto py-2">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'users'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Users className="h-4 w-4" />
            <span>Gerenciar Usuários ({adminUsers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('rooms')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'rooms'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Video className="h-4 w-4" />
            <span>Gerenciar Salas ({adminRooms.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('relationships')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'relationships'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Heart className="h-4 w-4" />
            <span>Níveis de Relacionamento ({relationshipLevels.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('tariffs')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'tariffs'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <CreditCard className="h-4 w-4" />
            <span>Tarifas Chamasso & Mercado Pago</span>
          </button>

          <button
            onClick={() => setActiveTab('financial')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'financial'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <DollarSign className="h-4 w-4 text-emerald-400" />
            <span>Financeiro & Clientes (Pagar/Receber/Free)</span>
          </button>

          <button
            onClick={() => setActiveTab('firewall')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'firewall'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <ShieldAlert className="h-4 w-4 text-rose-400" />
            <span>Firewall Anti-Ataques (DDoS/Phishing/Brute-Force)</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'supabase'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Cloud className="h-4 w-4 text-[#22D3EE]" />
            <span>Nuvem Supabase & Disaster Recovery</span>
          </button>

          <button
            onClick={() => setActiveTab('pasqcoin')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'pasqcoin'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Coins className="h-4 w-4 text-[#22D3EE]" />
            <span>🪙 Moeda Pasqcoin ({pasqcoinSettings.availableReserve} PASQ)</span>
          </button>

          <button
            onClick={() => setActiveTab('server')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'server'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Server className="h-4 w-4" />
            <span>Servidor Debian 12 & Apache</span>
          </button>

          <button
            onClick={() => setActiveTab('database')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'database'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Database className="h-4 w-4" />
            <span>Banco de Dados & SGBD (PostgreSQL)</span>
          </button>

          <button
            onClick={() => setActiveTab('installer')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'installer'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <Terminal className="h-4 w-4" />
            <span>Script Instalador Debian 12</span>
          </button>

          <button
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'logs'
                ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md'
                : 'text-slate-400 hover:bg-[#1E293B] hover:text-[#E2E8F0]'
            }`}
          >
            <ShieldCheck className="h-4 w-4" />
            <span>Auditoria 2FA & Segurança</span>
          </button>
        </div>
      </div>

      {/* Main Admin Content Container */}
      <main className="mx-auto max-w-7xl flex-1 p-4 sm:p-6 w-full">
        {/* TAB 1: USERS MANAGEMENT */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-black uppercase italic tracking-tight text-white">Usuários Cadastrados no Sistema</h2>
                <p className="text-xs text-slate-400">
                  Gerenciamento completo: criar, editar, bloquear/desbloquear, excluir e gerenciar 2FA.
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={fetchAdminData}
                  className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Atualizar</span>
                </button>
                <button
                  onClick={() => setShowCreateUserModal(true)}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-black text-black hover:brightness-110 transition shadow-md"
                >
                  <PlusCircle className="h-4 w-4" />
                  <span>Criar Novo Usuário</span>
                </button>
              </div>
            </div>

            {/* Users Table */}
            <div className="overflow-x-auto rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="border-b border-[#1E293B] bg-[#0A0C10] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                  <tr>
                    <th className="px-4 py-3">Nome / CPF</th>
                    <th className="px-4 py-3">E-mail Google</th>
                    <th className="px-4 py-3">2FA Status</th>
                    <th className="px-4 py-3">11 Códigos Descartáveis</th>
                    <th className="px-4 py-3">Status da Conta</th>
                    <th className="px-4 py-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]/60">
                  {adminUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-[#1E293B]/40 transition">
                      <td className="px-4 py-3">
                        <div className="font-bold text-white">
                          {user.name} {user.lastName}
                        </div>
                        <div className="font-mono text-[11px] text-[#22D3EE]">{user.formattedCpf}</div>
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-300">{user.googleEmail}</td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 rounded-md bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
                          <CheckCircle2 className="h-3 w-3" />
                          Vinculado
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-amber-300 font-mono">
                            {user.disposableCodesRemaining} / 11
                          </span>
                          <button
                            onClick={() => handleResetCodes(user.id)}
                            className="rounded p-1 text-slate-400 hover:text-[#22D3EE] hover:bg-[#1E293B] transition"
                            title="Resetar 11 códigos descartáveis"
                          >
                            <KeyRound className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {user.isBlocked ? (
                          <span className="rounded bg-rose-950 border border-rose-800 px-2 py-0.5 text-[10px] font-bold text-rose-300">
                            Bloqueado
                          </span>
                        ) : (
                          <span className="rounded bg-emerald-950 border border-emerald-800 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                            Ativo
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleToggleBlockUser(user)}
                            className={`rounded-lg px-2 py-1 text-[11px] font-semibold border transition ${
                              user.isBlocked
                                ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900'
                                : 'border-amber-500/40 bg-amber-950/40 text-amber-300 hover:bg-amber-900'
                            }`}
                          >
                            {user.isBlocked ? 'Desbloquear' : 'Bloquear'}
                          </button>
                          <button
                            onClick={() => handleDeleteUser(user.id)}
                            className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-950 hover:text-rose-400 transition"
                            title="Excluir Usuário"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: ROOMS MANAGEMENT */}
        {activeTab === 'rooms' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-black uppercase italic tracking-tight text-white">Salas de Bate-Papo & Videoconferência</h2>
                <p className="text-xs text-slate-400">
                  Gerenciamento de salas públicas e privadas, participantes e encerramento.
                </p>
              </div>

              <button
                onClick={() => setShowCreateRoomModal(true)}
                className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-black text-black hover:brightness-110 transition shadow-md"
              >
                <PlusCircle className="h-4 w-4" />
                <span>Criar Sala pelo Super Admin</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {adminRooms.map((room) => (
                <div
                  key={room.id}
                  className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-lg flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                          room.type === 'public'
                            ? 'bg-[#22D3EE]/10 text-[#22D3EE] border border-[#22D3EE]/30'
                            : 'bg-[#F472B6]/10 text-[#F472B6] border border-[#F472B6]/30'
                        }`}
                      >
                        {room.type === 'public' ? 'Pública' : 'Privada'}
                      </span>
                      <span className="text-xs text-slate-400">
                        {room.activeParticipantsCount || 0} conectados
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white">{room.name}</h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">{room.description}</p>
                    <p className="text-[11px] text-slate-500 mt-2">
                      Criador: <strong className="text-slate-300">{room.creatorName}</strong>
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#1E293B] flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 font-mono">{room.id}</span>
                    <button
                      onClick={() => handleDeleteRoom(room.id)}
                      className="flex items-center gap-1 rounded-xl border border-rose-500/30 bg-rose-950/40 px-2.5 py-1 text-xs font-semibold text-rose-300 hover:bg-rose-900 transition"
                    >
                      <Trash2 className="h-3 w-3" />
                      <span>Excluir Sala</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB: NÍVEIS DE RELACIONAMENTO (BATE-PAPO & AMIZADES) */}
        {activeTab === 'relationships' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-black uppercase italic tracking-tight text-white flex items-center gap-2">
                  <Heart className="h-5 w-5 text-[#F472B6]" />
                  <span>Níveis de Relacionamento do Bate-Papo</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Opções de níveis pré-criados e personalizados para solicitações de amizade entre usuários de qualquer status.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleResetRelationshipLevels}
                  className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
                  title="Restaura os 6 níveis padrão pré-criados"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Restaurar Padrões</span>
                </button>

                <button
                  onClick={() => {
                    setEditingLevel(null);
                    setLevelName('');
                    setLevelDesc('');
                    setLevelIcon('✨');
                    setLevelColor('#22D3EE');
                    setShowCreateLevelModal(true);
                  }}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-black text-black shadow-md hover:brightness-110 transition"
                >
                  <PlusCircle className="h-4 w-4" />
                  <span>Novo Nível Personalizado</span>
                </button>
              </div>
            </div>

            {/* Explanatory Banner of the Friendship System Rules */}
            <div className="rounded-2xl border border-[#22D3EE]/30 bg-gradient-to-r from-[#22D3EE]/10 to-[#F472B6]/10 p-4 sm:p-5">
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-xl bg-[#22D3EE]/20 border border-[#22D3EE]/40 flex items-center justify-center text-[#22D3EE] shrink-0 font-bold">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white mb-1">
                    Regra Operacional de Amizades & Níveis de Relacionamento
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Todos os usuários do chat têm acesso a esta matriz de níveis para solicitar amizade a qualquer pessoa que esteja com status:
                    <strong className="text-emerald-400"> Online (🟢)</strong>,{' '}
                    <strong className="text-rose-400">Ocupado (🔴)</strong>,{' '}
                    <strong className="text-amber-400">Em horário de almoço (🍔)</strong>,{' '}
                    <strong className="text-yellow-400">Ausente (🟡)</strong> ou{' '}
                    <strong className="text-slate-400">Invisível=offline (⚪)</strong>.
                    <br />
                    <strong>Regra de Aceite:</strong> Quem recebe o convite pode{' '}
                    <span className="text-emerald-400 font-bold">Aceitar</span> (escolhendo em qual de seus grupos deseja salvar o contato),{' '}
                    <span className="text-rose-400 font-bold">Recusar</span> ou{' '}
                    <span className="text-slate-400 font-bold">Deixar sem resposta</span>.
                  </p>
                </div>
              </div>
            </div>

            {/* Relationship Levels Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {relationshipLevels.map((lvl) => (
                <div
                  key={lvl.id}
                  className="flex flex-col justify-between rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 hover:border-slate-600 transition group"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-center gap-3">
                        <div
                          style={{ borderColor: lvl.color || '#22D3EE' }}
                          className="h-12 w-12 rounded-2xl bg-[#0A0C10] border-2 flex items-center justify-center text-2xl shadow-md"
                        >
                          {lvl.icon || '✨'}
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white leading-tight">{lvl.name}</h4>
                          <span
                            style={{ color: lvl.color || '#22D3EE' }}
                            className="text-[10px] font-mono font-semibold"
                          >
                            {lvl.color}
                          </span>
                        </div>
                      </div>

                      {lvl.isDefault ? (
                        <span className="rounded-full bg-[#1E293B] border border-slate-700 px-2.5 py-0.5 text-[10px] font-bold text-slate-300">
                          Padrão Sistema
                        </span>
                      ) : (
                        <span className="rounded-full bg-[#22D3EE]/15 border border-[#22D3EE]/40 px-2.5 py-0.5 text-[10px] font-bold text-[#22D3EE]">
                          Personalizado
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-300 bg-[#0A0C10] p-3 rounded-xl border border-[#1E293B] leading-relaxed">
                      {lvl.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#1E293B] flex items-center justify-end gap-2">
                    <button
                      onClick={() => {
                        setEditingLevel(lvl);
                        setLevelName(lvl.name);
                        setLevelDesc(lvl.description);
                        setLevelIcon(lvl.icon || '✨');
                        setLevelColor(lvl.color || '#22D3EE');
                        setShowCreateLevelModal(true);
                      }}
                      className="flex items-center gap-1 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                      <span>Editar</span>
                    </button>

                    {!lvl.isDefault && (
                      <button
                        onClick={() => handleDeleteRelationshipLevel(lvl.id, lvl.name)}
                        className="flex items-center gap-1 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-xs font-semibold text-rose-300 hover:bg-rose-500/20 transition"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Excluir</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB: TARIFAS CHAMASSO & MERCADO PAGO */}
        {activeTab === 'tariffs' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-black uppercase italic tracking-tight text-white flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-[#22D3EE]" />
                Tarifas Chamasso & Gateway Mercado Pago
              </h2>
              <p className="text-xs text-slate-400">
                Gerenciamento da cobrança por minuto do bate-papo, pacotes de recarga pré-paga e credenciais da API Mercado Pago.
              </p>
            </div>

            {/* Grid com Formulário de Tarifas e Formulário do Mercado Pago */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* FORMULÁRIO 1: TARIFAS CHAMASSO */}
              <div className="rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] p-5 shadow-xl space-y-5">
                <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="rounded-xl border border-[#22D3EE]/40 bg-[#22D3EE]/10 p-2 text-[#22D3EE]">
                      <DollarSign className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                        Tarifas do Bate-Papo
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Cobrança por minuto e regras de acesso às salas
                      </p>
                    </div>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      tariffSettings.billingEnabled
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-slate-700/50 text-slate-300 border border-slate-600'
                    }`}
                  >
                    {tariffSettings.billingEnabled ? 'Tarifação Ativa' : 'Acesso Gratuito'}
                  </span>
                </div>

                <form onSubmit={handleSaveTariffSettings} className="space-y-4">
                  {/* Toggle Ativar Tarifas Gerais */}
                  <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Botão de Ativação Geral das Tarifas
                      </span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {tariffSettings.billingEnabled
                          ? 'Apenas usuários com créditos interagem na sala. Sem saldo, apenas assistem.'
                          : 'Cobrança suspensa. Todas as salas e funções de áudio/vídeo estão gratuitas.'}
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input
                        type="checkbox"
                        checked={tariffSettings.billingEnabled}
                        onChange={(e) =>
                          setTariffSettings({ ...tariffSettings, billingEnabled: e.target.checked })
                        }
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#22D3EE]"></div>
                    </label>
                  </div>

                  {/* Toggle Ativar/Desativar Taxa de Desbloqueio das Funcionalidades do Chat */}
                  <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3.5 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white block">
                          Taxa de Desbloqueio das Funcionalidades do Chat
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                            tariffSettings.unlockFeeEnabled !== false
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                          }`}
                        >
                          {tariffSettings.unlockFeeEnabled !== false ? 'Taxa Ativa' : 'Desbloqueio Grátis'}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {tariffSettings.unlockFeeEnabled !== false
                          ? 'Exige créditos ou Pasqcoins para desbloquear microfone, câmera, envio de texto e áudio.'
                          : 'Todas as funcionalidades do chat (áudio, vídeo, texto) ficam desbloqueadas gratuitamente sem custos.'}
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input
                        type="checkbox"
                        checked={tariffSettings.unlockFeeEnabled !== false}
                        onChange={(e) =>
                          setTariffSettings({ ...tariffSettings, unlockFeeEnabled: e.target.checked })
                        }
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#F472B6]"></div>
                    </label>
                  </div>

                  {/* Valor por minuto */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-300">
                        Tarifa por Minuto de Interação (Reais):
                      </label>
                      <span className="text-[11px] font-mono text-[#22D3EE] font-bold">
                        R$ {Number(tariffSettings.ratePerMinute || 0).toFixed(2).replace('.', ',')} / min
                      </span>
                    </div>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">R$</span>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={tariffSettings.ratePerMinute}
                        onChange={(e) => {
                          const val = e.target.value;
                          setTariffSettings({
                            ...tariffSettings,
                            ratePerMinute: val === '' ? 0 : parseFloat(val),
                          });
                        }}
                        className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      Padrão do sistema: <strong className="text-white">R$ 0,01</strong> (um centavo de real por minuto = R$ 0,60 por hora). Salvo de forma persistente.
                    </p>
                  </div>

                  {/* Recarga mínima */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-300">
                        Valor Mínimo de Recarga Pré-Paga:
                      </label>
                      <span className="text-[11px] font-mono text-emerald-400 font-bold">
                        R$ {tariffSettings.minRechargeAmount.toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">R$</span>
                      <input
                        type="number"
                        step="1"
                        min="1"
                        value={tariffSettings.minRechargeAmount}
                        onChange={(e) =>
                          setTariffSettings({
                            ...tariffSettings,
                            minRechargeAmount: parseFloat(e.target.value) || 5,
                          })
                        }
                        className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      Pacotes de recarga a partir de <strong className="text-white">R$ 5,00</strong> no mínimo.
                    </p>
                  </div>

                  {/* Validade em dias */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-300">
                        Validade das Recargas (Dias):
                      </label>
                      <span className="text-[11px] font-mono text-amber-400 font-bold">
                        {tariffSettings.rechargeValidityDays} dias
                      </span>
                    </div>
                    <div className="relative">
                      <Clock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                      <input
                        type="number"
                        step="1"
                        min="1"
                        value={tariffSettings.rechargeValidityDays}
                        onChange={(e) =>
                          setTariffSettings({
                            ...tariffSettings,
                            rechargeValidityDays: parseInt(e.target.value, 10) || 30,
                          })
                        }
                        className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-9 pr-3 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      Expiram em 30 dias após a primeira entrada em sala de bate-papo ou contato direto.
                    </p>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    {tariffSavedSuccess && (
                      <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4" /> Tarifas salvas no PostgreSQL!
                      </span>
                    )}
                    <button
                      type="submit"
                      disabled={savingTariffs}
                      className="ml-auto rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2.5 text-xs font-black text-black hover:brightness-110 active:scale-98 transition disabled:opacity-50"
                    >
                      {savingTariffs ? 'Gravando no Banco...' : 'Salvar Tarifas Chamasso'}
                    </button>
                  </div>
                </form>
              </div>

              {/* FORMULÁRIO 2: CONFIGURAÇÃO DA API MERCADO PAGO */}
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-5">
                <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="rounded-xl border border-[#009EE3]/40 bg-[#009EE3]/10 p-2 text-[#009EE3]">
                      <Zap className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                        API de Pagamento Mercado Pago
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Chaves de API, webhooks e links de redirecionamento
                      </p>
                    </div>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      mercadoPagoSettings.sandboxMode
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    }`}
                  >
                    {mercadoPagoSettings.sandboxMode ? 'Sandbox (Teste)' : 'Produção'}
                  </span>
                </div>

                <form onSubmit={handleSaveMercadoPagoSettings} className="space-y-3.5">
                  {/* Modo Sandbox Toggle */}
                  <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Modo Sandbox (Ambiente de Testes)
                      </span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        Cada ambiente mantém suas próprias chaves e URLs. Ao alternar, os dados salvos daquele ambiente são carregados automaticamente.
                      </span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input
                        type="checkbox"
                        checked={mercadoPagoSettings.sandboxMode}
                        onChange={(e) => handleMercadoPagoEnvironmentChange(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#009EE3]"></div>
                    </label>
                  </div>

                  {/* Public Key */}
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      API Key / Public Key (Chave Pública):
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: APP_USR-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx ou TEST-..."
                      value={mercadoPagoSettings.publicKey}
                      onChange={(e) =>
                        setMercadoPagoSettings({
                          ...mercadoPagoSettings,
                          publicKey: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                    />
                  </div>

                  {/* Access Token / Secret Key */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-300">
                        Secret Key / Access Token (Chave Secreta):
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowSecretKey(!showSecretKey)}
                        className="text-[11px] text-[#22D3EE] hover:underline flex items-center gap-1"
                      >
                        {showSecretKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        <span>{showSecretKey ? 'Ocultar' : 'Exibir'}</span>
                      </button>
                    </div>
                    <input
                      type={showSecretKey ? 'text' : 'password'}
                      placeholder="Ex: APP_USR-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx-xxxxxx..."
                      value={mercadoPagoSettings.accessToken}
                      onChange={(e) =>
                        setMercadoPagoSettings({
                          ...mercadoPagoSettings,
                          accessToken: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2 text-xs font-mono text-white focus:border-[#22D3EE] focus:outline-none"
                    />
                  </div>

                  {/* Webhooks Link */}
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Link Webhooks (Notificações Instantâneas):
                    </label>
                    <input
                      type="url"
                      placeholder="https://chamasso.pasquared.space/api/payments/mercadopago/webhook"
                      value={mercadoPagoSettings.webhookUrl}
                      onChange={(e) =>
                        setMercadoPagoSettings({
                          ...mercadoPagoSettings,
                          webhookUrl: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2 text-xs font-mono text-[#22D3EE] focus:border-[#22D3EE] focus:outline-none"
                    />
                  </div>

                  {/* Redirect Link */}
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Link de Redirecionamento (Retorno Pós-Pagamento):
                    </label>
                    <input
                      type="url"
                      placeholder="https://chamasso.pasquared.space/app?payment=success"
                      value={mercadoPagoSettings.redirectUrl}
                      onChange={(e) =>
                        setMercadoPagoSettings({
                          ...mercadoPagoSettings,
                          redirectUrl: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2 text-xs font-mono text-slate-300 focus:border-[#22D3EE] focus:outline-none"
                    />
                  </div>

                  {/* Resultado do Teste de Conexão */}
                  {testMpResult && (
                    <div
                      className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                        testMpResult.success
                          ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                          : 'border-rose-500/40 bg-rose-500/10 text-rose-300'
                      }`}
                    >
                      {testMpResult.success ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-rose-400" />
                      )}
                      <div>
                        <span className="font-bold block">{testMpResult.message}</span>
                        {testMpResult.seller && (
                          <span className="text-[11px] opacity-80 block mt-0.5">
                            Conta: {testMpResult.seller.nickname || testMpResult.seller.email} (ID: {testMpResult.seller.id})
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-2">
                    <button
                      type="button"
                      disabled={testingMp}
                      onClick={handleTestMercadoPago}
                      className="w-full sm:w-auto rounded-xl border border-[#1E293B] bg-[#1E293B] px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition disabled:opacity-50"
                    >
                      {testingMp ? 'Testando Conexão...' : 'Testar Conexão com Mercado Pago'}
                    </button>

                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      {mpSavedSuccess && (
                        <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="h-4 w-4" /> Salvo!
                        </span>
                      )}
                      <button
                        type="submit"
                        disabled={savingMp}
                        className="rounded-xl bg-[#009EE3] px-5 py-2.5 text-xs font-black text-white hover:bg-[#0082ba] active:scale-98 transition disabled:opacity-50 shadow-md"
                      >
                        {savingMp ? 'Gravando no Banco...' : `Salvar API ${mercadoPagoSettings.sandboxMode ? 'de Teste' : 'de Produção'}`}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>

            {/* TABELA: HISTÓRICO DE RECARGAS & TRANSAÇÕES */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Clock className="h-4 w-4 text-[#22D3EE]" />
                    Histórico de Recargas e Transações
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Controle de créditos adquiridos pelos usuários do bate-papo via Mercado Pago.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="rounded-xl bg-[#0A0C10] border border-[#1E293B] px-3 py-1.5 text-right">
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 block font-semibold">
                      Total de Transações
                    </span>
                    <span className="text-sm font-black text-[#22D3EE] font-mono">
                      {rechargeTransactions.length}
                    </span>
                  </div>
                  <div className="rounded-xl bg-[#0A0C10] border border-[#1E293B] px-3 py-1.5 text-right">
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 block font-semibold">
                      Volume Aprovado
                    </span>
                    <span className="text-sm font-black text-emerald-400 font-mono">
                      R${' '}
                      {rechargeTransactions
                        .filter((t) => t.status === 'approved')
                        .reduce((acc, t) => acc + t.amount, 0)
                        .toFixed(2)
                        .replace('.', ',')}
                    </span>
                  </div>
                </div>
              </div>

              {rechargeTransactions.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  Nenhuma transação de recarga registrada até o momento.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="border-b border-[#1E293B] bg-[#0A0C10] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                      <tr>
                        <th className="px-4 py-3">ID da Transação</th>
                        <th className="px-4 py-3">Usuário</th>
                        <th className="px-4 py-3">Valor (R$)</th>
                        <th className="px-4 py-3">Método</th>
                        <th className="px-4 py-3">Data</th>
                        <th className="px-4 py-3">Expiração (30 dias)</th>
                        <th className="px-4 py-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1E293B]/60">
                      {rechargeTransactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-[#1E293B]/40">
                          <td className="px-4 py-3 font-mono text-[11px] text-slate-400">{tx.id}</td>
                          <td className="px-4 py-3 font-semibold text-white">
                            {tx.userName || tx.userEmail || tx.userId}
                          </td>
                          <td className="px-4 py-3 font-mono font-bold text-emerald-400">
                            R$ {tx.amount.toFixed(2).replace('.', ',')}
                          </td>
                          <td className="px-4 py-3 uppercase text-[11px] font-bold text-[#22D3EE]">
                            {tx.method}
                          </td>
                          <td className="px-4 py-3 font-mono text-[11px] text-slate-400">
                            {new Date(tx.createdAt).toLocaleString('pt-BR')}
                          </td>
                          <td className="px-4 py-3 font-mono text-[11px] text-amber-300/80">
                            {tx.expiresAt ? new Date(tx.expiresAt).toLocaleDateString('pt-BR') : '30 dias'}
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                tx.status === 'approved'
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                                  : tx.status === 'pending'
                                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                              }`}
                            >
                              {tx.status === 'approved' ? 'Aprovado' : tx.status === 'pending' ? 'Pendente' : tx.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB: GESTÃO FINANCEIRA */}
        {activeTab === 'financial' && <FinancialAdminTab />}

        {/* TAB: FIREWALL & MONITORAMENTO ONLINE */}
        {activeTab === 'firewall' && <FirewallAdminTab />}

        {/* TAB: NUVEM SUPABASE & BACKUP */}
        {activeTab === 'supabase' && <SupabaseAdminTab />}

        {/* TAB: MOEDA VIRTUAL PASQCOIN */}
        {activeTab === 'pasqcoin' && (
          <PasqcoinAdminTab
            settings={pasqcoinSettings}
            batches={pasqcoinBatches}
            transactions={pasqcoinTransactions}
            users={adminUsers}
            onRefresh={fetchAdminData}
          />
        )}

        {/* TAB 3: SERVER DEBIAN 12 & APACHE & PM2 */}
        {activeTab === 'server' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-black uppercase italic tracking-tight text-white">
                Infraestrutura Linux Debian 12 + Apache 2.4 + SSL + PM2
              </h2>
              <p className="text-xs text-slate-400">
                Parâmetros do servidor VPS, virtual host parametrizado e monitoramento de processos.
              </p>
            </div>

            {/* Server Specs Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <p className="text-slate-400 text-xs font-semibold">Sistema Operacional</p>
                <p className="text-sm font-bold text-white mt-1">Linux Debian 12 (Bookworm)</p>
                <p className="text-[11px] text-emerald-400 mt-0.5">Compatível & Parametrizado</p>
              </div>

              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <p className="text-slate-400 text-xs font-semibold">Servidor Web</p>
                <p className="text-sm font-bold text-white mt-1">Apache 2.4 (Reverse Proxy)</p>
                <p className="text-[11px] text-[#22D3EE] mt-0.5">mod_proxy + mod_proxy_wstunnel</p>
              </div>

              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <p className="text-slate-400 text-xs font-semibold">Certificado SSL Válido</p>
                <p className="text-sm font-bold text-white mt-1">chamasso.pasquared.space</p>
                <p className="text-[11px] text-[#F472B6] mt-0.5">rogeriogomes11@ukbelol.space</p>
              </div>

              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <p className="text-slate-400 text-xs font-semibold">Gerenciador de Processos</p>
                <p className="text-sm font-bold text-white mt-1">PM2 (Cluster Mode)</p>
                <p className="text-[11px] text-emerald-400 mt-0.5">Autorestart & Systemd</p>
              </div>
            </div>

            {/* VirtualHost Configuration View */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-[#22D3EE] flex items-center gap-2">
                  <Terminal className="h-4 w-4" />
                  Arquivo de Configuração: /etc/apache2/sites-available/chamasso.pasquared.space.conf
                </span>
                <button
                  onClick={() => {
                    setCopiedVhost(true);
                    setTimeout(() => setCopiedVhost(false), 2000);
                  }}
                  className="flex items-center gap-1 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-[#334155]"
                >
                  {copiedVhost ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedVhost ? 'Copiado' : 'Copiar Config'}</span>
                </button>
              </div>

              <pre className="overflow-x-auto rounded-xl bg-[#0A0C10] border border-[#1E293B] p-4 text-[11px] font-mono text-slate-300 leading-relaxed max-h-72">
{`<VirtualHost *:80>
    ServerName chamasso.pasquared.space
    ServerAdmin rogeriogomes11@ukbelol.space
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</VirtualHost>

<VirtualHost *:443>
    ServerName chamasso.pasquared.space
    ServerAdmin rogeriogomes11@ukbelol.space

    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem

    # Proxy para WebSockets (/ws) do chamasso live chat
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*) ws://127.0.0.1:3000/$1 [P,L]

    ProxyPass /ws ws://127.0.0.1:3000/ws
    ProxyPassReverse /ws ws://127.0.0.1:3000/ws

    # Proxy reverso para o app gerenciado por PM2 na porta 3000
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/
</VirtualHost>`}
              </pre>
            </div>
          </div>
        )}

        {/* TAB: DATABASE POSTGRESQL & PERSISTENCE */}
        {activeTab === 'database' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h2 className="text-lg font-black uppercase italic tracking-tight text-white flex items-center gap-2">
                  <Database className="h-5 w-5 text-[#22D3EE]" />
                  SGBD PostgreSQL & Persistência de Dados (db_chamasso)
                </h2>
                <p className="text-xs text-slate-400">
                  Gerenciamento do banco de dados relacional, script de criação SQL, credenciais do Super Admin e configurações persistentes.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadSql}
                  className="flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/40 bg-[#22D3EE]/10 px-3 py-1.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#22D3EE] hover:text-black transition"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Baixar db_chamasso.sql</span>
                </button>
              </div>
            </div>

            {/* SGBD Specs Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-slate-400 text-xs font-semibold">SGBD Recomendado</p>
                  <Database className="h-4 w-4 text-[#22D3EE]" />
                </div>
                <p className="text-sm font-bold text-white mt-1">PostgreSQL 14 / 15 / 16</p>
                <p className="text-[11px] text-emerald-400 mt-0.5 font-mono">
                  {dbStatus?.storageMode || 'Persistência Durável Ativa'}
                </p>
              </div>

              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-slate-400 text-xs font-semibold">Banco & Usuário Padrão</p>
                  <Server className="h-4 w-4 text-[#F472B6]" />
                </div>
                <p className="text-sm font-bold text-white mt-1 font-mono">db_chamasso</p>
                <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
                  user: <span className="text-[#22D3EE]">user_chamasso</span>
                </p>
              </div>

              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-slate-400 text-xs font-semibold">Super Admin Master</p>
                  <ShieldCheck className="h-4 w-4 text-emerald-400" />
                </div>
                <p className="text-sm font-bold text-white mt-1 truncate">roger577@ukbelol.space</p>
                <p className="text-[11px] text-[#22D3EE] mt-0.5 font-semibold">
                  Permissões: ALL (Controle Total)
                </p>
              </div>

              <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4">
                <div className="flex items-center justify-between">
                  <p className="text-slate-400 text-xs font-semibold">Tabelas & Registros</p>
                  <Layers className="h-4 w-4 text-[#FACC15]" />
                </div>
                <p className="text-sm font-bold text-white mt-1">10 Tabelas Normalizadas</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {adminUsers.length} Usuários • {adminRooms.length} Salas • {relationshipLevels.length} Níveis
                </p>
              </div>
            </div>

            {/* Credenciais do Super Admin */}
            <div className="rounded-2xl border border-[#22D3EE]/30 bg-gradient-to-r from-[#0F172A] to-[#1E293B]/40 p-5 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#22D3EE] bg-[#22D3EE]/10 px-2 py-0.5 rounded-full border border-[#22D3EE]/30">
                    Credenciais Oficiais de Super Administrador
                  </span>
                  <h3 className="text-sm font-bold text-white mt-2 flex items-center gap-2">
                    <KeyRound className="h-4 w-4 text-[#F472B6]" />
                    Acesso Master com Permissões Irrestritas (ALL)
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3 text-xs font-mono">
                    <div className="bg-[#0A0C10] p-2.5 rounded-xl border border-[#1E293B]">
                      <span className="text-slate-500 block text-[10px]">E-mail de Login:</span>
                      <span className="text-[#22D3EE] font-bold">roger577@ukbelol.space</span>
                    </div>
                    <div className="bg-[#0A0C10] p-2.5 rounded-xl border border-[#1E293B]">
                      <span className="text-slate-500 block text-[10px]">Senha Padrão:</span>
                      <span className="text-emerald-400 font-bold">Senha definida no servidor (.env)</span>
                    </div>
                    <div className="bg-[#0A0C10] p-2.5 rounded-xl border border-[#1E293B]">
                      <span className="text-slate-500 block text-[10px]">Perfil & Permissões:</span>
                      <span className="text-[#F472B6] font-bold">SUPER_ADMIN (["ALL"])</span>
                    </div>
                  </div>
                </div>
                <div className="shrink-0 flex sm:flex-col gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('roger577@ukbelol.space');
                      alert('Credenciais copiadas para a área de transferência!');
                    }}
                    className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-[#334155] transition"
                  >
                    <Copy className="h-3.5 w-3.5" />
                    <span>Copiar Credenciais</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Configurações Persistentes do Sistema (Salvas no Banco de Dados) */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-[#22D3EE]" />
                    Configurações Gerais do Sistema (Persistência Garantida)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Estes parâmetros ficam gravados de forma persistente no banco de dados e não são perdidos ao reiniciar o servidor.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.keys(dbSettings).map((key) => {
                  const setting = dbSettings[key];
                  return (
                    <div key={key} className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-mono text-xs font-bold text-[#22D3EE]">{setting.key}</span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            Atualizado: {new Date(setting.updatedAt).toLocaleTimeString('pt-BR')}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mb-2">{setting.description}</p>
                        <textarea
                          rows={4}
                          value={settingEditValues[key] || ''}
                          onChange={(e) =>
                            setSettingEditValues({
                              ...settingEditValues,
                              [key]: e.target.value,
                            })
                          }
                          className="w-full rounded-lg border border-[#1E293B] bg-[#0F172A] p-2.5 font-mono text-xs text-slate-200 focus:border-[#22D3EE] focus:outline-none"
                        />
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        {saveSettingSuccess === key ? (
                          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <Check className="h-3.5 w-3.5" /> Gravado no Banco com Sucesso!
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-500">Formato JSON</span>
                        )}
                        <button
                          onClick={() => handleSaveSetting(key)}
                          className="flex items-center gap-1.5 rounded-lg bg-[#22D3EE] px-3 py-1 text-xs font-bold text-black hover:brightness-110 transition"
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>Salvar no Banco</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Script SQL de Criação e Configuração (db_chamasso.sql) */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                <div>
                  <span className="text-xs font-bold text-[#22D3EE] flex items-center gap-2">
                    <Terminal className="h-4 w-4" />
                    Script de Criação de Banco, Usuário, Tabelas e Super Admin: db_chamasso.sql
                  </span>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Este script é executado automaticamente pelo instalador (<code className="text-[#22D3EE]">install.sh</code>) no Debian 12 com PostgreSQL.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(sqlScript);
                      setCopiedSql(true);
                      setTimeout(() => setCopiedSql(false), 2000);
                    }}
                    className="flex items-center gap-1 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-[#334155]"
                  >
                    {copiedSql ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copiedSql ? 'Copiado' : 'Copiar SQL'}</span>
                  </button>
                  <button
                    onClick={handleDownloadSql}
                    className="flex items-center gap-1 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-3 py-1 text-xs font-black text-black hover:brightness-110"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Baixar Arquivo .sql</span>
                  </button>
                </div>
              </div>

              <pre className="overflow-x-auto rounded-xl bg-[#0A0C10] border border-[#1E293B] p-4 text-[11px] font-mono text-slate-300 leading-relaxed max-h-96">
                {sqlScript || '-- Carregando script SQL...'}
              </pre>

              <div className="mt-3 p-3 rounded-xl bg-[#0A0C10] border border-[#1E293B] text-xs text-slate-400">
                <span className="font-bold text-white">Como executar manualmente no PostgreSQL:</span>
                <div className="mt-1 font-mono text-[11px] text-[#22D3EE] bg-[#0F172A] p-2 rounded-lg">
                  sudo -u postgres psql -f /caminho/do/projeto/db_chamasso.sql
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: AUTOMATED INSTALLER SCRIPT (Debian 12) */}
        {activeTab === 'installer' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-black uppercase italic tracking-tight text-white">
                Script de Instalação Automatizada (Debian 12 + Apache + PM2)
              </h2>
              <p className="text-xs text-slate-400">
                Execute este instalador diretamente no terminal do seu servidor Debian 12 ou superior para
                instalar todas as dependências, configurar o Apache, obter o certificado SSL e subir o PM2.
              </p>
            </div>

            {/* Quick Command */}
            <div className="rounded-2xl border border-[#22D3EE]/40 bg-[#0F172A] p-4">
              <p className="text-xs text-slate-400 mb-2">Comando rápido para executar no servidor VPS como root:</p>
              <div className="flex items-center justify-between rounded-xl bg-[#0A0C10] border border-[#1E293B] px-4 py-3 font-mono text-xs text-[#22D3EE]">
                <span>sudo chmod +x install.sh && sudo ./install.sh</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('sudo chmod +x install.sh && sudo ./install.sh');
                    setCopiedScript(true);
                    setTimeout(() => setCopiedScript(false), 2000);
                  }}
                  className="flex items-center gap-1 rounded-xl bg-[#1E293B] px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:bg-[#22D3EE] hover:text-black transition"
                >
                  {copiedScript ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedScript ? 'Copiado' : 'Copiar'}</span>
                </button>
              </div>
            </div>

            {/* Full Script Preview */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-white flex items-center gap-2">
                  <Terminal className="h-4 w-4 text-[#22D3EE]" />
                  Conteúdo Completo do install.sh
                </span>
              </div>

              <pre className="overflow-x-auto rounded-xl bg-[#0A0C10] border border-[#1E293B] p-4 text-[11px] font-mono text-slate-300 leading-relaxed max-h-96">
{`#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO AUTOMATIZADA: CHAMASSO LIVE CHAT
# Compatível com: Linux Debian 12 (Bookworm)
# SGBD: PostgreSQL 15+ (db_chamasso / user_chamasso)
# Servidor Web: Apache 2.4 com Proxy Reverso + WebSockets + Certificado SSL
# Domínio: chamasso.pasquared.space
# E-mail de Segurança: rogeriogomes11@ukbelol.space
# Gerenciador de Processos: PM2
# ==============================================================================
set -e

apt-get update -y && apt-get upgrade -y
apt-get install -y curl wget git build-essential ufw apache2 certbot python3-certbot-apache postgresql postgresql-contrib

# Iniciar e habilitar PostgreSQL
systemctl enable postgresql
systemctl start postgresql

# Configurar Banco de Dados db_chamasso e usuário user_chamasso
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='user_chamasso'" | grep -q 1 || \
sudo -u postgres psql -c "CREATE USER user_chamasso WITH PASSWORD 'Chamasso@2026_SecureDb!';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='db_chamasso'" | grep -q 1 || \
sudo -u postgres psql -c "CREATE DATABASE db_chamasso OWNER user_chamasso;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE db_chamasso TO user_chamasso;"

# Executar Script SQL de criação de tabelas e Super Admin
sudo -u postgres psql -d db_chamasso -f db_chamasso.sql

# Instalar Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
npm install -g pm2

# Módulos essenciais Apache
a2enmod proxy proxy_http proxy_wstunnel rewrite ssl headers deflate

# Compilar aplicação
npm install
npm run build

# Certificado SSL Certbot
certbot --apache -d chamasso.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@ukbelol.space --redirect

# Iniciar com PM2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup`}
              </pre>
            </div>
          </div>
        )}

        {/* TAB 5: AUDIT LOGS & DISPOSABLE CODES */}
        {activeTab === 'logs' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-black uppercase italic tracking-tight text-white">Auditoria de Segurança & 2FA</h2>
              <p className="text-xs text-slate-400">
                Registro de logins, códigos descartáveis consumidos, alertas e bloqueios de moderadores.
              </p>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="border-b border-[#1E293B] bg-[#0A0C10] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                  <tr>
                    <th className="px-4 py-3">Data / Hora</th>
                    <th className="px-4 py-3">Ação</th>
                    <th className="px-4 py-3">Ator</th>
                    <th className="px-4 py-3">Detalhes</th>
                    <th className="px-4 py-3">Nível</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]/60">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-[#1E293B]/40">
                      <td className="px-4 py-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString('pt-BR')}
                      </td>
                      <td className="px-4 py-3 font-semibold text-[#22D3EE]">{log.action}</td>
                      <td className="px-4 py-3 text-slate-200">{log.actor}</td>
                      <td className="px-4 py-3 text-slate-300 max-w-md">{log.details}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                            log.level === 'security'
                              ? 'bg-amber-950 border border-amber-700 text-amber-300'
                              : log.level === 'warn'
                              ? 'bg-rose-950 border border-rose-700 text-rose-300'
                              : 'bg-[#1E293B] text-slate-400'
                          }`}
                        >
                          {log.level}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* MODAL: CRIAR NOVO USUÁRIO PELO ADMIN */}
        {showCreateUserModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
            <div className="w-full max-w-md rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <h3 className="text-base font-black uppercase italic tracking-tight text-white mb-3">Criar Usuário pelo Super Admin</h3>
              <form onSubmit={handleCreateUser} className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Nome"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Sobrenome"
                    value={newUserLastName}
                    onChange={(e) => setNewUserLastName(e.target.value)}
                    className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>
                <input
                  type="date"
                  required
                  value={newUserBirthDate}
                  onChange={(e) => setNewUserBirthDate(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                />
                <input
                  type="text"
                  required
                  placeholder="CPF (000.000.000-00)"
                  value={newUserCpf}
                  onChange={(e) => setNewUserCpf(formatCPF(e.target.value))}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                />
                <input
                  type="email"
                  required
                  placeholder="E-mail Google"
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                />
                <div className="flex gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateUserModal(false)}
                    className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2 text-xs font-black text-black hover:brightness-110"
                  >
                    Salvar Usuário & Gerar 2FA
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL: CRIAR SALA PELO ADMIN */}
        {showCreateRoomModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
            <div className="w-full max-w-md rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <h3 className="text-base font-black uppercase italic tracking-tight text-white mb-3">Criar Nova Sala de Bate-Papo</h3>
              <form onSubmit={handleCreateRoom} className="space-y-3">
                <input
                  type="text"
                  required
                  placeholder="Nome da Sala (ex: Encontros em São Paulo)"
                  value={newRoomName}
                  onChange={(e) => setNewRoomName(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                />
                <textarea
                  rows={3}
                  placeholder="Descrição da Sala"
                  value={newRoomDesc}
                  onChange={(e) => setNewRoomDesc(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                />
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={newRoomCat}
                    onChange={(e) => setNewRoomCat(e.target.value as any)}
                    className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                  >
                    <option value="paquera">❤️ Paquera</option>
                    <option value="amizade">☕ Amizade</option>
                    <option value="romance">🌹 Romance</option>
                    <option value="musica">🎵 Música & Voz</option>
                  </select>
                  <select
                    value={newRoomType}
                    onChange={(e) => setNewRoomType(e.target.value as any)}
                    className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                  >
                    <option value="public">Pública (Livre)</option>
                    <option value="private">Privada (Aprovação)</option>
                  </select>
                </div>
                <div className="flex gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateRoomModal(false)}
                    className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2 text-xs font-black text-black hover:brightness-110"
                  >
                    Criar Sala
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL: CRIAR / EDITAR NÍVEL DE RELACIONAMENTO */}
        {showCreateLevelModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
            <div className="w-full max-w-md rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-[#F472B6]" />
                  <h3 className="text-base font-black uppercase italic tracking-tight text-white">
                    {editingLevel ? 'Editar Nível de Relacionamento' : 'Novo Nível de Relacionamento'}
                  </h3>
                </div>
                <button
                  onClick={() => setShowCreateLevelModal(false)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-[#1E293B]"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSaveRelationshipLevel} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Nome do Nível:</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Colegas de Faculdade, Mentoria, etc."
                    value={levelName}
                    onChange={(e) => setLevelName(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Descrição do Nível:</label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Descreva o propósito ou contexto desta relação..."
                    value={levelDesc}
                    onChange={(e) => setLevelDesc(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Ícone / Emoji Representativo:</label>
                  <div className="flex flex-wrap items-center gap-2">
                    {['☕', '❤️', '⭐', '💼', '💍', '🏡', '🏖️', '🚀', '🔥', '🎉', '🎧', '✨'].map(
                      (ic) => (
                        <button
                          key={ic}
                          type="button"
                          onClick={() => setLevelIcon(ic)}
                          className={`h-9 w-9 rounded-xl border text-base transition ${
                            levelIcon === ic
                              ? 'border-[#22D3EE] bg-[#22D3EE]/20 scale-110'
                              : 'border-[#1E293B] bg-[#0A0C10] hover:border-slate-600'
                          }`}
                        >
                          {ic}
                        </button>
                      )
                    )}
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Cor de Destaque:</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={levelColor}
                      onChange={(e) => setLevelColor(e.target.value)}
                      className="h-9 w-12 rounded-lg cursor-pointer bg-transparent border-0"
                    />
                    <div className="flex gap-1.5">
                      {['#22D3EE', '#F472B6', '#F59E0B', '#38BDF8', '#EC4899', '#A855F7', '#10B981'].map(
                        (col) => (
                          <button
                            key={col}
                            type="button"
                            onClick={() => setLevelColor(col)}
                            style={{ backgroundColor: col }}
                            className={`h-6 w-6 rounded-full border-2 transition ${
                              levelColor === col ? 'border-white scale-110' : 'border-transparent'
                            }`}
                          />
                        )
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-3 border-t border-[#1E293B]">
                  <button
                    type="button"
                    onClick={() => setShowCreateLevelModal(false)}
                    className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2 text-xs font-black text-black hover:brightness-110"
                  >
                    {editingLevel ? 'Atualizar Nível' : 'Salvar Nível de Relacionamento'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {/* MODAL: 11 CÓDIGOS DESCARTÁVEIS RESETADOS */}
        {resetCodesModalData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <div className="relative w-full max-w-lg rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-[#22D3EE] to-emerald-400 text-black font-black">
                    <KeyRound className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">11 Códigos Provisórios Resetados</h3>
                    <p className="text-[11px] text-slate-400">
                      Usuário: {resetCodesModalData.user?.name} {resetCodesModalData.user?.lastName}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setResetCodesModalData(null)}
                  className="rounded-lg p-1 text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-3.5 flex items-start gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="text-xs text-emerald-300">
                    <strong className="block text-white mb-0.5">Disparado com Sucesso!</strong>
                    Os 11 códigos foram enviados para o e-mail cadastrado{' '}
                    <span className="font-mono underline text-emerald-200">{resetCodesModalData.email}</span>{' '}
                    como anexo TXT (<span className="font-mono">{resetCodesModalData.fileName}</span>).
                  </div>
                </div>

                <div>
                  <span className="text-xs font-bold text-slate-300 block mb-2">
                    Lista dos 11 Novos Códigos Descartáveis 2FA:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-[#0A0C10] p-3 rounded-2xl border border-[#1E293B]">
                    {resetCodesModalData.codes.map((code, idx) => (
                      <div
                        key={idx}
                        className="rounded-lg border border-[#1E293B] bg-[#0F172A] p-2 text-center"
                      >
                        <span className="text-[9px] font-mono text-slate-500 block">
                          CÓDIGO #{String(idx + 1).padStart(2, '0')}
                        </span>
                        <span className="font-mono text-xs font-bold text-[#22D3EE] tracking-wider">
                          {code}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#1E293B]">
                  <button
                    type="button"
                    onClick={() => {
                      const blob = new Blob([resetCodesModalData.txtContent], { type: 'text/plain;charset=utf-8' });
                      const url = URL.createObjectURL(blob);
                      const link = document.createElement('a');
                      link.href = url;
                      link.download = resetCodesModalData.fileName;
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                      URL.revokeObjectURL(url);
                    }}
                    className="flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/40 bg-[#22D3EE]/10 px-4 py-2 text-xs font-bold text-[#22D3EE] hover:bg-[#22D3EE]/20 transition"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Baixar Novamente .TXT</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setResetCodesModalData(null)}
                    className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2 text-xs font-black text-black hover:brightness-110 shadow-md"
                  >
                    Concluir
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
