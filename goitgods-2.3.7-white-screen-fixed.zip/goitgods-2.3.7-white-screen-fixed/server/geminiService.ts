import { GoogleGenAI } from '@google/genai';

let aiClient: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
  }
  return aiClient;
}

export async function generateTextWithGemini(
  prompt: string,
  systemInstruction?: string,
  responseJson: boolean = false
): Promise<string | null> {
  const ai = getGeminiClient();
  if (!ai) return null;

  const models = ['gemini-2.5-flash', 'gemini-1.5-flash', 'gemini-2.5-pro'];
  const maxRetries = 2;

  for (const model of models) {
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            systemInstruction,
            responseMimeType: responseJson ? 'application/json' : undefined,
          },
        });

        if (response && response.text) {
          return response.text;
        }
      } catch (error: any) {
        console.warn(`[GEMINI WARNING] Attempt ${attempt} failed for model ${model}:`, error.message || error);
        
        // If it's the last attempt on the last model, throw or return null
        if (attempt === maxRetries && model === models[models.length - 1]) {
          console.error('[GEMINI ERROR] All fallback models and retry attempts exhausted.', error);
          return null;
        }

        // Wait before retrying (exponential backoff)
        const delay = Math.pow(2, attempt) * 500;
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  return null;
}
