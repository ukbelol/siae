import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, Search } from 'lucide-react';
import PhotoUpload from '../components/PhotoUpload';

export default function Register() {
  const navigate = useNavigate();
  const [role, setRole] = useState('assisted');
  const [error, setError] = useState('');
  
  // User Data
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', cpf: '', dob: '', age: '', religion: '', email: '', password: '',
    phone: '', street: '', number: '', neighborhood: '', city: '', state: '', country: '',
    skills: '', specializations: '', profession: '', photo_url: ''
  });

  // House Data (if representative)
  const [houseData, setHouseData] = useState({
    name: '', cnpj: '', email: '', phone: '', street: '', number: '', neighborhood: '', city: '', state: '', country: ''
  });

  // House Search
  const [houses, setHouses] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchService, setSearchService] = useState('');
  const [searchTime, setSearchTime] = useState('');

  useEffect(() => {
    const delay = setTimeout(() => {
      if (searchTerm.length < 3 && !searchService && !searchTime) {
        if (searchTerm.length === 0) setHouses([]);
        return;
      }
      fetch(`/api/houses/search?term=${encodeURIComponent(searchTerm)}&service=${encodeURIComponent(searchService)}&time=${encodeURIComponent(searchTime)}`)
        .then(res => res.json())
        .then(setHouses)
        .catch(console.error);
    }, 400);
    return () => clearTimeout(delay);
  }, [searchTerm, searchService, searchTime]);

  const submitRegistration = async () => {
    try {
      // 1. Register User
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, role })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      localStorage.setItem('siae_token', data.token);
      localStorage.setItem('siae_user', JSON.stringify(data.user));
      
      if (role === 'representative') {
        navigate('/register-house');
      } else {
        alert('Cadastro realizado! Dirija-se à casa espírita mais próxima para gravar sua tag NFC localmente e fazer o primeiro check-in.');
        navigate('/dashboard');
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitRegistration();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="SIAE Logo" className="mx-auto h-24 w-auto object-contain mb-4" onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling?.classList.remove('hidden'); }} />
          <Heart className="mx-auto h-12 w-12 text-indigo-600 hidden" />
          <h2 className="mt-2 text-3xl font-extrabold text-gray-900">Cadastro SIAE</h2>
          <p className="mt-2 text-sm text-gray-600 font-medium">Sistema Integrado de Atendimento Espírita</p>
          <p className="mt-2 text-sm text-gray-600">
            Já tem uma conta? <Link to="/login" className="text-indigo-600 hover:text-indigo-500">Faça login</Link>
          </p>
        </div>

        {error && <div className="mb-4 text-red-500 text-sm text-center bg-red-50 p-3 rounded-lg">{error}</div>}

        <form onSubmit={handleUserSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Qual o seu perfil?</label>
              <select 
                value={role} 
                onChange={(e) => setRole(e.target.value)}
                className="w-full rounded-lg border-gray-300 border p-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="assisted">Assistido (Frequentador)</option>
                <option value="worker">Trabalhador</option>
                <option value="representative">Representante de Casa Espírita</option>
              </select>
            </div>

            <div className="mb-4 flex flex-col items-center">
               <label className="block text-sm font-medium text-gray-700 mb-2 text-center">Sua Foto de Perfil</label>
               <PhotoUpload 
                 currentPhoto={formData.photo_url} 
                 onUploadComplete={(url) => setFormData({...formData, photo_url: url})} 
               />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-700">Nome</label>
                <input required type="text" className="w-full border rounded p-2" value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Sobrenome</label>
                <input required type="text" className="w-full border rounded p-2" value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">CPF</label>
                <input required type="text" className="w-full border rounded p-2" value={formData.cpf} onChange={e => setFormData({...formData, cpf: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Data de Nascimento</label>
                <input required type="date" className="w-full border rounded p-2" value={formData.dob} onChange={e => {
                  const dob = new Date(e.target.value);
                  const today = new Date();
                  let age = today.getFullYear() - dob.getFullYear();
                  if (today.getMonth() < dob.getMonth() || (today.getMonth() === dob.getMonth() && today.getDate() < dob.getDate())) {
                    age--;
                  }
                  setFormData({...formData, dob: e.target.value, age: age.toString()});
                }} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Idade</label>
                <input type="number" readOnly className="w-full border rounded p-2 bg-gray-100" value={formData.age} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Religião</label>
                <input required type="text" className="w-full border rounded p-2" value={formData.religion} onChange={e => setFormData({...formData, religion: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">E-mail</label>
                <input required type="email" className="w-full border rounded p-2" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Senha</label>
                <input required type="password" className="w-full border rounded p-2" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Telefone</label>
                <input type="text" className="w-full border rounded p-2" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Profissão</label>
                <input type="text" className="w-full border rounded p-2" value={formData.profession} onChange={e => setFormData({...formData, profession: e.target.value})} />
              </div>
            </div>

            <h3 className="text-lg font-medium text-gray-900 mt-6">Endereço</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-700">Rua</label>
                <input type="text" className="w-full border rounded p-2" value={formData.street} onChange={e => setFormData({...formData, street: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Número</label>
                <input type="text" className="w-full border rounded p-2" value={formData.number} onChange={e => setFormData({...formData, number: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Bairro</label>
                <input type="text" className="w-full border rounded p-2" value={formData.neighborhood} onChange={e => setFormData({...formData, neighborhood: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Cidade</label>
                <input type="text" className="w-full border rounded p-2" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm text-gray-700">Estado</label>
                <input type="text" className="w-full border rounded p-2" value={formData.state} onChange={e => setFormData({...formData, state: e.target.value})} />
              </div>
            </div>

            <button type="submit" className="w-full bg-indigo-600 text-white p-3 rounded-lg font-medium hover:bg-indigo-700">
              {role === 'representative' ? 'Salvar e Continuar (Cadastro da Casa)' : 'Concluir Cadastro'}
            </button>
          </form>
      </div>

      {(role === 'assisted' || role === 'worker') && (
        <div className="max-w-4xl mx-auto mt-8 bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Encontre sua Casa Espírita Ideal</h2>
          <p className="text-sm text-gray-600 mb-6">Busque opções disponíveis por local, tipo de serviço ou horário de funcionamento antes de se registrar.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
              <input 
                type="text" 
                placeholder="Nome, cidade, estado..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <input 
                type="text" 
                placeholder="Tipo de serviço (ex: Passe)..." 
                value={searchService}
                onChange={(e) => setSearchService(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <input 
                type="text" 
                placeholder="Horário (ex: sáb, 08h)..." 
                value={searchTime}
                onChange={(e) => setSearchTime(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {houses.length === 0 && (searchTerm || searchService || searchTime) ? (
              <p className="text-gray-500 col-span-full">Nenhuma casa espírita encontrada para estes filtros.</p>
            ) : (
              houses.map((house: any) => (
                <div key={house.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50 flex flex-col">
                  <h3 className="font-bold text-gray-900">{house.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{house.street}, {house.number} - {house.city} / {house.state}</p>
                  
                  {house.operating_hours && (
                    <div className="mt-3 text-sm text-gray-700">
                      <span className="font-semibold block">Horários:</span>
                      {house.operating_hours}
                    </div>
                  )}
                  
                  <div className="mt-3 flex flex-wrap gap-2 flex-grow">
                    {house.services?.split(',').map((s: string, i: number) => (
                      <span key={i} className="px-2 py-1 bg-white border border-gray-200 text-gray-600 text-xs rounded-full">{s.trim()}</span>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
