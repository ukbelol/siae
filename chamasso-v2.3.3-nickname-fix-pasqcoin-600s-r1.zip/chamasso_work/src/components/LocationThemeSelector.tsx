import React, { useState, useMemo } from 'react';
import {
  MapPin,
  Sparkles,
  Heart,
  Coffee,
  Flame,
  ArrowRight,
  Search,
  Filter,
  Users,
  Compass,
  CheckCircle2,
  Calendar,
  Zap,
} from 'lucide-react';
import { BRAZIL_STATES, CHAT_THEMES, type BrazilState, type ChatTheme } from '../data/brazilLocationsAndThemes.ts';
import type { Room, User } from '../types.ts';

interface LocationThemeSelectorProps {
  rooms: Room[];
  currentUser: User | null;
  onEnterRoom: (state: string, stateName: string, city: string, theme: ChatTheme) => void;
  onDirectJoinRoom?: (room: Room) => void;
}

export const LocationThemeSelector: React.FC<LocationThemeSelectorProps> = ({
  rooms,
  currentUser,
  onEnterRoom,
  onDirectJoinRoom,
}) => {
  const [selectedUf, setSelectedUf] = useState<string>('SP');
  const [selectedCity, setSelectedCity] = useState<string>('São Paulo (Capital)');
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<'all' | 'amizade' | 'paquera' | 'idade'>('all');
  const [selectedThemeId, setSelectedThemeId] = useState<string>('amizade_sincera');
  const [stateSearch, setStateSearch] = useState<string>('');
  const [citySearch, setCitySearch] = useState<string>('');

  // Encontra o estado atual
  const currentState: BrazilState = useMemo(() => {
    return BRAZIL_STATES.find((s) => s.uf === selectedUf) || BRAZIL_STATES[0];
  }, [selectedUf]);

  // Lista de estados filtrados pela busca
  const filteredStates = useMemo(() => {
    if (!stateSearch.trim()) return BRAZIL_STATES;
    const q = stateSearch.toLowerCase().trim();
    return BRAZIL_STATES.filter(
      (s) => s.name.toLowerCase().includes(q) || s.uf.toLowerCase().includes(q) || s.region.toLowerCase().includes(q)
    );
  }, [stateSearch]);

  // Lista de cidades filtradas pela busca
  const filteredCities = useMemo(() => {
    if (!citySearch.trim()) return currentState.popularCities;
    const q = citySearch.toLowerCase().trim();
    return currentState.popularCities.filter((c) => c.toLowerCase().includes(q));
  }, [currentState, citySearch]);

  // Temas filtrados pela aba de categoria
  const filteredThemes = useMemo(() => {
    if (selectedCategoryTab === 'all') return CHAT_THEMES;
    return CHAT_THEMES.filter((t) => t.category === selectedCategoryTab);
  }, [selectedCategoryTab]);

  // Tema atualmente selecionado
  const currentTheme: ChatTheme = useMemo(() => {
    return CHAT_THEMES.find((t) => t.id === selectedThemeId) || CHAT_THEMES[0];
  }, [selectedThemeId]);

  // Quando troca o estado, ajusta a cidade padrão para a primeira daquele estado
  const handleSelectState = (uf: string) => {
    setSelectedUf(uf);
    const st = BRAZIL_STATES.find((s) => s.uf === uf);
    if (st && st.popularCities.length > 0) {
      setSelectedCity(st.popularCities[0]);
    }
  };

  const handleEnterClick = () => {
    onEnterRoom(currentState.uf, currentState.name, selectedCity, currentTheme);
  };

  // Encontra se já existe alguma sala rodando exatamente com esse Estado, Cidade e Tema
  const existingMatchingRoom = useMemo(() => {
    return rooms.find((r) => {
      const matchState = r.state === currentState.uf || (r.name.includes(currentState.uf) && r.name.includes(selectedCity));
      const matchTheme = r.theme === currentTheme.id || r.name.toLowerCase().includes(currentTheme.label.toLowerCase());
      return matchState && matchTheme;
    });
  }, [rooms, currentState, selectedCity, currentTheme]);

  return (
    <div className="w-full mb-8 rounded-3xl border border-[#1E293B] bg-gradient-to-b from-[#0F172A] via-[#0A0C10] to-[#0F172A] p-4 sm:p-6 lg:p-7 shadow-2xl overflow-hidden">
      {/* Header do Seletor */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-[#1E293B]">
        <div className="flex items-center gap-3.5 min-w-0">
          <div className="flex h-11 w-11 sm:h-12 sm:w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[#22D3EE]/20 via-[#F472B6]/20 to-[#22D3EE]/10 border border-[#22D3EE]/40 text-[#22D3EE] shadow-[0_0_20px_rgba(34,211,238,0.25)] shrink-0">
            <Compass className="h-5 w-5 sm:h-6 sm:w-6" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg sm:text-2xl font-black italic uppercase tracking-tight text-white truncate">
                Bate-Papo por Cidades & Estados
              </h2>
              <span className="rounded-full bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-2.5 py-0.5 text-[10px] font-black uppercase text-black shadow-md shrink-0">
                Salas Regionais
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 line-clamp-2">
              Escolha seu estado, sua cidade e o tema de conversa para entrar instantaneamente na sala com chat, áudio e vídeo!
            </p>
          </div>
        </div>

        {/* Resumo da seleção atual e botão de entrada rápida */}
        <div className="w-full md:w-auto shrink-0">
          <button
            onClick={handleEnterClick}
            className="w-full md:w-auto flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#22D3EE] via-[#F472B6] to-[#22D3EE] bg-size-200 hover:bg-right px-4 sm:px-6 py-3 text-xs sm:text-sm font-black text-black shadow-xl shadow-[#22D3EE]/25 hover:scale-[1.02] active:scale-95 transition-all duration-300"
          >
            <span className="truncate max-w-[280px] sm:max-w-none">
              Entrar em {currentState.uf} - {selectedCity} ({currentTheme.label})
            </span>
            <ArrowRight className="h-4 w-4 text-black shrink-0" />
          </button>
        </div>
      </div>

      {/* Grid de 3 Colunas: 1. Estados | 2. Cidades Mais Populosas | 3. Temas de Amizade & Paquera */}
      <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 sm:gap-5">
        
        {/* COLUNA 1: Estados Principais (3 colunas no lg) */}
        <div className="lg:col-span-3 flex flex-col rounded-2xl border border-[#1E293B] bg-[#0A0C10]/80 p-3.5 sm:p-4">
          <div className="flex items-center justify-between pb-2.5 border-b border-[#1E293B] mb-2.5">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-slate-200">
              <MapPin className="h-3.5 w-3.5 text-[#22D3EE]" />
              <span>1. Estado (UF)</span>
            </div>
            <span className="text-[10px] font-bold text-[#22D3EE] bg-[#22D3EE]/10 px-2 py-0.5 rounded-full border border-[#22D3EE]/30">
              {currentState.uf} - {currentState.name}
            </span>
          </div>

          {/* Busca de Estado */}
          <div className="relative mb-2.5">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={stateSearch}
              onChange={(e) => setStateSearch(e.target.value)}
              placeholder="Filtrar estado ou região..."
              className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
            />
          </div>

          {/* Lista de Estados */}
          <div className="flex-1 max-h-[260px] sm:max-h-[300px] overflow-y-auto space-y-1 pr-1 scrollbar-thin scrollbar-thumb-[#1E293B] scrollbar-track-transparent">
            {filteredStates.map((st) => {
              const isSelected = selectedUf === st.uf;
              return (
                <button
                  key={st.uf}
                  onClick={() => handleSelectState(st.uf)}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs font-bold transition text-left ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#22D3EE]/20 to-[#F472B6]/20 border border-[#22D3EE] text-white shadow-md'
                      : 'border border-transparent hover:border-[#1E293B] bg-[#0F172A]/50 text-slate-300 hover:text-white hover:bg-[#1E293B]/40'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className={`w-7 h-6 rounded-md flex items-center justify-center text-[10px] font-black shrink-0 ${
                      isSelected ? 'bg-[#22D3EE] text-black' : 'bg-[#1E293B] text-slate-300'
                    }`}>
                      {st.uf}
                    </span>
                    <span className="truncate text-[11px] sm:text-xs">{st.name}</span>
                  </div>
                  <span className="text-[10px] font-normal text-slate-500 shrink-0 ml-1">
                    {st.region}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* COLUNA 2: Cidades Populosas (4 colunas no lg) */}
        <div className="lg:col-span-4 flex flex-col rounded-2xl border border-[#1E293B] bg-[#0A0C10]/80 p-3.5 sm:p-4">
          <div className="flex items-center justify-between pb-2.5 border-b border-[#1E293B] mb-2.5">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-slate-200">
              <Users className="h-3.5 w-3.5 text-[#F472B6]" />
              <span>2. Cidades ({currentState.uf})</span>
            </div>
            <span className="text-[10px] font-bold text-[#F472B6] bg-[#F472B6]/10 px-2 py-0.5 rounded-full border border-[#F472B6]/30 truncate max-w-[130px]">
              {selectedCity}
            </span>
          </div>

          {/* Busca de Cidade */}
          <div className="relative mb-2.5">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={citySearch}
              onChange={(e) => setCitySearch(e.target.value)}
              placeholder={`Buscar cidade em ${currentState.name}...`}
              className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:border-[#F472B6] focus:outline-none"
            />
          </div>

          {/* Lista de Cidades */}
          <div className="flex-1 max-h-[260px] sm:max-h-[300px] overflow-y-auto space-y-1 pr-1 scrollbar-thin scrollbar-thumb-[#1E293B] scrollbar-track-transparent">
            {filteredCities.map((city) => {
              const isSelected = selectedCity === city;
              return (
                <button
                  key={city}
                  onClick={() => setSelectedCity(city)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition text-left ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#F472B6]/20 to-[#22D3EE]/20 border border-[#F472B6] text-white shadow-md'
                      : 'border border-transparent hover:border-[#1E293B] bg-[#0F172A]/50 text-slate-300 hover:text-white hover:bg-[#1E293B]/40'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${isSelected ? 'bg-[#F472B6] animate-pulse' : 'bg-slate-600'}`} />
                    <span className="truncate text-[11px] sm:text-xs">{city}</span>
                  </div>
                  {isSelected && <CheckCircle2 className="h-3.5 w-3.5 text-[#F472B6] shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* COLUNA 3: Temas de Conversa e Salas Temáticas (5 colunas no lg) */}
        <div className="md:col-span-2 lg:col-span-5 flex flex-col rounded-2xl border border-[#1E293B] bg-[#0A0C10]/80 p-3.5 sm:p-4">
          <div className="flex items-center justify-between pb-2.5 border-b border-[#1E293B] mb-2.5">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-slate-200">
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>3. Tema da Sala</span>
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {currentTheme.badge}
            </span>
          </div>

          {/* Abas de Categorias de Tema */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 scrollbar-none">
            <button
              onClick={() => setSelectedCategoryTab('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                selectedCategoryTab === 'all'
                  ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-sm'
                  : 'bg-[#0F172A] text-slate-400 hover:text-slate-200 border border-[#1E293B]'
              }`}
            >
              Todos ({CHAT_THEMES.length})
            </button>
            <button
              onClick={() => setSelectedCategoryTab('amizade')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                selectedCategoryTab === 'amizade'
                  ? 'bg-[#22D3EE] text-black font-extrabold shadow-sm'
                  : 'bg-[#0F172A] text-slate-400 hover:text-[#22D3EE] border border-[#1E293B]'
              }`}
            >
              <Coffee className="h-3 w-3" />
              <span>Amizades</span>
            </button>
            <button
              onClick={() => setSelectedCategoryTab('paquera')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                selectedCategoryTab === 'paquera'
                  ? 'bg-[#F472B6] text-black font-extrabold shadow-sm'
                  : 'bg-[#0F172A] text-slate-400 hover:text-[#F472B6] border border-[#1E293B]'
              }`}
            >
              <Flame className="h-3 w-3" />
              <span>Paqueras</span>
            </button>
            <button
              onClick={() => setSelectedCategoryTab('idade')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                selectedCategoryTab === 'idade'
                  ? 'bg-purple-500 text-white font-extrabold shadow-sm'
                  : 'bg-[#0F172A] text-slate-400 hover:text-purple-300 border border-[#1E293B]'
              }`}
            >
              <Zap className="h-3 w-3" />
              <span>Idades</span>
            </button>
          </div>

          {/* Grade de Temas */}
          <div className="flex-1 max-h-[260px] sm:max-h-[295px] overflow-y-auto space-y-2 pr-1 scrollbar-thin scrollbar-thumb-[#1E293B] scrollbar-track-transparent">
            {filteredThemes.map((theme) => {
              const isSelected = selectedThemeId === theme.id;
              return (
                <div
                  key={theme.id}
                  onClick={() => setSelectedThemeId(theme.id)}
                  className={`cursor-pointer rounded-xl p-2.5 sm:p-3 border transition-all duration-200 ${
                    isSelected
                      ? 'border-[#22D3EE] bg-gradient-to-r from-[#22D3EE]/15 via-[#F472B6]/15 to-transparent shadow-md'
                      : 'border-[#1E293B] bg-[#0F172A]/60 hover:bg-[#1E293B]/40 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-base sm:text-lg">{theme.icon}</span>
                      <span className="text-xs font-bold text-white truncate">{theme.label}</span>
                    </div>
                    <span
                      className="text-[10px] font-bold px-2 py-0.5 rounded-md shrink-0 ml-2"
                      style={{
                        backgroundColor: `${theme.accentColor}20`,
                        color: theme.accentColor,
                        border: `1px solid ${theme.accentColor}50`,
                      }}
                    >
                      {theme.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                    {theme.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Barra de Ação Inferior: Acesso à Sala Customizada */}
      <div className="mt-5 pt-4 border-t border-[#1E293B] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0A0C10]/60 p-3.5 sm:p-4 rounded-2xl">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#22D3EE] to-[#F472B6] text-black font-black text-base shadow-md shrink-0">
            {currentTheme.icon}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold text-white flex flex-wrap items-center gap-1.5 truncate">
              <span>Sala Selecionada:</span>
              <span className="text-[#22D3EE]">
                {currentState.name} ({currentState.uf}) • {selectedCity}
              </span>
              <span className="text-slate-400">—</span>
              <span className="text-[#F472B6] font-black">{currentTheme.label}</span>
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5 truncate">
              {currentTheme.description}
            </p>
          </div>
        </div>

        <button
          onClick={handleEnterClick}
          className="w-full sm:w-auto shrink-0 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2.5 sm:py-3 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/20 hover:brightness-110 active:scale-95 transition"
        >
          <span>Acessar Bate-Papo Agora</span>
          <ArrowRight className="h-4 w-4 text-black" />
        </button>
      </div>
    </div>
  );
};
