import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Users, Home, Activity, Settings, Edit, Trash2, ShoppingBag, Video } from 'lucide-react';
import AdminStoreConfig from '../components/AdminStoreConfig';
import AdminUsersManager from '../components/AdminUsersManager';
import AdminHousesManager from '../components/AdminHousesManager';
import AdminNFCManager from '../components/AdminNFCManager';
import AdminMeetConfig from '../components/AdminMeetConfig';

export default function SuperAdmin() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [view, setView] = useState('dashboard');
  const [stats, setStats] = useState<any>({});
  const [houses, setHouses] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [backupConfig, setBackupConfig] = useState({ 
    networkIp: '',
    networkShare: '',
    networkDrive: '/mnt/backup',
    networkUser: '',
    networkPass: '',
    frequency: 'daily',
    startTime: '00:00',
    retention: '21',
    backupType: 'incremental'
  });
  const [selectedBackupHouse, setSelectedBackupHouse] = useState<string>('global');
  const [testShares, setTestShares] = useState<string[]>([]);
  const [saveBackupStatus, setSaveBackupStatus] = useState<string | null>(null);

  useEffect(() => {
    const u = localStorage.getItem('siae_user');
    if (u) {
      const parsed = JSON.parse(u);
      setUser(parsed);
      loadData();
    } else {
      navigate('/login');
    }
  }, [navigate]);

  useEffect(() => {
    loadBackupConfig();
  }, [selectedBackupHouse]);

  const loadBackupConfig = () => {
    fetch(`/api/admin/system-settings/backup?houseId=${selectedBackupHouse}`).then(r => r.json()).then(data => {
      if (data && data.frequency) {
        setBackupConfig(data);
      } else {
        setBackupConfig({
           networkIp: '',
           networkShare: '',
           networkDrive: '', 
           networkUser: '',
           networkPass: '',
           frequency: 'daily',
           startTime: '00:00',
           retention: '21',
           backupType: 'incremental'
        });
      }
      setTestShares([]);
    }).catch(e => console.error(e));
  };

  const loadData = async () => {
    fetch('/api/admin/dashboard').then(r => r.json()).then(setStats);
    fetch('/api/admin/houses').then(r => r.json()).then(setHouses);
    fetch('/api/admin/users').then(r => r.json()).then(setUsersList);
    loadBackupConfig();
  };

  const handleLogout = () => {
    localStorage.removeItem('siae_token');
    localStorage.removeItem('siae_user');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-indigo-900 text-white flex flex-col shadow-xl">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-2">
            <Settings className="w-8 h-8 text-indigo-400" />
            <span className="text-2xl font-bold tracking-tight">SIAE Admin</span>
          </div>
          <p className="text-indigo-300 text-sm">Painel de Super Admin</p>
        </div>
        
        <nav className="flex-1 px-4 space-y-2 mt-4">
          <button onClick={() => setView('dashboard')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'dashboard' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <Activity className="w-5 h-5" /> <span>Visão Geral</span>
          </button>
          <button onClick={() => setView('houses')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'houses' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <Home className="w-5 h-5" /> <span>Casas Espíritas</span>
          </button>
          <button onClick={() => setView('users')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'users' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <Users className="w-5 h-5" /> <span>Usuários do Sistema</span>
          </button>
          <button onClick={() => setView('store')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'store' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <ShoppingBag className="w-5 h-5" /> <span>Loja e Pagamentos</span>
          </button>
          <button onClick={() => setView('nfc')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'nfc' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <Settings className="w-5 h-5" /> <span>Gerenciar NFC</span>
          </button>
          <button onClick={() => setView('mirotalk')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'mirotalk' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <Video className="w-5 h-5" /> <span>Videoconferência</span>
          </button>
          <button onClick={() => setView('backup')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'backup' ? 'bg-indigo-800 text-white shadow-md' : 'text-indigo-200 hover:bg-indigo-800/50 hover:text-white'}`}>
            <Settings className="w-5 h-5" /> <span>Backup do Sistema</span>
          </button>
        </nav>

        <div className="p-4 border-t border-indigo-800">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="w-10 h-10 rounded-full bg-indigo-700 flex items-center justify-center text-lg font-bold border-2 border-indigo-500 shadow-inner">
              {user?.firstName?.[0] || 'A'}
            </div>
            <div>
              <p className="font-bold text-sm leading-tight">{user?.firstName} {user?.lastName}</p>
              <p className="text-xs text-indigo-300">Administrador</p>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors text-sm font-bold">
            <LogOut className="w-4 h-4" /> Sair do Sistema
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-8 py-5 flex justify-between items-center shadow-sm z-10">
          <h2 className="text-2xl font-bold text-gray-800">
            {view === 'dashboard' && 'Dashboard de Performance Geral'}
            {view === 'houses' && 'Gerenciamento de Casas Espíritas'}
            {view === 'users' && 'Gestão Global de Usuários'}
            {view === 'store' && 'Configurações da Loja e Mercado Pago'}
            {view === 'nfc' && 'Gestão de Dispositivos NFC'}
            {view === 'mirotalk' && 'Serviço de Videoconferência (SIAE Meet)'}
            {view === 'backup' && 'Backup Automático do Sistema'}
          </h2>
        </header>

        <main className="flex-1 overflow-y-auto p-8 bg-gray-50">
          <div className="max-w-7xl mx-auto space-y-6">
            
            {view === 'store' && (
               <AdminStoreConfig />
            )}
            
            {view === 'nfc' && (
               <AdminNFCManager />
            )}

            {view === 'mirotalk' && (
               <AdminMeetConfig />
            )}

            {view === 'dashboard' && (
              <>
                <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-wrap gap-4 mb-6 items-end">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 mb-1">Filtrar por Cidade</label>
                    <input type="text" placeholder="Ex: São Paulo" className="border rounded-lg px-3 py-2 text-sm w-full" onChange={(e) => {
                      fetch(`/api/admin/dashboard?city=${e.target.value}`).then(r=>r.json()).then(setStats);
                    }}/>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 mb-1">Filtrar por Estado</label>
                    <input type="text" placeholder="Ex: SP" className="border rounded-lg px-3 py-2 text-sm w-full" onChange={(e) => {
                       fetch(`/api/admin/dashboard?state=${e.target.value}`).then(r=>r.json()).then(setStats);
                    }}/>
                  </div>
                  <div className="flex-1"></div>
                  <div>
                    <button onClick={loadData} className="bg-indigo-50 text-indigo-700 px-4 py-2 rounded-lg text-sm font-bold hover:bg-indigo-100">Limpar Filtros</button>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col justify-center">
                    <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Total Casas Espíritas</p>
                    <p className="text-4xl font-extrabold text-indigo-900">{stats.houses || 0}</p>
                  </div>
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col justify-center">
                    <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Total Assistidos</p>
                    <p className="text-4xl font-extrabold text-blue-900">{stats.assisteds || 0}</p>
                  </div>
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col justify-center">
                    <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Total Trabalhadores</p>
                    <p className="text-4xl font-extrabold text-emerald-900">{stats.workers || 0}</p>
                  </div>
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col justify-center">
                    <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Total Atendimentos</p>
                    <p className="text-4xl font-extrabold text-purple-900">{stats.attendances || 0}</p>
                  </div>
                </div>
              </>
            )}

            {view === 'houses' && (
              <AdminHousesManager houses={houses} usersList={usersList} loadData={loadData} />
            )}

            {view === 'users' && (
              <AdminUsersManager usersList={usersList} loadData={loadData} />
            )}
            
            {view === 'backup' && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold text-gray-800">Configuração de Backup Automático</h3>
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-bold text-gray-700">Casa Espírita:</label>
                    <select 
                       value={selectedBackupHouse}
                       onChange={(e) => setSelectedBackupHouse(e.target.value)}
                       className="border rounded-lg px-3 py-1.5 focus:ring-2 focus:ring-indigo-500 text-sm font-bold bg-indigo-50 text-indigo-800"
                    >
                       <option value="global">Todas / Backup Global do Sistema</option>
                       {houses.map(h => (
                         <option key={h.id} value={h.id.toString()}>{h.name}</option>
                       ))}
                    </select>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-6">
                  O sistema realizará backups da área selecionada automaticamente seguindo a frequência configurada. Para salvar externamente, preencha os dados do servidor. Todos os arquivos gerarão scripts para fácil restauração.
                </p>
                <div className="space-y-4 max-w-3xl">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Frequência</label>
                      <select 
                        value={backupConfig.frequency}
                        onChange={(e) => setBackupConfig({...backupConfig, frequency: e.target.value})}
                        className="border rounded-lg px-4 py-2 text-sm w-full focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="daily">Diária</option>
                        <option value="weekly">Semanal</option>
                        <option value="monthly">Mensal</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Horário de Início</label>
                      <input 
                        type="time" 
                        value={backupConfig.startTime}
                        onChange={(e) => setBackupConfig({...backupConfig, startTime: e.target.value})}
                        className="border rounded-lg px-4 py-2 w-full text-sm focus:ring-2 focus:ring-indigo-500" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Tempo de Retenção</label>
                      <select 
                        value={backupConfig.retention}
                        onChange={(e) => setBackupConfig({...backupConfig, retention: e.target.value})}
                        className="border rounded-lg px-4 py-2 w-full text-sm focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="7">7 dias (antes de arquivar)</option>
                        <option value="21">21 dias (antes de arquivar)</option>
                        <option value="42">42 dias (antes de arquivar)</option>
                        <option value="63">63 dias (antes de arquivar)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Tipo de Backup</label>
                      <select 
                        value={backupConfig.backupType}
                        onChange={(e) => setBackupConfig({...backupConfig, backupType: e.target.value})}
                        className="border rounded-lg px-4 py-2 w-full text-sm bg-gray-100 cursor-not-allowed text-gray-500"
                        disabled
                      >
                        <option value="incremental">Incremental</option>
                      </select>
                    </div>
                  </div>

                  <div className="border-t pt-4 mt-4">
                    <h4 className="font-bold text-gray-800 mb-2">Destino de Rede Externa (SMB)</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">IP Público ou URL do Servidor de Arquivos</label>
                        <input 
                          type="text" 
                          value={backupConfig.networkIp || ''}
                          onChange={(e) => setBackupConfig({...backupConfig, networkIp: e.target.value})}
                          placeholder="Ex: 177.10.20.30 ou file-server.xyz.com" 
                          className="border rounded-lg px-4 py-2 w-full text-sm font-mono focus:ring-2 focus:ring-indigo-500 border-indigo-200" 
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-bold text-gray-700 mb-1">Usuário de Rede SMB</label>
                          <input 
                            type="text" 
                            value={backupConfig.networkUser || ''}
                            onChange={(e) => setBackupConfig({...backupConfig, networkUser: e.target.value})}
                            placeholder="usuário ou dominio\usuário" 
                            className="border rounded-lg px-4 py-2 w-full text-sm focus:ring-2 focus:ring-indigo-500" 
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-bold text-gray-700 mb-1">Senha de Rede SMB</label>
                          <input 
                            type="password" 
                            value={backupConfig.networkPass || ''}
                            onChange={(e) => setBackupConfig({...backupConfig, networkPass: e.target.value})}
                            placeholder="senha do compartilhamento" 
                            className="border rounded-lg px-4 py-2 w-full text-sm focus:ring-2 focus:ring-indigo-500" 
                          />
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                         <button 
                            type="button"
                            onClick={async () => {
                               setSaveBackupStatus('Testando conexão à rede...');
                               try {
                                  const res = await fetch('/api/admin/system-settings/backup/test', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify(backupConfig)
                                  });
                                  const data = await res.json();
                                  if (data.error) {
                                    setSaveBackupStatus(`Erro: ${data.error}`);
                                    setTestShares([]);
                                  } else {
                                    setSaveBackupStatus(`Sucesso: ${data.message}`);
                                    setTestShares(data.shares || []);
                                    if(data.shares?.length > 0 && !backupConfig.networkShare) {
                                      setBackupConfig({...backupConfig, networkShare: data.shares[0]});
                                    }
                                    setTimeout(() => setSaveBackupStatus(null), 10000);
                                  }
                               } catch(e: any) {
                                  setSaveBackupStatus('Falha crítica ao contactar API de teste.');
                               }
                            }}
                            className="bg-sky-600 text-white font-bold px-4 py-2 text-sm rounded-lg hover:bg-sky-700 transition"
                         >
                            Testar Conexão e Listar Pastas
                         </button>
                      </div>

                      {testShares.length > 0 && (
                        <div className="bg-sky-50 border border-sky-200 p-4 rounded-xl mt-4">
                           <label className="block text-sm font-bold text-sky-900 mb-2">Pastas Compartilhadas Encontradas (Escolha Uma):</label>
                           <select 
                             value={backupConfig.networkShare || ''}
                             onChange={(e) => setBackupConfig({...backupConfig, networkShare: e.target.value})}
                             className="border-sky-300 rounded-lg px-4 py-2 w-full text-sm focus:ring-2 focus:ring-sky-500"
                           >
                              <option value="">Selecione o diretório alvo</option>
                              {testShares.map(share => (
                                 <option key={share} value={share}>{share}</option>
                              ))}
                           </select>
                           <p className="text-xs text-sky-700 mt-2">O diretório selecionado será montado e os backups da casa '{selectedBackupHouse === 'global' ? 'Global' : houses.find((h:any) => h.id.toString() === selectedBackupHouse)?.name}' gravados nele.</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {saveBackupStatus && (
                    <div className="p-3 mt-4 text-sm rounded-lg font-semibold bg-gray-100 text-gray-800 border">
                      {saveBackupStatus}
                    </div>
                  )}

                  <div className="flex gap-4 pt-6">
                    <button 
                      onClick={async () => {
                        setSaveBackupStatus('Salvando...');
                        try {
                          await fetch(`/api/admin/system-settings/backup?houseId=${selectedBackupHouse}`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(backupConfig)
                          });
                          setSaveBackupStatus('Configurações salvas e rotina de backup agendada com sucesso!');
                          setTimeout(() => setSaveBackupStatus(null), 5000);
                        } catch (e) {
                          setSaveBackupStatus('Erro ao salvar configurações.');
                        }
                      }}
                      className="bg-indigo-600 text-white font-bold px-6 py-3 rounded-lg hover:bg-indigo-700 transition"
                    >
                      Salvar Parâmetros de Backup
                    </button>
                    <button 
                      onClick={async () => {
                        setSaveBackupStatus('Executando backup manual...');
                        try {
                          await fetch(`/api/admin/system-settings/backup/run?houseId=${selectedBackupHouse}`, { method: 'POST' });
                          setSaveBackupStatus('Backup manual concluído com sucesso!');
                          setTimeout(() => setSaveBackupStatus(null), 5000);
                        } catch (e) {
                          setSaveBackupStatus('Erro ao rodar backup.');
                        }
                      }}
                      className="bg-gray-100 text-gray-700 font-bold px-6 py-3 rounded-lg hover:bg-gray-200 transition border border-gray-300"
                    >
                      Forçar Execução Agora
                    </button>
                  </div>
                </div>
              </div>
            )}
            
          </div>
        </main>
      </div>
    </div>
  );
}
