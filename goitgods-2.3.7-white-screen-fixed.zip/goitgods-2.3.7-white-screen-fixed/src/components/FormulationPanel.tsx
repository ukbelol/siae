import React from 'react';
import { FormulationState, FormulationMode, EbookDNA } from '../types';
import { Sliders, CheckCircle2, AlertCircle, HelpCircle, Layers, Cpu } from 'lucide-react';

interface FormulationPanelProps {
  formulation: FormulationState;
  onChange: (updated: FormulationState) => void;
  onConfirm: () => void;
}

export const FormulationPanel: React.FC<FormulationPanelProps> = ({
  formulation,
  onChange,
  onConfirm,
}) => {
  const { mode, completenessScore, ebookDNA, cognitiveVector } = formulation;

  const handleModeChange = (newMode: FormulationMode) => {
    let newFCS = 0.95;
    if (newMode === 'PERSONALIZED') newFCS = 0.7;
    if (newMode === 'EXPERT') newFCS = 1.0;

    onChange({
      ...formulation,
      mode: newMode,
      completenessScore: newFCS,
    });
  };

  const handleDnaChange = (key: keyof EbookDNA, value: any) => {
    const updatedDna = { ...ebookDNA, [key]: value };
    onChange({
      ...formulation,
      ebookDNA: updatedDna,
    });
  };

  return (
    <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#FF3E00] p-5 sm:p-6 text-[#E0E0E0] space-y-6">
      {/* Top Banner & Mode Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222222] pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-[#FF3E00]" />
            <h3 className="text-lg font-black text-white tracking-tight uppercase">
              PFA — PASQUARED Formulation Agent
            </h3>
          </div>
          <p className="text-xs text-[#888888] font-mono mt-0.5">
            Calibração adaptativa dos parâmetros cognitivos da pesquisa e do e-book
          </p>
        </div>

        {/* FCS Score Gauge */}
        <div className="flex items-center space-x-3 bg-[#0A0A0A] px-4 py-2 border border-[#222222]">
          <div className="text-right font-mono">
            <span className="text-[9px] uppercase font-bold text-[#666666] block tracking-widest">
              Completude PFA (FCS)
            </span>
            <span className={`text-base font-black ${completenessScore >= 0.8 ? 'text-[#00FF41]' : 'text-[#FF3E00]'}`}>
              {(completenessScore * 100).toFixed(0)}%
            </span>
          </div>
          <div className="w-9 h-9 border border-[#333333] flex items-center justify-center bg-[#111111]">
            {completenessScore >= 0.8 ? (
              <CheckCircle2 className="w-4 h-4 text-[#00FF41]" />
            ) : (
              <AlertCircle className="w-4 h-4 text-[#FF3E00]" />
            )}
          </div>
        </div>
      </div>

      {/* Mode Selector Buttons */}
      <div className="space-y-2">
        <label className="text-[10px] font-mono font-bold uppercase text-[#666666] tracking-widest">
          Modo de Formulação
        </label>
        <div className="grid grid-cols-3 gap-3">
          {(['EXPRESS', 'PERSONALIZED', 'EXPERT'] as FormulationMode[]).map(m => (
            <button
              key={m}
              id={`pfa-mode-${m.toLowerCase()}`}
              onClick={() => handleModeChange(m)}
              className={`py-2.5 px-3 text-xs font-mono font-bold uppercase transition-all flex flex-col items-center justify-center space-y-1 border ${
                mode === m
                  ? 'bg-[#111111] border-[#FF3E00] text-[#FF3E00]'
                  : 'bg-[#0A0A0A] border-[#222222] text-[#888888] hover:text-white hover:border-[#444444]'
              }`}
            >
              <span className="tracking-wider">{m}</span>
              <span className="text-[9px] font-normal text-[#666666]">
                {m === 'EXPRESS' && 'Padrão rápido'}
                {m === 'PERSONALIZED' && 'Adaptativo com perguntas'}
                {m === 'EXPERT' && 'Controle avançado'}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Form Controls for EBOOK DNA */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div>
          <label className="block text-[#888888] font-mono text-[11px] uppercase mb-1">Profundidade da Investigação</label>
          <select
            id="dna-select-depth"
            value={ebookDNA.depth}
            onChange={e => handleDnaChange('depth', e.target.value)}
            className="w-full bg-[#0A0A0A] border border-[#222222] px-3 py-2 text-white font-mono focus:outline-none focus:border-[#FF3E00]"
          >
            <option value="superficial">Superficial (Visão Geral)</option>
            <option value="intermediario">Intermediário (Visão Estruturada)</option>
            <option value="profundo">Profundo (Análise Racional Detalhada)</option>
            <option value="exaustivo">Exaustivo (Especialista Acadêmico)</option>
          </select>
        </div>

        <div>
          <label className="block text-[#888888] font-mono text-[11px] uppercase mb-1">Estilo Expositivo</label>
          <select
            id="dna-select-style"
            value={ebookDNA.style}
            onChange={e => handleDnaChange('style', e.target.value)}
            className="w-full bg-[#0A0A0A] border border-[#222222] px-3 py-2 text-white font-mono focus:outline-none focus:border-[#FF3E00]"
          >
            <option value="narrativo">Narrativo Envolvente com Fatos</option>
            <option value="academico">Acadêmico com Citações Rigorosas</option>
            <option value="tecnico">Técnico & Engenharia</option>
            <option value="divulgacao">Divulgação Científica / Popular</option>
            <option value="ensaio">Ensaio Crítico Interdisciplinar</option>
          </select>
        </div>

        <div>
          <label className="block text-[#888888] font-mono text-[11px] uppercase mb-1">Número de Capítulos ({ebookDNA.chapterCount})</label>
          <input
            id="dna-range-chapters"
            type="range"
            min="4"
            max="12"
            value={ebookDNA.chapterCount}
            onChange={e => handleDnaChange('chapterCount', parseInt(e.target.value, 10))}
            className="w-full accent-[#FF3E00] bg-[#0A0A0A] h-2 cursor-pointer"
          />
        </div>

        <div>
          <label className="block text-[#888888] font-mono text-[11px] uppercase mb-1">Formato de Saída</label>
          <select
            id="dna-select-format"
            value={ebookDNA.outputFormat}
            onChange={e => handleDnaChange('outputFormat', e.target.value)}
            className="w-full bg-[#0A0A0A] border border-[#222222] px-3 py-2 text-white font-mono focus:outline-none focus:border-[#FF3E00]"
          >
            <option value="EPUB">EPUB 3 (Reflowable Recomendado)</option>
            <option value="PDF">PDF (Layout Fixo)</option>
            <option value="DOCX">DOCX Editável</option>
            <option value="HTML">HTML Navegável</option>
          </select>
        </div>
      </div>

      {/* Sliders for Cognitive Parameters */}
      <div className="space-y-3 pt-2 border-t border-[#222222]">
        <h4 className="text-[10px] font-mono font-bold uppercase text-[#888888] tracking-widest flex items-center space-x-2">
          <Sliders className="w-4 h-4 text-[#FF3E00]" />
          <span>Calibração de Vetores Cognitivos</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div>
            <div className="flex justify-between text-[11px] text-[#888888] mb-1">
              <span>Profundidade Histórica</span>
              <span className="text-[#FF3E00] font-bold">{(ebookDNA.historicalDepth * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={ebookDNA.historicalDepth}
              onChange={e => handleDnaChange('historicalDepth', parseFloat(e.target.value))}
              className="w-full accent-[#FF3E00] bg-[#0A0A0A] h-1.5 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-[#888888] mb-1">
              <span>Criticidade & ARES</span>
              <span className="text-[#FF3E00] font-bold">{(ebookDNA.criticalDepth * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={ebookDNA.criticalDepth}
              onChange={e => handleDnaChange('criticalDepth', parseFloat(e.target.value))}
              className="w-full accent-[#FF3E00] bg-[#0A0A0A] h-1.5 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-[#888888] mb-1">
              <span>Rigor de Evidência</span>
              <span className="text-[#FF3E00] font-bold">{(ebookDNA.evidenceLevel * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={ebookDNA.evidenceLevel}
              onChange={e => handleDnaChange('evidenceLevel', parseFloat(e.target.value))}
              className="w-full accent-[#FF3E00] bg-[#0A0A0A] h-1.5 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Display Cognitive Vector Preview */}
      <div className="bg-[#0A0A0A] p-3 border border-[#222222] text-[11px] font-mono text-[#888888] flex flex-wrap gap-2 items-center justify-between">
        <span className="font-bold text-[#FF3E00]">Vetor Cognitivo P:</span>
        <span>D: {cognitiveVector.depth.toFixed(2)}</span>
        <span>T: {cognitiveVector.technicality.toFixed(2)}</span>
        <span>A: {cognitiveVector.academicLevel.toFixed(2)}</span>
        <span>N: {cognitiveVector.narrativeLevel.toFixed(2)}</span>
        <span>C: {cognitiveVector.criticalDepth.toFixed(2)}</span>
        <span>H: {cognitiveVector.historicalDepth.toFixed(2)}</span>
        <span>R: {cognitiveVector.referenceRigor.toFixed(2)}</span>
      </div>

      <div className="flex justify-end pt-2">
        <button
          id="btn-confirm-pfa"
          onClick={onConfirm}
          className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black uppercase px-5 py-2.5 transition-all text-xs sm:text-sm tracking-wider font-mono"
        >
          Confirmar Parâmetros de Formulação
        </button>
      </div>
    </div>
  );
};
