import React, { useState, useEffect } from 'react';
import { ShoppingBag, Save, Edit, Trash2, Plus, CreditCard, Sliders } from 'lucide-react';

export default function AdminStoreConfig() {
  const [config, setConfig] = useState({ 
    env: 'production', 
    test_access_token: '', 
    test_public_key: '', 
    test_client_id: '', 
    test_client_secret: '', 
    access_token: '', 
    public_key: '', 
    client_id: '', 
    client_secret: '', 
    redirect_url: 'https://api.siae.space/mp-webhook',
    enable_pix_qr_code: 1,
    enable_pix_copia_cola: 1,
    enable_card: 1,
    max_qty_per_order: 10,
    unit_price: 15.00
  });
  const [products, setProducts] = useState<any[]>([]);
  const [newProduct, setNewProduct] = useState({ name: '', description: '', price: 0, stock: 0, image_url: '', status: 'active' });
  const [editingId, setEditingId] = useState<number | null>(null);

  useEffect(() => {
    fetchConfig();
    fetchProducts();
  }, []);

  const fetchConfig = () => {
    fetch('/api/config/mercadopago').then(r => r.json()).then(data => {
      if (data) setConfig({
         ...config,
         ...data
      });
    });
  };

  const fetchProducts = () => {
    fetch('/api/products').then(r => r.json()).then(setProducts);
  };

  const saveConfig = async () => {
    await fetch('/api/config/mercadopago', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config)
    });
    alert('Configuração salva com sucesso!');
  };

  const saveProduct = async () => {
    const url = editingId ? `/api/products/${editingId}` : '/api/products';
    const method = editingId ? 'PUT' : 'POST';
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProduct)
    });
    setNewProduct({ name: '', description: '', price: 0, stock: 0, image_url: '', status: 'active' });
    setEditingId(null);
    fetchProducts();
  };

  const editProduct = (p: any) => {
    setNewProduct({ name: p.name, description: p.description, price: p.price, stock: p.stock, image_url: p.image_url || '', status: p.status });
    setEditingId(p.id);
  };

  const deleteProduct = async (id: number) => {
    if (!window.confirm('Tem certeza?')) return;
    await fetch(`/api/products/${id}`, { method: 'DELETE' });
    fetchProducts();
  };

  return (
    <div className="space-y-8">
       {/* MP Config */}
       <div className="bg-white p-6 rounded-xl shadow border border-gray-200">
         <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2"><CreditCard className="w-5 h-5 text-indigo-600"/> Configuração Mercado Pago (Integração Pix)</h2>
         <p className="text-sm text-gray-500 mb-6 bg-blue-50 p-4 rounded-lg border border-blue-100">
            <strong>Dica:</strong> Para obter as chaves de acesso (Access Token / Public Key), acesse o painel de desenvolvedor do Mercado Pago, crie uma aplicação e vá em "Credenciais de Produção" e chaves. Configure a URL de Redirecionamento da documentação de sua API caso necessário.
         </p>
         <div className="mb-6 flex gap-4 bg-gray-50 p-2 rounded-lg border border-gray-200">
             <button onClick={() => setConfig({...config, env: 'test'})} className={`flex-1 py-2 font-bold rounded-md ${config.env === 'test' ? 'bg-indigo-600 text-white shadow' : 'text-gray-600 hover:bg-gray-100'}`}>Modo Teste (Sandbox)</button>
             <button onClick={() => setConfig({...config, env: 'production'})} className={`flex-1 py-2 font-bold rounded-md ${config.env === 'production' ? 'bg-indigo-600 text-white shadow' : 'text-gray-600 hover:bg-gray-100'}`}>Modo Produção</button>
         </div>

         {config.env === 'production' ? (
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Access Token (Produção)</label>
                <input type="text" className="mt-1 w-full border border-gray-300 rounded px-3 py-2" value={config.access_token || ''} onChange={e => setConfig({...config, access_token: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Public Key (Produção)</label>
                <input type="text" className="mt-1 w-full border border-gray-300 rounded px-3 py-2" value={config.public_key || ''} onChange={e => setConfig({...config, public_key: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Client ID (Produção - Opcional)</label>
                <input type="text" className="mt-1 w-full border border-gray-300 rounded px-3 py-2" value={config.client_id || ''} onChange={e => setConfig({...config, client_id: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Client Secret (Produção - Opcional)</label>
                <input type="password" className="mt-1 w-full border border-gray-300 rounded px-3 py-2" value={config.client_secret || ''} onChange={e => setConfig({...config, client_secret: e.target.value})} />
              </div>
           </div>
         ) : (
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Test Access Token (Sandbox)</label>
                <input type="text" className="mt-1 w-full border border-gray-300 rounded px-3 py-2" value={config.test_access_token || ''} onChange={e => setConfig({...config, test_access_token: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Test Public Key (Sandbox)</label>
                <input type="text" className="mt-1 w-full border border-gray-350 rounded px-3 py-2" value={config.test_public_key || ''} onChange={e => setConfig({...config, test_public_key: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Test Client ID (Sandbox - Opcional)</label>
                <input type="text" className="mt-1 w-full border border-gray-350 rounded px-3 py-2" value={config.test_client_id || ''} onChange={e => setConfig({...config, test_client_id: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Test Client Secret (Sandbox - Opcional)</label>
                <input type="password" className="mt-1 w-full border border-gray-350 rounded px-3 py-2" value={config.test_client_secret || ''} onChange={e => setConfig({...config, test_client_secret: e.target.value})} />
              </div>
           </div>
         )}
         
         {/* Métodos de Pagamento e Parametrização do Chaveiro */}
         <div className="mt-8 pt-6 border-t border-gray-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
               <Sliders className="w-5 h-5 text-indigo-600" /> Parâmetros de Venda do Chaveiro NFC SIAE
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {/* Meios de Pagamento */}
               <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-3">
                  <h4 className="text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Meios de Pagamento Ativados no Checkout</h4>
                  
                  <label className="flex items-center gap-3 cursor-pointer p-2 hover:bg-gray-100 rounded-lg transition-colors">
                     <input 
                        type="checkbox" 
                        checked={config.enable_pix_qr_code === 1} 
                        onChange={e => setConfig({...config, enable_pix_qr_code: e.target.checked ? 1 : 0})} 
                        className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                     />
                     <div>
                        <p className="text-sm font-semibold text-gray-800">Pix QR Code Dinâmico</p>
                        <p className="text-xs text-gray-500">Geração de imagem de QR Code instantânea no checkout.</p>
                     </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer p-2 hover:bg-gray-100 rounded-lg transition-colors">
                     <input 
                        type="checkbox" 
                        checked={config.enable_pix_copia_cola === 1} 
                        onChange={e => setConfig({...config, enable_pix_copia_cola: e.target.checked ? 1 : 0})} 
                        className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                     />
                     <div>
                        <p className="text-sm font-semibold text-gray-800">Pix Copia e Cola / Chave Copiável</p>
                        <p className="text-xs text-gray-500">Permitir copiar a chave pix longa de formato texto por um botão.</p>
                     </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer p-2 hover:bg-gray-100 rounded-lg transition-colors">
                     <input 
                        type="checkbox" 
                        checked={config.enable_card === 1} 
                        onChange={e => setConfig({...config, enable_card: e.target.checked ? 1 : 0})} 
                        className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                     />
                     <div>
                        <p className="text-sm font-semibold text-gray-800">Cartão de Crédito (MP Checkout Pro)</p>
                        <p className="text-xs text-gray-500">Habilita gateway para processar parcelas em cartões Visa/Master/Elo.</p>
                     </div>
                  </label>
               </div>

               {/* Limites e Preços */}
               <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 grid grid-cols-1 gap-4">
                  <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wide">Limites e Precificação do Chaveiro</h4>
                  
                  <div>
                     <label className="block text-xs font-bold text-gray-750 uppercase">Quantidade Máxima de Compra por Pedido</label>
                     <input 
                        type="number" 
                        min="1" 
                        max="100" 
                        className="mt-1 w-full border border-gray-300 rounded-lg px-3 py-2 bg-white focus:ring-2 focus:ring-indigo-500 shadow-sm font-bold text-indigo-900" 
                        value={config.max_qty_per_order || 10} 
                        onChange={e => setConfig({...config, max_qty_per_order: Math.max(1, Number(e.target.value))})} 
                     />
                     <p className="text-[11px] text-gray-500 mt-1">Evita compras em lote exageradas em um único checkout.</p>
                  </div>

                  <div>
                     <label className="block text-xs font-bold text-gray-750 uppercase">Valor Unitário do Chaveiro (R$)</label>
                     <div className="relative mt-1">
                        <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 font-bold text-sm">R$</span>
                        <input 
                           type="number" 
                           step="0.01" 
                           min="0.10" 
                           className="w-full border border-gray-300 rounded-lg pl-9 pr-3 py-2 bg-white focus:ring-2 focus:ring-indigo-500 shadow-sm font-bold text-indigo-650" 
                           value={config.unit_price || 15.00} 
                           onChange={e => setConfig({...config, unit_price: parseFloat(e.target.value) || 0})} 
                        />
                     </div>
                     <p className="text-[11px] text-gray-500 mt-1">O preço de venda em toda a loja e checkout único será sincronizado para este valor.</p>
                  </div>
               </div>
            </div>
         </div>
         
         <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700">URL de Redirecionamento Configurável no MP e Webhook Notification</label>
            <input type="text" className="mt-1 w-full border border-gray-300 rounded px-3 py-2 bg-gray-50" readOnly placeholder="https://api.siae.space/mp-webhook" value={`https://siae.space/api/store/mp-webhook`} />
         </div>
         <div className="mt-6">
           <button onClick={saveConfig} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded font-bold flex items-center gap-2"><Save className="w-4 h-4"/> Salvar Configurações</button>
         </div>
       </div>

       {/* Products CRUD */}
       <div className="bg-white p-6 rounded-xl shadow border border-gray-200">
         <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2"><ShoppingBag className="w-5 h-5 text-emerald-600"/> Produtos / Marketplace</h2>
         
         <div className="mb-8 bg-gray-50 p-4 border rounded-lg">
           <h3 className="font-bold text-gray-800 mb-4">{editingId ? 'Editar Produto' : 'Adicionar Novo Produto'}</h3>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-700 uppercase">Nome</label>
                <input type="text" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="mt-1 w-full border px-3 py-2 rounded" placeholder="Ex: Chaveiro Tag NFC"/>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-700 uppercase">Descrição</label>
                <input type="text" value={newProduct.description} onChange={e => setNewProduct({...newProduct, description: e.target.value})} className="mt-1 w-full border px-3 py-2 rounded" placeholder="Para agilizar entrada..."/>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase">Preço (R$)</label>
                <input type="number" step="0.01" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: Number(e.target.value)})} className="mt-1 w-full border px-3 py-2 rounded"/>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase">Estoque Disponível</label>
                <input type="number" value={newProduct.stock} onChange={e => setNewProduct({...newProduct, stock: Number(e.target.value)})} className="mt-1 w-full border px-3 py-2 rounded"/>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase">Status</label>
                <select value={newProduct.status} onChange={e => setNewProduct({...newProduct, status: e.target.value})} className="mt-1 w-full border px-3 py-2 rounded">
                  <option value="active">Ativo (Visível)</option>
                  <option value="inactive">Inativo (Oculto)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase">Url Imagem</label>
                <input type="text" value={newProduct.image_url} onChange={e => setNewProduct({...newProduct, image_url: e.target.value})} className="mt-1 w-full border px-3 py-2 rounded" placeholder="Opcional"/>
              </div>
           </div>
           <button onClick={saveProduct} className="mt-4 bg-emerald-600 text-white font-bold px-4 py-2 rounded hover:bg-emerald-700 flex items-center gap-2"><Plus className="w-4 h-4"/> Salvar Produto</button>
         </div>

         <table className="w-full text-left">
           <thead className="bg-gray-100">
             <tr>
               <th className="p-3 font-bold text-gray-600 text-sm">Produto</th>
               <th className="p-3 font-bold text-gray-600 text-sm">Preço</th>
               <th className="p-3 font-bold text-gray-600 text-sm">Estoque</th>
               <th className="p-3 font-bold text-gray-600 text-sm">Status</th>
               <th className="p-3 font-bold text-gray-600 text-sm text-right">Ações</th>
             </tr>
           </thead>
           <tbody>
             {products.map(p => (
               <tr key={p.id} className="border-b">
                 <td className="p-3">
                   <p className="font-bold text-gray-800">{p.name}</p>
                   <p className="text-xs text-gray-500">{p.description}</p>
                 </td>
                 <td className="p-3 font-bold text-indigo-600">R$ {Number(p.price).toFixed(2)}</td>
                 <td className="p-3">{p.stock}</td>
                 <td className="p-3">
                   <span className={`px-2 py-1 text-xs font-bold rounded ${p.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                     {p.status === 'active' ? 'Ativo' : 'Inativo'}
                   </span>
                 </td>
                 <td className="p-3 flex justify-end gap-2">
                   <button onClick={() => editProduct(p)} className="p-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded"><Edit className="w-4 h-4"/></button>
                   <button onClick={() => deleteProduct(p.id)} className="p-2 bg-red-50 text-red-600 hover:bg-red-100 rounded"><Trash2 className="w-4 h-4"/></button>
                 </td>
               </tr>
             ))}
           </tbody>
         </table>
       </div>
    </div>
  );
}
