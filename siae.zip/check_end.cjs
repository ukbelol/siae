const fs = require('fs');
let t = fs.readFileSync('src/api/index.ts', 'utf8');
if (!t.trim().endsWith("export default router;")) {
    console.log("Missing exports?");
}
