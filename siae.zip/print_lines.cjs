const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

// The errors are on specific lines. I will print them to see what they are.
console.log("Line 140:", lines[139]);
console.log("Line 151:", lines[150]);
console.log("Line 1009:", lines[1008]);
console.log("Line 1013:", lines[1012]);
console.log("Line 1069:", lines[1068]);
console.log("Line 1141:", lines[1140]);
console.log("Line 1144:", lines[1143]);
console.log("Line 1201:", lines[1200]);
console.log("Line 1204:", lines[1203]);
console.log("Line 1207:", lines[1206]);
console.log("Line 1210:", lines[1209]);
