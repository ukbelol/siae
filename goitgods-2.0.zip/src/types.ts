export type KnowledgeClassification = 'FACT' | 'INFERENCE' | 'FICTION' | 'HYPOTHESIS' | 'COUNTERFACTUAL';

export type DecisionState = 
  | 'ACCEPTED' 
  | 'HIGH_CONFIDENCE' 
  | 'PROVISIONAL' 
  | 'PARTIAL_CONSENSUS' 
  | 'LOW_CONFIDENCE' 
  | 'CONFLICT' 
  | 'NO_CONSENSUS' 
  | 'INSUFFICIENT_DATA';

export type GodId = 
  | 'zeus' 
  | 'athena' 
  | 'apollo' 
  | 'hermes' 
  | 'hephaestus' 
  | 'hades' 
  | 'ares' 
  | 'poseidon' 
  | 'demeter' 
  | 'aphrodite' 
  | 'dionysus' 
  | 'chronos';

export interface GodDefinition {
  id: GodId;
  name: string;
  title: string;
  domain: string;
  namespace: string;
  specialties: string[];
  reasoningStrategy: string;
  iconName: string;
  color: string;
  minReplicas: number;
  maxReplicas: number;
  gpsScore: number; // God Performance Score 0-1
}

export interface KnowledgeObject {
  knowledge_id: string;
  source_id: string;
  entity_id: string;
  domain: string;
  claim: string;
  type: KnowledgeClassification;
  confidence: number;
  timestamp: string;
  author: string;
  publisher: string;
  source_url: string;
  source_hash: string;
  evidence_score: number;
  verification_status: 'VERIFIED' | 'UNVERIFIED' | 'CONTESTED';
  created_at: string;
  updated_at: string;
}

export interface UCI {
  id: string;
  type: 'texto' | 'imagem' | 'som' | 'memória' | 'emoção' | 'símbolo' | 'conceito' | 'evento';
  source: string;
  weight: number; // 0-1
  context: string;
  sensoryMode?: string;
  intensity?: number;
}

export interface CognitiveDNA {
  cdnaId: string;
  primaryDomain: string;
  secondaryDomains: string[];
  origin: string;
  modality: string;
  reliability: number;
  sensitivity: 'public' | 'restricted' | 'confidential';
}

export interface GodResponse {
  godId: GodId;
  godName: string;
  claim: string;
  reasoning_summary: string;
  evidence: Array<{ id: string; source: string; snippet: string; trustScore: number }>;
  confidence: number;
  uncertainties: string[];
  counterarguments: string[];
  dependencies: string[];
  recommendation: string;
  classificationBreakdown: {
    fact: number;
    inference: number;
    fiction: number;
    hypothesis: number;
  };
}

export interface ContradictionItem {
  id: string;
  claimA: string;
  godA: string;
  claimB: string;
  godB: string;
  contradictionScore: number;
  reasoning: string;
}

export interface AresAttack {
  attack: string;
  counterexample: string;
  missing_evidence: string;
  risk: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  attackScore: number;
}

export interface HadesRisk {
  uncertainty: number;
  contradiction: number;
  dependencyRisk: number;
  bias: number;
  sourceRisk: number;
  riskScore: number;
  hiddenRisks: string[];
}

export interface MvedResult {
  m1_evidence: number; // w1 = 0.30
  m2_logic: number;    // w2 = 0.25
  m3_relevance: number;// w3 = 0.20
  m4_risk: number;     // w4 = 0.15
  m5_consensus: number;// w5 = 0.10
  totalMvedScore: number;
}

export interface DissentItem {
  dissent_id: string;
  god_id: GodId;
  god_name: string;
  claim: string;
  reason: string;
  evidence: string;
  severity: 'MINIMAL' | 'SIGNIFICANT' | 'CRITICAL';
}

export interface ZeusArbitration {
  decision: string;
  confidence: number;
  consensusScore: number;
  uncertaintyScore: number;
  decisionState: DecisionState;
  reason: string;
  evidence_ids: string[];
  dissentList: DissentItem[];
}

export interface ChronosTimelineEvent {
  id: string;
  date: string;
  title: string;
  description: string;
  actors: string[];
  organizations: string[];
  location: string;
  causes: string[];
  consequences: string[];
  sources: string[];
  domains: string[];
  technologies: string[];
  uncertainties: string[];
  narrativeMode: {
    factual: string;
    analytical: string;
    olympusChronicle: string; // Fictional/mythological framing with clear FICTION disclaimer
  };
}

export interface SearchParametersResult {
  topic: string;
  summary: string;
  originAndBeginning: string; // Como foi o início
  causativeFactors: string[]; // Fatores que causaram o acontecimento
  strengthsAndWeaknesses: {
    strengths: string[];
    weaknesses: string[];
  }; // Pontos fortes e pontos fracos
  durationInEvidence: {
    timeframe: string;
    peakPeriod: string;
    currentStatus: string;
  }; // Quanto tempo esteve em evidência
  chronologicalSequence: {
    inicio: string;
    desenvolvimento: string;
    meio: string;
    fim: string;
  }; // Sequência de início, desenvolvimento, meio e fim
  sources: Array<{ title: string; type: string; url: string; trustScore: number }>;
}

export interface EbookChapter {
  id: string;
  chapterNumber: number;
  title: string;
  subtitle: string;
  content: string;
  chapterType: 'origin' | 'causes' | 'pros_cons' | 'duration' | 'chronology' | 'olympus_debate' | 'mved_decision';
  highlights?: string[];
  diagramData?: {
    type: 'timeline' | 'pros_cons_table' | 'radar_chart' | 'causal_flow';
    items: any[];
  };
}

export interface EbookDocument {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  publisher: string;
  dateCreated: string;
  coverImageTheme: string;
  topic: string;
  chapters: EbookChapter[];
  totalPages: number;
  pksScore: number;
  kqScore: number;
}

export interface SuperAdminUser {
  email: string;
  role: 'SUPER_ADMIN';
  isAuthenticated: boolean;
  loginTime?: string;
}

export interface SystemHealthMetrics {
  activeGodsCount: number;
  pckStatus: 'OPTIMAL' | 'DEGRADED' | 'HEALING';
  mvedAccuracy: number;
  knowledgeObjectsCount: number;
  kubernetesNodes: number;
  cpuUsage: number;
  memoryUsage: number;
  recentQueries: number;
}
