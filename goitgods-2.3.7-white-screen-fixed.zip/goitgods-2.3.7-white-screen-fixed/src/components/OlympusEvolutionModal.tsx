import React, { useState } from 'react';
import { Activity, Sparkles, AlertCircle, CheckCircle2, RefreshCw, Cpu, Layers } from 'lucide-react';

export const OlympusEvolutionModal: React.FC = () => {
  const [domainDemand, setDomainDemand] = useState('Logística e Resiliência de Suprimentos');
  const [kgsScore, setKgsScore] = useState(0.74);
  const [candidateGod, setCandidateGod] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleEvolveCheck = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/v2/olympus/evolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domainDemand }),
      });
      const data = await res.json();
      if (data.success) {
        setCandidateGod(data.evolution.candidateGod);
        setKgsScore(data.evolution.kgsScore);
      }
    } catch (e) {
      console.error('Error evolving Olympus:', e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0F0F0F] border border-[#222222] border-l-4 border-l-[#FF3E00] p-5 sm:p-6 text-[#E0E0E0] space-y-5">
      <div className="flex items-center justify-between border-b border-[#222222] pb-3">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-[#FF3E00]" />
          <h3 className="text-sm sm:text-base font-black text-white tracking-tight uppercase">
            Auto-Evolução do Olympus & Sandbox de Especialistas
          </h3>
        </div>
        <span className="text-[10px] px-2.5 py-1 font-mono uppercase bg-[#1A1A1A] text-[#00FF41] font-bold border border-[#333333]">
          KGS Threshold: 0.65
        </span>
      </div>

      <p className="text-xs text-[#888888] font-mono">
        Quando uma lacuna de conhecimento ($KGS &gt; 0.65$) é detectada, o PASQUARED-OS gera uma especificação controlada de especialista (Plugin Spec) submetida a sandbox e benchmark automatizado antes da ativação.
      </p>

      {/* Input Domain Demand */}
      <div className="space-y-3 font-mono">
        <div>
          <label className="block text-xs font-bold text-[#888888] uppercase mb-1">
            Simular Demanda de Domínio Desconhecido / Emergente
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={domainDemand}
              onChange={e => setDomainDemand(e.target.value)}
              className="flex-1 bg-[#0A0A0A] border border-[#222222] px-3 py-2 text-xs text-white focus:outline-none focus:border-[#FF3E00]"
            />
            <button
              id="btn-trigger-olympus-evolve"
              onClick={handleEvolveCheck}
              disabled={loading}
              className="bg-[#FF3E00] hover:bg-white hover:text-black text-black font-black px-4 py-2 text-xs uppercase flex items-center space-x-2 transition-all disabled:opacity-50"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Executar Auto-Evolução</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Output Candidate God Sandbox Card */}
        {candidateGod && (
          <div className="bg-[#0A0A0A] p-4 border border-[#00FF41] space-y-3 text-xs animate-fadeIn font-mono">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#00FF41] flex items-center space-x-1.5 uppercase">
                <CheckCircle2 className="w-4 h-4 text-[#00FF41]" />
                <span>Candidato Sintetizado (Sandbox Status: {candidateGod.status})</span>
              </span>
              <span className="font-mono text-[10px] text-[#888888]">v{candidateGod.version}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px] pt-1 border-t border-[#222222]">
              <div>
                <span className="text-[#888888] block">Nome do Agente:</span>
                <span className="font-bold text-white">{candidateGod.name}</span>
              </div>
              <div>
                <span className="text-[#888888] block">GPS Estimado:</span>
                <span className="font-bold text-[#00FF41]">{candidateGod.gps}</span>
              </div>
            </div>

            <p className="text-[11px] text-[#CCCCCC] font-sans">
              Aprovado nos testes de segurança e alocação em container Kubernetes isolado.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
