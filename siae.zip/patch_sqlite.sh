#!/bin/bash
# Patch para corrigir o erro ExecStart=/usr/bin/node dist/server.cjs (status=1)
# Ocasionado pela incompatibilidade de compilação ou banco malformado do better-sqlite3

echo "=========================================================="
echo " Corrigindo banco malformado e binários do better-sqlite3 "
echo "=========================================================="

APP_DIR="/var/www/siae"

if [ -d "$APP_DIR" ]; then
    echo ">> Acessando diretório do sistema: $APP_DIR"
    cd "$APP_DIR"
else
    echo ">> Acessando diretório atual: $(pwd)"
fi

echo ">> Removendo banco malformado (backup em .bak)..."
if [ -f "siae.db" ]; then
    mv "siae.db" "siae.db.bak_$(date +%Y%m%d%H%M%S)"
    echo ">> Um novo banco de dados limpo será automaticamente recriado."
fi

echo ">> Limpando node_modules antigos e recompilando dependências..."
rm -rf node_modules dist package-lock.json
npm cache clean --force 2>/dev/null || true
npm install better-sqlite3@latest
npm install
npm rebuild --build-from-source better-sqlite3
npm run build

echo ">> Ajustando permissões (www-data)..."
chown -R www-data:www-data "$APP_DIR" || true
find "$APP_DIR" -type d -exec chmod 775 {} \;

echo ">> Reiniciando o serviço SIAE..."
systemctl restart siae
systemctl status siae --no-pager

echo "=========================================================="
echo " Correção aplicada com sucesso!"
echo " Acesse seu sistema novamente para verificar."
echo "=========================================================="
