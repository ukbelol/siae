#!/bin/bash
# Script de Instalação Automatizada - Hair Smart Mall
# SO: Debian 12
# Web Server: Apache2 com SSL/TLS (Let's Encrypt)
# Domínio: hair.smartmall577.space
# Email de Segurança: rogeriogomes11@gmail.com

set -e

# Configurações
DOMAIN="hair.smartmall577.space"
EMAIL="rogeriogomes11@gmail.com"
APP_DIR="/var/www/hairsmartmall"
PORT=3000

# Cores para output
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${GREEN}Iniciando instalação automatizada para Debian 12...${NC}"

# 1. Atualização do Sistema
echo "Atualizando pacotes do sistema..."
apt update && apt upgrade -y

# 2. Instalação de Dependências Básicas e Reinstalação do Apache
echo "Instalando dependências (Apache, Certbot, Build Tools)..."
apt install -y curl git build-essential python3 software-properties-common apache2 certbot python3-certbot-apache
echo "Reinstalando o Apache2 para garantir configurações limpas..."
apt install --reinstall -y apache2

# 3. Instalação do Node.js 20 (LTS)
echo "Instalando Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# 4. Configuração de Módulos do Apache
echo "Habilitando módulos do Apache (proxy, ssl, rewrite, headers)..."
a2enmod proxy proxy_http ssl rewrite headers
a2dissite 000-default.conf || true

# Limpeza de configurações antigas do domínio para evitar conflitos com o Certbot
echo "Limpando configurações antigas do Apache para o domínio..."
a2dissite $DOMAIN.conf || true
a2dissite $DOMAIN-le-ssl.conf || true
rm -f /etc/apache2/sites-available/$DOMAIN.conf
rm -f /etc/apache2/sites-available/$DOMAIN-le-ssl.conf
systemctl reload apache2 || true

# 5. Criação do Diretório da Aplicação
echo "Configurando diretório da aplicação em $APP_DIR..."
mkdir -p $APP_DIR
# Copia os arquivos do diretório atual (onde o script foi executado) para o APP_DIR
echo "Copiando arquivos do projeto..."
cp -r ./* $APP_DIR/ || true
cp -r ./.[!.]* $APP_DIR/ || true
chown -R www-data:www-data $APP_DIR

# 6. Obtenção do Certificado SSL via Certbot Standalone
echo "Parando o Apache temporariamente para liberar a porta 80 para a validação Standalone..."
systemctl stop apache2 || true

echo "Solicitando certificado SSL Standalone para $DOMAIN..."
certbot certonly --standalone -m $EMAIL --agree-tos --no-eff-email --reinstall --expand -d $DOMAIN -d www.$DOMAIN --non-interactive || echo -e "${GREEN}Aviso: Certbot Standalone falhou. Certifique-se de que a porta 80 está livre e o DNS aponta para este IP.${NC}"

# 7. Configuração do Virtual Host Apache compatível com SSL Standalone
echo "Configurando Virtual Host Apache compatível com SSL para $DOMAIN..."
cat > /etc/apache2/sites-available/$DOMAIN.conf <<EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN
    
    # Redirecionamento permanente de HTTP para HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)\$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</VirtualHost>

<VirtualHost *:443>
    ServerName $DOMAIN
    ServerAlias www.$DOMAIN
    DocumentRoot $APP_DIR/dist

    # Configuração de Certificado SSL Standalone Let's Encrypt
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/$DOMAIN/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/$DOMAIN/privkey.pem

    # Proxy para o Backend Node.js
    ProxyPreserveHost On
    ProxyPass /api http://localhost:$PORT/api
    ProxyPassReverse /api http://localhost:$PORT/api

    # Configuração para SPA (Single Page Application)
    <Directory $APP_DIR/dist>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        
        # Fallback para index.html para rotas do React/Vite
        FallbackResource /index.html
    </Directory>

    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}_error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}_access.log combined
</VirtualHost>
EOF

# 8. Ativação do Site
echo "Ativando site no Apache e iniciando o servidor..."
a2ensite $DOMAIN.conf
systemctl start apache2
systemctl restart apache2

# 9. Instalação do PM2 e Dependências do Projeto
echo "Instalando PM2 globalmente..."
npm install -g pm2

echo "Instalando dependências do projeto e compilando..."
cd $APP_DIR

# Configurar .env para chaves de pagamento
echo "Criando .env.production..."
cat <<EOF > .env.production
NODE_ENV=production
PORT=3000
MP_ACCESS_TOKEN=
MP_PUBLIC_KEY=
MP_CLIENT_ID=
MP_CLIENT_SECRET=
EOF
echo "Lembre-se de preencher as chaves do Mercado Pago no arquivo /var/www/hairsmartmall/.env.production após a instalação, caso prefira variáveis de ambiente, ou direto pelo Painel Super Admin."

npm install
npm run build

# 10. Inicialização com PM2
echo "Iniciando servidor com PM2..."
export NODE_ENV=production
pm2 delete hair-smart-mall 2>/dev/null || true
pm2 start server.ts --name "hair-smart-mall" --interpreter node --interpreter-args "-r tsx" --env NODE_ENV=production
pm2 save
pm2 startup

# Reiniciar o Apache por via das dúvidas para carregar as configs do SSL
systemctl restart apache2

echo -e "${GREEN}====================================================${NC}"
echo -e "${GREEN}Instalação concluída com sucesso!${NC}"
echo -e "${GREEN}Domínio: https://$DOMAIN${NC}"
echo -e "${GREEN}Tema Configurado: Quantum Innovation (Ciano, Verde Água, Laranja)${NC}"
echo -e "${GREEN}Super Admin: roger577@smartmall577.space${NC}"
echo -e "${GREEN}Senha: 21490905@Hair-RGS${NC}"
echo -e "${GREEN}Monitoramento Integrado: Fee de Plataforma de 5% e Filtros Geográficos Integrados por Recharts!${NC}"
echo -e "${GREEN}O sistema já está no ar e rodando em background.${NC}"
echo -e "${GREEN}====================================================${NC}"
