import React, { useState } from 'react';
import { 
  Search, 
  Sparkles, 
  BookOpen, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Zap, 
  Layers, 
  ShieldCheck, 
  Globe2, 
  ExternalLink,
  ChevronRight,
  Loader2
} from 'lucide-react';
import { SearchParametersResult, EbookDocument } from '../types';

interface SearchHomeProps {
  onSearchSubmit: (query: string) => Promise<void>;
  isLoading: boolean;
  searchResult: SearchParametersResult | null;
  onOpenEbookReader: () => void;
  generatedEbook: EbookDocument | null;
}

const SAMPLE_TOPICS = [
  'Revolução Industrial',
  'Inteligência Artificial Generativa',
  'Corrida Espacial Apollo 11',
  'Crise Financeira de 2008',
  'Projeto Manhattan',
  'Descobrimento da Penicilina',
  'Teoria da Relatividade Geral',
  'Internet e a WWW',
];

export const SearchHome: React.FC<SearchHomeProps> = ({
  onSearchSubmit,
  isLoading,
  searchResult,
  onOpenEbookReader,
  generatedEbook,
}) => {
  const [queryInput, setQueryInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (queryInput.trim() && !isLoading) {
      onSearchSubmit(queryInput.trim());
    }
  };

  const handleTopicClick = (topic: string) => {
    setQueryInput(topic);
    onSearchSubmit(topic);
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-[#080808] border border-zinc-800 p-8 sm:p-14 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
          <p className="text-[11px] font-black uppercase tracking-[0.5em] text-yellow-400">
            System Operational // Version Upgrade Confirmed
          </p>

          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-display font-black leading-none uppercase italic tracking-tighter text-white">
            GOIT<span className="text-yellow-400">GODS</span> <span className="text-zinc-600 font-mono text-3xl sm:text-5xl not-italic tracking-normal">2.0</span>
          </h1>

          <p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed font-medium">
            Sistema de inteligência multiagente baseado no kernel PASQUARED-OS. Pesquisa em bases públicas (Wikipedia, acervos e notícias) para filtragem rigorosa e e-books diagramados.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSubmit} className="relative max-w-2xl mx-auto pt-2">
            <div className="relative flex items-center">
              <input
                id="search-input-field"
                type="text"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                placeholder="DIGITE O ASSUNTO OU HISTÓRIA (EX: REVOLUÇÃO INDUSTRIAL)..."
                className="w-full bg-[#050505] text-white placeholder-zinc-600 text-xs sm:text-sm font-mono tracking-wider rounded-none pl-12 pr-36 py-4 border border-zinc-700 focus:outline-none focus:border-yellow-400"
              />
              <Search className="absolute left-4 w-5 h-5 text-zinc-500" />
              
              <button
                id="search-submit-btn"
                type="submit"
                disabled={isLoading || !queryInput.trim()}
                className="absolute right-2 bg-yellow-400 hover:bg-yellow-300 text-black font-black px-6 py-2.5 text-xs uppercase tracking-widest transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                    <span>VARRENDO...</span>
                  </>
                ) : (
                  <>
                    <span>INICIAR</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Preset Topics */}
          <div className="pt-2">
            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.3em] mb-3">Tópicos Táticos em Destaque:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {SAMPLE_TOPICS.map((topic) => (
                <button
                  key={topic}
                  onClick={() => handleTopicClick(topic)}
                  className="text-xs font-mono bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-yellow-400 px-3.5 py-2 border border-zinc-800 transition-colors"
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Loading Skeleton Indicator */}
      {isLoading && (
        <div className="bg-[#080808] border border-zinc-800 p-10 text-center space-y-4 shadow-xl animate-pulse">
          <Loader2 className="w-10 h-10 text-yellow-400 animate-spin mx-auto" />
          <h3 className="text-xl font-display font-black uppercase italic tracking-tighter text-white">Consultando Bases Públicas & Convocando Olimpo...</h3>
          <p className="text-xs font-mono text-zinc-500 max-w-md mx-auto uppercase tracking-wider">
            Executando vetores UCL, calculando matriz MVED 2.0 e compilando e-book diagramado.
          </p>
        </div>
      )}

      {/* Structured Search Results Display */}
      {searchResult && !isLoading && (
        <div className="space-y-8 animate-fade-in">

          {/* Header Action Bar */}
          <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div>
              <p className="text-[10px] font-black text-yellow-400 uppercase tracking-[0.3em]">
                00 / DEEP SCAN COMPLETE
              </p>
              <h2 className="text-3xl sm:text-4xl font-display font-black uppercase italic tracking-tighter text-white mt-1">
                {searchResult.topic}
              </h2>
            </div>

            <button
              id="open-ebook-from-search-btn"
              onClick={onOpenEbookReader}
              className="w-full sm:w-auto bg-white hover:bg-yellow-400 text-black font-black px-8 py-4 text-xs uppercase tracking-widest transition-colors flex items-center justify-center space-x-3"
            >
              <BookOpen className="w-4 h-4" />
              <span>ABRIR E-BOOK DIAGRAMADO NO LEITOR</span>
            </button>
          </div>

          {/* Parameter 1: Como foi o Início */}
          <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">01 / PRIMARY GÊNESE</p>
              <h3 className="text-lg font-display font-black uppercase italic text-white">
                Como foi o Início (Origens & Germinação)
              </h3>
            </div>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed font-medium">
              {searchResult.originAndBeginning}
            </p>
          </div>

          {/* Parameter 2: Fatores que causaram o acontecimento */}
          <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">02 / CAUSATION VECTORS</p>
              <h3 className="text-lg font-display font-black uppercase italic text-white">
                Fatores que Causaram o Acontecimento
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {searchResult.causativeFactors.map((factor, idx) => (
                <div 
                  key={idx}
                  className="bg-[#050505] border border-zinc-800 p-4 text-xs font-mono text-zinc-300 flex items-start space-x-3"
                >
                  <span className="text-yellow-400 font-bold shrink-0">[{idx + 1}]</span>
                  <span>{factor}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Parameter 3: Pontos Fortes e Pontos Fracos */}
          <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">03 / TACTICAL STRENGTHS & WEAKNESSES</p>
              <h3 className="text-lg font-display font-black uppercase italic text-white">
                Análise Comparativa
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Pontos Fortes */}
              <div className="bg-[#050505] border border-zinc-800 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <span className="text-xs font-black uppercase tracking-widest text-emerald-400">Pontos Fortes & Vantagens</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <ul className="space-y-3">
                  {searchResult.strengthsAndWeaknesses.strengths.map((item, idx) => (
                    <li key={idx} className="text-xs text-zinc-300 flex items-start space-x-2.5">
                      <span className="text-emerald-400 font-mono font-bold">+</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Pontos Fracos */}
              <div className="bg-[#050505] border border-zinc-800 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <span className="text-xs font-black uppercase tracking-widest text-red-400">Pontos Fracos & Desafios</span>
                  <XCircle className="w-4 h-4 text-red-400" />
                </div>
                <ul className="space-y-3">
                  {searchResult.strengthsAndWeaknesses.weaknesses.map((item, idx) => (
                    <li key={idx} className="text-xs text-zinc-300 flex items-start space-x-2.5">
                      <span className="text-red-400 font-mono font-bold">-</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Parameter 4: Quanto tempo esteve em evidência */}
          <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">04 / TIMEFRAME & IMPACT</p>
              <h3 className="text-lg font-display font-black uppercase italic text-white">
                Tempo em Evidência
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2">
                <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">DURAÇÃO ESTIMADA</p>
                <p className="text-sm font-bold text-white font-mono">
                  {searchResult.durationInEvidence.timeframe}
                </p>
              </div>

              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2">
                <p className="text-[10px] font-black text-yellow-400 uppercase tracking-widest">PERÍODO DE ÁPICE</p>
                <p className="text-sm font-bold text-white font-mono">
                  {searchResult.durationInEvidence.peakPeriod}
                </p>
              </div>

              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2">
                <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">ESTADO ATUAL & LEGADO</p>
                <p className="text-sm font-bold text-white font-mono">
                  {searchResult.durationInEvidence.currentStatus}
                </p>
              </div>
            </div>
          </div>

          {/* Parameter 5: Sequência Cronológica (Início -> Desenvolvimento -> Meio -> Fim) */}
          <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">05 / SEQUÊNCIA CRONOLÓGICA</p>
              <h3 className="text-lg font-display font-black uppercase italic text-white">
                Início → Desenvolvimento → Meio → Fim
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Início */}
              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2 hover:border-yellow-400 transition-colors">
                <p className="text-[10px] font-black text-yellow-400 uppercase tracking-widest">1. GÊ N E S E</p>
                <p className="text-xs text-zinc-300 leading-relaxed font-medium">
                  {searchResult.chronologicalSequence.inicio}
                </p>
              </div>

              {/* Desenvolvimento */}
              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2 hover:border-yellow-400 transition-colors">
                <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">2. DESENVOLVIMENTO</p>
                <p className="text-xs text-zinc-300 leading-relaxed font-medium">
                  {searchResult.chronologicalSequence.desenvolvimento}
                </p>
              </div>

              {/* Meio */}
              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2 hover:border-yellow-400 transition-colors">
                <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">3. MEIO (ÁPICE)</p>
                <p className="text-xs text-zinc-300 leading-relaxed font-medium">
                  {searchResult.chronologicalSequence.meio}
                </p>
              </div>

              {/* Fim */}
              <div className="bg-[#050505] border border-zinc-800 p-5 space-y-2 hover:border-yellow-400 transition-colors">
                <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">4. FIM & LEGADO</p>
                <p className="text-xs text-zinc-300 leading-relaxed font-medium">
                  {searchResult.chronologicalSequence.fim}
                </p>
              </div>
            </div>
          </div>

          {/* Connected Public Sources */}
          <div className="bg-[#080808] border border-zinc-800 p-6 space-y-3">
            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">
              Bases de Dados Públicas Indexadas:
            </p>
            <div className="flex flex-wrap gap-3">
              {searchResult.sources.map((src, i) => (
                <a
                  key={i}
                  href={src.url}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#050505] border border-zinc-800 hover:border-yellow-400 px-4 py-2 text-xs font-mono text-zinc-300 hover:text-white flex items-center space-x-2 transition-colors"
                >
                  <span className="font-bold text-yellow-400">{src.title}</span>
                  <span className="text-[10px] text-zinc-600">[{src.type}]</span>
                  <ExternalLink className="w-3 h-3 text-zinc-500" />
                </a>
              ))}
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
