# GOITGODS 2.3.7 — correção definitiva do bootstrap do frontend

- `index.html` passa a ser servido com `Cache-Control: no-store`, evitando HTML antigo apontando para hashes Vite removidos após um novo deploy.
- Assets Vite com hash recebem cache `immutable`, sem afetar o índice.
- Apache declara MIME explícito para `.js`, `.mjs` e `.css`.
- O instalador valida os arquivos JS/CSS exatos referenciados pelo `dist/index.html` através do próprio VirtualHost Apache.
- `repair-white-screen.sh` ganhou a mesma validação de bundles.
- Mantidas as correções 2.3.6 de usuário, PM2, porta 3100, SSH/UFW e ServerName.
