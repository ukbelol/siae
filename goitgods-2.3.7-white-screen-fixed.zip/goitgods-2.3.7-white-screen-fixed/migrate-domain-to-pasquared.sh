#!/usr/bin/env bash
set -Eeuo pipefail
OLD_DOMAIN="goitgods.ukbelol.space"
NEW_DOMAIN="goitgods.pasquared.space"
APP_DIR="${APP_DIR:-/opt/goitgods}"
EMAIL="${CERTBOT_EMAIL:-}"
if [[ $EUID -ne 0 ]]; then echo "Execute como root: sudo $0"; exit 1; fi
if [[ -z "$EMAIL" ]]; then read -r -p "E-mail válido para Let's Encrypt: " EMAIL; fi
if [[ ! "$EMAIL" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]]; then echo "E-mail inválido."; exit 1; fi
if ! getent ahosts "$NEW_DOMAIN" >/dev/null 2>&1; then echo "ERRO: $NEW_DOMAIN ainda não resolve no DNS."; exit 1; fi
cp -a /etc/apache2/sites-available /etc/apache2/sites-available.backup-goitgods-$(date +%Y%m%d%H%M%S)
grep -RIl "$OLD_DOMAIN" /etc/apache2/sites-available 2>/dev/null | while read -r f; do sed -i "s/$OLD_DOMAIN/$NEW_DOMAIN/g" "$f"; done
if [[ -d "$APP_DIR" ]]; then
  grep -RIl --exclude-dir=node_modules --exclude-dir=.git "$OLD_DOMAIN" "$APP_DIR" 2>/dev/null | while read -r f; do sed -i "s/$OLD_DOMAIN/$NEW_DOMAIN/g" "$f"; done
fi
apache2ctl configtest
systemctl reload apache2
certbot --apache -d "$NEW_DOMAIN" --email "$EMAIL" --agree-tos --no-eff-email --redirect --non-interactive
apache2ctl configtest
systemctl reload apache2
certbot certificates
curl -fsSI "https://$NEW_DOMAIN/" | head
printf '
OK: domínio migrado para https://%s/
' "$NEW_DOMAIN"
