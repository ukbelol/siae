import React, { useEffect, useMemo, useState } from 'react';
import { Bot, Database, RefreshCw, Plus, Trash2, Save, ShieldCheck, KeyRound, Activity } from 'lucide-react';

type Registry = any;

const roles = [
  ['RESEARCH_ORCHESTRATOR','Research Orchestrator','Planeja a anamnese, decompõe a questão e decide quais fontes consultar.'],
  ['PASQUARED_REASONER','PASQUARED Reasoner','Estrutura premissas, evidências, incertezas e relações.'],
  ['SOURCE_ANALYST','Source Analyst / Apollo','Avalia qualidade, independência e rastreabilidade das fontes.'],
  ['ARES_CRITIC','ARES Critic','Procura contraevidências e tenta refutar premissas.'],
  ['HADES_RISK','HADES Risk Auditor','Audita riscos, lacunas e excesso de confiança.'],
  ['ZEUS_ARBITER','ZEUS Arbiter','Arbitra evidências e determina o estado epistemológico.'],
  ['BOOK_ARCHITECT','Book Architect','Transforma o ledger verificado em estrutura acadêmica/editorial.'],
  ['BOOK_WRITER','Book Writer','Redige somente com base no material verificado.'],
  ['FACT_CHECKER','Fact Checker','Confere afirmações, referências e consistência final.'],
] as const;

const adminFetch = (url:string, init:RequestInit = {}) => {
  const token = localStorage.getItem('goitgods_admin_token') || '';
  return fetch(url, { ...init, headers: { 'Content-Type':'application/json', 'x-admin-token': token, ...(init.headers || {}) } });
};

export const SuperAdminInfrastructure: React.FC = () => {
  const [registry, setRegistry] = useState<Registry | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [foundrySecret, setFoundrySecret] = useState('');
  const [newKb, setNewKb] = useState({ name:'', provider:'REST_JSON', baseUrl:'', domains:'MULTIDISCIPLINAR', authMode:'NONE', secret:'' });

  const load = async () => {
    const r = await adminFetch('/api/v2/admin/registry'); const d = await r.json();
    if (d.success) setRegistry(d.registry); else setMessage(d.error || 'Falha ao carregar registro administrativo.');
  };
  useEffect(() => { load().catch(e => setMessage(e.message)); }, []);

  const saveFoundry = async () => {
    setBusy('foundry');
    const r = await adminFetch('/api/v2/admin/registry/foundry', { method:'PATCH', body: JSON.stringify({ ...registry.foundry, clientSecret: foundrySecret || undefined }) });
    const d = await r.json(); setMessage(d.success ? 'Configuração do Microsoft Foundry salva.' : d.error); if(d.success) setFoundrySecret(''); setBusy(null); load();
  };

  const saveAgent = async (agent:any) => {
    setBusy(agent.id);
    const r = await adminFetch('/api/v2/admin/registry/agents', { method:'POST', body: JSON.stringify(agent) });
    const d = await r.json(); setMessage(d.success ? `${agent.label} salvo.` : d.error); setBusy(null); load();
  };

  const updateAgentLocal = (id:string, patch:any) => setRegistry((r:any) => ({ ...r, agents:r.agents.map((a:any) => a.id === id ? { ...a, ...patch } : a) }));
  const updateKbLocal = (id:string, patch:any) => setRegistry((r:any) => ({ ...r, knowledgeBases:r.knowledgeBases.map((k:any) => k.id === id ? { ...k, ...patch } : k) }));

  const saveKb = async (kb:any) => {
    setBusy(kb.id);
    const r = await adminFetch('/api/v2/admin/registry/knowledge-bases', { method:'POST', body:JSON.stringify(kb) });
    const d = await r.json(); setMessage(d.success ? `Base ${kb.name} salva.` : d.error); setBusy(null); load();
  };

  const addKb = async () => {
    if (!newKb.name || !newKb.baseUrl) { setMessage('Informe nome e URL da nova base.'); return; }
    const payload = { ...newKb, domains:newKb.domains.split(',').map(x=>x.trim()).filter(Boolean), syncMode:'METADATA', enabled:true };
    const r = await adminFetch('/api/v2/admin/registry/knowledge-bases', { method:'POST', body:JSON.stringify(payload) });
    const d = await r.json(); setMessage(d.success ? 'Nova base adicionada.' : d.error); setNewKb({ name:'', provider:'REST_JSON', baseUrl:'', domains:'MULTIDISCIPLINAR', authMode:'NONE', secret:'' }); load();
  };

  const sync = async (id:string) => {
    setBusy(`sync-${id}`); const r = await adminFetch(`/api/v2/admin/registry/knowledge-bases/${id}/sync`, { method:'POST' }); const d = await r.json();
    setMessage(d.success ? `Sincronização de ${d.knowledgeBase?.name || id} concluída: ${d.knowledgeBase?.lastSyncStatus}.` : d.error); setBusy(null); load();
  };
  const syncAll = async () => {
    setBusy('sync-all'); const r = await adminFetch('/api/v2/admin/registry/knowledge-bases/sync-all', { method:'POST' }); const d=await r.json();
    setMessage(d.success ? `Sincronização global executada em ${d.results.length} base(s).` : d.error); setBusy(null); load();
  };


  const testFoundry = async () => {
    setBusy('foundry-test'); const r=await adminFetch('/api/v2/admin/foundry/test',{method:'POST',body:'{}'}); const d=await r.json();
    setMessage(d.success ? d.result?.message || 'Conexão com Foundry confirmada.' : d.error); setBusy(null);
  };
  const createRemoteAgent = async (id:string) => {
    setBusy(`create-${id}`); const r=await adminFetch(`/api/v2/admin/foundry/agents/${id}/create`,{method:'POST',body:JSON.stringify({activate:true})}); const d=await r.json();
    setMessage(d.success ? `Agente criado no Foundry e publicado no endpoint estável: ${d.result?.name} v${d.result?.version}.` : d.error); setBusy(null); load();
  };
  const activateRemoteAgent = async (id:string, version?:string) => {
    setBusy(`activate-${id}`); const r=await adminFetch(`/api/v2/admin/foundry/agents/${id}/activate`,{method:'POST',body:JSON.stringify({version})}); const d=await r.json();
    setMessage(d.success ? `Versão ${d.result?.version} ativada para ${d.result?.name}.` : d.error); setBusy(null); load();
  };
  const createStandardArchitecture = async () => {
    if(!confirm('Criar/atualizar e ativar todos os Prompt Agents habilitados no Microsoft Foundry? Cada execução pode criar uma nova versão.')) return;
    setBusy('create-standard'); const r=await adminFetch('/api/v2/admin/foundry/architecture/create-standard',{method:'POST',body:'{}'}); const d=await r.json();
    if(d.success){ const ok=(d.results||[]).filter((x:any)=>x.success).length; const fail=(d.results||[]).length-ok; setMessage(`Arquitetura PASQUARED criada: ${ok} agente(s) ativo(s), ${fail} falha(s).`); } else setMessage(d.error); setBusy(null); load();
  };

  const savePolicies = async () => {
    setBusy('policies'); const r=await adminFetch('/api/v2/admin/registry/policies',{method:'PATCH',body:JSON.stringify(registry.policies)}); const d=await r.json();
    setMessage(d.success?'Políticas de governança salvas.':d.error); setBusy(null); load();
  };

  const configuredAgents = useMemo(() => registry?.agents?.filter((a:any)=>a.agentName || a.agentId || a.modelDeployment).length || 0, [registry]);
  if (!registry) return <div className="p-8 text-xs text-slate-400">Carregando infraestrutura administrativa...</div>;

  return <div className="space-y-8">
    {message && <div className="border border-blue-500/40 bg-blue-500/10 p-3 text-xs text-blue-200">{message}</div>}

    <section className="border border-[#222] bg-[#0B0B0B] p-5 space-y-4">
      <div className="flex items-center justify-between gap-4"><div><h2 className="text-white font-black uppercase flex items-center gap-2"><Bot className="w-4 h-4 text-blue-400"/> Microsoft Foundry & Agentes</h2><p className="text-xs text-slate-400 mt-1">Mapeie cada função do PASQUARED/GOITGODS a um Prompt Agent, Hosted Agent ou deployment direto.</p></div><span className="text-[10px] border border-slate-700 px-2 py-1">{configuredAgents}/{registry.agents.length} configurados</span></div>
      <div className="grid md:grid-cols-2 gap-3">
        <input className="admin-input" placeholder="Foundry project endpoint (https://...services.ai.azure.com/api/projects/...)" value={registry.foundry.defaultProjectEndpoint || ''} onChange={e=>setRegistry({...registry,foundry:{...registry.foundry,defaultProjectEndpoint:e.target.value}})}/>
        <input className="admin-input" placeholder="Deployment/modelo padrão (ex.: gpt-5-mini)" value={registry.foundry.defaultModelDeployment || ''} onChange={e=>setRegistry({...registry,foundry:{...registry.foundry,defaultModelDeployment:e.target.value}})}/>
        <input className="admin-input" placeholder="Tenant ID" value={registry.foundry.tenantId || ''} onChange={e=>setRegistry({...registry,foundry:{...registry.foundry,tenantId:e.target.value}})}/>
        <input className="admin-input" placeholder="Client ID (App Registration / Service Principal)" value={registry.foundry.clientId || ''} onChange={e=>setRegistry({...registry,foundry:{...registry.foundry,clientId:e.target.value}})}/>
        <input className="admin-input" type="password" placeholder={registry.foundry.hasClientSecret?'Client Secret configurado — digite para substituir':'Client Secret do Microsoft Entra ID'} value={foundrySecret} onChange={e=>setFoundrySecret(e.target.value)}/>
        <input className="admin-input" placeholder="Nome do projeto Foundry" value={registry.foundry.projectName || ''} onChange={e=>setRegistry({...registry,foundry:{...registry.foundry,projectName:e.target.value}})}/>
      </div>
      <div className="flex flex-wrap gap-2"><button onClick={saveFoundry} className="admin-btn"><Save className="w-3.5 h-3.5"/> Salvar configuração Foundry</button><button onClick={testFoundry} disabled={busy==='foundry-test'} className="admin-btn"><Activity className="w-3.5 h-3.5"/> Testar conexão</button><button onClick={createStandardArchitecture} disabled={busy==='create-standard'} className="admin-btn border-blue-500/60"><Bot className="w-3.5 h-3.5"/> Criar arquitetura padrão PASQUARED no Foundry</button></div>
      <div className="text-[11px] text-slate-400 border-l-2 border-blue-500 pl-3">Indicação: comece com <b className="text-white">Prompt Agents</b> para cada papel. Use Hosted Agent quando quiser executar a própria lógica multiagente/código no Foundry. Para autenticação de produção, prefira Microsoft Entra ID; guarde API keys somente quando necessário.</div>

      <div className="space-y-3">
        {registry.agents.map((a:any) => {
          const roleInfo = roles.find(r=>r[0]===a.role);
          return <div key={a.id} className="border border-[#202020] p-4 space-y-3 bg-black/30">
            <div className="flex justify-between gap-3"><div><div className="text-xs text-white font-bold">{a.label} <span className="text-[9px] text-blue-400">{a.role}</span></div><div className="text-[10px] text-slate-500">{roleInfo?.[2]}</div></div><label className="text-[10px] text-slate-300"><input type="checkbox" checked={a.enabled} onChange={e=>updateAgentLocal(a.id,{enabled:e.target.checked})}/> ativo</label></div>
            <div className="grid md:grid-cols-4 gap-2">
              <select className="admin-input" value={a.agentType} onChange={e=>updateAgentLocal(a.id,{agentType:e.target.value})}><option value="PROMPT_AGENT">Prompt Agent</option><option value="HOSTED_AGENT">Hosted Agent</option><option value="MODEL_DIRECT">Modelo direto</option></select>
              <input className="admin-input" placeholder="Agent name" value={a.agentName || ''} onChange={e=>updateAgentLocal(a.id,{agentName:e.target.value})}/>
              <input className="admin-input" placeholder="Agent ID (se aplicável)" value={a.agentId || ''} onChange={e=>updateAgentLocal(a.id,{agentId:e.target.value})}/>
              <input className="admin-input" placeholder="Deployment/model" value={a.modelDeployment || ''} onChange={e=>updateAgentLocal(a.id,{modelDeployment:e.target.value})}/>
              <input className="admin-input md:col-span-2" placeholder="Project endpoint (vazio = padrão)" value={a.projectEndpoint || ''} onChange={e=>updateAgentLocal(a.id,{projectEndpoint:e.target.value})}/>
              <select className="admin-input" value={a.authMode} onChange={e=>updateAgentLocal(a.id,{authMode:e.target.value})}><option value="ENTRA_ID">Entra ID</option><option value="API_KEY">API Key</option></select>
              <input className="admin-input" type="password" placeholder={a.hasSecret?'Chave configurada — digite para substituir':'API key (opcional)'} onChange={e=>updateAgentLocal(a.id,{secret:e.target.value})}/>
            </div>
            <textarea className="admin-input w-full min-h-16" value={a.instructions || ''} onChange={e=>updateAgentLocal(a.id,{instructions:e.target.value})}/>
            <div className="flex flex-wrap items-center gap-2"><button onClick={()=>saveAgent(a)} disabled={busy===a.id} className="admin-btn"><Save className="w-3 h-3"/> Salvar agente</button>{a.agentType==='PROMPT_AGENT' && <button onClick={()=>createRemoteAgent(a.id)} disabled={busy===`create-${a.id}`} className="admin-btn"><Bot className="w-3 h-3"/> Criar/Publicar no Foundry</button>}{a.remoteVersion && <button onClick={()=>activateRemoteAgent(a.id,a.remoteVersion)} disabled={busy===`activate-${a.id}`} className="admin-btn"><Activity className="w-3 h-3"/> Ativar v{a.remoteVersion}</button>}<span className="text-[10px] text-slate-400">Foundry: <b className={a.remoteStatus==='ACTIVE'?'text-green-400':'text-blue-300'}>{a.remoteStatus || 'LOCAL'}</b>{a.remoteVersion?` · v${a.remoteVersion}`:''}{a.lastPublishedAt?` · ${new Date(a.lastPublishedAt).toLocaleString()}`:''}</span></div>
          </div>;
        })}
      </div>
    </section>

    <section className="border border-[#222] bg-[#0B0B0B] p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-white font-black uppercase flex items-center gap-2"><Database className="w-4 h-4 text-purple-400"/> Bases de Conhecimento</h2><p className="text-xs text-slate-400">Cadastre conectores e sincronize individualmente ou todas as bases habilitadas.</p></div><button onClick={syncAll} disabled={busy==='sync-all'} className="admin-btn"><RefreshCw className={`w-3.5 h-3.5 ${busy==='sync-all'?'animate-spin':''}`}/> Sincronizar todas</button></div>
      <div className="grid gap-3">
        {registry.knowledgeBases.map((k:any) => <div key={k.id} className="border border-[#202020] p-4 space-y-3">
          <div className="flex flex-wrap justify-between gap-2"><div><div className="text-xs font-bold text-white">{k.name} <span className="text-[9px] text-purple-300">{k.provider}</span></div><div className="text-[10px] text-slate-500">{k.baseUrl}</div></div><div className="text-[10px]">Status: <b className={k.lastSyncStatus==='OK'?'text-green-400':k.lastSyncStatus==='ERROR'?'text-red-400':'text-slate-400'}>{k.lastSyncStatus}</b></div></div>
          <div className="grid md:grid-cols-4 gap-2"><input className="admin-input" value={k.name} onChange={e=>updateKbLocal(k.id,{name:e.target.value})}/><input className="admin-input md:col-span-2" value={k.baseUrl} onChange={e=>updateKbLocal(k.id,{baseUrl:e.target.value})}/><label className="admin-input text-xs"><input type="checkbox" checked={k.enabled} onChange={e=>updateKbLocal(k.id,{enabled:e.target.checked})}/> habilitada</label></div>
          <div className="text-[10px] text-slate-500">Domínios: {(k.domains || []).join(', ')} · Última sincronização: {k.lastSyncAt || 'nunca'} · Itens declarados/estimados: {k.lastItemCount ?? '-'}</div>
          {k.lastSyncMessage && <div className="text-[10px] text-slate-400">{k.lastSyncMessage}</div>}
          <div className="flex gap-2"><button onClick={()=>saveKb(k)} className="admin-btn"><Save className="w-3 h-3"/> Salvar</button><button onClick={()=>sync(k.id)} className="admin-btn"><RefreshCw className={`w-3 h-3 ${busy===`sync-${k.id}`?'animate-spin':''}`}/> Sincronizar</button></div>
        </div>)}
      </div>
      <div className="border border-dashed border-[#333] p-4 space-y-3"><h3 className="text-xs font-bold text-white flex items-center gap-2"><Plus className="w-3.5 h-3.5"/> Nova base</h3><div className="grid md:grid-cols-3 gap-2"><input className="admin-input" placeholder="Nome" value={newKb.name} onChange={e=>setNewKb({...newKb,name:e.target.value})}/><select className="admin-input" value={newKb.provider} onChange={e=>setNewKb({...newKb,provider:e.target.value})}><option>CROSSREF</option><option>OPENALEX</option><option>PUBMED</option><option>EUROPE_PMC</option><option>REST_JSON</option><option>CUSTOM</option></select><input className="admin-input" placeholder="Domínios separados por vírgula" value={newKb.domains} onChange={e=>setNewKb({...newKb,domains:e.target.value})}/><input className="admin-input md:col-span-2" placeholder="Base URL / endpoint" value={newKb.baseUrl} onChange={e=>setNewKb({...newKb,baseUrl:e.target.value})}/><select className="admin-input" value={newKb.authMode} onChange={e=>setNewKb({...newKb,authMode:e.target.value})}><option>NONE</option><option>API_KEY</option><option>BEARER</option></select><input className="admin-input" type="password" placeholder="Segredo/API key (opcional)" value={newKb.secret} onChange={e=>setNewKb({...newKb,secret:e.target.value})}/></div><button onClick={addKb} className="admin-btn"><Plus className="w-3 h-3"/> Adicionar base</button></div>
    </section>

    <section className="border border-[#222] bg-[#0B0B0B] p-5 space-y-4">
      <h2 className="text-white font-black uppercase flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-400"/> Governança epistemológica e segurança</h2>
      <div className="grid md:grid-cols-2 gap-3 text-xs">
        <label className="admin-check"><input type="checkbox" checked={registry.policies.requireSourceForFactualClaim} onChange={e=>setRegistry({...registry,policies:{...registry.policies,requireSourceForFactualClaim:e.target.checked}})}/> Exigir fonte para afirmações factuais</label>
        <label className="admin-check"><input type="checkbox" checked={registry.policies.rejectInventedCitations} onChange={e=>setRegistry({...registry,policies:{...registry.policies,rejectInventedCitations:e.target.checked}})}/> Rejeitar citações/referências não verificadas</label>
        <label className="admin-check">Fontes independentes mínimas <input className="ml-2 w-16 bg-black border border-[#333] px-2 py-1" type="number" min="1" max="10" value={registry.policies.minimumIndependentSources} onChange={e=>setRegistry({...registry,policies:{...registry.policies,minimumIndependentSources:Number(e.target.value)}})}/></label>
        <label className="admin-check"><input type="checkbox" checked={registry.policies.syncOnStartup} onChange={e=>setRegistry({...registry,policies:{...registry.policies,syncOnStartup:e.target.checked}})}/> Sincronizar conectores na inicialização</label>
        <label className="admin-check text-amber-300"><input type="checkbox" checked={registry.policies.allowMedicalDiagnosis} onChange={e=>setRegistry({...registry,policies:{...registry.policies,allowMedicalDiagnosis:e.target.checked}})}/> Permitir diagnóstico médico automatizado (não recomendado)</label>
        <label className="admin-check text-amber-300"><input type="checkbox" checked={registry.policies.allowLegalOpinionAsProfessionalAdvice} onChange={e=>setRegistry({...registry,policies:{...registry.policies,allowLegalOpinionAsProfessionalAdvice:e.target.checked}})}/> Tratar resposta jurídica como aconselhamento profissional (não recomendado)</label>
      </div>
      <button onClick={savePolicies} className="admin-btn"><Save className="w-3.5 h-3.5"/> Salvar políticas</button>
    </section>

    <style>{`.admin-input{background:#050505;border:1px solid #272727;padding:.6rem .7rem;color:#e5e7eb;font-size:11px;outline:none}.admin-input:focus{border-color:#3b82f6}.admin-btn{display:inline-flex;align-items:center;gap:.4rem;background:#151515;border:1px solid #333;padding:.55rem .75rem;color:white;font-size:10px;font-weight:800;text-transform:uppercase}.admin-btn:hover{border-color:#60a5fa}.admin-check{background:#050505;border:1px solid #222;padding:.7rem;color:#cbd5e1}`}</style>
  </div>;
};
