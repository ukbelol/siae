import React from 'react';
import { ShoppingCart, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function StoreAd() {
  const navigate = useNavigate();

  return (
    <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-blue-950 rounded-2xl p-6 md:p-8 shadow-2xl mb-8 border border-indigo-500/30 relative overflow-hidden group">
      {/* Dynamic Background Accents */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl group-hover:bg-indigo-500/20 transition duration-700"></div>
      <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl group-hover:bg-emerald-500/10 transition duration-700"></div>
      
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center relative z-10">
        
        {/* Left Column: Prominently Highlighted Keychain Image */}
        <div className="col-span-12 md:col-span-5 flex justify-center">
          <div className="relative group/img max-w-xs w-full">
            {/* Elegant Outer Multi-layered Glow */}
            <div className="absolute -inset-1.5 bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-2xl blur-lg opacity-40 group-hover/img:opacity-75 transition duration-500"></div>
            
            {/* Image Card Container */}
            <div className="relative bg-gray-900/40 backdrop-blur-md p-6 rounded-2xl border border-indigo-400/20 shadow-xl flex flex-col items-center">
              <span className="absolute top-3 left-3 bg-indigo-600/80 text-white text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded border border-indigo-400/30">
                Oficial SIAE
              </span>
              
              <img 
                src="/chaveiro-siae.png" 
                alt="Chaveiro NFC SIAE" 
                className="w-48 h-48 md:w-56 md:h-56 object-contain drop-shadow-[0_0_20px_rgba(99,102,241,0.6)] transform group-hover/img:scale-105 transition-transform duration-300"
              />
              
              {/* Feature Tags at the bottom of the image card */}
              <div className="mt-4 flex gap-2">
                <span className="bg-emerald-500/20 text-emerald-300 text-xs font-bold px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  NFC Integrado
                </span>
                <span className="bg-indigo-500/20 text-indigo-300 text-xs font-bold px-2.5 py-1 rounded-full border border-indigo-500/30">
                  Sem Bateria
                </span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Column: Promotional Copy & Call-to-Action Link */}
        <div className="col-span-12 md:col-span-7 space-y-5 text-center md:text-left">
          <div className="space-y-2">
            <span className="text-emerald-400 text-sm font-bold tracking-wider uppercase">Facilidade &amp; Praticidade</span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-white leading-tight">
              Seu Acesso Instantâneo Sem Fila
            </h2>
          </div>
          
          <p className="text-indigo-200 text-base leading-relaxed">
            Adquira o <strong>Chaveiro Plástico com Etiqueta Eletrônica e Tecnologia NFC</strong>. 
            Esqueça as preocupações com o celular e aplicativos abertos: basta aproximar o chaveiro nos totens do painel de triagem e seu check-in na fila de assistência é instantâneo.
          </p>
          
          {/* Main highlights list */}
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-indigo-150 text-sm text-left font-sans">
            <li className="flex items-center gap-2 text-indigo-200">
              <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Dispensa uso do smartphone</span>
            </li>
            <li className="flex items-center gap-2 text-indigo-200">
              <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Check-in em menos de 1 segundo</span>
            </li>
            <li className="flex items-center gap-2 text-indigo-200">
              <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Material ultra durável e à prova d'água</span>
            </li>
            <li className="flex items-center gap-2 text-indigo-200">
              <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Retirada simples na própria Casa</span>
            </li>
          </ul>

          <div className="pt-4 flex flex-col sm:flex-row items-center gap-4">
            <button 
              onClick={() => navigate('/comprar-chaveiro')}
              className="bg-gradient-to-r from-emerald-500 to-indigo-600 hover:from-emerald-600 hover:to-indigo-700 text-white font-bold py-3.5 px-8 rounded-xl flex items-center justify-center space-x-3 transition-all duration-300 transform hover:scale-[1.03] active:scale-95 shadow-xl hover:shadow-indigo-500/20 w-full sm:w-auto"
            >
              <ShoppingCart className="w-5 h-5" />
              <span className="tracking-wide">Comprar Meu Chaveiro NFC</span>
            </button>
            <span className="text-xs text-indigo-300 font-medium italic">
              Disponível para entrega imediata
            </span>
          </div>
        </div>
        
      </div>
    </div>
  );
}
