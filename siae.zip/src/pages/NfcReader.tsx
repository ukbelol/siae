import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Nfc, ArrowLeft, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function NfcReader() {
  const { houseId } = useParams();
  const navigate = useNavigate();
  const [cpfInput, setCpfInput] = useState('');
  const [scanResult, setScanResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [assistanceTypes, setAssistanceTypes] = useState<any[]>([]);
  const [selectedType, setSelectedType] = useState('');
  const [roomNumberInput, setRoomNumberInput] = useState('');
  
  const [isWritingTagMode, setIsWritingTagMode] = useState(false);
  const [writeTagStep, setWriteTagStep] = useState<'request_cpf' | 'request_scan'>('request_cpf');
  const [cpfForWrite, setCpfForWrite] = useState('');
  const [userForWrite, setUserForWrite] = useState<any>(null);
  
  const [showDuplicatePrompt, setShowDuplicatePrompt] = useState(false);
  const [duplicateTagInput, setDuplicateTagInput] = useState('');

  const isProcessingRef = React.useRef(false);
  const lastReadCpfRef = React.useRef<string | null>(null);
  const lastReadTimeRef = React.useRef<number>(0);

  const resetTerminal = (keepSuccessMessage: boolean | React.MouseEvent = false) => {
    const keep = typeof keepSuccessMessage === 'boolean' ? keepSuccessMessage : false;
    setScanResult(null);
    setMessage('');
    if (!keep) {
      setSuccessMessage('');
    }
    setShowDuplicatePrompt(false);
    setDuplicateTagInput('');
    setCpfInput('');
    setIsWritingTagMode(false);
    setCpfForWrite('');
    setUserForWrite(null);
    setRoomNumberInput('');
    // Clear our nfc scan lock/cache
    lastReadCpfRef.current = null;
    lastReadTimeRef.current = 0;
    isProcessingRef.current = false;
  };

  const handleStartWriteFlow = async () => {
    setMessage('');
    if (!('NDEFReader' in window)) {
      if (window.confirm('A funcionalidade de gravação de tag NFC requer permissões e recursos adequados (Navegador com suporte e WebNFC ativado). Deseja tentar iniciar mesmo assim para solicitar permissão?')) {
         setIsWritingTagMode(true);
         setWriteTagStep('request_cpf');
      }
    } else {
      setIsWritingTagMode(true);
      setWriteTagStep('request_cpf');
    }
  };

  const verifyCpfForWrite = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    try {
      const res = await fetch('/api/terminal/verify-cpf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cpf: cpfForWrite })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      setUserForWrite(data.user);
      setWriteTagStep('request_scan');
      
      // Start NFC Reading for the write process
      if ('NDEFReader' in window) {
        const ndef = new (window as any).NDEFReader();
        try {
          await ndef.scan();
          let beepInterval: any;
          ndef.onreading = async (event: any) => {
             const serialNumber = event.serialNumber;
             clearInterval(beepInterval); // Stop beep if we get a response
             
             if (!serialNumber) {
               setMessage('Tag lida, mas não possui serial válido. Tente outra tag.');
               const audio = new Audio('/alert.mp3'); 
               audio.loop = true;
               audio.play().catch(() => {});
               setTimeout(() => { audio.loop = false; audio.pause(); }, 30000);
               return;
             }
             
             let payloadText = '';
             for (const record of event.message.records) {
                 if (record.recordType === "text") {
                     const decoder = new TextDecoder();
                     payloadText = decoder.decode(record.data);
                 }
             }
             
             let p_serial = '';
             let p_timestamp = '';
             
             if (payloadText && payloadText.includes("Serial SIAE:")) {
                 const parts = payloadText.split('|');
                 const serialMatch = parts[0].match(/Serial SIAE: (.*)/);
                 p_serial = serialMatch ? serialMatch[1].trim() : '';
                 if (parts[1]) p_timestamp = parts[1].trim();
             }
             
             if (!p_serial || !p_timestamp) {
                 setMessage('Esta tag não foi formatada oficialmente. Use o painel Administrador para ativá-la e gerar a Serial.');
                 const audio = new Audio('/alert.mp3'); audio.play().catch(()=>{});
                 setTimeout(() => resetTerminal(), 4000);
                 return;
             }
             
             try {
                // Validate serial strictly via nfc-scan but purely to check integrity
                const validRes = await fetch('/api/terminal/nfc-scan', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ houseId, p_serial, p_timestamp, cpf: p_serial }) // send cpf as p_serial just to pass simple checks
                });
                const validData = await validRes.json();
                
                // If status is 401, error on integrity
                if (!validRes.ok && validRes.status === 401) {
                   const audio = new Audio('/alert.mp3'); audio.play().catch(()=>{});
                   setMessage(validData.error);
                   return;
                }
                
                // Bind to user in DB
                const writeRes = await fetch('/api/terminal/write-tag', {
                   method: 'POST',
                   headers: { 'Content-Type': 'application/json' },
                   body: JSON.stringify({ userId: data.user.id, nfcTag: p_serial })
                });
                const writeData = await writeRes.json();
                
                if (!writeRes.ok) {
                   setMessage(`Erro ao vincular: ${writeData.error}`);
                } else {
                   setMessage(`Vinculação bem sucedida! Tag ativada e pronta para check-in/out. (${writeData.message})`);
                }
                setTimeout(() => resetTerminal(), 6000);
             } catch (wErr: any) {
                setMessage('Erro na verificação da Tag: ' + wErr.message);
             }
          };
          ndef.onreadingerror = () => {
             setMessage('Erro de leitura NFC!');
          };
        } catch (scanErr) {
           setMessage('Erro ao iniciar NFC: verifique permissões. ' + String(scanErr));
        }
      }
    } catch (err: any) {
      setMessage(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetch(`/api/houses/${houseId}/assistance-types`)
      .then(res => res.json())
      .then(data => {
        setAssistanceTypes(data);
        if (data.length > 0) setSelectedType(data[0].name);
      })
      .catch(console.error);
  }, [houseId]);

  useEffect(() => {
    if (scanResult && scanResult.session) {
      if (scanResult.session.current_assistance_type) {
        setSelectedType(scanResult.session.current_assistance_type);
      }
      if (scanResult.session.room_number) {
        setRoomNumberInput(scanResult.session.room_number);
      }
    }
  }, [scanResult]);

  useEffect(() => {
    let timerId: NodeJS.Timeout | null = null;

    if (scanResult && scanResult.user?.role === 'worker' && scanResult.action === 'worker_prompt_status') {
      timerId = setTimeout(() => {
        resetTerminal();
      }, 11000);
    }

    return () => {
      if (timerId) clearTimeout(timerId);
    };
  }, [scanResult, selectedType, roomNumberInput]);

  const startContinuousWebNFC = async () => {
    setMessage('');
    if (!('NDEFReader' in window)) {
      alert('Navegador não suporta WebNFC.');
      return;
    }
    try {
      const ndef = new (window as any).NDEFReader();
      await ndef.scan();
      setMessage('Leitor Web NFC ativo e escutando...');
      ndef.onreading = async (event: any) => {
          let payloadText = '';
          for (const record of event.message.records) {
              if (record.recordType === "text") {
                  const decoder = new TextDecoder();
                  payloadText = decoder.decode(record.data);
              }
          }
          
          let p_serial = event.serialNumber;
          let p_timestamp = '';
          
          if (payloadText && payloadText.includes("Serial SIAE:")) {
              const parts = payloadText.split('|');
              const serialMatch = parts[0].match(/Serial SIAE: (.*)/);
              p_serial = serialMatch ? serialMatch[1].trim() : event.serialNumber;
              if (parts[1]) p_timestamp = parts[1].trim();
          }

          const now = Date.now();
          if (isProcessingRef.current) return;
          if (p_serial === lastReadCpfRef.current && (now - lastReadTimeRef.current < 5000)) {
              return; // ignore duplicates within 5 seconds
          }

          isProcessingRef.current = true;
          lastReadCpfRef.current = p_serial;
          lastReadTimeRef.current = now;

          setLoading(true);
          setMessage('');
          setSuccessMessage('');
          try {
            const res = await fetch('/api/terminal/nfc-scan', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ houseId, cpf: p_serial, p_serial, p_timestamp })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            setScanResult(data);
            handlePostScanSuccess(data);
          } catch (err: any) {
            setMessage(err.message);
            setScanResult(null);
            setTimeout(() => resetTerminal(), 4000);
          } finally {
            setLoading(false);
            isProcessingRef.current = false;
          }
      };
    } catch (err) {
       setMessage('Erro ao iniciar Leitor Web NFC. Verifique as permissões.');
    }
  };

  const handlePostScanSuccess = (data: any) => {
      if (data.accessedViaCpf && data.hasNfcTag) {
        if (data.action === 'worker_clocked_in' || data.action === 'assisted_prompt_checkin' || data.action === 'assisted_started_attendance') {
           setShowDuplicatePrompt(true);
        }
      }
      if (!data.accessedViaCpf || !data.hasNfcTag || (data.action !== 'worker_clocked_in' && data.action !== 'assisted_prompt_checkin' && data.action !== 'assisted_started_attendance')) {
        const autoResetActions = [
            'worker_clocked_in', 
            'worker_attendance_finished', 
            'assisted_already_in_queue', 
            'assisted_started_attendance', 
            'assisted_already_in_progress'
        ];
        if (autoResetActions.includes(data.action)) {
            setTimeout(() => resetTerminal(), 4000);
        }
      }
  };

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!cpfInput) return;

    const now = Date.now();
    if (isProcessingRef.current) return;
    if (cpfInput === lastReadCpfRef.current && (now - lastReadTimeRef.current < 5000)) {
       return; // ignore duplicates within 5 seconds
    }

    isProcessingRef.current = true;
    lastReadCpfRef.current = cpfInput;
    lastReadTimeRef.current = now;

    setLoading(true);
    setMessage('');
    setSuccessMessage('');
    try {
      const res = await fetch('/api/terminal/nfc-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ houseId, cpf: cpfInput })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      setScanResult(data);
      handlePostScanSuccess(data);
      
      setCpfInput('');
    } catch (err: any) {
      setMessage(err.message);
      setScanResult(null);
    } finally {
      setLoading(false);
      isProcessingRef.current = false;
    }
  };

  const handleWorkerStatus = async (status: string, clockOut: boolean = false) => {
    try {
      // Esvaziar o cache de leitura imediatamente ao clicar em confirmar
      lastReadCpfRef.current = null;
      lastReadTimeRef.current = 0;
      isProcessingRef.current = false;

      await fetch(`/api/worker/session/${scanResult.session.id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, clockOut, currentAssistanceType: selectedType, roomNumber: roomNumberInput })
      });
      
      if (status === 'available') {
        // Call next in queue
        const callRes = await fetch('/api/queue/call-next', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ houseId, workerId: scanResult.user.id, type: selectedType || 'Passe' })
        });
        const callData = await callRes.json();
        if (callRes.ok) {
          setSuccessMessage(`Status: Disponível. ${callData.message} (Senha: ${callData.attendance.ticket_number})`);
        } else if (callRes.status === 404) {
          setSuccessMessage('Status: Disponível. Fila vazia no momento.');
        } else {
           throw new Error(callData.error);
        }
      } else if (clockOut) {
        setSuccessMessage('Ponto encerrado com sucesso.');
      } else if (status === 'break') {
        setSuccessMessage('Status atualizado para: Em intervalo.');
      } else {
        setSuccessMessage('Status atualizado.');
      }
      resetTerminal(true);
    } catch (err: any) {
      setMessage(err.message);
    }
  };

  const handleCheckIn = async () => {
    try {
      // Esvaziar o cache de leitura imediatamente ao clicar em confirmar
      lastReadCpfRef.current = null;
      lastReadTimeRef.current = 0;
      isProcessingRef.current = false;

      const res = await fetch('/api/queue/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ houseId, assistedId: scanResult.user.id, requiredTypes: [selectedType] })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      if (scanResult?.accessedViaCpf && scanResult?.hasNfcTag) {
        setSuccessMessage(`Check-in realizado! Senha: ${data.ticketNumber}`);
        setShowDuplicatePrompt(true);
      } else {
        setSuccessMessage(`Check-in realizado! Senha: ${data.ticketNumber}`);
        // Reset terminal immediately but keep success message on screen
        resetTerminal(true);
      }
    } catch (err: any) {
      setMessage(err.message);
    }
  };

  const handleWriteDuplicate = async () => {
    if (!duplicateTagInput) {
      alert('Aproxime a nova Tag NFC ou digite-a.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/terminal/write-tag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: scanResult.user.id, nfcTag: duplicateTagInput })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setMessage(data.message);
      setTimeout(() => resetTerminal(), 3000);
    } catch (err: any) {
      setMessage(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <button onClick={() => navigate('/terminal/select')} className="absolute top-6 left-6 text-gray-400 hover:text-white flex items-center gap-2">
        <ArrowLeft className="w-6 h-6" /> Voltar
      </button>

      <div className="text-center mb-12 z-10">
        <div className="relative inline-block mb-6 h-40 w-40 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div
                key="reading"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="relative flex items-center justify-center"
              >
                <div className="absolute inset-0 bg-blue-500 rounded-full blur-3xl opacity-30 animate-pulse"></div>
                <Loader2 className="w-32 h-32 text-blue-400 relative z-10 animate-spin" />
              </motion.div>
            ) : scanResult ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.5, rotate: -45 }}
                animate={{ opacity: 1, scale: 1, rotate: 0 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="relative flex items-center justify-center"
              >
                <div className="absolute inset-0 bg-indigo-500 rounded-full blur-3xl opacity-30"></div>
                <CheckCircle className="w-32 h-32 text-indigo-400 relative z-10" />
              </motion.div>
            ) : message && !scanResult ? (
              <motion.div
                key="error"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ type: "spring", bounce: 0.6 }}
                className="relative flex items-center justify-center"
              >
                <div className="absolute inset-0 bg-red-500 rounded-full blur-3xl opacity-30"></div>
                <XCircle className="w-32 h-32 text-red-400 relative z-10" />
              </motion.div>
            ) : (
              <motion.div
                key="waiting"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="relative flex items-center justify-center"
              >
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }} 
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                  className="absolute inset-0 bg-emerald-500 rounded-full blur-3xl opacity-20" 
                />
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                >
                  <Nfc className="w-32 h-32 text-emerald-400 relative z-10" />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <h1 className="text-4xl font-bold text-white mb-4">
          {loading ? 'Processando leitura...' : scanResult ? 'Leitura concluída' : message && !scanResult ? 'Falha na Leitura' : 'Aproxime sua Tag NFC'}
        </h1>
        <p className="text-xl text-gray-400">Terminal de Check-in / Check-out</p>
      </div>

      <div className="bg-gray-800 p-6 rounded-2xl w-full max-w-md z-10 border border-gray-700 shadow-2xl">
        {showDuplicatePrompt && scanResult ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-4"
          >
            <h3 className="text-xl font-bold text-white mb-2">Tag NFC Vinculada Encontrada</h3>
            <p className="text-gray-300 text-sm mb-4">
              Notamos que você acessou via CPF e já possui uma tag gravada.
              <br/><br/>
              Deseja gravar uma <strong>segunda via</strong> da sua tag/crachá?
            </p>

            <div className="mt-4 p-4 bg-gray-900 border border-gray-600 rounded-lg">
              <label className="block text-sm font-medium text-gray-400 mb-2">Simulação: Encoste a nova Tag NFC</label>
              <input 
                type="text" 
                value={duplicateTagInput} 
                onChange={e => setDuplicateTagInput(e.target.value)} 
                className="w-full px-4 py-3 bg-gray-800 border border-emerald-500/50 rounded-lg text-white focus:ring-emerald-500 focus:border-emerald-500 mb-4" 
                placeholder="TagExemplo123" 
              />
              <button 
                onClick={handleWriteDuplicate} 
                disabled={loading}
                className="w-full bg-emerald-600 text-white py-3 rounded-lg font-bold hover:bg-emerald-700 transition-colors disabled:opacity-50"
              >
                {loading ? 'Gravando...' : 'Gravar Segunda Via'}
              </button>
            </div>

            <button onClick={resetTerminal} className="w-full text-center text-sm font-bold text-gray-400 hover:text-white py-2">
              Não gravar
            </button>
          </motion.div>
        ) : isWritingTagMode ? (
          <div className="space-y-4">
            {writeTagStep === 'request_cpf' ? (
              <form onSubmit={verifyCpfForWrite} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Passo 1: Qual o CPF do usuário?</label>
                  <input 
                    type="text" 
                    value={cpfForWrite} 
                    onChange={e => setCpfForWrite(e.target.value)} 
                    className="w-full px-4 py-3 bg-gray-900 border border-indigo-500/50 rounded-lg text-white focus:ring-indigo-500 focus:border-indigo-500" 
                    placeholder="000.000.000-00" 
                    required
                  />
                </div>
                <button type="submit" disabled={loading} className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold hover:bg-indigo-700 transition-colors disabled:opacity-50">
                  {loading ? 'Buscando...' : 'Avançar'}
                </button>
                <button type="button" onClick={resetTerminal} className="w-full text-center text-sm text-gray-500 hover:text-white py-2">Cancelar</button>
              </form>
            ) : (
              <div className="text-center">
                <h3 className="text-xl font-bold text-white mb-2">Usuário Encontrado: {userForWrite?.first_name}</h3>
                <p className="text-indigo-400 mb-6">Agora, aproxime a Tag NFC virgem ou desativada no sensor (traseira do celular).</p>
                <div className="flex flex-col gap-2">
                   {message && <div className="p-3 bg-gray-900 border border-gray-700 rounded-lg text-sm text-center font-medium text-amber-400">{message}</div>}
                   <button onClick={resetTerminal} className="w-full text-center text-sm font-bold text-gray-500 hover:text-white py-2 mt-4">Cancelar Gravação</button>
                </div>
              </div>
            )}
          </div>
        ) : !scanResult ? (
          <div className="space-y-4">
            <form onSubmit={handleScan} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Simulação: Digite o CPF ou Tag do crachá</label>
                <input 
                  type="text" 
                  value={cpfInput} 
                  onChange={e => setCpfInput(e.target.value)} 
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-600 rounded-lg text-white focus:ring-emerald-500 focus:border-emerald-500" 
                  placeholder="000.000.000-00 ou TagExemplo123" 
                />
              </div>
              <button type="submit" disabled={loading} className="w-full bg-emerald-600 text-white py-3 rounded-lg font-bold hover:bg-emerald-700 transition-colors disabled:opacity-50">
                {loading ? 'Lendo...' : 'Simular Leitura NFC'}
              </button>
            </form>
            <div className="pt-4 border-t border-gray-700 mt-4 space-y-3">
               <button type="button" onClick={startContinuousWebNFC} className="w-full bg-emerald-900/40 border border-emerald-500/30 text-emerald-400 py-3 rounded-lg font-bold hover:bg-emerald-800 transition-colors">
                 Ativar Leitor Web NFC Contínuo
               </button>
               <button type="button" onClick={handleStartWriteFlow} className="w-full bg-gray-800 border border-indigo-500/30 text-indigo-400 py-3 rounded-lg font-bold hover:bg-gray-700 transition-colors">
                 Gravar nova tag NFC
               </button>
            </div>
          </div>
        ) : null}

        {message && !scanResult && !isWritingTagMode && !showDuplicatePrompt && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-4 bg-gray-900 border border-red-500/30 rounded-lg text-center text-red-200"
          >
            {message}
          </motion.div>
        )}

        {successMessage && !isWritingTagMode && !showDuplicatePrompt && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-4 bg-[#0d1e1c] border border-emerald-500/40 rounded-lg text-center text-emerald-300 font-bold"
          >
            {successMessage}
          </motion.div>
        )}

        {message && scanResult && !showDuplicatePrompt && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-4 bg-gray-900 border border-emerald-500/30 rounded-lg text-center text-emerald-200"
          >
            {message}
          </motion.div>
        )}

        {!showDuplicatePrompt && scanResult && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-6 p-6 bg-gray-900 border border-emerald-500/30 rounded-xl"
          >
            <h3 className="text-lg font-bold text-white mb-1">{scanResult.user.first_name} {scanResult.user.last_name}</h3>
            <p className="text-sm text-gray-400 mb-4 capitalize">Perfil: {scanResult.user.role === 'worker' ? 'Trabalhador' : 'Assistido'}</p>

            {/* Worker Views */}
            {scanResult.user.role === 'worker' && scanResult.action === 'worker_clocked_in' && (
              <div className="flex flex-col items-center gap-3 text-emerald-400 bg-emerald-400/10 p-4 rounded-lg text-center">
                <CheckCircle className="w-8 h-8" />
                <span className="font-bold">Ponto Registrado com Sucesso!</span>
                <span className="text-sm">Passe o crachá novamente caso deseje iniciar atendimentos já.</span>
              </div>
            )}

            {scanResult.user.role === 'worker' && scanResult.action === 'worker_attendance_finished' && (
              <div className="flex flex-col items-center gap-3 text-indigo-400 bg-indigo-400/10 p-4 rounded-lg text-center">
                <CheckCircle className="w-8 h-8" />
                <span className="font-bold">Atendimento Finalizado!</span>
                {scanResult.nextAttendanceScheduled && (
                  <span className="text-sm font-semibold text-emerald-400">O assistido foi encaminhado para a próxima assistência da trilha.</span>
                )}
                <span className="text-sm border-t border-indigo-400/20 pt-2 mt-2 w-full">Passe o crachá novamente para ficar disponível e chamar o próximo assistido.</span>
              </div>
            )}

            {scanResult.user.role === 'worker' && scanResult.action === 'worker_prompt_status' && (
              <div className="space-y-4 text-left">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Qual atendimento você fará agora?</label>
                  <select 
                    value={selectedType} 
                    onChange={e => setSelectedType(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white"
                  >
                    {assistanceTypes.map(t => (
                      <option key={t.id} value={t.name}>{t.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1 text-left">Número da Sala de Atendimento</label>
                  <input 
                    type="text"
                    value={roomNumberInput}
                    onChange={e => setRoomNumberInput(e.target.value)}
                    placeholder="Ex: Sala 1, Sala 2 ou 103"
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white font-mono font-bold"
                  />
                </div>
                <div className="flex flex-col gap-2 mt-4">
                  <button onClick={() => handleWorkerStatus('available')} className="w-full bg-emerald-600 text-white py-2 rounded-lg font-bold hover:bg-emerald-700">
                    Estou Disponível (Chamar Próximo)
                  </button>
                  <button onClick={() => handleWorkerStatus('break')} className="w-full bg-amber-600 text-white py-2 rounded-lg font-bold hover:bg-amber-700">
                    Sair para Intervalo
                  </button>
                  <button onClick={() => handleWorkerStatus('offline', true)} className="w-full bg-red-600 text-white py-2 rounded-lg font-bold hover:bg-red-700">
                    Encerrar Expediente (Check-out)
                  </button>
                </div>
              </div>
            )}

            {/* Assisted Views */}
            {scanResult.user.role === 'assisted' && scanResult.action === 'assisted_prompt_checkin' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Selecione o Atendimento</label>
                  <select 
                    value={selectedType} 
                    onChange={e => setSelectedType(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white"
                  >
                    {assistanceTypes.map(t => (
                      <option key={t.id} value={t.name}>{t.name}</option>
                    ))}
                  </select>
                </div>
                <button onClick={handleCheckIn} className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold hover:bg-indigo-700">
                  Confirmar Check-in na Fila
                </button>
              </div>
            )}

            {scanResult.user.role === 'assisted' && scanResult.action === 'assisted_already_in_queue' && (
              <div className="flex flex-col items-center gap-3 text-amber-400 bg-amber-400/10 p-4 rounded-lg text-center">
                <CheckCircle className="w-8 h-8" />
                <span className="font-bold">Aguarde sua vez!</span>
                <span className="text-sm">Você está na fila para "{scanResult.attendance.type}" (Senha: {scanResult.attendance.ticket_number}).</span>
              </div>
            )}

            {scanResult.user.role === 'assisted' && scanResult.action === 'assisted_started_attendance' && (
              <div className="flex flex-col items-center gap-3 text-emerald-400 bg-emerald-400/10 p-4 rounded-lg text-center">
                <CheckCircle className="w-8 h-8" />
                <span className="font-bold">Atendimento Confirmado!</span>
                <span className="text-sm">Você iniciou o atendimento. Pode entrar na sala.</span>
              </div>
            )}

            {scanResult.user.role === 'assisted' && scanResult.action === 'assisted_already_in_progress' && (
              <div className="flex flex-col items-center gap-3 text-indigo-400 bg-indigo-400/10 p-4 rounded-lg text-center">
                <CheckCircle className="w-8 h-8" />
                <span className="font-bold">Em Atendimento</span>
                <span className="text-sm">Seu atendimento já está ocorrendo neste momento.</span>
              </div>
            )}

            <button onClick={resetTerminal} className="mt-4 w-full text-center text-sm text-gray-500 hover:text-white">
              Cancelar
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
