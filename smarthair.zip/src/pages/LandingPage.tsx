import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Calendar, Star, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Logo from '../components/Logo';

const slides = [
  {
    id: 1,
    title: "Conexão Capilar Quântica",
    subtitle: "Inovação & Sinergia",
    description: "O futuro da beleza está aqui. Agende seu horário com inteligência e energia. Alinhamos precisão quântica no estilo e bem-estar para otimizar sua energia capilar.",
    image: "/logo-HSM.jpg",
    features: ["Agendamento em Tempo-Real", "Alinhamento Sincronizado", "Garantia de Fluxo Fluido"]
  },
  {
    id: 2,
    title: "Sinergia de Estilo e Alta Tecnologia",
    subtitle: "Simetria Atômica",
    description: "Combinamos tendências estéticas lendárias com agilidade algorítmica para proporcionar um visual sob medida de alta performance.",
    image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=1200",
    features: ["Salões Elite Quantum", "Lembretes Magnéticos", "Catálogo Multidimensional"]
  },
  {
    id: 3,
    title: "Bem-estar Magnético e Vitalidade",
    subtitle: "Equilíbrio em Fluxo",
    description: "Desperte a energia vital do seu corpo. Experimente tratamentos estéticos inovadores e tecnológicos para harmonizar o seu dia a dia.",
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&q=80&w=1200",
    features: ["Espaço de Alta Frequência", "Tratamentos Avançados", "Experiência Fluida"]
  },
  {
    id: 4,
    title: "Gestão Corporativa Inteligente",
    subtitle: "Smart Matrix Business",
    description: "O ecossistema definitivo para gerenciar sua equipe, automatizar split de pagamentos e impulsionar a órbita de clientes.",
    image: "https://images.unsplash.com/photo-1556761175-5973dc0f32d7?auto=format&fit=crop&q=80&w=1200",
    features: ["Dashboard Analítico", "Divisão de Contas Instantânea", "Controle de Escalas"]
  }
];

export default function LandingPage() {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 10000); // 10 seconds interval
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans overflow-x-hidden energy-grid">
      {/* Header */}
      <header className="flex items-center justify-between p-6 max-w-7xl mx-auto absolute top-0 left-0 right-0 z-20">
        <div className="flex items-center gap-2 text-2xl font-bold tracking-tight text-white drop-shadow-[0_0_15px_rgba(0,210,255,0.6)]">
          <Logo className="w-10 h-10 quantum-animate-pulse" />
          <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-orange-400 bg-clip-text text-transparent">Hair Smart Mall</span>
        </div>
        <div className="flex gap-4">
          <Link to="/login/client" className="px-4 py-2 text-sm font-semibold text-white/90 hover:text-cyan-400 transition-colors drop-shadow-md">
            Sou Cliente
          </Link>
          <Link to="/login/salon" className="px-5 py-2.5 text-sm font-bold bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 rounded-xl transition-all duration-300 shadow-[0_0_20px_rgba(0,210,255,0.3)] hover:shadow-[0_0_25px_rgba(13,245,196,0.6)] transform hover:-translate-y-0.5">
            Sou Profissional
          </Link>
        </div>
      </header>

      {/* Hero Carousel Section */}
      <main className="relative w-full h-[600px] md:h-[700px] bg-slate-900 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
          >
            <img 
              src={slides[currentSlide].image} 
              alt={slides[currentSlide].title} 
              className={`w-full h-full opacity-50 ${currentSlide === 0 ? 'object-contain max-h-[80%] mx-auto mt-10' : 'object-cover'}`}
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent flex items-center">
              <div className="max-w-7xl mx-auto px-6 w-full pt-20">
                <div className="max-w-2xl text-white">
                  <motion.span 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="inline-block px-4 py-1 bg-cyan-600 rounded-full text-sm font-medium mb-4"
                  >
                    {slides[currentSlide].subtitle}
                  </motion.span>
                  <motion.h1 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="text-4xl md:text-6xl font-bold leading-tight mb-6"
                  >
                    {slides[currentSlide].title}
                  </motion.h1>
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 }}
                    className="text-lg md:text-xl text-slate-200 mb-8"
                  >
                    {slides[currentSlide].description}
                  </motion.p>
                  
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.9 }}
                    className="flex flex-col sm:flex-row gap-4 mb-8"
                  >
                    {slides[currentSlide].features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm font-medium text-slate-300">
                        <CheckCircle className="w-5 h-5 text-cyan-500" />
                        {feature}
                      </div>
                    ))}
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.1 }}
                  >
                    <Link to="/login/client" className="inline-flex items-center gap-2 px-8 py-4 bg-cyan-600 text-white rounded-xl font-bold hover:bg-cyan-500 transition-colors text-lg shadow-lg">
                      <Calendar className="w-6 h-6" />
                      Agendar Agora
                    </Link>
                  </motion.div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Carousel Controls */}
        <div className="absolute bottom-8 left-0 right-0 flex justify-center gap-3 z-10">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-3 rounded-full transition-all ${
                idx === currentSlide ? 'bg-cyan-500 w-10' : 'bg-white/50 hover:bg-white w-3'
              }`}
              aria-label={`Ir para o slide ${idx + 1}`}
            />
          ))}
        </div>
      </main>

      {/* Benefits */}
      <section className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <h2 className="text-4xl font-extrabold text-center mb-16 tracking-tight">
            Por que usar o <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-orange-400 bg-clip-text text-transparent">Hair Smart Mall</span>?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="quantum-card p-8 rounded-2xl">
              <div className="w-14 h-14 bg-gradient-to-br from-cyan-550 to-cyan-400 text-slate-950 rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(0,210,255,0.4)]">
                <Calendar className="w-7 h-7 text-slate-950" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-cyan-300">Agendamento Inteligente</h3>
              <p className="text-slate-300 text-sm leading-relaxed">Sincronização em tempo real de horários e profissionais que se encaixam na sua rotina, 24 horas por dia.</p>
            </div>
            <div className="quantum-card p-8 rounded-2xl border-teal-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-teal-400 to-teal-500 text-slate-950 rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(13,245,196,0.4)]">
                <CheckCircle className="w-7 h-7 text-slate-950" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-teal-300">Gestão de Alta Performance</h3>
              <p className="text-slate-300 text-sm leading-relaxed">Para profissionais: controle total de escalas multidimensionais, split de fluxo financeiro inteligente e controle de equipe.</p>
            </div>
            <div className="quantum-card p-8 rounded-2xl border-orange-500/10">
              <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-orange-600 text-slate-950 rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(255,107,0,0.4)]">
                <Logo className="w-8 h-8" variant="dark" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-orange-400">Atendimento Conectado</h3>
              <p className="text-slate-300 text-sm leading-relaxed">Encontre e acesse locais exclusivos de alta tecnologia estética na sua região com integração instantânea.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-white font-bold text-lg">
            <Logo className="w-8 h-8" />
            Hair Smart Mall
          </div>
          <p className="text-xs text-slate-400">© 2026 Hair Smart Mall. Todos os direitos reservados.</p>
          <button 
            onClick={() => {
              const userData = localStorage.getItem('user');
              if (userData) {
                try {
                  const parsedUser = JSON.parse(userData);
                  if (parsedUser.role === 'superadmin') {
                    navigate('/dashboard/admin');
                    return;
                  }
                } catch (e) {}
              }
              navigate('/login/superadmin');
            }}
            className="text-xs font-semibold text-slate-300 hover:text-cyan-400 transition-colors bg-slate-950 hover:bg-slate-800 px-4 py-2 rounded-xl border border-slate-800 flex items-center gap-2 shadow-lg"
          >
            🔐 Área Restrita
          </button>
        </div>
      </footer>
    </div>
  );
}
