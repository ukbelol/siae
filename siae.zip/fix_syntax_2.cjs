const fs = require('fs');
let t = fs.readFileSync('src/api/index.ts', 'utf8');

// Undo the transaction break for `});\n\n`
t = t.replace(/\} catch\(e\) \{ await conn\.rollback\(\); throw e; \} finally \{ conn\.release\(\); \} \};/g, "});");

// Now let's fix transaction blocks manually.
t = t.replace(/const (\w+) = async \((.*?)\) => \{ const conn = await db\.getConnection\(\); await conn\.beginTransaction\(\); try \{/g, `const $1 = async ($2) => {
  const conn = await db.getConnection();
  await conn.beginTransaction();
  try {
`);

// The user transactions were mostly `db.transaction(...)`
// So I will just add the try catch manually by searching for them.
// Let's just write to file and check errors.
fs.writeFileSync('src/api/index.ts', t);
