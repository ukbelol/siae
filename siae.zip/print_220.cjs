const fs = require('fs');

let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

for (let i = 220; i < 235; i++) console.log(i+1, lines[i]);
