import React, { useState, useEffect, useRef } from 'react';
import {
  Cpu,
  Layers,
  Sparkles,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  Play,
  Pause,
  Compass,
  Lightbulb,
  CheckCircle,
  Clock,
  ShieldAlert,
  Terminal,
} from 'lucide-react';

interface Slide {
  id: number;
  label: string;
  title: string;
  subtitle: string;
  description: string;
  epistemologyTitle: string;
  epistemologyDesc: string;
  badge: string;
  badgeColor: string;
  icon: React.ReactNode;
  schematic: React.ReactNode;
}

export const MethodologySlideshow: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const autoPlayTimer = useRef<NodeJS.Timeout | null>(null);
  const progressTimer = useRef<NodeJS.Timeout | null>(null);

  const slides: Slide[] = [
    {
      id: 0,
      label: '01. VISÃO GERAL',
      title: 'A Revolução Epistemológica do Conhecimento',
      subtitle: 'GOITGODS 2.1 — Pesquisa Avançada e Geração de E-Books Sem Ruídos',
      description: 'GOITGODS é um ecossistema cognitivo pioneiro projetado para responder a um dos maiores desafios da era da Inteligência Artificial: as alucinações de dados e a fragmentação acadêmica. Combinando agentes especialistas altamente treinados com uma esteira de validação em camadas, o sistema transforma consultas genéricas em tomos literários densos, precisos e prontos para publicação.',
      epistemologyTitle: 'Objetivo Epistêmico Principal',
      epistemologyDesc: 'Garantir que a produção intelectual gerada por inteligência artificial tenha o mesmo rigor, validação bibliográfica e encadeamento lógico de uma obra acadêmica de alto nível.',
      badge: 'Cognição Confiável',
      badgeColor: 'border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10',
      icon: <Sparkles className="w-5 h-5" />,
      schematic: (
        <div className="w-full h-full flex flex-col justify-center items-center p-4 font-mono text-[10px] space-y-4">
          <div className="flex items-center space-x-2 border border-[#333333] bg-[#0A0A0A] px-3 py-1.5 rounded text-white">
            <Terminal className="w-3.5 h-3.5 text-[#FF3E00]" />
            <span>Entrada de Pesquisa</span>
          </div>
          <div className="text-[#888888] animate-bounce">↓</div>
          <div className="border-2 border-dashed border-[#FF3E00] bg-[#111111] p-3 text-center rounded w-full max-w-[240px]">
            <span className="text-white font-bold block">Filtro de Ruído</span>
            <span className="text-[#666666] text-[9px]">Eliminação de Heurísticas</span>
          </div>
          <div className="text-[#888888]">↓</div>
          <div className="flex items-center space-x-2 border border-[#00FF41] bg-[#00FF41]/10 px-3 py-1.5 rounded text-[#00FF41]">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>E-Book Acadêmico Pronto</span>
          </div>
        </div>
      ),
    },
    {
      id: 1,
      label: '02. O KERNEL DE VERDADE',
      title: 'PASQUARED-OS: O Núcleo de Rigor Factológico',
      subtitle: 'Arbitragem de Fatos com o Protocolo PFA',
      description: 'O PASQUARED-OS funciona como o kernel (sistema operacional interno) de controle e consistência lógica. Sua principal ferramenta é o PFA (Primal Fact Arbitration), que analisa as proposições conceituais em tempo de execução, cruzando referências cruzadas em múltiplas fontes e rejeitando suposições não comprovadas.',
      epistemologyTitle: 'Atribuição Epistemológica',
      epistemologyDesc: 'O PASQUARED-OS estabelece as regras de verdade e justificação. Ele atua sob o princípio do fundacionalismo crítico: nenhuma verdade sintética é adicionada à obra sem uma raiz probatória devidamente fundamentada.',
      badge: 'Kernel de Validação',
      badgeColor: 'border-amber-500 text-amber-500 bg-amber-500/10',
      icon: <Cpu className="w-5 h-5" />,
      schematic: (
        <div className="w-full h-full flex flex-col justify-center items-center p-4 font-mono text-[9px] space-y-3">
          <div className="bg-[#111] border border-[#222] p-2 text-center rounded w-full">
            <span className="text-[#888] block">Fato Candidato</span>
            <span className="text-white">&quot;Dada Proposição X&quot;</span>
          </div>
          <div className="flex items-center justify-between w-full px-2 text-[#888]">
            <span>[Falso?]</span>
            <span>[Verdade?]</span>
          </div>
          <div className="grid grid-cols-2 gap-2 w-full">
            <div className="border border-red-900 bg-red-950/20 p-1.5 text-center rounded text-red-500">
              Descartar e Registrar Auditoria
            </div>
            <div className="border border-[#00FF41] bg-[#00FF41]/10 p-1.5 text-center rounded text-[#00FF41]">
              Sincronizar com Banco de Dados
            </div>
          </div>
        </div>
      ),
    },
    {
      id: 2,
      label: '03. CONSELHO DE AGENTES',
      title: 'A Rede de Especialistas GOITGODS',
      subtitle: 'Dialética Multi-Agente e Consiliência Acadêmica',
      description: 'Em vez de confiar em uma única rede neural que tenta responder sobre tudo, o GOITGODS aciona o Conselho de Olympus: agentes especializados simulados que debatem criticamente entre si. Temos especialistas em Filosofia, História Comparada, Análise Econômica, Engenharia e Métodos Científicos trabalhando em sinergia.',
      epistemologyTitle: 'Atribuição Epistemológica',
      epistemologyDesc: 'Baseado na Dialética de Hegel e no conceito de Consiliência de E.O. Wilson: o conhecimento definitivo surge da fricção e síntese de visões disciplinares opostas e complementares.',
      badge: 'Multidisciplinaridade',
      badgeColor: 'border-[#FF3E00] text-[#FF3E00] bg-[#FF3E00]/10',
      icon: <Layers className="w-5 h-5" />,
      schematic: (
        <div className="w-full h-full flex flex-col justify-center items-center p-4 font-mono text-[9px] space-y-2">
          <span className="text-[#888] text-[8px] uppercase font-bold">Conselho de Olympus</span>
          <div className="grid grid-cols-2 gap-1.5 w-full">
            <div className="border border-[#333] bg-[#111] p-1.5 text-center rounded text-amber-400">
              🏛️ Clio (História)
            </div>
            <div className="border border-[#333] bg-[#111] p-1.5 text-center rounded text-cyan-400">
              🔬 Athena (Ciência)
            </div>
            <div className="border border-[#333] bg-[#111] p-1.5 text-center rounded text-purple-400">
              ⚖️ Aristóteles (Física)
            </div>
            <div className="border border-[#333] bg-[#111] p-1.5 text-center rounded text-emerald-400">
              ✍️ Hermes (Narrativa)
            </div>
          </div>
          <div className="w-full bg-[#1A1A1A] border border-[#222] p-1.5 rounded text-center text-white mt-1">
            Síntese Crítica Consensual
          </div>
        </div>
      ),
    },
    {
      id: 3,
      label: '04. FLUXO METODOLÓGICO',
      title: 'A Linha de Montagem de Livros Inteligentes',
      subtitle: 'Do vetor cognitivo à indexação de evidências',
      description: 'Como uma obra ganha vida no ecossistema? Primeiramente, o usuário define as premissas no painel PFA. Em seguida, o subsistema CHRONOS mapeia causas e sequências temporais. O Conselho GOITGODS debate os tópicos e redige o conteúdo. Por fim, o manuscrito é gerado com indexação de citações e auditoria de segurança completa.',
      epistemologyTitle: 'Atribuição Epistemológica',
      epistemologyDesc: 'Combinação indissociável de Historiografia Sistemática (estruturação precisa do tempo) e Estruturalismo Conceitual (divisão em capítulos hierárquicos e densos).',
      badge: 'Processamento em Fluxo',
      badgeColor: 'border-blue-400 text-blue-400 bg-blue-400/10',
      icon: <Clock className="w-5 h-5" />,
      schematic: (
        <div className="w-full h-full flex flex-col justify-center font-mono text-[9px] p-2 space-y-1.5">
          <div className="flex items-center justify-between border border-[#222] bg-[#111] px-2 py-1 rounded">
            <span className="text-[#888]">PASSO 1:</span>
            <span className="text-white font-bold">Vetor Cognitivo PFA</span>
          </div>
          <div className="flex items-center justify-between border border-[#222] bg-[#111] px-2 py-1 rounded">
            <span className="text-[#888]">PASSO 2:</span>
            <span className="text-white font-bold">Investigação CHRONOS</span>
          </div>
          <div className="flex items-center justify-between border border-[#222] bg-[#111] px-2 py-1 rounded">
            <span className="text-[#888]">PASSO 3:</span>
            <span className="text-[#00FF41] font-bold">Validação de Fontes</span>
          </div>
          <div className="flex items-center justify-between border border-[#222] bg-[#111] px-2 py-1 rounded">
            <span className="text-[#888]">PASSO 4:</span>
            <span className="text-[#FF3E00] font-bold">Geração de E-Book Completo</span>
          </div>
        </div>
      ),
    },
    {
      id: 4,
      label: '05. OBJETIVOS E METAS',
      title: 'Nossos Compromissos e Horizontes de IA',
      subtitle: 'Preservando a herança cultural humana através da tecnologia',
      description: 'O objetivo final do GOITGODS e do PASQUARED-OS é disponibilizar uma ferramenta que permita a qualquer pesquisador, estudante ou profissional, sintetizar conhecimento profundo em velocidades industriais sem sacrificar a honestidade intelectual. Cada e-book gerado torna-se um ativo durável guardado localmente e sincronizado na nuvem.',
      epistemologyTitle: 'Visão de Futuro',
      epistemologyDesc: 'Democratizar o acesso a métodos avançados de pesquisa de elite, unindo o melhor da automação algorítmica moderna à insubstituível tradição acadêmica e filosófica.',
      badge: 'Horizonte Evolutivo',
      badgeColor: 'border-purple-500 text-purple-500 bg-purple-500/10',
      icon: <Compass className="w-5 h-5" />,
      schematic: (
        <div className="w-full h-full flex flex-col justify-center items-center p-4 font-mono text-center space-y-3">
          <div className="w-10 h-10 border border-purple-500 bg-purple-500/10 flex items-center justify-center text-purple-400 rounded-full">
            <Lightbulb className="w-5 h-5" />
          </div>
          <p className="text-[10px] text-gray-300">
            &quot;A síntese perfeita entre a automação contemporânea e o rigor tradicional.&quot;
          </p>
          <span className="text-[8px] text-[#666666] uppercase">GOITGODS v2.1</span>
        </div>
      ),
    },
  ];

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    setProgress(0);
  };

  useEffect(() => {
    if (isPlaying) {
      // Auto play slide shift calibrated to an extended 22 seconds for slow/easy reading
      autoPlayTimer.current = setInterval(() => {
        handleNext();
      }, 22000);

      // Smooth progress bar update every 220ms (220ms * 100 = 22000ms)
      progressTimer.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) return 0;
          return prev + 1;
        });
      }, 220);
    } else {
      if (autoPlayTimer.current) clearInterval(autoPlayTimer.current);
      if (progressTimer.current) clearInterval(progressTimer.current);
    }

    return () => {
      if (autoPlayTimer.current) clearInterval(autoPlayTimer.current);
      if (progressTimer.current) clearInterval(progressTimer.current);
    };
  }, [isPlaying, currentSlide]);

  const slide = slides[currentSlide];

  return (
    <div className="bg-[#0D0D0D] border border-[#222222] p-5 sm:p-8 relative shadow-xl overflow-hidden">
      {/* Absolute background accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF3E00]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#00FF41]/5 rounded-full blur-3xl pointer-events-none" />

      {/* Slide Header area */}
      <div className="flex items-center justify-between border-b border-[#222222] pb-4 mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 border border-[#222222] bg-[#0A0A0A] flex items-center justify-center text-[#FF3E00]">
            {slide.icon}
          </div>
          <div>
            <span className="text-[10px] font-mono text-[#888888] font-bold block uppercase tracking-wider">
              {slide.label}
            </span>
            <span className="text-xs font-mono font-bold text-white uppercase tracking-tight">
              Metodologia de Sistema e Epistemologia
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Play/Pause Button */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-8 h-8 border border-[#222222] bg-[#0A0A0A] hover:bg-[#151515] text-gray-400 hover:text-white flex items-center justify-center transition-all"
            title={isPlaying ? 'Pausar Apresentação Automática' : 'Iniciar Apresentação Automática'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          {/* Navigation Controls */}
          <button
            onClick={handlePrev}
            className="w-8 h-8 border border-[#222222] bg-[#0A0A0A] hover:bg-[#151515] text-gray-400 hover:text-white flex items-center justify-center transition-all"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleNext}
            className="w-8 h-8 border border-[#222222] bg-[#0A0A0A] hover:bg-[#151515] text-gray-400 hover:text-white flex items-center justify-center transition-all"
          >
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Slide Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 items-stretch">
        {/* Texts details - takes 2 cols on wide screens */}
        <div className="lg:col-span-2 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="inline-block">
              <span className={`px-2.5 py-0.5 border text-[9px] font-mono font-black uppercase ${slide.badgeColor}`}>
                {slide.badge}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-white leading-tight uppercase">
              {slide.title}
            </h2>
            <p className="text-xs sm:text-sm text-[#FF3E00] font-mono font-bold">
              {slide.subtitle}
            </p>
            <p className="text-xs text-gray-300 leading-relaxed font-sans">
              {slide.description}
            </p>
          </div>

          {/* Epistemological focus box */}
          <div className="border border-[#222222] bg-[#080808] p-4 space-y-1">
            <span className="text-[9px] font-mono font-black text-[#00FF41] uppercase tracking-widest block">
              💡 {slide.epistemologyTitle}
            </span>
            <p className="text-xs text-gray-400 font-sans leading-normal">
              {slide.epistemologyDesc}
            </p>
          </div>
        </div>

        {/* Interactive Schematic Diagram - takes 1 col */}
        <div className="border border-[#222222] bg-[#0A0A0A] relative overflow-hidden flex flex-col justify-between p-4 min-h-[220px]">
          {/* Decorative Corner matrix */}
          <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-[#444444]" />
          <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-[#444444]" />
          <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-[#444444]" />
          <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-[#444444]" />

          <div className="text-[9px] font-mono text-[#555555] uppercase font-bold text-center border-b border-[#1A1A1A] pb-2">
            Esquema Técnico Epistêmico
          </div>

          <div className="flex-1 flex items-center justify-center">
            {slide.schematic}
          </div>

          <div className="text-[8px] font-mono text-[#444444] text-center border-t border-[#1A1A1A] pt-2">
            PASQUARED-OS KNOWLEDGE KERNEL
          </div>
        </div>
      </div>

      {/* Progress timeline dots & bar */}
      <div className="mt-6 flex items-center justify-between gap-4">
        {/* Timeline dots indicator */}
        <div className="flex items-center space-x-2">
          {slides.map((s, idx) => (
            <button
              key={s.id}
              onClick={() => {
                setCurrentSlide(idx);
                setProgress(0);
              }}
              className={`px-2.5 py-1 text-[10px] font-mono font-bold transition-all border ${
                idx === currentSlide
                  ? 'bg-[#FF3E00] text-black border-[#FF3E00] font-black'
                  : 'bg-[#0A0A0A] text-gray-500 border-[#222222] hover:text-white hover:border-gray-500'
              }`}
            >
              {String(idx + 1).padStart(2, '0')}
            </button>
          ))}
        </div>

        {/* Progress bar timeline */}
        <div className="flex-1 h-1.5 bg-[#151515] border border-[#222222] relative">
          <div
            className="absolute left-0 top-0 h-full bg-[#FF3E00] transition-all duration-100 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>

        <span className="text-[9px] font-mono text-[#555555] tracking-widest uppercase shrink-0">
          Slide {currentSlide + 1} de {slides.length}
        </span>
      </div>
    </div>
  );
};
