const fs = require('fs');
let lines = fs.readFileSync('src/api/index.ts', 'utf8').split('\n');

// The issue at 1069 must be due to unmatched braces. 
// Let's print out the structure of `/terminal/identify` route.

// We will fix the IIFE transaction manually.
lines[1198] = "      // replacing db.transaction";
lines[1199] = "      for (const userId of participantIds) {";
lines[1200] = "         await db.query(insertParticipantCmd, [Number(info.insertId), userId]);";
lines[1201] = "      }";
lines[1202] = "      // end replace";

// We saw TS errors:
// src/api/index.ts(140,57): error TS1005: ')' expected. -> WE FIXED ALREADY!
// Let's write array to index.ts and run TS again to get exact errors.
fs.writeFileSync('src/api/index.ts', lines.join('\n'));
