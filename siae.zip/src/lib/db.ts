import mysql from 'mysql2/promise';
import Database from 'better-sqlite3';
import { schema } from './schema.js';

// Setup local SQLite fallback
let sqliteDb: Database.Database | null = null;
let useSqlite = false;

try {
  sqliteDb = new Database('./siae.db');
  console.log('Local SQLite backend initialized successfully.');
} catch (err: any) {
  console.error('Failed to initialize local SQLite fallback:', err.message);
}

export const db: any = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'siae_user',
  password: process.env.DB_PASSWORD || 'siae_password',
  database: process.env.DB_NAME || 'siae_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Handle ECONNREFUSED or other uncaught DB errors gracefully
db.on('error', (err: any) => {
  if (err.code === 'ECONNREFUSED') {
    if (!useSqlite) {
      console.log('MySQL connection failed (ECONNREFUSED). Falling back to SQLite backend.');
      useSqlite = true;
    }
  } else {
    console.error('MySQL Pool Error:', err);
  }
});

db.on('connection', (connection: any) => {
  connection.on('error', (err: any) => {
    if (err.code === 'ECONNREFUSED') {
      if (!useSqlite) {
        console.log('MySQL connection failed (ECONNREFUSED). Falling back to SQLite backend.');
        useSqlite = true;
      }
    } else {
      console.error('MySQL Connection Error:', err);
    }
  });
});

function translateQuery(sql: string): string {
  let translated = sql.trim();
  
  // Remove AUTO_INCREMENT since SQLite autoincrements INTEGER PRIMARY KEY automatically
  translated = translated.replace(/AUTO_INCREMENT/gi, '');
  
  // Replace INSERT IGNORE with INSERT OR IGNORE
  translated = translated.replace(/INSERT IGNORE/gi, 'INSERT OR IGNORE');
  
  // Translate system_settings ON DUPLICATE KEY UPDATE query
  if (/ON DUPLICATE KEY UPDATE/i.test(translated)) {
    translated = translated.replace(/ON DUPLICATE KEY UPDATE\s+value\s*=\s*\?/gi, 'ON CONFLICT(`key`) DO UPDATE SET value = excluded.value');
  }

  // Handle MariaDB backtick escapes for settings key column if needed
  translated = translated.replace(/`key`/g, '"key"');

  // Translate SUBDATE/DATE_SUB to SQLite datetime equivalent
  translated = translated.replace(/(SUBDATE|DATE_SUB)\(\s*CURRENT_TIMESTAMP\s*,\s*INTERVAL\s+(\d+)\s+SECOND\s*\)/gi, "datetime(CURRENT_TIMESTAMP, '-$2 seconds')");

  return translated;
}

const originalQuery = db.query.bind(db);
db.query = async function(...args: any[]) {
  const originalSql = args[0] || '';
  const params = args[1] || [];

  if (!useSqlite) {
    try {
      return await originalQuery(...args);
    } catch (e: any) {
      if (e.code === 'ECONNREFUSED') {
        useSqlite = true;
        console.log('MySQL connection failed during query. Falling back to SQLite backend.');
      } else {
        throw e;
      }
    }
  }

  // SQLite fallback path
  if (sqliteDb) {
    const translatedSql = translateQuery(originalSql);
    try {
      const isRead = /^(select|show|desc|pragma)/i.test(translatedSql);
      if (isRead) {
        const rows = sqliteDb.prepare(translatedSql).all(params);
        return [rows, []];
      } else {
        const result = sqliteDb.prepare(translatedSql).run(params);
        return [{ insertId: Number(result.lastInsertRowid), affectedRows: result.changes, changedRows: result.changes }, []];
      }
    } catch (err: any) {
      // Gracefully bypass structural alter modifications that fails on SQLite
      if (translatedSql.toLowerCase().startsWith('alter table')) {
        return [{ insertId: 0, affectedRows: 0 }, []];
      }
      console.error('SQLite query failed:', translatedSql, err.message);
      throw err;
    }
  }

  // Pure fallback mock if both fail
  const sql = (args[0] || '').toString().trim().toLowerCase();
  if (sql.startsWith('select')) {
    return [[], []] as any;
  }
  return [{ insertId: 1, affectedRows: 1, changedRows: 1 }, []] as any;
};

export async function initDb() {
  if (useSqlite && sqliteDb) {
    console.log('Initializing SQLite database schema...');
  }
  
  try {
    await db.query('ALTER TABLE nfc_tags MODIFY activation_date VARCHAR(50)');
    await db.query('ALTER TABLE nfc_tags MODIFY serial_number VARCHAR(60)');
    await db.query('ALTER TABLE users MODIFY nfc_tag VARCHAR(60)');
  } catch(e) {}

  const statements = schema.split(';').filter(s => s.trim().length > 0);
  for (const stmt of statements) {
    try {
      await db.query(stmt);
    } catch (e: any) {
      if (e.code !== 'ECONNREFUSED') console.error('Schema Error on statement:', stmt, e.message);
    }
  }

  // Basic alter tables, ignore if fail (already exist)
  try { await db.query('ALTER TABLE assistance_requests ADD COLUMN total_sessions INTEGER DEFAULT 1'); } catch (e) {}
  try { await db.query('ALTER TABLE assistance_requests ADD COLUMN completed_sessions INTEGER DEFAULT 0'); } catch (e) {}
  try { await db.query("ALTER TABLE assistance_types ADD COLUMN status TEXT DEFAULT 'active'"); } catch (e) {}
  try { await db.query("ALTER TABLE users ADD COLUMN religion TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE users ADD COLUMN age INTEGER"); } catch (e) {}
  try { await db.query("ALTER TABLE worker_sessions ADD COLUMN current_assistance_type TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE worker_sessions ADD COLUMN room_number TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE assistance_requests ADD COLUMN target_treatments TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE users ADD COLUMN recommendations TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE houses ADD COLUMN email TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE houses ADD COLUMN phone TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE houses ADD COLUMN cep TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN theme TEXT DEFAULT 'Escuro'"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN trueconf_link TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN trueconf_cid TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN mirotalk_link TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN mirotalk_room_id TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN openmeetings_link TEXT"); } catch (e) {}
  try { await db.query("ALTER TABLE conferences ADD COLUMN openmeetings_room_id TEXT"); } catch (e) {}
  
  try { await db.query("ALTER TABLE mercadopago_config ADD COLUMN enable_pix_qr_code INTEGER DEFAULT 1"); } catch (e) {}
  try { await db.query("ALTER TABLE mercadopago_config ADD COLUMN enable_pix_copia_cola INTEGER DEFAULT 1"); } catch (e) {}
  try { await db.query("ALTER TABLE mercadopago_config ADD COLUMN enable_card INTEGER DEFAULT 1"); } catch (e) {}
  try { await db.query("ALTER TABLE mercadopago_config ADD COLUMN max_qty_per_order INTEGER DEFAULT 10"); } catch (e) {}
  try { await db.query("ALTER TABLE mercadopago_config ADD COLUMN unit_price DECIMAL(10,2) DEFAULT 15.00"); } catch (e) {}

  // New columns for worker sessions, online presence, and ticket calling limits/TTS
  try { await db.query("ALTER TABLE house_workers ADD COLUMN queue_enabled INTEGER DEFAULT 0"); } catch (e) {}
  try { await db.query("ALTER TABLE users ADD COLUMN online_status VARCHAR(20) DEFAULT 'offline'"); } catch (e) {}
  try { await db.query("ALTER TABLE users ADD COLUMN last_seen_at DATETIME DEFAULT CURRENT_TIMESTAMP"); } catch (e) {}
  try { await db.query("ALTER TABLE attendances ADD COLUMN called_at DATETIME"); } catch (e) {}
  try { await db.query("ALTER TABLE attendances ADD COLUMN call_count INTEGER DEFAULT 0"); } catch (e) {}

  try { await db.query("ALTER TABLE users ADD COLUMN force_password_change TINYINT(1) DEFAULT 0"); } catch (e) {}
  try { await db.query("ALTER TABLE houses ADD COLUMN status TEXT DEFAULT 'active'"); } catch (e) {}
  try { await db.query("ALTER TABLE users ADD COLUMN status TEXT DEFAULT 'active'"); } catch (e) {}

  try {
    const defaultPassword = '21490905@Siae-577';
    const bcrypt = await import('bcryptjs');
    const hashedPassword = await bcrypt.hash(defaultPassword, 10);
    const existingOld = await db.query("SELECT * FROM users WHERE email = 'admin@appa.siae.space'");
    if ((existingOld[0] as any[]).length === 0) {
      await db.query(`INSERT INTO users (role, email, password, first_name, last_name, cpf, dob, force_password_change) VALUES ('super_admin', 'admin@appa.siae.space', ?, 'Super', 'Admin', '00000000001', '1990-01-01', 0)`, [hashedPassword]);
    } else {
      await db.query(`UPDATE users SET force_password_change = 0, password = ?, role = 'super_admin' WHERE email = 'admin@appa.siae.space'`, [hashedPassword]);
    }
  } catch(e) { console.error(e); }

  try {
    const existingProducts = await db.query("SELECT * FROM products WHERE name LIKE '%Chaveiro%'");
    if ((existingProducts[0] as any[]).length === 0) {
      await db.query(`INSERT INTO products (name, description, price, stock, image_url, status) VALUES ('Chaveiro NFC SIAE', 'Chaveiro de plástico com etiqueta eletrônica e tecnologia NFC para acesso instantâneo às filas de assistência espiritual sem celular.', 15.00, 100, '/chaveiro-siae.png', 'active')`);
    }
  } catch(e) { console.error(e); }

  console.log('Database initialized successfully.');
}
