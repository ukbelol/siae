# Chamasso v2.3.0 — Galeria social, fotos de perfil/capa e nickname

- Corrige os controles de edição da foto de capa e da foto de perfil.
- Todos os seletores de foto do perfil social agora permitem upload do dispositivo ou escolha de uma imagem existente na galeria.
- Todo upload de foto feito para perfil/capa é automaticamente incluído na galeria.
- Galeria aceita imagens PNG/JPG/JPEG/GIF/WEBP e vídeos MP4, identifica FOTO/VÍDEO, permite download e exclusão.
- Limite compartilhado da galeria: 200 MB por usuário; limite por arquivo: 33 MB.
- Mídias ficam em `/var/lib/chamasso/user-media`, fora da árvore da aplicação, e são incluídas nas imagens de recuperação/Azure Blob.
- Nickname ampliado de 8 para 16 caracteres no frontend e backend.
- Nickname aceita letras com acentos do alfabeto usado em português, números 0–9 e `.`, `_`, `-`.
- Fluxo do formulário de nickname mantém `preventDefault` e botões auxiliares explicitamente não submetem o formulário.
