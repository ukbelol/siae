import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Sliders, 
  Activity, 
  Key, 
  Database, 
  Layers, 
  Terminal, 
  Cpu, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw,
  Server,
  Plus,
  Power,
  RotateCw,
  Zap,
  Check,
  X,
  Radio,
  Globe,
  Gauge,
  HardDrive,
  Trash2,
  Smartphone,
  QrCode,
  Copy,
  Lock,
  Unlock,
  ShieldAlert
} from 'lucide-react';
import { SuperAdminUser } from '../types';

interface SuperAdminViewProps {
  adminUser: SuperAdminUser;
}

interface DatabaseConnection {
  id: string;
  name: string;
  type: string;
  endpoint: string;
  status: 'Active' | 'Inactive';
  lastSync: string;
  recordsCount: number;
  isSyncing?: boolean;
}

interface ClusterNode {
  id: string;
  name: string;
  godNamespace: string;
  role: string;
  replicas: number;
  maxReplicas: number;
  status: 'Healthy' | 'Warning' | 'Restarting' | 'Offline';
  latencyMs: number;
  cpuUsage: number;
  memoryUsage: string;
  cacheMb: number;
  isActionLoading?: boolean;
}

export const SuperAdminView: React.FC<SuperAdminViewProps> = ({ adminUser }) => {
  // Database Connections State
  const [databases, setDatabases] = useState<DatabaseConnection[]>([
    {
      id: 'db-1',
      name: 'Wikipedia API Public Data',
      type: 'Enciclopédia Pública',
      endpoint: 'https://pt.wikipedia.org/w/api.php',
      status: 'Active',
      lastSync: 'Há 3 minutos',
      recordsCount: 45200,
    },
    {
      id: 'db-2',
      name: 'Open Access Academic Journals',
      type: 'Repositório Acadêmico',
      endpoint: 'https://api.openaccess.org/v2/articles',
      status: 'Active',
      lastSync: 'Há 12 minutos',
      recordsCount: 128400,
    },
    {
      id: 'db-3',
      name: 'National Digital Archives',
      type: 'Acervo Histórico',
      endpoint: 'https://acervo.gov.br/api/v1/search',
      status: 'Inactive',
      lastSync: 'Há 2 horas',
      recordsCount: 88100,
    },
    {
      id: 'db-4',
      name: 'Global News & Press Feed',
      type: 'Notícias & Imprensa',
      endpoint: 'https://newsapi.org/v2/everything',
      status: 'Active',
      lastSync: 'Há 1 minuto',
      recordsCount: 64000,
    },
    {
      id: 'db-5',
      name: 'PASQUARED PKG Knowledge Graph',
      type: 'Ontologia Distribuída',
      endpoint: 'https://pasquared.space/rci/pkg',
      status: 'Active',
      lastSync: 'Agora mesmo',
      recordsCount: 184900,
    },
  ]);

  // Cluster Nodes State - All 12 Gods Clusters
  const [clusters, setClusters] = useState<ClusterNode[]>([
    {
      id: 'cluster-zeus',
      name: 'ZEUS-KERNEL-CLUSTER-01',
      godNamespace: 'ns/zeus-governance',
      role: 'Governança, Arbitragem & Decisão Final',
      replicas: 4,
      maxReplicas: 8,
      status: 'Healthy',
      latencyMs: 12,
      cpuUsage: 14,
      memoryUsage: '2.1 GB / 4.0 GB',
      cacheMb: 128,
    },
    {
      id: 'cluster-athena',
      name: 'ATHENA-LOGIC-CLUSTER-02',
      godNamespace: 'ns/athena-deductive',
      role: 'Estratégia, Lógica & Planejamento',
      replicas: 6,
      maxReplicas: 12,
      status: 'Healthy',
      latencyMs: 18,
      cpuUsage: 22,
      memoryUsage: '3.8 GB / 8.0 GB',
      cacheMb: 512,
    },
    {
      id: 'cluster-apollo',
      name: 'APOLLO-EMPIRIC-CLUSTER-03',
      godNamespace: 'ns/apollo-factcheck',
      role: 'Ciência, Coleta Empírica & Descoberta',
      replicas: 5,
      maxReplicas: 10,
      status: 'Healthy',
      latencyMs: 24,
      cpuUsage: 19,
      memoryUsage: '2.9 GB / 8.0 GB',
      cacheMb: 256,
    },
    {
      id: 'cluster-hermes',
      name: 'HERMES-COMM-CLUSTER-04',
      godNamespace: 'ns/hermes-language',
      role: 'Comunicação, Linguagem & Transmissões',
      replicas: 5,
      maxReplicas: 12,
      status: 'Healthy',
      latencyMs: 11,
      cpuUsage: 18,
      memoryUsage: '2.3 GB / 6.0 GB',
      cacheMb: 192,
    },
    {
      id: 'cluster-hephaestus',
      name: 'HEPHAESTUS-ENG-CLUSTER-05',
      godNamespace: 'ns/hephaestus-tech',
      role: 'Engenharia, Tecnologia & Infraestrutura',
      replicas: 4,
      maxReplicas: 10,
      status: 'Healthy',
      latencyMs: 16,
      cpuUsage: 25,
      memoryUsage: '3.1 GB / 8.0 GB',
      cacheMb: 320,
    },
    {
      id: 'cluster-hades',
      name: 'HADES-RISK-CLUSTER-06',
      godNamespace: 'ns/hades-anomaly',
      role: 'Riscos Ocultos, Vieses & Anomalias',
      replicas: 3,
      maxReplicas: 6,
      status: 'Healthy',
      latencyMs: 15,
      cpuUsage: 9,
      memoryUsage: '1.4 GB / 4.0 GB',
      cacheMb: 64,
    },
    {
      id: 'cluster-ares',
      name: 'ARES-STRESS-CLUSTER-07',
      godNamespace: 'ns/ares-conflict',
      role: 'Raciocínio Adversarial & Contradição',
      replicas: 4,
      maxReplicas: 8,
      status: 'Healthy',
      latencyMs: 14,
      cpuUsage: 17,
      memoryUsage: '2.0 GB / 4.0 GB',
      cacheMb: 160,
    },
    {
      id: 'cluster-poseidon',
      name: 'POSEIDON-NET-CLUSTER-08',
      godNamespace: 'ns/poseidon-logistics',
      role: 'Redes, Logística & Sistemas Complexos',
      replicas: 3,
      maxReplicas: 8,
      status: 'Healthy',
      latencyMs: 19,
      cpuUsage: 15,
      memoryUsage: '2.5 GB / 6.0 GB',
      cacheMb: 224,
    },
    {
      id: 'cluster-demeter',
      name: 'DEMETER-ECO-CLUSTER-09',
      godNamespace: 'ns/demeter-resources',
      role: 'Recursos, Sustentabilidade & Equilíbrio',
      replicas: 3,
      maxReplicas: 6,
      status: 'Healthy',
      latencyMs: 13,
      cpuUsage: 11,
      memoryUsage: '1.8 GB / 4.0 GB',
      cacheMb: 96,
    },
    {
      id: 'cluster-aphrodite',
      name: 'APHRODITE-BEHAVIOR-CLUSTER-10',
      godNamespace: 'ns/aphrodite-society',
      role: 'Comportamento Humano, Sociedade & Cultura',
      replicas: 3,
      maxReplicas: 8,
      status: 'Healthy',
      latencyMs: 17,
      cpuUsage: 13,
      memoryUsage: '1.9 GB / 4.0 GB',
      cacheMb: 128,
    },
    {
      id: 'cluster-dionysus',
      name: 'DIONYSUS-CREATIVE-CLUSTER-11',
      godNamespace: 'ns/dionysus-innovation',
      role: 'Criatividade, Inovação & Raciocínio Lateral',
      replicas: 3,
      maxReplicas: 8,
      status: 'Healthy',
      latencyMs: 16,
      cpuUsage: 14,
      memoryUsage: '2.2 GB / 4.0 GB',
      cacheMb: 160,
    },
    {
      id: 'cluster-chronos',
      name: 'CHRONOS-TEMPORAL-CLUSTER-12',
      godNamespace: 'ns/chronos-graph',
      role: 'História, Tempo & Causalidade Temporal',
      replicas: 4,
      maxReplicas: 8,
      status: 'Healthy',
      latencyMs: 21,
      cpuUsage: 16,
      memoryUsage: '2.4 GB / 6.0 GB',
      cacheMb: 384,
    },
  ]);

  // New DB Modal Form State
  const [isNewDbModalOpen, setIsNewDbModalOpen] = useState(false);
  const [newDbName, setNewDbName] = useState('');
  const [newDbType, setNewDbType] = useState('REST API Pública');
  const [newDbEndpoint, setNewDbEndpoint] = useState('');

  // Bulk operation loading indicator
  const [isBulkSyncing, setIsBulkSyncing] = useState(false);

  // MVED Vector Slider weights
  const [w1, setW1] = useState<number>(0.30); // Evidence
  const [w2, setW2] = useState<number>(0.25); // Logic
  const [w3, setW3] = useState<number>(0.20); // Relevance
  const [w4, setW4] = useState<number>(0.15); // Risk
  const [w5, setW5] = useState<number>(0.10); // Consensus

  // Audit Logs Stream
  const [auditLog, setAuditLog] = useState<string[]>([
    `[${new Date().toLocaleTimeString()}] PRE Epistemological Audit Trail Engine v2.0 ativado.`,
    `[${new Date().toLocaleTimeString()}] Super Admin autenticado: ${adminUser.email}`,
    `[${new Date().toLocaleTimeString()}] Status do Kernel Linux Debian 12: ESTÁVEL (12 Clusters do Olimpo Operacionais).`,
    `[${new Date().toLocaleTimeString()}] 5 Bases de Dados registradas e auditadas com sucesso.`,
  ]);

  const addLog = (msg: string) => {
    setAuditLog((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev]);
  };

  // 2FA Authentication State
  const [is2FAActive, setIs2FAActive] = useState<boolean>(false);
  const [is2FAModalOpen, setIs2FAModalOpen] = useState<boolean>(false);
  const [twoFactorSecret, setTwoFactorSecret] = useState<string>('');
  const [twoFactorQrUrl, setTwoFactorQrUrl] = useState<string>('');
  const [verificationCode, setVerificationCode] = useState<string>('');
  const [twoFactorError, setTwoFactorError] = useState<string | null>(null);
  const [twoFactorSuccess, setTwoFactorSuccess] = useState<string | null>(null);
  const [isGenerating2FA, setIsGenerating2FA] = useState<boolean>(false);
  const [isVerifying2FA, setIsVerifying2FA] = useState<boolean>(false);
  const [copiedSecret, setCopiedSecret] = useState<boolean>(false);

  // Fetch initial 2FA status from server on mount
  useEffect(() => {
    fetch('/api/v2/admin/2fa/status')
      .then((res) => res.json())
      .then((data) => {
        if (data) {
          setIs2FAActive(!!data.enabled);
          if (data.secret) setTwoFactorSecret(data.secret);
          if (data.qrCodeUrl) setTwoFactorQrUrl(data.qrCodeUrl);
        }
      })
      .catch((err) => console.error('Error fetching 2FA status:', err));
  }, []);

  const handleStart2FASetup = async () => {
    setTwoFactorError(null);
    setTwoFactorSuccess(null);
    setIsGenerating2FA(true);
    try {
      const res = await fetch('/api/v2/admin/2fa/setup', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setTwoFactorSecret(data.secret);
        setTwoFactorQrUrl(data.qrCodeUrl);
        setIs2FAModalOpen(true);
        addLog(`Setup 2FA iniciado para Super Admin (${adminUser.email}). QR Code gerado.`);
      } else {
        setTwoFactorError(data.error || 'Erro ao gerar QR Code 2FA.');
      }
    } catch (err: any) {
      setTwoFactorError('Erro de conexão ao gerar 2FA.');
    } finally {
      setIsGenerating2FA(false);
    }
  };

  const handleVerifyAndActivate2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    setTwoFactorError(null);
    setTwoFactorSuccess(null);

    if (!verificationCode.trim() || verificationCode.trim().length !== 6) {
      setTwoFactorError('Informe o código de 6 dígitos gerado pelo seu aplicativo Authenticator.');
      return;
    }

    setIsVerifying2FA(true);
    try {
      const res = await fetch('/api/v2/admin/2fa/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: verificationCode.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setIs2FAActive(true);
        setTwoFactorSuccess('Autenticação de 2 Fatores (2FA) ativada e validada com sucesso!');
        addLog(`AUTENTICAÇÃO 2FA ATIVADA COM SUCESSO para Super Admin (${adminUser.email}). Token validado.`);
        setTimeout(() => {
          setIs2FAModalOpen(false);
          setVerificationCode('');
          setTwoFactorSuccess(null);
        }, 2000);
      } else {
        setTwoFactorError(data.error || 'Código 2FA incorreto ou expirado.');
      }
    } catch (err) {
      setTwoFactorError('Erro de rede ao verificar código 2FA.');
    } finally {
      setIsVerifying2FA(false);
    }
  };

  const handleDisable2FA = async () => {
    if (!confirm('Deseja realmente desativar a Autenticação de 2 Fatores (2FA) do Super Admin?')) {
      return;
    }
    try {
      const res = await fetch('/api/v2/admin/2fa/disable', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setIs2FAActive(false);
        setIs2FAModalOpen(false);
        addLog(`Autenticação 2FA DESATIVADA para Super Admin (${adminUser.email}).`);
      }
    } catch (err) {
      console.error('Error disabling 2FA:', err);
    }
  };

  const handleCopySecret = () => {
    navigator.clipboard.writeText(twoFactorSecret);
    setCopiedSecret(true);
    setTimeout(() => setCopiedSecret(false), 2000);
  };

  // Unitary DB Activation / Deactivation
  const handleToggleDbStatus = (id: string) => {
    setDatabases((prev) =>
      prev.map((db) => {
        if (db.id === id) {
          const nextStatus = db.status === 'Active' ? 'Inactive' : 'Active';
          addLog(`Base de Dados [${db.name}] teve status alterado para: ${nextStatus.toUpperCase()}`);
          return { ...db, status: nextStatus };
        }
        return db;
      })
    );
  };

  // Unitary DB Sync
  const handleSyncDbUnitary = (id: string) => {
    setDatabases((prev) =>
      prev.map((db) => (db.id === id ? { ...db, isSyncing: true } : db))
    );

    const targetDb = databases.find((d) => d.id === id);
    if (targetDb) {
      addLog(`Sincronização unitária iniciada para: [${targetDb.name}]`);
    }

    setTimeout(() => {
      setDatabases((prev) =>
        prev.map((db) => {
          if (db.id === id) {
            addLog(`Sincronização concluída com sucesso para [${db.name}]. Indexados +120 registros.`);
            return {
              ...db,
              isSyncing: false,
              lastSync: 'Agora mesmo',
              recordsCount: db.recordsCount + 120,
            };
          }
          return db;
        })
      );
    }, 1200);
  };

  // Bulk Connect & Sync All Databases
  const handleBulkSyncAll = () => {
    setIsBulkSyncing(true);
    addLog(`[AÇÃO EM LOTE] Conectando e sincronizando TODAS as bases de dados públicas e privadas...`);

    // Set all to syncing
    setDatabases((prev) => prev.map((db) => ({ ...db, isSyncing: true, status: 'Active' })));

    setTimeout(() => {
      setDatabases((prev) =>
        prev.map((db) => ({
          ...db,
          isSyncing: false,
          status: 'Active',
          lastSync: 'Agora mesmo',
          recordsCount: db.recordsCount + 500,
        }))
      );
      setIsBulkSyncing(false);
      addLog(`[AÇÃO EM LOTE CONCLUÍDA] 100% das bases conectadas e sincronizadas simultaneamente (+2.500 registros indexados).`);
    }, 2000);
  };

  // Create New Database Connection
  const handleCreateNewDb = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDbName.trim() || !newDbEndpoint.trim()) return;

    const newDb: DatabaseConnection = {
      id: `db-custom-${Date.now()}`,
      name: newDbName.trim(),
      type: newDbType,
      endpoint: newDbEndpoint.trim(),
      status: 'Active',
      lastSync: 'Agora mesmo',
      recordsCount: 1000,
    };

    setDatabases((prev) => [newDb, ...prev]);
    addLog(`Nova Conexão de Base de Dados registrada: [${newDb.name}] (${newDb.endpoint})`);
    setNewDbName('');
    setNewDbEndpoint('');
    setIsNewDbModalOpen(false);
  };

  // Cluster Management: Restart Cluster
  const handleRestartCluster = (clusterId: string) => {
    setClusters((prev) =>
      prev.map((c) => (c.id === clusterId ? { ...c, status: 'Restarting', isActionLoading: true } : c))
    );

    const cluster = clusters.find((c) => c.id === clusterId);
    if (cluster) {
      addLog(`Reiniciando pod container do cluster [${cluster.name}]...`);
    }

    setTimeout(() => {
      setClusters((prev) =>
        prev.map((c) => {
          if (c.id === clusterId) {
            addLog(`Cluster [${c.name}] reiniciado com sucesso. Status: HEALTHY (Latência: 10ms).`);
            return { ...c, status: 'Healthy', latencyMs: 10, isActionLoading: false };
          }
          return c;
        })
      );
    }, 1500);
  };

  // Cluster Management: Scale Replicas
  const handleScaleReplicas = (clusterId: string, delta: number) => {
    setClusters((prev) =>
      prev.map((c) => {
        if (c.id === clusterId) {
          const newReplicas = Math.min(c.maxReplicas, Math.max(1, c.replicas + delta));
          addLog(`Cluster [${c.name}] réplicas escaladas de ${c.replicas} para ${newReplicas}.`);
          return { ...c, replicas: newReplicas };
        }
        return c;
      })
    );
  };

  // Cluster Management: Test Latency / Health Check
  const handleTestLatency = (clusterId: string) => {
    const randomLatency = Math.floor(Math.random() * 15) + 8;
    setClusters((prev) =>
      prev.map((c) => {
        if (c.id === clusterId) {
          addLog(`Health check executado no cluster [${c.name}]. Latência medida: ${randomLatency}ms (OK).`);
          return { ...c, latencyMs: randomLatency };
        }
        return c;
      })
    );
  };

  // Cluster Management: Purge Cache / Rebalance
  const handlePurgeCache = (clusterId: string) => {
    setClusters((prev) =>
      prev.map((c) => {
        if (c.id === clusterId) {
          addLog(`Purga de cache e rebalanceamento concluídos para o cluster [${c.name}]. Memória libertada.`);
          return { ...c, cacheMb: 0 };
        }
        return c;
      })
    );
  };

  const handleSaveMvedWeights = () => {
    addLog(`Pesos MVED 2.0 recalibrados: w1=${w1}, w2=${w2}, w3=${w3}, w4=${w4}, w5=${w5}.`);
  };

  return (
    <div className="space-y-10 pb-16 animate-fade-in">
      {/* Banner */}
      <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 text-xs font-mono font-bold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Painel de Governança Restrita // Super Admin</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-display font-black uppercase italic tracking-tighter text-white">
              GOITGODS <span className="text-yellow-400">2.0</span> DASHBOARD
            </h1>
            <p className="text-xs sm:text-sm font-mono text-zinc-400">
              Sessão Autenticada: <span className="text-white font-bold">{adminUser.email}</span> • Role: <span className="text-yellow-400 font-bold">SUPER_ADMIN</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleBulkSyncAll}
              disabled={isBulkSyncing}
              className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-6 py-3.5 text-xs font-mono uppercase tracking-widest transition-colors flex items-center space-x-2 disabled:opacity-50"
            >
              <Zap className={`w-4 h-4 ${isBulkSyncing ? 'animate-bounce' : ''}`} />
              <span>{isBulkSyncing ? 'SINCRONIZANDO TODAS...' : 'CONECTAR E SINCRONIZAR TODAS'}</span>
            </button>

            <button
              onClick={() => setIsNewDbModalOpen(true)}
              className="bg-zinc-800 hover:bg-zinc-700 text-white font-black px-5 py-3.5 text-xs font-mono uppercase tracking-widest border border-zinc-700 transition-colors flex items-center space-x-2"
            >
              <Plus className="w-4 h-4 text-yellow-400" />
              <span>NOVA BASE DE DADOS</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION: 2FA SECURITY CONTROL BOX */}
      <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className={`p-2.5 ${is2FAActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}`}>
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">SEGURANÇA DA CONTA SUPER ADMIN</span>
                <span className={`px-2 py-0.5 text-[10px] font-mono font-black uppercase ${is2FAActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}`}>
                  {is2FAActive ? '2FA ATIVADA (PROTEGIDO)' : '2FA DESATIVADA'}
                </span>
              </div>
              <h2 className="text-xl font-display font-black uppercase italic text-white mt-1">
                Autenticação de 2 Fatores por Aplicativo Authenticator
              </h2>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {is2FAActive ? (
              <button
                onClick={handleDisable2FA}
                className="bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-800 font-mono font-black px-4 py-2.5 text-xs uppercase tracking-wider transition-colors flex items-center space-x-2 cursor-pointer"
              >
                <Unlock className="w-4 h-4 text-red-400" />
                <span>DESATIVAR 2FA</span>
              </button>
            ) : (
              <button
                onClick={handleStart2FASetup}
                disabled={isGenerating2FA}
                className="bg-yellow-400 hover:bg-yellow-300 text-black font-mono font-black px-5 py-2.5 text-xs uppercase tracking-wider transition-colors flex items-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                <Lock className="w-4 h-4" />
                <span>{isGenerating2FA ? 'GERANDO SERVIÇO 2FA...' : 'ATIVAR AUTENTICAÇÃO 2FA'}</span>
              </button>
            )}
          </div>
        </div>

        <p className="text-xs font-mono text-zinc-400 leading-relaxed">
          {is2FAActive 
            ? 'A autenticação de dois fatores (2FA) está ativa na sua conta Super Admin. Qualquer novo acesso exigirá a verificação da senha mestre combinada ao código numérico rotativo de 6 dígitos do seu aplicativo Authenticator (Google Authenticator, Authy, Microsoft Authenticator, 1Password, etc).'
            : 'Ative a proteção de dois fatores (2FA) no aplicativo Authenticator para garantir que requisições administrativas e acesso aos clusters do Olimpo sejam protegidos por uma camada adicional de segurança bi-fatorial.'}
        </p>
      </div>

      {/* Global Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-[#080808] border border-zinc-800 p-5 space-y-1">
          <span className="text-[10px] font-mono font-black text-zinc-500 uppercase tracking-widest">CLUSTERS ATIVOS</span>
          <div className="text-3xl font-display font-black text-white font-mono">{clusters.length} NODES</div>
          <span className="text-[10px] text-emerald-400 font-mono font-bold">100% HEALTHY DEBIAN 12</span>
        </div>

        <div className="bg-[#080808] border border-zinc-800 p-5 space-y-1">
          <span className="text-[10px] font-mono font-black text-zinc-500 uppercase tracking-widest">BASES CONECTADAS</span>
          <div className="text-3xl font-display font-black text-yellow-400 font-mono">{databases.length} FONTES</div>
          <span className="text-[10px] text-zinc-400 font-mono">
            {databases.filter((d) => d.status === 'Active').length} Ativas // {databases.filter((d) => d.status === 'Inactive').length} Inativas
          </span>
        </div>

        <div className="bg-[#080808] border border-zinc-800 p-5 space-y-1">
          <span className="text-[10px] font-mono font-black text-zinc-500 uppercase tracking-widest">REGISTROS INDEXADOS</span>
          <div className="text-3xl font-display font-black text-cyan-400 font-mono">
            {databases.reduce((acc, curr) => acc + curr.recordsCount, 0).toLocaleString()}
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">Conhecimento Estruturado</span>
        </div>

        <div className="bg-[#080808] border border-zinc-800 p-5 space-y-1">
          <span className="text-[10px] font-mono font-black text-zinc-500 uppercase tracking-widest">ACURÁCIA MVED 2.0</span>
          <div className="text-3xl font-display font-black text-emerald-400 font-mono">91.2%</div>
          <span className="text-[10px] text-zinc-500 font-mono">Calibração Tripla</span>
        </div>
      </div>

      {/* SECTION 1: BASES DE DADOS PÚBLICA & PRIVADA */}
      <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
          <div className="flex items-center space-x-3">
            <Database className="w-5 h-5 text-yellow-400" />
            <div>
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">REPOSITÓRIOS CONECTADOS</p>
              <h2 className="text-2xl font-display font-black uppercase italic text-white">
                Gerenciamento de Bases de Dados Públicas & Privadas
              </h2>
            </div>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono text-zinc-400">
            <span>Ações Individuais e em Lote</span>
          </div>
        </div>

        {/* Database Rows List */}
        <div className="space-y-3">
          {databases.map((db) => (
            <div
              key={db.id}
              className={`bg-[#050505] border p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-colors ${
                db.status === 'Active' ? 'border-zinc-800 hover:border-zinc-700' : 'border-red-950/50 opacity-75'
              }`}
            >
              {/* DB Info */}
              <div className="space-y-1 max-w-xl">
                <div className="flex items-center space-x-3">
                  <span
                    className={`px-2 py-0.5 text-[10px] font-black uppercase font-mono tracking-wider ${
                      db.status === 'Active'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-red-950 text-red-400 border border-red-800'
                    }`}
                  >
                    {db.status === 'Active' ? 'ATIVO' : 'INATIVO'}
                  </span>

                  <h3 className="text-base font-bold text-white font-mono">{db.name}</h3>
                </div>

                <p className="text-xs font-mono text-zinc-400">
                  Tipo: <span className="text-zinc-300">{db.type}</span> • Endpoint:{' '}
                  <span className="text-yellow-400/80">{db.endpoint}</span>
                </p>

                <div className="text-[11px] font-mono text-zinc-500 flex items-center space-x-4">
                  <span>Última Sincronização: {db.lastSync}</span>
                  <span>Registros: {db.recordsCount.toLocaleString()}</span>
                </div>
              </div>

              {/* Action Buttons for each DB */}
              <div className="flex items-center space-x-2 w-full md:w-auto shrink-0 pt-2 md:pt-0">
                {/* Activate / Deactivate button */}
                <button
                  onClick={() => handleToggleDbStatus(db.id)}
                  className={`px-3 py-2 text-xs font-mono font-bold uppercase tracking-wider border transition-colors flex items-center space-x-1.5 ${
                    db.status === 'Active'
                      ? 'bg-zinc-900 hover:bg-red-950 text-zinc-300 hover:text-red-400 border-zinc-800 hover:border-red-800'
                      : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800'
                  }`}
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>{db.status === 'Active' ? 'DESATIVAR' : 'ATIVAR'}</span>
                </button>

                {/* Individual Sync button */}
                <button
                  onClick={() => handleSyncDbUnitary(db.id)}
                  disabled={db.isSyncing}
                  className="bg-zinc-800 hover:bg-zinc-700 text-yellow-400 font-mono font-bold px-3 py-2 text-xs uppercase tracking-wider border border-zinc-700 transition-colors flex items-center space-x-1.5 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${db.isSyncing ? 'animate-spin' : ''}`} />
                  <span>{db.isSyncing ? 'SINCRONIZANDO...' : 'SINCRONIZAR'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: CLUSTERS DE PROCESSAMENTO E INFERÊNCIA */}
      <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
          <div className="flex items-center space-x-3">
            <Server className="w-5 h-5 text-yellow-400" />
            <div>
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">PODS & REPLICAS KUBERNETES</p>
              <h2 className="text-2xl font-display font-black uppercase italic text-white">
                Status e Gerenciamento de Clusters de Inferência
              </h2>
            </div>
          </div>

          <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800 px-3 py-1">
            {clusters.length} NODES ONLINE (12 GODS)
          </span>
        </div>

        {/* Cluster Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {clusters.map((cluster) => (
            <div
              key={cluster.id}
              className="bg-[#050505] border border-zinc-800 p-6 space-y-5 relative flex flex-col justify-between"
            >
              {/* Card Header */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-black text-yellow-400 uppercase tracking-widest">
                    {cluster.godNamespace}
                  </span>
                  <span
                    className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase ${
                      cluster.status === 'Healthy'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-yellow-950 text-yellow-400 border border-yellow-800'
                    }`}
                  >
                    {cluster.status}
                  </span>
                </div>

                <h3 className="text-base font-display font-black uppercase italic text-white">
                  {cluster.name}
                </h3>
                <p className="text-xs font-mono text-zinc-400">{cluster.role}</p>
              </div>

              {/* Live Cluster Metrics */}
              <div className="bg-[#080808] border border-zinc-800/80 p-3 space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between text-zinc-400">
                  <span>Réplicas Ativas:</span>
                  <span className="text-white font-bold">{cluster.replicas} / {cluster.maxReplicas}</span>
                </div>
                <div className="flex items-center justify-between text-zinc-400">
                  <span>Latência da Rede:</span>
                  <span className="text-yellow-400 font-bold">{cluster.latencyMs} ms</span>
                </div>
                <div className="flex items-center justify-between text-zinc-400">
                  <span>Uso de CPU:</span>
                  <span className="text-cyan-400 font-bold">{cluster.cpuUsage}%</span>
                </div>
                <div className="flex items-center justify-between text-zinc-400">
                  <span>Memória RAM:</span>
                  <span className="text-zinc-300">{cluster.memoryUsage}</span>
                </div>
                <div className="flex items-center justify-between text-zinc-400">
                  <span>Cache Alocado:</span>
                  <span className="text-purple-400 font-bold">{cluster.cacheMb} MB</span>
                </div>
              </div>

              {/* Common Cluster Management Functions */}
              <div className="space-y-2 pt-2">
                <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest font-mono">
                  Funções de Gerenciamento:
                </p>

                <div className="grid grid-cols-2 gap-2">
                  {/* Restart Cluster */}
                  <button
                    onClick={() => handleRestartCluster(cluster.id)}
                    disabled={cluster.isActionLoading}
                    className="bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-mono text-[11px] font-bold py-2 px-2 border border-zinc-800 transition-colors flex items-center justify-center space-x-1"
                    title="Reiniciar Pods do Cluster"
                  >
                    <RotateCw className={`w-3 h-3 text-yellow-400 ${cluster.isActionLoading ? 'animate-spin' : ''}`} />
                    <span>REINICIAR</span>
                  </button>

                  {/* Health Check */}
                  <button
                    onClick={() => handleTestLatency(cluster.id)}
                    className="bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-mono text-[11px] font-bold py-2 px-2 border border-zinc-800 transition-colors flex items-center justify-center space-x-1"
                    title="Testar Saúde e Latência"
                  >
                    <Activity className="w-3 h-3 text-emerald-400" />
                    <span>PING TEST</span>
                  </button>
                </div>

                <div className="flex items-center justify-between bg-zinc-900 border border-zinc-800 p-2 font-mono text-xs text-zinc-300">
                  <span className="text-[10px] uppercase text-zinc-500 font-bold">Escalar Réplicas:</span>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleScaleReplicas(cluster.id, -1)}
                      disabled={cluster.replicas <= 1}
                      className="w-6 h-6 bg-zinc-800 hover:bg-zinc-700 text-white font-bold flex items-center justify-center border border-zinc-700 disabled:opacity-40"
                    >
                      -
                    </button>
                    <span className="font-bold text-yellow-400">{cluster.replicas}</span>
                    <button
                      onClick={() => handleScaleReplicas(cluster.id, 1)}
                      disabled={cluster.replicas >= cluster.maxReplicas}
                      className="w-6 h-6 bg-zinc-800 hover:bg-zinc-700 text-white font-bold flex items-center justify-center border border-zinc-700 disabled:opacity-40"
                    >
                      +
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => handlePurgeCache(cluster.id)}
                  className="w-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white font-mono text-[10px] font-bold py-1.5 border border-zinc-800 transition-colors flex items-center justify-center space-x-1"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                  <span>PURGAR CACHE & REBALANCEAR</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 3: MVED 2.0 VECTOR WEIGHTS CALIBRATION */}
      <div className="bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center space-x-3">
            <Sliders className="w-5 h-5 text-yellow-400" />
            <div>
              <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em]">PONDERAÇÃO ALGORÍTMICA</p>
              <h3 className="text-xl font-display font-black uppercase italic text-white">
                Calibração dos Pesos Vetoriais do MVED 2.0
              </h3>
            </div>
          </div>
          <button
            onClick={handleSaveMvedWeights}
            className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-5 py-2.5 text-xs font-mono uppercase tracking-widest transition-colors"
          >
            SALVAR PESOS
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 text-xs font-mono">
          <div className="space-y-2 bg-[#050505] p-4 border border-zinc-800">
            <label className="text-zinc-300 font-bold block">w1 Evidência: {w1}</label>
            <input
              type="range"
              min="0.1"
              max="0.5"
              step="0.05"
              value={w1}
              onChange={(e) => setW1(parseFloat(e.target.value))}
              className="w-full accent-yellow-400 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-[#050505] p-4 border border-zinc-800">
            <label className="text-zinc-300 font-bold block">w2 Lógica: {w2}</label>
            <input
              type="range"
              min="0.1"
              max="0.5"
              step="0.05"
              value={w2}
              onChange={(e) => setW2(parseFloat(e.target.value))}
              className="w-full accent-blue-400 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-[#050505] p-4 border border-zinc-800">
            <label className="text-zinc-300 font-bold block">w3 Relevância: {w3}</label>
            <input
              type="range"
              min="0.1"
              max="0.5"
              step="0.05"
              value={w3}
              onChange={(e) => setW3(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-[#050505] p-4 border border-zinc-800">
            <label className="text-zinc-300 font-bold block">w4 Risco: {w4}</label>
            <input
              type="range"
              min="0.1"
              max="0.5"
              step="0.05"
              value={w4}
              onChange={(e) => setW4(parseFloat(e.target.value))}
              className="w-full accent-purple-400 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-[#050505] p-4 border border-zinc-800">
            <label className="text-zinc-300 font-bold block">w5 Consenso: {w5}</label>
            <input
              type="range"
              min="0.1"
              max="0.5"
              step="0.05"
              value={w5}
              onChange={(e) => setW5(parseFloat(e.target.value))}
              className="w-full accent-emerald-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* SECTION 4: EPISTEMOLOGICAL AUDIT TRAIL STREAM */}
      <div className="bg-[#080808] border border-zinc-800 p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center space-x-2 text-yellow-400">
            <Terminal className="w-5 h-5" />
            <h3 className="font-display font-black uppercase italic text-base text-white">
              Protocolo de Rastreabilidade Epistemológica (PRE) - Audit Trail Log
            </h3>
          </div>
          <span className="text-[10px] font-mono text-zinc-500">KERNEL SYSLOG STREAM</span>
        </div>

        <div className="bg-[#050505] p-4 border border-zinc-800 font-mono text-xs text-zinc-300 space-y-2 max-h-64 overflow-y-auto">
          {auditLog.map((log, i) => (
            <div key={i} className="flex items-start space-x-2">
              <span className="text-yellow-400 font-bold shrink-0">&gt;</span>
              <span>{log}</span>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL: NOVA CONEXÃO DE BASE DE DADOS */}
      {isNewDbModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in">
          <div className="w-full max-w-lg bg-[#080808] border border-zinc-800 p-6 sm:p-8 space-y-6 relative">
            <button
              onClick={() => setIsNewDbModalOpen(false)}
              className="absolute top-4 right-4 text-zinc-500 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 bg-yellow-400/10 text-yellow-400 text-[10px] font-mono font-bold uppercase">
                <Plus className="w-3 h-3" />
                <span>Nova Conexão</span>
              </div>
              <h3 className="text-xl font-display font-black uppercase italic text-white">
                Registrar Nova Base de Dados
              </h3>
              <p className="text-xs font-mono text-zinc-400">
                Adicione um novo endpoint ou repositório ontológico ao ecossistema GOITGODS 2.0.
              </p>
            </div>

            <form onSubmit={handleCreateNewDb} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-mono font-bold uppercase text-zinc-300">
                  Nome da Base de Dados:
                </label>
                <input
                  type="text"
                  required
                  value={newDbName}
                  onChange={(e) => setNewDbName(e.target.value)}
                  placeholder="Ex: Acervo de Patentes INPI"
                  className="w-full bg-[#050505] text-white text-xs font-mono px-4 py-3 border border-zinc-700 focus:outline-none focus:border-yellow-400"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-bold uppercase text-zinc-300">
                  Tipo de Fonte / Conector:
                </label>
                <select
                  value={newDbType}
                  onChange={(e) => setNewDbType(e.target.value)}
                  className="w-full bg-[#050505] text-white text-xs font-mono px-4 py-3 border border-zinc-700 focus:outline-none focus:border-yellow-400"
                >
                  <option value="REST API Pública">REST API Pública</option>
                  <option value="SPARQL / Knowledge Graph">SPARQL / Knowledge Graph</option>
                  <option value="Acervo Governamental">Acervo Governamental / PDF Archive</option>
                  <option value="Feed de Notícias RSS">Feed de Notícias RSS</option>
                  <option value="Banco Relacional SQL">Banco Relacional PostgreSQL/SQL</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-bold uppercase text-zinc-300">
                  Endpoint URL / Connection String:
                </label>
                <input
                  type="url"
                  required
                  value={newDbEndpoint}
                  onChange={(e) => setNewDbEndpoint(e.target.value)}
                  placeholder="https://api.exemplo.org/v1/search"
                  className="w-full bg-[#050505] text-white text-xs font-mono px-4 py-3 border border-zinc-700 focus:outline-none focus:border-yellow-400"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsNewDbModalOpen(false)}
                  className="bg-zinc-900 hover:bg-zinc-800 text-zinc-300 px-4 py-3 text-xs font-mono uppercase font-bold border border-zinc-800"
                >
                  CANCELAR
                </button>

                <button
                  type="submit"
                  className="bg-yellow-400 hover:bg-yellow-300 text-black px-6 py-3 text-xs font-mono uppercase font-black"
                >
                  CRIAR CONEXÃO
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2FA SETUP & QR CODE SCAN MODAL */}
      {is2FAModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in">
          <div className="w-full max-w-lg bg-[#080808] border border-yellow-400/50 p-6 sm:p-8 space-y-6 shadow-2xl relative">
            <button
              onClick={() => setIs2FAModalOpen(false)}
              className="absolute top-4 right-4 text-zinc-500 hover:text-white p-1 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-yellow-400/10 border border-yellow-400/30 flex items-center justify-center text-yellow-400 mx-auto">
                <QrCode className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-display font-black uppercase italic tracking-wider text-white">
                Configurar Autenticação 2FA
              </h3>
              <p className="text-xs text-zinc-400 font-mono">
                Escaneie o QR Code no seu aplicativo de autenticação (Google Authenticator, Authy, etc)
              </p>
            </div>

            {twoFactorError && (
              <div className="bg-red-950/90 border border-red-800 text-red-200 p-3 text-xs font-mono flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
                <span>{twoFactorError}</span>
              </div>
            )}

            {twoFactorSuccess && (
              <div className="bg-emerald-950/90 border border-emerald-800 text-emerald-200 p-3 text-xs font-mono flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{twoFactorSuccess}</span>
              </div>
            )}

            {/* QR Code Container & Key */}
            <div className="bg-[#030303] border border-zinc-800 p-5 text-center space-y-4">
              <div className="text-xs font-mono text-zinc-300 font-bold uppercase tracking-widest">
                PASSO 1: ESCANEIE O QR CODE ABAIXO
              </div>

              {twoFactorQrUrl ? (
                <div className="bg-white p-3 inline-block shadow-lg rounded-none border-4 border-yellow-400">
                  <img src={twoFactorQrUrl} alt="2FA QR Code" className="w-52 h-52 mx-auto" />
                </div>
              ) : (
                <div className="w-52 h-52 mx-auto bg-zinc-900 flex items-center justify-center text-zinc-600 font-mono text-xs">
                  Gerando QR Code...
                </div>
              )}

              {/* Manual secret key */}
              <div className="space-y-1.5 pt-2">
                <label className="text-[11px] font-mono text-zinc-400 uppercase">
                  Ou digite a Chave de Recuperação manualmente no App:
                </label>
                <div className="flex items-center justify-center space-x-2">
                  <code className="bg-zinc-900 border border-zinc-700 text-yellow-400 px-3 py-1.5 font-mono text-xs font-bold tracking-widest">
                    {twoFactorSecret || '••••••••••••••••'}
                  </code>
                  <button
                    onClick={handleCopySecret}
                    type="button"
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 px-2.5 py-1.5 text-xs font-mono flex items-center space-x-1 transition-colors cursor-pointer"
                  >
                    {copiedSecret ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSecret ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Verification Form */}
            <form onSubmit={handleVerifyAndActivate2FA} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-black uppercase tracking-widest text-zinc-300 font-mono">
                  PASSO 2: DIGITE O CÓDIGO DE 6 DÍGITOS DO APLICATIVO:
                </label>
                <div className="relative flex items-center">
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="000 000"
                    className="w-full bg-[#000000] text-center text-yellow-400 font-mono text-2xl tracking-[0.3em] font-black rounded-none py-3 border border-yellow-400/60 focus:outline-none focus:border-yellow-400"
                  />
                  <Smartphone className="absolute left-3 w-5 h-5 text-yellow-400/60" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isVerifying2FA || verificationCode.length !== 6}
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-black py-3.5 text-xs font-mono uppercase tracking-widest transition-colors flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{isVerifying2FA ? 'VALIDANDO CÓDIGO 2FA...' : 'CONFIRMAR E ATIVAR 2FA NO SISTEMA'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
