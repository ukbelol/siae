# Alterações — Anamnese Acadêmica

- Novo `server/researchAnamnesisEngine.ts`.
- Novo `src/components/ResearchAnamnesisPanel.tsx`.
- Novos tipos acadêmicos e estruturas de protocolo/premissas em `src/types.ts`.
- Integração visual da anamnese na tela de pesquisa em `src/App.tsx`.
- Endpoints `/api/v3/anamnesis/start`, `/protocol` e `/evaluate` em `server.ts`.
- Perfis de rigor para Fundamental I, Fundamental II, Médio, Técnico, Graduação, Pós-graduação, Mestrado, Doutorado e Outro.
- Etapas completas do protocolo: problema, recorte, objetivos, hipóteses, busca, fontes, triangulação, avaliação, conclusão e revisão.
- Avaliação explícita de premissas com veredictos SUPPORTED, REFUTED, DISPUTED, PROVISIONAL ou INSUFFICIENT_EVIDENCE.
- O PASQUARED permanece como estruturador/orquestrador e o GOITGODS como avaliador especializado de premissas e evidências.

## Observação de validação
O ambiente de geração não conseguiu concluir `npm install` dentro da janela de execução; por isso a compilação integral depende da instalação das dependências no ambiente de destino. O código foi mantido compatível com a estrutura TypeScript/React/Express já usada no ZIP original.
