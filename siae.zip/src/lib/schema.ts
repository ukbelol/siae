export const schema = `
-- Permissions Table
CREATE TABLE IF NOT EXISTS permissions (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  module TEXT NOT NULL,
  can_read BOOLEAN DEFAULT 1,
  can_write BOOLEAN DEFAULT 0,
  can_delete BOOLEAN DEFAULT 0
);

CREATE TABLE IF NOT EXISTS user_permissions (
  user_id INTEGER NOT NULL,
  permission_id INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (permission_id) REFERENCES permissions(id)
);

-- Users table (Assistidos, Trabalhadores, Representantes)
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  role TEXT NOT NULL CHECK(role IN ('assisted', 'worker', 'representative', 'super_admin')),
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  photo_url TEXT,
  cpf TEXT UNIQUE NOT NULL,
  dob TEXT NOT NULL,
  phone TEXT,
  street TEXT,
  number TEXT,
  neighborhood TEXT,
  city TEXT,
  state TEXT,
  country TEXT,
  skills TEXT,
  specializations TEXT,
  profession TEXT,
  nfc_tag TEXT UNIQUE,
  religion TEXT,
  age INTEGER,
  recommendations TEXT,
  status TEXT DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Spiritual Houses (Casas Espíritas)
CREATE TABLE IF NOT EXISTS houses (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  representative_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  cnpj TEXT UNIQUE NOT NULL,
  email TEXT,
  phone TEXT,
  photo_url TEXT,
  cep TEXT,
  street TEXT,
  number TEXT,
  neighborhood TEXT,
  city TEXT,
  state TEXT,
  country TEXT,
  operating_hours TEXT,
  foundation_date TEXT,
  services TEXT,
  courses TEXT,
  status TEXT DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (representative_id) REFERENCES users(id)
);

-- House Workers Link
CREATE TABLE IF NOT EXISTS house_workers (
  house_id INTEGER NOT NULL,
  worker_id INTEGER NOT NULL,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'approved', 'rejected', 'active', 'inactive')),
  PRIMARY KEY (house_id, worker_id),
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (worker_id) REFERENCES users(id)
);

-- Worker Sessions (Ponto e Status)
CREATE TABLE IF NOT EXISTS worker_sessions (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  worker_id INTEGER NOT NULL,
  house_id INTEGER NOT NULL,
  clock_in DATETIME DEFAULT CURRENT_TIMESTAMP,
  clock_out DATETIME,
  status TEXT DEFAULT 'available' CHECK(status IN ('available', 'busy', 'offline')),
  current_assistance_type TEXT,
  room_number TEXT,
  FOREIGN KEY (worker_id) REFERENCES users(id),
  FOREIGN KEY (house_id) REFERENCES houses(id)
);

-- House Assisted Link
CREATE TABLE IF NOT EXISTS house_assisted (
  house_id INTEGER NOT NULL,
  assisted_id INTEGER NOT NULL,
  status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive')),
  PRIMARY KEY (house_id, assisted_id),
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (assisted_id) REFERENCES users(id)
);

-- Assistance Types
CREATE TABLE IF NOT EXISTS assistance_types (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  house_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive')),
  FOREIGN KEY (house_id) REFERENCES houses(id)
);

-- House Operating Days
CREATE TABLE IF NOT EXISTS house_operating_days (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  house_id INTEGER NOT NULL,
  day_of_week INTEGER NOT NULL,
  open_time TEXT NOT NULL,
  close_time TEXT NOT NULL,
  FOREIGN KEY (house_id) REFERENCES houses(id)
);

-- House Day Assistances
CREATE TABLE IF NOT EXISTS house_day_assistances (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  house_id INTEGER NOT NULL,
  day_of_week INTEGER NOT NULL,
  assistance_type_id INTEGER NOT NULL,
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (assistance_type_id) REFERENCES assistance_types(id)
);

-- Conferences (Salas de Tratamento em Grupo)
CREATE TABLE IF NOT EXISTS conferences (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  house_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  theme TEXT DEFAULT 'Escuro',
  scheduled_date TEXT NOT NULL,
  scheduled_time TEXT NOT NULL,
  room_name TEXT UNIQUE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (house_id) REFERENCES houses (id)
);

CREATE TABLE IF NOT EXISTS conference_participants (
  conference_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  FOREIGN KEY (conference_id) REFERENCES conferences (id),
  FOREIGN KEY (user_id) REFERENCES users (id),
  PRIMARY KEY (conference_id, user_id)
);

-- Assistance Requests (Triagem / Relatos)
CREATE TABLE IF NOT EXISTS assistance_requests (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  house_id INTEGER NOT NULL,
  assisted_id INTEGER NOT NULL,
  problem_description TEXT NOT NULL,
  duration TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'analyzed', 'in_treatment', 'completed')),
  treatment_plan TEXT,
  target_treatments TEXT,
  total_sessions INTEGER DEFAULT 1,
  completed_sessions INTEGER DEFAULT 0,
  assigned_worker_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (assisted_id) REFERENCES users(id),
  FOREIGN KEY (assigned_worker_id) REFERENCES users(id)
);

-- Treatment Schedules (Agendamentos de Tratamento)
CREATE TABLE IF NOT EXISTS treatment_schedules (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  assistance_request_id INTEGER NOT NULL,
  assistance_type_id INTEGER NOT NULL,
  scheduled_date TEXT NOT NULL,
  scheduled_time TEXT NOT NULL,
  status TEXT DEFAULT 'scheduled' CHECK(status IN ('scheduled', 'completed', 'cancelled')),
  FOREIGN KEY (assistance_request_id) REFERENCES assistance_requests(id),
  FOREIGN KEY (assistance_type_id) REFERENCES assistance_types(id)
);

-- System Settings Table
CREATE TABLE IF NOT EXISTS system_settings (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL
);

-- Queue / Attendances
CREATE TABLE IF NOT EXISTS attendances (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  house_id INTEGER NOT NULL,
  assisted_id INTEGER NOT NULL,
  worker_id INTEGER,
  assistance_request_id INTEGER,
  type TEXT NOT NULL,
  ticket_number TEXT,
  status TEXT DEFAULT 'waiting' CHECK(status IN ('waiting', 'called', 'in_progress', 'completed', 'cancelled')),
  check_in_time DATETIME,
  start_time DATETIME,
  end_time DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (assisted_id) REFERENCES users(id),
  FOREIGN KEY (worker_id) REFERENCES users(id),
  FOREIGN KEY (assistance_request_id) REFERENCES assistance_requests(id)
);

CREATE TABLE IF NOT EXISTS mercadopago_config (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  env VARCHAR(20) DEFAULT 'production',
  test_access_token TEXT,
  test_public_key TEXT,
  test_client_id TEXT,
  test_client_secret TEXT,
  access_token TEXT,
  public_key TEXT,
  client_id TEXT,
  client_secret TEXT,
  redirect_url TEXT,
  enable_pix_qr_code INTEGER DEFAULT 1,
  enable_pix_copia_cola INTEGER DEFAULT 1,
  enable_card INTEGER DEFAULT 1,
  max_qty_per_order INTEGER DEFAULT 10,
  unit_price DECIMAL(10, 2) DEFAULT 15.00,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS nfc_tags (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  serial_number VARCHAR(60) UNIQUE NOT NULL,
  status VARCHAR(20) DEFAULT 'active' CHECK(status IN ('active', 'inactive')),
  user_id INTEGER,
  house_id INTEGER,
  activation_date VARCHAR(50),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (house_id) REFERENCES houses(id)
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  stock INTEGER DEFAULT 0,
  image_url TEXT,
  status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  user_id INTEGER NOT NULL,
  house_id INTEGER,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'paid', 'cancelled', 'delivered')),
  payment_method TEXT DEFAULT 'pix',
  payment_id TEXT,
  qr_code TEXT,
  qr_code_base64 TEXT,
  ticket_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (house_id) REFERENCES houses(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Test Users
INSERT IGNORE INTO users (role, email, password, first_name, last_name, cpf, dob)
VALUES 
  ('assisted', 'assistido@siae.space', '$2b$10$cKraa5jQIYfsYCKDp66gbeyWVZPYmCsNUb07jYDnxWS0abTVCNlKS', 'Usuário', 'Assistido', '34567890123', '01/01/1980'),
  ('worker', 'trabalhador@siae.space', '$2b$10$s6MWepHLKryN9u7.NdYkROAraDKt3hk/2mA0HFqUt9wlnO7sKoWd2', 'Usuário', 'Trabalhador', '23456789012', '01/01/1980'),
  ('representative', 'representante@siae.space', '$2b$10$Y/zk.IPeukv.6Ay1tp95nOTKVeVyL09Qb1XQjuL9a3FdYQhwwMwLS', 'Representante', 'Casa', '12345678901', '01/01/1980');

-- Test House
INSERT IGNORE INTO houses (representative_id, name, cnpj, street, number, city, state, country) 
SELECT id, 'Casa esp virtual 01', '11111111000100', 'rua sem nome', '1', 'ukbelol', 'Sp', 'Brasil'
FROM users WHERE cpf = '12345678901';

-- Operating Days
INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 0, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 0);

INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 1, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 1);

INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 2, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 2);

INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 3, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 3);

INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 4, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 4);

INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 5, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 5);

INSERT INTO house_operating_days (house_id, day_of_week, open_time, close_time)
SELECT id, 6, '00:00', '23:59' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM house_operating_days d WHERE d.house_id = houses.id AND d.day_of_week = 6);

-- Assistance Types
INSERT INTO assistance_types (house_id, name, status)
SELECT id, 'Passe', 'active' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM assistance_types a WHERE a.house_id = houses.id AND a.name = 'Passe');

INSERT INTO assistance_types (house_id, name, status)
SELECT id, 'Heiki', 'active' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM assistance_types a WHERE a.house_id = houses.id AND a.name = 'Heiki');

INSERT INTO assistance_types (house_id, name, status)
SELECT id, 'Auricultura', 'active' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM assistance_types a WHERE a.house_id = houses.id AND a.name = 'Auricultura');

INSERT INTO assistance_types (house_id, name, status)
SELECT id, 'Apometria', 'active' FROM houses WHERE cnpj = '11111111000100'
AND NOT EXISTS (SELECT 1 FROM assistance_types a WHERE a.house_id = houses.id AND a.name = 'Apometria');

-- House Day Assistances
INSERT INTO house_day_assistances (house_id, day_of_week, assistance_type_id)
SELECT h.id, d.day_of_week, a.id 
FROM houses h
JOIN house_operating_days d ON d.house_id = h.id
JOIN assistance_types a ON a.house_id = h.id
WHERE h.cnpj = '11111111000100'
AND NOT EXISTS (
  SELECT 1 FROM house_day_assistances hda 
  WHERE hda.house_id = h.id AND hda.day_of_week = d.day_of_week AND hda.assistance_type_id = a.id
);
`;
