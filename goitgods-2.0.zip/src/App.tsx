/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SearchHome } from './components/SearchHome';
import { EbookReader } from './components/EbookReader';
import { LiveDebateView } from './components/LiveDebateView';
import { KnowledgeGraphView } from './components/KnowledgeGraphView';
import { EvolutionView } from './components/EvolutionView';
import { SuperAdminView } from './components/SuperAdminView';
import { SuperAdminModal } from './components/SuperAdminModal';
import { 
  SearchParametersResult, 
  EbookDocument, 
  SuperAdminUser, 
  DecisionState 
} from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('search');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchResult, setSearchResult] = useState<SearchParametersResult | null>(null);
  const [generatedEbook, setGeneratedEbook] = useState<EbookDocument | null>(null);

  // Super Admin state
  const [adminUser, setAdminUser] = useState<SuperAdminUser | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);

  // Initial load default search dataset ("Revolução Industrial")
  useEffect(() => {
    executeSearch('Revolução Industrial');
  }, []);

  const executeSearch = async (queryTopic: string) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/v2/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryTopic }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        const data = json.data;

        const searchRes: SearchParametersResult = {
          topic: data.topic || queryTopic,
          summary: data.summary || '',
          originAndBeginning: data.originAndBeginning,
          causativeFactors: data.causativeFactors || [],
          strengthsAndWeaknesses: data.strengthsAndWeaknesses || { strengths: [], weaknesses: [] },
          durationInEvidence: data.durationInEvidence || { timeframe: '', peakPeriod: '', currentStatus: '' },
          chronologicalSequence: data.chronologicalSequence || { inicio: '', desenvolvimento: '', meio: '', fim: '' },
          sources: data.sources || [],
        };

        setSearchResult(searchRes);

        // Build E-Book Document
        const ebookDoc: EbookDocument = {
          id: `ebk-${Date.now()}`,
          title: `O Livro Definitive: ${data.topic}`,
          subtitle: `Investigação Epistemológica pelo Sistema GOITGODS 2.0 & PASQUARED-OS`,
          author: `Conselho dos 12 Deuses do Olimpo`,
          publisher: `PASQUARED-OS Knowledge Publishing`,
          dateCreated: new Date().toLocaleDateString('pt-BR'),
          coverImageTheme: 'ancient_gold',
          topic: data.topic,
          chapters: data.ebookChapters || [],
          totalPages: data.ebookChapters?.length || 5,
          pksScore: 0.94,
          kqScore: 0.92,
        };

        setGeneratedEbook(ebookDoc);
      }
    } catch (err) {
      console.error('Search query error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenEbookReader = () => {
    setActiveTab('ebook');
  };

  return (
    <div className="min-h-screen bg-[#050505] text-zinc-100 font-sans selection:bg-yellow-400/30 selection:text-yellow-200 antialiased flex flex-col">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        adminUser={adminUser}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onLogoutAdmin={() => setAdminUser(null)}
      />

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {activeTab === 'search' && (
          <SearchHome
            onSearchSubmit={executeSearch}
            isLoading={isLoading}
            searchResult={searchResult}
            onOpenEbookReader={handleOpenEbookReader}
            generatedEbook={generatedEbook}
          />
        )}

        {activeTab === 'ebook' && (
          <EbookReader
            ebook={generatedEbook}
            onBackToSearch={() => setActiveTab('search')}
          />
        )}

        {activeTab === 'debate' && (
          <LiveDebateView searchResult={searchResult} />
        )}

        {activeTab === 'graph' && (
          <KnowledgeGraphView searchResult={searchResult} />
        )}

        {activeTab === 'evolution' && (
          <EvolutionView />
        )}

        {activeTab === 'admin' && (
          adminUser && adminUser.isAuthenticated ? (
            <SuperAdminView adminUser={adminUser} />
          ) : (
            <div className="bg-[#080808] border border-zinc-800 p-12 text-center space-y-4 max-w-md mx-auto my-12">
              <p className="text-[10px] font-black text-yellow-400 uppercase tracking-[0.3em]">ACESSO RESTRITO</p>
              <h3 className="text-xl font-display font-black uppercase italic text-white">Autenticação Requerida</h3>
              <p className="text-xs font-mono text-zinc-400">
                Você precisa estar autenticado como Super Admin para acessar este painel.
              </p>
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-6 py-3 text-xs uppercase tracking-widest transition-colors"
              >
                Fazer Login Super Admin
              </button>
            </div>
          )
        )}
      </main>

      {/* Super Admin Login Modal Dialog */}
      <SuperAdminModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(user) => {
          setAdminUser(user);
          setActiveTab('admin');
        }}
      />

      {/* Global Footer */}
      <footer className="bg-[#050505] border-t border-zinc-800 py-6 text-center text-xs text-zinc-500 font-mono space-y-1 mt-auto">
        <div className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">
          GOITGODS 2.0 // ORQUESTRADOR DE DECISÕES PASQUARED-OS PCK (v2.0.4)
        </div>
        <div className="text-[10px] text-zinc-600">
          Suporte Completo a Linux Debian 12 • Sistema de Segurança Ativo
        </div>
      </footer>
    </div>
  );
}
