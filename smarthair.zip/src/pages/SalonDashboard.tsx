import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Scissors, Clock, DollarSign, LogOut, Settings, Trash2, Edit2, Eye, EyeOff, Calendar, CheckCircle } from 'lucide-react';
import Logo from '../components/Logo';
import { SERVICE_CATEGORIES } from '../constants/services';

const DAYS_OF_WEEK = [
  { id: 0, name: 'Domingo' },
  { id: 1, name: 'Segunda-feira' },
  { id: 2, name: 'Terça-feira' },
  { id: 3, name: 'Quarta-feira' },
  { id: 4, name: 'Quinta-feira' },
  { id: 5, name: 'Sexta-feira' },
  { id: 6, name: 'Sábado' }
];

export default function SalonDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [salon, setSalon] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('appointments');
  const [employees, setEmployees] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  
  const [filterDay, setFilterDay] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<boolean>(false);
  
  const [editingEmployee, setEditingEmployee] = useState<any>(null);
  const [editingService, setEditingService] = useState<any>(null);
  
  const [timeSlots, setTimeSlots] = useState<any[]>([{ id: Date.now().toString(), start_time: '09:00', end_time: '18:00', days: [1,2,3,4,5], services: [] }]);
  const [employeeServices, setEmployeeServices] = useState<{id: number, days_of_week: number[]}[]>([]);
  const [employeeWorkingHours, setEmployeeWorkingHours] = useState<any[]>([]);
  const [isConnectingMP, setIsConnectingMP] = useState(false);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'MP_AUTH_SUCCESS') {
        showToast('Mercado Pago conectado com sucesso!');
        fetchData(user.id);
      } else if (event.data?.type === 'MP_AUTH_ERROR') {
        showToast(event.data.message || 'Erro ao conectar com Mercado Pago.', 'error');
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [user]);

  const handleConnectMP = async () => {
    if (!salon) return;
    setIsConnectingMP(true);
    try {
      const res = await fetch(`/api/auth/mercadopago/url?salonId=${salon.id}`);
      const data = await res.json();
      if (data.url) {
        window.open(data.url, 'mp_auth', 'width=600,height=700');
      } else {
        showToast(data.message || 'Erro ao gerar URL de conexão.', 'error');
      }
    } catch (error) {
      showToast('Erro ao conectar com Mercado Pago.', 'error');
    } finally {
      setIsConnectingMP(false);
    }
  };

  const handleEditEmployee = (emp: any) => {
    setEditingEmployee(emp);
    setEmployeeServices(emp.services || []);
    setEmployeeWorkingHours(emp.workingHours || []);
    
    // Create timeslots by grouping workingHours
    const groupedWH: Record<string, any> = {};
    (emp.workingHours || []).forEach((wh: any) => {
      const key = `${wh.start_time}-${wh.end_time}`;
      if (!groupedWH[key]) {
        groupedWH[key] = { id: key, start_time: wh.start_time, end_time: wh.end_time, days: [], services: [] };
      }
      groupedWH[key].days.push(wh.day_of_week);
    });
    
    const slots = Object.values(groupedWH);
    slots.forEach(slot => {
      (emp.services || []).forEach((svc: any) => {
        const hasOverlap = svc.days_of_week.some((d: number) => slot.days.includes(d));
        if (hasOverlap) {
          slot.services.push(svc.id);
        }
      });
    });
    
    setTimeSlots(slots.length > 0 ? slots : [{ id: 'default', start_time: '09:00', end_time: '18:00', days: [1,2,3,4,5], services: [] }]);
  };

  const cancelEditEmployee = () => {
    setEditingEmployee(null);
    setEmployeeServices([]);
    setEmployeeWorkingHours([]);
    setTimeSlots([{ id: Date.now().toString(), start_time: '09:00', end_time: '18:00', days: [1,2,3,4,5], services: [] }]);
  };

  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const [landingConfig, setLandingConfig] = useState({
    slogan: '',
    about_text: '',
    mission_text: '',
    logo_url: '',
    bg_url: '',
    street: '',
    number: '',
    neighborhood: '',
    city: '',
    state: '',
    country: ''
  });

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/login/salon');
      return;
    }
    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);
    fetchData(parsedUser.id, parsedUser);
  }, []);

  const fetchData = async (userId: number, parsedUser: any = user) => {
    try {
      let salonData;
      if (parsedUser.role === 'employee' && parsedUser.salon_id) {
        const salonRes = await fetch(`/api/salons/${parsedUser.salon_id}`);
        if (!salonRes.ok) return;
        salonData = await salonRes.json();
      } else {
        const salonRes = await fetch(`/api/admin/${userId}/salon`);
        if (!salonRes.ok) return;
        salonData = await salonRes.json();
      }
      
      setSalon(salonData);
      setLandingConfig({
        slogan: salonData.slogan || '',
        about_text: salonData.about_text || '',
        mission_text: salonData.mission_text || '',
        logo_url: salonData.logo_url || '',
        bg_url: salonData.bg_url || '',
        street: salonData.street || parsedUser?.street || '',
        number: salonData.number || parsedUser?.number || '',
        neighborhood: salonData.neighborhood || parsedUser?.neighborhood || '',
        city: salonData.city || parsedUser?.city || '',
        state: salonData.state || parsedUser?.state || '',
        country: salonData.country || parsedUser?.country || ''
      });

      const [empRes, srvRes, appRes] = await Promise.all([
        fetch(`/api/salons/${salonData.id}/employees`),
        fetch(`/api/salons/${salonData.id}/services`),
        fetch(`/api/salons/${salonData.id}/appointments`)
      ]);
      
      setEmployees(await empRes.json());
      setServices(await srvRes.json());
      setAppointments(await appRes.json());
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const logout = () => {
    localStorage.removeItem('user');
    navigate('/');
  };

  const handleAddEmployee = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!salon) return;
    const form = e.currentTarget;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    // Process timeSlots to determine services and workingHours
    const computedWorkingHours: any[] = [];
    const computedServicesMap: Record<number, Set<number>> = {};
    
    timeSlots.forEach((slot: any) => {
      slot.days.forEach((day: number) => {
        computedWorkingHours.push({ day_of_week: day, start_time: slot.start_time, end_time: slot.end_time });
        slot.services.forEach((svcId: number) => {
          if (!computedServicesMap[svcId]) computedServicesMap[svcId] = new Set();
          computedServicesMap[svcId].add(day);
        });
      });
    });
    
    const computedServices = Object.keys(computedServicesMap).map(id => ({
      id: Number(id),
      days_of_week: Array.from(computedServicesMap[Number(id)])
    }));

    let payload: any = {
      ...data,
      services: computedServices,
      workingHours: computedWorkingHours
    };

    const fileInput = form.querySelector('input[name="photo_url_file"]') as HTMLInputElement;
    if (fileInput && fileInput.files && fileInput.files[0]) {
      const file = fileInput.files[0];
      const reader = new FileReader();
      
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.readAsDataURL(file);
      });
      
      const base64Image = await base64Promise;
      payload = { ...payload, photo_url: base64Image };
    } else if (editingEmployee?.photo_url) {
      payload = { ...payload, photo_url: editingEmployee.photo_url };
    }
    
    if (editingEmployee) {
      const res = await fetch(`/api/salons/${salon.id}/employees/${editingEmployee.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...editingEmployee, ...payload })
      });
      if (res.ok) {
        showToast('Funcionário atualizado com sucesso!');
        cancelEditEmployee();
        fetchData(user.id);
        form.reset();
        setActiveTab('employee_list');
      } else {
        showToast('Erro ao atualizar funcionário.', 'error');
      }
    } else {
      const res = await fetch(`/api/salons/${salon.id}/employees`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (res.ok) {
        showToast('Funcionário cadastrado com sucesso!');
        cancelEditEmployee();
        fetchData(user.id);
        form.reset();
        setActiveTab('employee_list');
      } else {
        showToast('Erro ao cadastrar funcionário.', 'error');
      }
    }
  };

  const handleAddService = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!salon) return;
    const form = e.currentTarget;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    const category = SERVICE_CATEGORIES.find(c => c.services.includes(data.name as string))?.category || 'Geral';
    let payload: any = { ...data, category };

    const fileInput = form.querySelector('input[type="file"]') as HTMLInputElement;
    if (fileInput && fileInput.files && fileInput.files[0]) {
      const file = fileInput.files[0];
      const reader = new FileReader();
      
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.readAsDataURL(file);
      });
      
      const base64Image = await base64Promise;
      payload = { ...payload, photo_url: base64Image };
    }

    if (editingService) {
      const res = await fetch(`/api/salons/${salon.id}/services/${editingService.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...editingService, ...payload })
      });
      if (res.ok) {
        showToast('Serviço atualizado com sucesso!');
        setEditingService(null);
        fetchData(user.id);
        form.reset();
      } else {
        showToast('Erro ao atualizar serviço.', 'error');
      }
    } else {
      const res = await fetch(`/api/salons/${salon.id}/services`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (res.ok) {
        showToast('Serviço cadastrado com sucesso!');
        fetchData(user.id);
        form.reset();
      } else {
        showToast('Erro ao cadastrar serviço.', 'error');
      }
    }
  };

  const toggleEmployeeStatus = async (emp: any) => {
    if (!salon) return;
    const res = await fetch(`/api/salons/${salon.id}/employees/${emp.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...emp, active: emp.active ? 0 : 1 })
    });
    if (res.ok) fetchData(user.id);
  };

  const deleteEmployee = async (id: number) => {
    if (!salon) return;
    const res = await fetch(`/api/salons/${salon.id}/employees/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Funcionário excluído com sucesso!');
      fetchData(user.id);
    }
  };

  const toggleServiceStatus = async (srv: any) => {
    if (!salon) return;
    const res = await fetch(`/api/salons/${salon.id}/services/${srv.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...srv, active: srv.active ? 0 : 1 })
    });
    if (res.ok) fetchData(user.id);
  };

  const toggleServiceDay = async (srv: any, day: number) => {
    if (!salon) return;
    let days = [];
    try {
      days = JSON.parse(srv.days_of_week || '[0,1,2,3,4,5,6]');
    } catch {}
    
    if (days.includes(day)) {
      days = days.filter((d: number) => d !== day);
    } else {
      days.push(day);
    }
    
    const res = await fetch(`/api/salons/${salon.id}/services/${srv.id}/days`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ days_of_week: days })
    });
    if (res.ok) fetchData(user.id);
  };

  const deleteService = async (id: number) => {
    if (!salon) return;
    const res = await fetch(`/api/salons/${salon.id}/services/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Serviço excluído com sucesso!');
      fetchData(user.id);
    }
  };

  const filteredAppointments = appointments.filter(app => {
    // Role filter: employees only see their own appointments
    if (user?.role === 'employee' && app.employee_id !== user.id) return false;
    
    const date = new Date(app.start_time);
    
    // Day filter
    if (filterDay !== 'all') {
      if (date.getDay() !== parseInt(filterDay)) return false;
    }
    
    // Month filter (current month)
    if (filterMonth) {
      const now = new Date();
      if (date.getMonth() !== now.getMonth() || date.getFullYear() !== now.getFullYear()) return false;
    }
    
    return true;
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'logo_url' | 'bg_url') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setLandingConfig(prev => ({ ...prev, [field]: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const saveLandingConfig = async () => {
    if (!salon) return;
    const res = await fetch(`/api/salons/${salon.id}/landing`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(landingConfig)
    });
    if (res.ok) {
      showToast('Configurações da Landing Page salvas com sucesso!');
      fetchData(user.id);
    } else {
      showToast('Erro ao salvar configurações.', 'error');
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {toast && (
        <div className={`fixed top-4 right-4 px-6 py-3 rounded-xl shadow-lg font-medium z-50 transition-all ${
          toast.type === 'success' ? 'bg-cyan-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.message}
        </div>
      )}
      {/* Sidebar */}
      <aside className="w-64 bg-teal-900 text-white flex flex-col">
        <div className="p-6 text-2xl font-bold border-b border-teal-800 flex items-center gap-2">
          <Logo className="w-8 h-8" />
          Hair Smart Mall
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setActiveTab('appointments')} 
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'appointments' ? 'bg-teal-800' : 'hover:bg-teal-800/50'}`}
          >
            <Calendar className="w-5 h-5" /> Agendamentos
          </button>
          
          {user?.role === 'salon_admin' && (
            <>
              <div className="w-full">
                <button onClick={() => setActiveTab(activeTab.startsWith('employee_') ? 'appointments' : 'employee_list')} className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors ${activeTab.startsWith('employee_') ? 'bg-teal-800' : 'hover:bg-teal-800/50'}`}>
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5" /> Funcionários
                  </div>
                  <span className="text-xs transition-transform duration-200" style={{ transform: activeTab.startsWith('employee_') ? 'rotate(180deg)' : 'rotate(0deg)'}}>▼</span>
                </button>
                {activeTab.startsWith('employee_') && (
                  <div className="pl-12 pr-4 py-2 flex flex-col gap-2 relative">
                    <div className="absolute left-6 top-0 bottom-0 w-px bg-teal-800/50"></div>
                    <button onClick={() => setActiveTab('employee_list')} className={`w-full text-left text-sm py-2 rounded-lg transition-colors ${activeTab === 'employee_list' ? 'text-cyan-300 font-medium' : 'text-slate-300 hover:text-white'}`}>
                      Lista de Funcionários
                    </button>
                    <button onClick={() => { setActiveTab('employee_add'); cancelEditEmployee(); }} className={`w-full text-left text-sm py-2 rounded-lg transition-colors ${activeTab === 'employee_add' ? 'text-cyan-300 font-medium' : 'text-slate-300 hover:text-white'}`}>
                      Cadastrar Funcionário
                    </button>
                  </div>
                )}
              </div>
              <button onClick={() => setActiveTab('services')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'services' ? 'bg-teal-800' : 'hover:bg-teal-800/50'}`}>
                <Scissors className="w-5 h-5" /> Serviços
              </button>
              <button onClick={() => setActiveTab('finance')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'finance' ? 'bg-teal-800' : 'hover:bg-teal-800/50'}`}>
                <DollarSign className="w-5 h-5" /> Financeiro
              </button>
              <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'settings' ? 'bg-teal-800' : 'hover:bg-teal-800/50'}`}>
                <Settings className="w-5 h-5" /> Configurações
              </button>
            </>
          )}
        </nav>
        <div className="p-4 border-t border-teal-800">
          <div className="px-4 py-3 mb-4">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-xs text-cyan-300 capitalize">{user.role === 'salon_admin' ? 'Administrador' : 'Funcionário'}</p>
            <p className="text-[10px] text-cyan-400 font-mono mt-1">{user.identifier}</p>
          </div>
          <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-teal-800 transition-colors text-cyan-100">
            <LogOut className="w-5 h-5" /> Sair
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="mb-8 flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">
              {activeTab === 'appointments' ? 'Agendamentos' : 'Dashboard do Salão'}
            </h1>
            <p className="text-slate-500">Bem-vindo, {user.name}</p>
          </div>
          
          {activeTab === 'appointments' && (
            <div className="flex items-center gap-4">
              <div className="flex flex-col">
                <label className="text-xs font-medium text-slate-500 mb-1">Filtrar por Dia</label>
                <select 
                  value={filterDay}
                  onChange={(e) => setFilterDay(e.target.value)}
                  className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-cyan-500 outline-none"
                >
                  <option value="all">Todos os dias</option>
                  {DAYS_OF_WEEK.map(day => (
                    <option key={day.id} value={day.id}>{day.name}</option>
                  ))}
                </select>
              </div>
              
              <div className="flex flex-col">
                <label className="text-xs font-medium text-slate-500 mb-1">Período</label>
                <button 
                  onClick={() => setFilterMonth(!filterMonth)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                    filterMonth ? 'bg-cyan-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                  }`}
                >
                  {filterMonth ? 'Mês Atual' : 'Todo o Período'}
                </button>
              </div>
            </div>
          )}
        </header>

        {activeTab === 'appointments' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 text-sm font-semibold text-slate-700">Cliente</th>
                    <th className="px-6 py-4 text-sm font-semibold text-slate-700">Serviço</th>
                    {user.role === 'salon_admin' && (
                      <th className="px-6 py-4 text-sm font-semibold text-slate-700">Profissional</th>
                    )}
                    <th className="px-6 py-4 text-sm font-semibold text-slate-700">Data e Horário</th>
                    <th className="px-6 py-4 text-sm font-semibold text-slate-700">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAppointments.length > 0 ? (
                    filteredAppointments.map((app) => (
                      <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="font-medium text-slate-900">{app.client_name}</div>
                          <div className="text-xs text-slate-500">
                            Nasc: {app.client_dob ? new Date(app.client_dob).toLocaleDateString() : 'N/A'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-slate-700">{app.service_name}</div>
                        </td>
                        {user.role === 'salon_admin' && (
                          <td className="px-6 py-4">
                            <div className="text-sm text-slate-600">{app.employee_name || 'Não atribuído'}</div>
                          </td>
                        )}
                        <td className="px-6 py-4">
                          <div className="text-sm text-slate-900 font-medium">
                            {new Date(app.start_time).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                          </div>
                          <div className="text-xs text-slate-500">
                            {new Date(app.start_time).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            app.status === 'confirmed' ? 'bg-cyan-100 text-cyan-700' :
                            app.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                            'bg-slate-100 text-slate-600'
                          }`}>
                            {app.status === 'confirmed' ? 'Confirmado' : app.status === 'pending' ? 'Pendente' : app.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={user.role === 'salon_admin' ? 5 : 4} className="px-6 py-12 text-center text-slate-500">
                        Nenhum agendamento encontrado.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'employee_add' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-xl font-bold mb-4">{editingEmployee ? 'Editar Funcionário' : 'Cadastrar Funcionário'}</h2>
              <form onSubmit={handleAddEmployee} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Nome</label>
                    <input name="name" defaultValue={editingEmployee?.name || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Sobrenome</label>
                    <input name="surname" defaultValue={editingEmployee?.surname || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                    <input name="email" type="email" defaultValue={editingEmployee?.email || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Telefone</label>
                    <input name="phone" defaultValue={editingEmployee?.phone || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">CPF</label>
                    <input name="cpf" defaultValue={editingEmployee?.cpf || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Data de Nascimento</label>
                    <input name="dob" type="date" defaultValue={editingEmployee?.dob || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Foto de Perfil</label>
                    <div className="flex items-center gap-4">
                      {editingEmployee?.photo_url && (
                        <img src={editingEmployee.photo_url} alt="Perfil" className="w-16 h-16 rounded-full object-cover border border-slate-200" referrerPolicy="no-referrer" />
                      )}
                      <input name="photo_url_file" type="file" accept="image/*" className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-cyan-50 file:text-cyan-700 hover:file:bg-cyan-100" />
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-4">
                  <h3 className="text-lg font-medium text-slate-900 mb-4">Endereço</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 sm:col-span-1">
                      <label className="block text-sm font-medium text-slate-700 mb-1">Rua</label>
                      <input name="street" defaultValue={editingEmployee?.street || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Número</label>
                      <input name="number" defaultValue={editingEmployee?.number || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Bairro</label>
                      <input name="neighborhood" defaultValue={editingEmployee?.neighborhood || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Cidade</label>
                      <input name="city" defaultValue={editingEmployee?.city || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Estado</label>
                      <input name="state" defaultValue={editingEmployee?.state || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-6">
                  <h3 className="text-lg font-medium text-slate-900 mb-4">Disponibilidade e Serviços</h3>
                  <div className="space-y-4">
                    {timeSlots.map((slot, index) => (
                      <div key={slot.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="font-medium text-slate-800">Horário {index + 1}</h4>
                          {timeSlots.length > 1 && (
                            <button
                              type="button"
                              onClick={() => setTimeSlots(timeSlots.filter(s => s.id !== slot.id))}
                              className="text-red-500 hover:text-red-700 text-sm font-medium"
                            >
                              Remover Horário
                            </button>
                          )}
                        </div>
                        <div className="grid md:grid-cols-3 gap-6">
                          <div className="space-y-3">
                            <div>
                               <label className="block text-xs font-medium text-slate-500 mb-1">Início</label>
                               <input type="time" value={slot.start_time} onChange={(e) => {
                                 const newSlots = [...timeSlots];
                                 newSlots[index].start_time = e.target.value;
                                 setTimeSlots(newSlots);
                               }} className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 outline-none" required />
                            </div>
                            <div>
                               <label className="block text-xs font-medium text-slate-500 mb-1">Fim</label>
                               <input type="time" value={slot.end_time} onChange={(e) => {
                                 const newSlots = [...timeSlots];
                                 newSlots[index].end_time = e.target.value;
                                 setTimeSlots(newSlots);
                               }} className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 outline-none" required />
                            </div>
                          </div>
                          
                          <div>
                            <label className="block text-xs font-medium text-slate-500 mb-2">Dias Disponíveis</label>
                            <div className="grid grid-cols-2 gap-2">
                              {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((dayName, dayIndex) => (
                                <label key={dayIndex} className="flex items-center gap-2 text-sm text-slate-700">
                                  <input type="checkbox" checked={slot.days.includes(dayIndex)} onChange={(e) => {
                                    const newSlots = [...timeSlots];
                                    if (e.target.checked) newSlots[index].days.push(dayIndex);
                                    else newSlots[index].days = newSlots[index].days.filter((d: number) => d !== dayIndex);
                                    setTimeSlots(newSlots);
                                  }} className="rounded text-cyan-600 focus:ring-cyan-500" />
                                  {dayName}
                                </label>
                              ))}
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-medium text-slate-500 mb-2">Serviços Executados</label>
                            <div className="space-y-2 max-h-32 overflow-y-auto">
                              {services.map((svc) => (
                                <label key={svc.id} className="flex items-center gap-2 text-sm text-slate-700">
                                  <input type="checkbox" checked={slot.services.includes(svc.id)} onChange={(e) => {
                                    const newSlots = [...timeSlots];
                                    if (e.target.checked) newSlots[index].services.push(svc.id);
                                    else newSlots[index].services = newSlots[index].services.filter((id: number) => id !== svc.id);
                                    setTimeSlots(newSlots);
                                  }} className="rounded text-cyan-600 focus:ring-cyan-500 shrink-0" />
                                  <span className="truncate">{svc.name}</span>
                                </label>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={() => setTimeSlots([...timeSlots, { id: Date.now().toString(), start_time: '09:00', end_time: '18:00', days: [], services: [] }])}
                      className="text-cyan-600 hover:text-cyan-700 font-medium text-sm border-2 border-dashed border-cyan-200 rounded-xl w-full py-4 bg-cyan-50/50 hover:bg-cyan-50 transition-colors"
                    >
                      + Adicionar Novo Horário
                    </button>
                  </div>
                </div>

                <div className="pt-4 flex items-center gap-4">
                  {!editingEmployee && <p className="text-xs text-slate-500 mb-4">A senha inicial será: <strong>funcs@Hair123</strong></p>}
                  <button type="submit" className="bg-teal-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-teal-800">
                    {editingEmployee ? 'Atualizar Funcionário' : 'Salvar Funcionário'}
                  </button>
                  {editingEmployee && (
                    <button type="button" onClick={cancelEditEmployee} className="bg-slate-200 text-slate-700 px-6 py-2 rounded-lg font-medium hover:bg-slate-300">
                      Cancelar
                    </button>
                  )}
                </div>
              </form>
            </div>
          </div>
        )}



        {activeTab === 'employee_list' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-xl font-bold mb-4">Funcionários Cadastrados</h2>
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-sm">
                    <th className="pb-3 font-medium">Nome</th>
                    <th className="pb-3 font-medium">Contato</th>
                    <th className="pb-3 font-medium">Serviços</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium text-right">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {employees.map(emp => (
                    <tr key={emp.id} className="border-b border-slate-100 last:border-0">
                      <td className="py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-200">
                            {emp.photo_url ? (
                              <img src={emp.photo_url} alt={emp.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <Users className="w-5 h-5 text-slate-400" />
                            )}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{emp.name} {emp.surname}</div>
                            <div className="text-xs text-slate-500">CPF: {emp.cpf || '-'}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3">
                        <div className="text-sm text-slate-900">{emp.email}</div>
                        <div className="text-xs text-slate-500">{emp.phone || '-'}</div>
                      </td>
                      <td className="py-3">
                        <div className="text-sm text-slate-600">
                          {emp.services?.length ? `${emp.services.length} serviço(s)` : 'Nenhum'}
                        </div>
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${emp.active ? 'bg-cyan-100 text-cyan-700' : 'bg-slate-100 text-slate-600'}`}>
                          {emp.active ? 'Ativo' : 'Inativo'}
                        </span>
                      </td>
                      <td className="py-3 flex items-center justify-end gap-2">
                        <button onClick={() => { handleEditEmployee(emp); setActiveTab('employee_add'); }} className="p-2 text-slate-500 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors" title="Editar">
                          <Settings className="w-4 h-4" />
                        </button>
                        <button onClick={() => toggleEmployeeStatus(emp)} className="p-2 text-slate-500 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors" title={emp.active ? 'Desativar' : 'Ativar'}>
                          {emp.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                        <button onClick={() => deleteEmployee(emp.id)} className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Excluir">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {employees.length === 0 && (
                    <tr><td colSpan={5} className="py-4 text-center text-slate-500">Nenhum funcionário cadastrado.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-xl font-bold mb-4">{editingService ? 'Editar Serviço' : 'Cadastrar Serviço'}</h2>
              <form onSubmit={handleAddService} className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nome do Serviço</label>
                  <select name="name" defaultValue={editingService?.name || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                    <option value="">Selecione um serviço</option>
                    {SERVICE_CATEGORIES.map(category => (
                      <optgroup key={category.category} label={category.category}>
                        {category.services.map(service => (
                          <option key={service} value={service}>{service}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Preço (R$)</label>
                  <input name="price" type="number" step="0.01" defaultValue={editingService?.price || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Duração (minutos)</label>
                  <input name="duration" type="number" defaultValue={editingService?.duration || ''} required className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Descrição</label>
                  <input name="description" defaultValue={editingService?.description || ''} className="w-full border border-slate-300 rounded-lg px-3 py-2" />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Imagem do Serviço (PNG/JPG)</label>
                  <input type="file" accept="image/png, image/jpeg" className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm" />
                  {editingService?.photo_url && (
                    <div className="mt-2">
                      <p className="text-xs text-slate-500 mb-1">Imagem atual:</p>
                      <img src={editingService.photo_url} alt="Serviço" className="h-20 w-20 object-cover rounded-lg border border-slate-200" />
                    </div>
                  )}
                </div>
                <div className="col-span-2 flex items-center gap-4 mt-2">
                  <button type="submit" className="bg-teal-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-teal-800">
                    {editingService ? 'Atualizar Serviço' : 'Salvar Serviço'}
                  </button>
                  {editingService && (
                    <button type="button" onClick={() => setEditingService(null)} className="bg-slate-200 text-slate-700 px-6 py-2 rounded-lg font-medium hover:bg-slate-300">
                      Cancelar
                    </button>
                  )}
                </div>
              </form>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-xl font-bold mb-4">Serviços Cadastrados</h2>
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-sm">
                    <th className="pb-3 font-medium">Serviço</th>
                    <th className="pb-3 font-medium">Duração</th>
                    <th className="pb-3 font-medium">Preço</th>
                    <th className="pb-3 font-medium">Dias Atendidos</th>
                    <th className="pb-3 font-medium text-right">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {services.map(srv => {
                    let days: number[] = [];
                    try {
                      days = JSON.parse(srv.days_of_week || '[0,1,2,3,4,5,6]');
                    } catch {}
                    const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

                    return (
                      <tr key={srv.id} className="border-b border-slate-100 last:border-0">
                        <td className="py-3">
                          <div className="flex flex-col">
                            <span className="font-medium text-slate-900">{srv.name}</span>
                            <span className={`w-fit mt-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${srv.active ? 'bg-cyan-100 text-cyan-700' : 'bg-slate-100 text-slate-600'}`}>
                              {srv.active ? 'Ativo (Página Aberta)' : 'Inativo'}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 text-slate-500">{srv.duration} min</td>
                        <td className="py-3 text-slate-500">R$ {srv.price.toFixed(2)}</td>
                        <td className="py-3">
                          <div className="flex gap-1">
                            {weekDays.map((d, i) => (
                              <label key={i} className="flex flex-col items-center gap-1 cursor-pointer group">
                                <span className="text-[10px] text-slate-500 group-hover:text-cyan-700">{d}</span>
                                <input 
                                  type="checkbox" 
                                  checked={days.includes(i)} 
                                  onChange={() => toggleServiceDay(srv, i)}
                                  className="w-3.5 h-3.5 rounded border-slate-300 text-cyan-600 focus:ring-cyan-500 cursor-pointer"
                                />
                              </label>
                            ))}
                          </div>
                        </td>
                        <td className="py-3 flex items-center justify-end gap-2">
                          <button onClick={() => setEditingService(srv)} className="p-2 text-slate-500 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors" title="Editar">
                            <Settings className="w-4 h-4" />
                          </button>
                          <button onClick={() => toggleServiceStatus(srv)} className="p-2 text-slate-500 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors" title={srv.active ? 'Desativar' : 'Ativar'}>
                            {srv.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                          <button onClick={() => deleteService(srv.id)} className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Excluir">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {services.length === 0 && (
                    <tr><td colSpan={5} className="py-4 text-center text-slate-500">Nenhum serviço cadastrado.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'finance' && (
          <div className="space-y-6">
            {(() => {
              const now = new Date();
              const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
              const startOfWeek = new Date(today);
              startOfWeek.setDate(today.getDate() - today.getDay());
              const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

              let totalDay = 0;
              let totalWeek = 0;
              let totalMonth = 0;
              const serviceTotals: Record<string, number> = {};

              appointments.forEach(app => {
                const appDate = new Date(app.start_time);
                const revenue = (app.paid_amount || 0) + (app.status === 'completed' ? (app.pending_amount || 0) : 0);

                if (appDate >= today) totalDay += revenue;
                if (appDate >= startOfWeek) totalWeek += revenue;
                if (appDate >= startOfMonth) totalMonth += revenue;

                if (!serviceTotals[app.service_name]) serviceTotals[app.service_name] = 0;
                serviceTotals[app.service_name] += revenue;
              });

              return (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                      <h3 className="text-slate-500 font-medium mb-2">Arrecadado Hoje</h3>
                      <p className="text-3xl font-bold text-cyan-600">R$ {totalDay.toFixed(2)}</p>
                    </div>
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                      <h3 className="text-slate-500 font-medium mb-2">Arrecadado na Semana</h3>
                      <p className="text-3xl font-bold text-cyan-600">R$ {totalWeek.toFixed(2)}</p>
                    </div>
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                      <h3 className="text-slate-500 font-medium mb-2">Arrecadado no Mês</h3>
                      <p className="text-3xl font-bold text-cyan-600">R$ {totalMonth.toFixed(2)}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                      <h2 className="text-xl font-bold mb-4">Agendamentos (Concluídos e Pendentes)</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="border-b border-slate-200 text-slate-500 text-sm">
                              <th className="pb-3 font-medium">Serviço</th>
                              <th className="pb-3 font-medium">Cliente</th>
                              <th className="pb-3 font-medium">Data Prevista</th>
                              <th className="pb-3 font-medium">Data Conclusão</th>
                              <th className="pb-3 font-medium">Status</th>
                              <th className="pb-3 font-medium">Valor Arrecadado</th>
                            </tr>
                          </thead>
                          <tbody>
                            {appointments.map(app => {
                              const revenue = (app.paid_amount || 0) + (app.status === 'completed' ? (app.pending_amount || 0) : 0);
                              return (
                                <tr key={app.id} className="border-b border-slate-100 last:border-0">
                                  <td className="py-3 font-medium">{app.service_name}</td>
                                  <td className="py-3 text-slate-600">{app.client_name}</td>
                                  <td className="py-3 text-slate-500">{new Date(app.start_time).toLocaleString('pt-BR')}</td>
                                  <td className="py-3 text-slate-500">{app.status === 'completed' ? new Date(app.end_time || app.start_time).toLocaleString('pt-BR') : '-'}</td>
                                  <td className="py-3">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${app.status === 'completed' ? 'bg-cyan-100 text-cyan-700' : 'bg-amber-100 text-amber-700'}`}>
                                      {app.status === 'completed' ? 'Concluído' : 'Pendente'}
                                    </span>
                                  </td>
                                  <td className="py-3 text-cyan-600 font-medium">R$ {revenue.toFixed(2)}</td>
                                </tr>
                              );
                            })}
                            {appointments.length === 0 && (
                              <tr><td colSpan={6} className="py-4 text-center text-slate-500">Nenhum agendamento encontrado.</td></tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                      <h2 className="text-xl font-bold mb-4">Arrecadação por Serviço</h2>
                      <div className="space-y-4">
                        {Object.entries(serviceTotals).sort((a, b) => b[1] - a[1]).map(([serviceName, total]) => (
                          <div key={serviceName} className="flex justify-between items-center border-b border-slate-100 pb-2 last:border-0 last:pb-0">
                            <span className="text-slate-700">{serviceName}</span>
                            <span className="font-bold text-cyan-600">R$ {total.toFixed(2)}</span>
                          </div>
                        ))}
                        {Object.keys(serviceTotals).length === 0 && (
                          <p className="text-slate-500 text-center py-4">Nenhum dado disponível.</p>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-8">
            {/* Mercado Pago Section */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <DollarSign className="w-6 h-6 text-cyan-600" />
                Configuração Mercado Pago
              </h2>
              <p className="text-slate-600 mb-8 max-w-2xl">
                Conecte sua conta do Mercado Pago para receber automaticamente os pagamentos dos agendamentos (15% de sinal). 
                Ao conectar, o sistema fará o split (divisão) do pagamento automaticamente, enviando a sua parte direto para sua conta do Mercado Pago e a taxa da plataforma para o administrador.
              </p>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <h3 className="font-bold text-slate-900">Conexão Automática (Recomendado)</h3>
                  <p className="text-sm text-slate-500">
                    A forma mais segura e fácil. Clique no botão abaixo para autorizar a plataforma a realizar os repasses. 
                    Você será redirecionado para o Mercado Pago para fazer login e aprovar a conexão.
                  </p>
                  {salon?.has_mp ? (
                    <div className="bg-cyan-50 border border-cyan-200 rounded-2xl p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="w-10 h-10 bg-cyan-100 rounded-full flex items-center justify-center text-cyan-600">
                          <CheckCircle className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-teal-900 text-sm">Conta Conectada</h4>
                          <p className="text-xs text-cyan-700">ID: {salon.mp_user_id}</p>
                        </div>
                      </div>
                      <button 
                        onClick={handleConnectMP}
                        className="w-full bg-cyan-600 text-white py-2 rounded-xl text-sm font-bold hover:bg-teal-600 transition-colors"
                      >
                        Reconectar Conta
                      </button>
                    </div>
                  ) : (
                    <button 
                      onClick={handleConnectMP}
                      disabled={isConnectingMP}
                      className="w-full bg-cyan-600 text-white py-3 rounded-xl font-bold hover:bg-teal-600 transition-colors disabled:opacity-50"
                    >
                      {isConnectingMP ? 'Conectando...' : 'Conectar Mercado Pago'}
                    </button>
                  )}
                </div>

                <div className="space-y-6 border-l border-slate-100 pl-8">
                  <h3 className="font-bold text-slate-900">Configuração Manual</h3>
                  <p className="text-sm text-slate-500">
                    Se preferir, informe suas credenciais manualmente (apenas para usuários avançados).
                  </p>
                  <form onSubmit={async (e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    const payload = Object.fromEntries(formData.entries());
                    const res = await fetch(`/api/salons/${salon.id}/mp-credentials`, {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(payload)
                    });
                    if (res.ok) {
                      showToast('Credenciais salvas com sucesso!');
                      fetchData(user.id);
                    } else {
                      showToast('Erro ao salvar credenciais.', 'error');
                    }
                  }} className="space-y-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-500 mb-1">Public Key</label>
                      <input 
                        name="mp_public_key" 
                        defaultValue={salon?.mp_public_key || ''} 
                        placeholder="APP_USR-..."
                        className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-cyan-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-500 mb-1">Access Token</label>
                      <input 
                        name="mp_access_token" 
                        type="password"
                        defaultValue={salon?.mp_access_token ? '********' : ''} 
                        placeholder="APP_USR-..."
                        className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-cyan-500 outline-none"
                      />
                    </div>
                    <button type="submit" className="w-full bg-slate-900 text-white py-2 rounded-xl text-sm font-bold hover:bg-slate-800 transition-colors">
                      Salvar Manualmente
                    </button>
                  </form>
                </div>
              </div>
            </div>

            {/* Landing Page Section */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Settings className="w-6 h-6 text-slate-500" />
                Configuração da Landing Page
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Slogan do Salão</label>
                  <input
                    type="text"
                    value={landingConfig.slogan}
                    onChange={e => setLandingConfig({...landingConfig, slogan: e.target.value})}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Slogan do seu salão..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Sobre o Estabelecimento</label>
                  <textarea
                    value={landingConfig.about_text}
                    onChange={e => setLandingConfig({...landingConfig, about_text: e.target.value})}
                    rows={4}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Conte um pouco sobre a história e os diferenciais do seu salão..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Missão</label>
                  <textarea
                    value={landingConfig.mission_text}
                    onChange={e => setLandingConfig({...landingConfig, mission_text: e.target.value})}
                    rows={3}
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Qual é a missão do seu estabelecimento?"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Logotipo (PNG/JPG)</label>
                    <input
                      type="file"
                      accept="image/png, image/jpeg"
                      onChange={e => handleFileUpload(e, 'logo_url')}
                      className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    />
                    {landingConfig.logo_url && (
                      <img src={landingConfig.logo_url} alt="Logo Preview" className="mt-2 h-16 object-contain" />
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Imagem de Fundo (PNG/JPG)</label>
                    <input
                      type="file"
                      accept="image/png, image/jpeg"
                      onChange={e => handleFileUpload(e, 'bg_url')}
                      className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    />
                    {landingConfig.bg_url && (
                      <img src={landingConfig.bg_url} alt="Background Preview" className="mt-2 h-24 object-cover rounded-lg w-full" />
                    )}
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-6">
                  <h3 className="text-lg font-medium text-slate-900 mb-4">Endereço</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 sm:col-span-1">
                      <label className="block text-sm font-medium text-slate-700 mb-1">Rua</label>
                      <input
                        value={landingConfig.street}
                        onChange={e => setLandingConfig({...landingConfig, street: e.target.value})}
                        className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Número</label>
                      <input
                        value={landingConfig.number}
                        onChange={e => setLandingConfig({...landingConfig, number: e.target.value})}
                        className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Bairro</label>
                      <input
                        value={landingConfig.neighborhood}
                        onChange={e => setLandingConfig({...landingConfig, neighborhood: e.target.value})}
                        className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Cidade</label>
                      <input
                        value={landingConfig.city}
                        onChange={e => setLandingConfig({...landingConfig, city: e.target.value})}
                        className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Estado</label>
                      <input
                        value={landingConfig.state}
                        onChange={e => setLandingConfig({...landingConfig, state: e.target.value})}
                        className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">País</label>
                      <input
                        value={landingConfig.country}
                        onChange={e => setLandingConfig({...landingConfig, country: e.target.value})}
                        className="w-full p-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200 flex items-center gap-4">
                  <button
                    onClick={saveLandingConfig}
                    className="bg-cyan-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-teal-600 transition-colors"
                  >
                    Salvar Configurações
                  </button>
                  <button
                    onClick={() => window.open(`/salon/${salon?.id}`, '_blank')}
                    className="bg-slate-200 text-slate-700 px-6 py-3 rounded-xl font-medium hover:bg-slate-300 transition-colors flex items-center gap-2"
                  >
                    <Eye className="w-5 h-5" /> Prévia da Landing Page
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
