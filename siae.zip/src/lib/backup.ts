import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { db } from './db.js';

let checkInterval: NodeJS.Timeout | null = null;
let lastBackupRun: string | null = null; // store "YYYY-MM-DD" of last run

export async function getBackupConfig(houseId: string = 'global') {
  try {
    const res = await db.query('SELECT value FROM system_settings WHERE key = ?', [`backup_config_${houseId}`]);
    const row = (res as any)[0][0] as any;
    if (!row || !row.value) return { 
      networkIp: '',
      networkShare: '',
      networkDrive: '',
      networkUser: '',
      networkPass: '',
      frequency: 'daily',
      startTime: '00:00',
      retention: '21',
      backupType: 'incremental'
    };
    try {
      return JSON.parse(row.value);
    } catch(e) {
      return { networkIp: '', networkShare: '', networkDrive: '', frequency: 'daily', startTime: '00:00', retention: '21', backupType: 'incremental' };
    }
  } catch(err: any) {
    if (err.code !== 'ECONNREFUSED') {
      console.error('getBackupConfig DB error:', err.message);
    }
    return { networkIp: '', networkShare: '', networkDrive: '', frequency: 'daily', startTime: '00:00', retention: '21', backupType: 'incremental' };
  }
}

export async function saveBackupConfig(config: any, houseId: string = 'global') {
  // Save as JSON string
  await db.query('INSERT INTO system_settings (key, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?', [`backup_config_${houseId}`, JSON.stringify(config), JSON.stringify(config)]);
  scheduleBackup();
}

async function runBackup(houseId: string = 'global') {
  const config = await getBackupConfig(houseId);
  if (!config.networkIp || !config.networkShare) return;

  const backupDir = `/mnt/backup_${houseId}`; // local mount point simulation

  try {
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
  } catch (error) {
    console.error('Failed to create/access backup dir:', error);
    // Continue despite error, so we don't crash the server
  }

  // Handle retention rotation
  const retentionDays = parseInt(config.retention) || 21;
  let sortedFiles: any[] = [];
  try {
    const files = fs.readdirSync(backupDir).filter(f => f.startsWith('backup_') && (f.endsWith('.tgz') || f.endsWith('.zip')));
    sortedFiles = files.map(f => {
      return { name: f, stat: fs.statSync(path.join(backupDir, f)) };
    }).sort((a, b) => b.stat.mtimeMs - a.stat.mtimeMs);
    
    if (sortedFiles.length >= retentionDays) {
      const toDelete = sortedFiles.slice(retentionDays - 1);
      for (const dFile of toDelete) {
        try {
          fs.unlinkSync(path.join(backupDir, dFile.name));
        } catch (err) {
          console.error('Failed to delete old backup:', err);
        }
      }
    }
  } catch(e) {}

  const dateStr = new Date().toISOString().split('T')[0];
  const dbPath = path.resolve(process.cwd(), 'siae.db');
  
  // Create a backup archive
  const backupFileName = `backup_siae_${dateStr}.tgz`;
  const backupPath = path.join(backupDir, backupFileName);
  
  // write restore script
  const restoreScript = `#!/bin/bash
# SIAE Restore Script
echo "Restaurando SIAE..."
tar -xzf backup_siae_${dateStr}.tgz -C /
echo "Restauração concluída."
`;
  const rsPath = path.join(backupDir, `restore_siae_${dateStr}.sh`);
  try {
    fs.writeFileSync(rsPath, restoreScript);
    fs.chmodSync(rsPath, 0o755);
  
    // Compressing database into target.
    execSync(`tar -czf ${backupPath} -C ${process.cwd()} siae.db`);
    lastBackupRun = dateStr;
  } catch (e) {
    console.error('Failed to tar:', e);
  }
}

export function scheduleBackup() {
  if (checkInterval) clearInterval(checkInterval);
  
  // Check every 1 minute
  checkInterval = setInterval(async () => {
    const config = await getBackupConfig();
    if (!config.networkDrive || !config.startTime) return;
    
    const now = new Date();
    const currentHour = now.getHours().toString().padStart(2, '0');
    const currentMinute = now.getMinutes().toString().padStart(2, '0');
    const currentTimeStr = `${currentHour}:${currentMinute}`;
    
    const dateStr = now.toISOString().split('T')[0];
    
    // Check if it's the right time
    if (currentTimeStr === config.startTime && lastBackupRun !== dateStr) {
       // Check frequency
       const dayOfWeek = now.getDay();
       const dayOfMonth = now.getDate();
       
       let shouldRun = false;
       if (config.frequency === 'daily') shouldRun = true;
       else if (config.frequency === 'weekly' && dayOfWeek === 0) shouldRun = true; // Every Sunday
       else if (config.frequency === 'monthly' && dayOfMonth === 1) shouldRun = true; // 1st of month
       
       if (shouldRun) {
         runBackup();
       }
    }
  }, 60000);
}

export async function runManualBackup(houseId: string = 'global') {
  runBackup(houseId);
}
